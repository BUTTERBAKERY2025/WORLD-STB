import { pgTable, text, serial, integer, timestamp, doublePrecision, boolean, jsonb, pgEnum, type PgTableWithColumns, type PgColumn } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projectTypeEnum = pgEnum('project_type', ['road', 'water', 'electricity', 'telecom', 'building']);
export const projectStatusEnum = pgEnum('project_status', ['planning', 'in_progress', 'delayed', 'completed', 'stopped']);
export const riskLevelEnum = pgEnum('risk_level', ['low', 'medium', 'high']);
export const assetTypeEnum = pgEnum('asset_type', ['vehicle', 'equipment', 'tool', 'other']);
export const resourceTypeEnum = pgEnum('resource_type', ['human', 'material', 'equipment']);
export const documentTypeEnum = pgEnum('document_type', ['contract', 'permit', 'report', 'invoice', 'other']);
export const userRoleEnum = pgEnum('user_role', ['admin', 'project_manager', 'engineer', 'financial', 'viewer']);
export const languageEnum = pgEnum('language', ['ar', 'en']);
export const transactionTypeEnum = pgEnum('transaction_type', ['income', 'expense', 'transfer', 'payment', 'adjustment']);
export const financialAccountTypeEnum = pgEnum('financial_account_type', [
  'asset', // الأصول
  'liability', // الالتزامات
  'equity', // حقوق الملكية
  'revenue', // الإيرادات
  'expense', // المصروفات
  'cost_of_sales', // تكلفة المبيعات
  'tax', // الضرائب
  'control' // الحسابات الرقابية
]);
export const transactionStatusEnum = pgEnum('transaction_status', ['pending', 'completed', 'cancelled', 'reconciled', 'disputed']);
export const costCategoryEnum = pgEnum('cost_category', [
  'direct_labor', // تكلفة العمالة المباشرة
  'materials', // المواد
  'equipment', // المعدات
  'subcontractors', // مقاولي الباطن
  'administrative', // إدارية
  'overhead', // نفقات عامة
  'transportation', // النقل
  'consulting', // استشارات
  'miscellaneous', // متفرقات
]);

// تصنيف حالات المصروفات
export const expenseStatusEnum = pgEnum('expense_status', [
  'pending', // معلق
  'approved', // معتمد
  'rejected', // مرفوض
  'recorded', // مسجل محاسبياً
  'paid', // مدفوع
  'cancelled', // ملغي
]);

// جدول أنواع المشاريع
export const projectTypes = pgTable(
  'project_types',
  {
    id: serial('id').primaryKey(),
    name: text('name').notNull(), // اسم نوع المشروع (مطابق للقيم في projectTypeEnum)
    description: text('description').notNull(), // وصف نوع المشروع
    createdAt: timestamp('created_at').defaultNow().notNull(),
  }
);

// أنواع بيانات أنواع المشاريع
export type ProjectType = typeof projectTypes.$inferSelect;
export type InsertProjectType = typeof projectTypes.$inferInsert;
export const insertProjectTypeSchema = createInsertSchema(projectTypes);

// إضافة للمستخلصات
export const paymentCertificateTypeEnum = pgEnum('payment_certificate_type', [
  'subcontractor', // مقاول باطن
  'main_contractor', // مقاول رئيسي
  'consultant', // استشاري
  'internal', // صرف داخلي
  'interim', // مستخلص مرحلي
  'final', // مستخلص نهائي
]);

export const paymentCertificateStatusEnum = pgEnum('payment_certificate_status', [
  'draft', // مسودة
  'submitted', // مقدم
  'supervisor_approved', // موافقة المشرف
  'pm_approved', // موافقة مدير المشروع
  'finance_approved', // موافقة المالية
  'gm_approved', // موافقة المدير العام
  'approved', // معتمد نهائياً
  'paid', // مدفوع
  'rejected', // مرفوض
]);

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email"),
  role: userRoleEnum("role").notNull().default('viewer'),
  language: languageEnum("language").notNull().default('ar'),
  profileImage: text("profile_image"),
  lastLogin: timestamp("last_login"),
});

// Projects
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: projectTypeEnum("type").notNull(),
  status: projectStatusEnum("status").notNull().default('planning'),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  budget: doublePrecision("budget"),
  progress: integer("progress").default(0),
  location: jsonb("location"), // GeoJSON format
  createdBy: integer("created_by").references(() => users.id),
  managedBy: integer("managed_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Project Tasks
// تصنيف أنواع المهام
export const taskTypeEnum = pgEnum('task_type', [
  'milestone', // معلم رئيسي
  'task', // مهمة
  'subtask', // مهمة فرعية
  'deliverable', // مخرج
  'package', // حزمة عمل
]);

// تصنيف حالات المهام
export const taskStatusEnum = pgEnum('task_status', [
  'not_started', // لم تبدأ
  'in_progress', // قيد التنفيذ
  'delayed', // متأخرة
  'completed', // مكتملة
  'on_hold', // متوقفة مؤقتا
  'cancelled', // ملغاة
]);

export const taskPriorityEnum = pgEnum('task_priority', [
  'low', // منخفضة
  'medium', // متوسطة
  'high', // عالية
  'critical', // حرجة
]);

// المهام (جزء من هيكل تقسيم العمل WBS)
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  parentId: integer("parent_id"), // للمهام الفرعية (تعيين العلاقة الهرمية)
  wbsCode: text("wbs_code"), // كود هيكل تقسيم العمل (مثال: 1.2.3)
  level: integer("level").default(1), // مستوى المهمة في هيكل تقسيم العمل
  orderIndex: integer("order_index").default(0), // ترتيب المهمة ضمن نفس المستوى والأب
  path: text("path"), // المسار الكامل للمهمة في شجرة WBS (مثال: 1/1.2/1.2.3)
  isLeaf: boolean("is_leaf").default(true), // هل المهمة هي مهمة نهائية (ورقة في شجرة WBS)
  isSummary: boolean("is_summary").default(false), // هل المهمة هي ملخص لمهام أخرى
  name: text("name").notNull(),
  description: text("description"),
  type: taskTypeEnum("type").notNull().default('task'), // نوع المهمة
  status: taskStatusEnum("status").notNull().default('not_started'), // حالة المهمة
  
  // الجدول الزمني
  plannedStartDate: timestamp("planned_start_date"), // تاريخ البداية المخطط
  plannedEndDate: timestamp("planned_end_date"), // تاريخ النهاية المخطط
  actualStartDate: timestamp("actual_start_date"), // تاريخ البداية الفعلي
  actualEndDate: timestamp("actual_end_date"), // تاريخ النهاية الفعلي
  
  // القياسات والمؤشرات
  plannedDuration: integer("planned_duration"), // المدة المخططة (بالأيام)
  actualDuration: integer("actual_duration"), // المدة الفعلية (بالأيام)
  plannedWorkHours: doublePrecision("planned_work_hours"), // ساعات العمل المخططة
  actualWorkHours: doublePrecision("actual_work_hours"), // ساعات العمل الفعلية
  progress: integer("progress").default(0), // نسبة التقدم (0-100)
  
  // المقاييس المالية
  plannedCost: doublePrecision("planned_cost"), // التكلفة المخططة
  actualCost: doublePrecision("actual_cost"), // التكلفة الفعلية
  budgetedCost: doublePrecision("budgeted_cost"), // التكلفة المعتمدة في الميزانية
  
  // علاقات
  assignedTo: integer("assigned_to").references(() => users.id), // المسؤول عن التنفيذ
  assignedTeam: integer("assigned_team"), // الفريق المسؤول (ربط مع صفحة القوى العاملة)
  contractItemId: integer("contract_item_id").references(() => contractItems.id), // ربط مع بنود العقد
  predecessorIds: jsonb("predecessor_ids"), // معرفات المهام السابقة (للتسلسل) format: [1, 2, 3]
  successorIds: jsonb("successor_ids"), // معرفات المهام اللاحقة format: [4, 5, 6]
  dependencyTypes: jsonb("dependency_types"), // أنواع العلاقات للمهام السابقة (FS, SS, FF, SF)
  
  // القيمة المكتسبة (Earned Value Management)
  plannedValue: doublePrecision("planned_value"), // القيمة المخططة (PV/BCWS)
  earnedValue: doublePrecision("earned_value"), // القيمة المكتسبة (EV/BCWP)
  actualCostValue: doublePrecision("actual_cost_value"), // التكلفة الفعلية (AC/ACWP)
  costVariance: doublePrecision("cost_variance"), // الفرق في التكلفة (CV = EV - AC)
  scheduleVariance: doublePrecision("schedule_variance"), // الفرق في الجدول (SV = EV - PV)
  costPerformanceIndex: doublePrecision("cost_performance_index"), // مؤشر أداء التكلفة (CPI = EV / AC)
  schedulePerformanceIndex: doublePrecision("schedule_performance_index"), // مؤشر أداء الجدول (SPI = EV / PV)
  estimateAtCompletion: doublePrecision("estimate_at_completion"), // التقدير عند الإكمال (EAC)
  estimateToComplete: doublePrecision("estimate_to_complete"), // التقدير للإكمال (ETC)
  varianceAtCompletion: doublePrecision("variance_at_completion"), // الفرق عند الإكمال (VAC)
  
  // المسار الحرج
  isOnCriticalPath: boolean("is_on_critical_path").default(false), // هل المهمة على المسار الحرج؟
  slack: integer("slack").default(0), // الوقت الاحتياطي (بالأيام)
  
  // الوسوم والتصنيفات
  tags: text("tags").array(), // وسوم لتصنيف المهام
  priority: taskPriorityEnum("priority").default('medium'), // أولوية المهمة
  
  // بيانات التتبع
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  completedAt: timestamp("completed_at"), // تاريخ الإكمال
  completedBy: integer("completed_by").references(() => users.id), // من أكمل المهمة
});

// Chart of Accounts (شجرة الحسابات)
export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // رمز الحساب
  name: text("name").notNull(),
  nameEn: text("name_en"),
  type: financialAccountTypeEnum("type").notNull(), // نوع الحساب (أصول، خصوم، إيرادات، مصروفات)
  parentId: integer("parent_id"), // الحساب الأب في الشجرة
  level: integer("level").default(1), // مستوى الحساب في الشجرة
  path: text("path"), // المسار الكامل للحساب في الشجرة
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// العلاقة الدائرية في شجرة الحسابات ستتم إدارتها من خلال الكود وليس قيود قاعدة البيانات
// للتبسيط نستخدم فقط حقل parentId بدون تعريف foreign key constraint
// يمكننا تطبيق علاقة فعلية باستخدام relation في drizzle-orm عند الاتصال الفعلي بقاعدة البيانات

// بنود ميزانية المشروع المفصلة (Project Budget Items)
export const projectBudgetItems = pgTable("project_budget_items", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  name: text("name").notNull(), // اسم بند الميزانية
  code: text("code"), // رمز بند الميزانية
  description: text("description"), // وصف مفصل
  category: costCategoryEnum("category"), // تصنيف البند (مثل مواد، عمالة، معدات، إلخ)
  amount: doublePrecision("amount").notNull(), // قيمة الميزانية
  usedAmount: doublePrecision("used_amount").default(0), // المبلغ المستخدم
  remainingAmount: doublePrecision("remaining_amount"), // المبلغ المتبقي
  accountId: integer("account_id").references(() => chartOfAccounts.id), // حساب مرتبط في شجرة الحسابات
  contractItemId: integer("contract_item_id").references(() => contractItems.id), // بند العقد المرتبط
  parentId: integer("parent_id"), // للبنود الفرعية ضمن هيكل هرمي
  notes: text("notes"), // ملاحظات
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// مصروفات المشاريع (Project Expenses)
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id), // المشروع المرتبط
  budgetItemId: integer("budget_item_id").references(() => projectBudgetItems.id), // بند الميزانية المرتبط
  accountId: integer("account_id").references(() => chartOfAccounts.id), // حساب المصروفات
  paymentAccountId: integer("payment_account_id").references(() => chartOfAccounts.id), // حساب النقدية/البنك
  journalEntryId: integer("journal_entry_id").references(() => journalEntries.id), // القيد المحاسبي المرتبط
  
  expenseDate: timestamp("expense_date").notNull(), // تاريخ المصروف
  description: text("description").notNull(), // وصف المصروف
  amount: doublePrecision("amount").notNull(), // قيمة المصروف
  category: costCategoryEnum("category"), // تصنيف المصروف
  status: expenseStatusEnum("status").default('pending'), // حالة المصروف
  
  // معلومات الدفع
  paymentMethod: text("payment_method"), // طريقة الدفع (نقدي، شيك، تحويل)
  paymentReference: text("payment_reference"), // مرجع الدفع (رقم الشيك، رقم التحويل)
  vendorId: integer("vendor_id"), // المورد/المقاول
  vendorName: text("vendor_name"), // اسم المورد إذا لم يكن مسجلا في النظام
  
  // معلومات الفترة المالية
  fiscalYear: integer("fiscal_year"), // السنة المالية
  fiscalPeriod: integer("fiscal_period"), // الفترة المالية
  
  // الإعتماد والتحقق
  approvedBy: integer("approved_by").references(() => users.id), // من اعتمد المصروف
  approvedAt: timestamp("approved_at"), // تاريخ الاعتماد
  notes: text("notes"), // ملاحظات
  attachmentPath: text("attachment_path"), // مسار المرفق
  
  // المعلومات العامة
  createJournalEntry: boolean("create_journal_entry").default(false), // هل يجب إنشاء قيد محاسبي تلقائيا
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Project Budgets (ميزانيات المشاريع)
export const projectBudgets = pgTable("project_budgets", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  
  // يمكن ربط الميزانية مباشرة ببند في العقد
  contractItemId: integer("contract_item_id").references(() => contractItems.id),
  
  // المعلومات الزمنية
  fiscalYear: integer("fiscal_year").notNull(), // السنة المالية
  fiscalQuarter: integer("fiscal_quarter"), // الربع المالي
  fiscalMonth: integer("fiscal_month"), // الشهر المالي
  fromDate: timestamp("from_date"), // تاريخ بداية فترة الميزانية
  toDate: timestamp("to_date"), // تاريخ نهاية فترة الميزانية
  
  // المبالغ والتصنيفات
  plannedAmount: doublePrecision("planned_amount").notNull(), // المبلغ المخطط
  actualAmount: doublePrecision("actual_amount").default(0), // المبلغ الفعلي (يتم تحديثه تلقائيًا)
  committedAmount: doublePrecision("committed_amount").default(0), // المبلغ الملتزم به (مثل العقود الموقعة)
  availableAmount: doublePrecision("available_amount"), // المبلغ المتاح (المخطط - الفعلي - الملتزم به)
  
  // التصنيفات
  costCategory: costCategoryEnum("cost_category"), // تصنيف التكلفة
  costCenter: text("cost_center"), // مركز التكلفة
  
  // حالة الميزانية
  status: text("status").default("active"), // فعالة، محفوظة، معتمدة، مغلقة
  approvedBy: integer("approved_by").references(() => users.id), // من اعتمد الميزانية
  approvedAt: timestamp("approved_at"), // تاريخ اعتماد الميزانية
  notes: text("notes"), // ملاحظات
  
  // معلومات الإنشاء والتحديث
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ربط المستخلصات بالمعاملات المالية
export const certificateTransactions = pgTable("certificate_transactions", {
  id: serial("id").primaryKey(),
  certificateId: integer("certificate_id").references(() => paymentCertificates.id).notNull(),
  transactionId: integer("transaction_id").references(() => financialTransactions.id).notNull(),
  amount: doublePrecision("amount").notNull(), // مبلغ المعاملة
  type: text("type").notNull(), // payment, tax, retention, deduction, etc.
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: integer("created_by").references(() => users.id),
});

// بنود المشروع - Contract Items (بنود العقد)
export const contractItems = pgTable("contract_items", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  itemNumber: text("item_number").notNull(), // رقم البند في العقد
  description: text("description").notNull(), // وصف البند
  unit: text("unit").notNull(), // وحدة القياس (متر، متر مربع، متر مكعب، عدد، الخ)
  quantity: doublePrecision("quantity").notNull(), // الكمية الإجمالية في العقد
  unitPrice: doublePrecision("unit_price").notNull(), // سعر الوحدة
  totalPrice: doublePrecision("total_price").notNull(), // إجمالي السعر (الكمية × سعر الوحدة)
  completed: doublePrecision("completed").default(0), // الكمية المنفذة حتى الآن
  completionPercentage: doublePrecision("completion_percentage").default(0), // نسبة الإنجاز
  notes: text("notes"), // ملاحظات
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// مستخلصات الدفع - Payment Certificates
export const paymentCertificates = pgTable("payment_certificates", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  certificateNumber: integer("certificate_number").notNull(), // رقم المستخلص
  referenceNumber: text("reference_number"), // رقم مرجعي آخر (رقم الفاتورة، رقم العقد، إلخ)
  type: paymentCertificateTypeEnum("type").notNull(), // نوع المستخلص
  status: paymentCertificateStatusEnum("status").default('draft'), // حالة المستخلص
  
  // الفترة الزمنية والفترة المالية
  fromDate: timestamp("from_date").notNull(), // الفترة الزمنية (من)
  toDate: timestamp("to_date").notNull(), // الفترة الزمنية (إلى)
  fiscalYear: integer("fiscal_year"), // السنة المالية
  fiscalPeriod: integer("fiscal_period"), // الفترة المالية
  
  // المبالغ الأساسية
  grossAmount: doublePrecision("gross_amount").notNull(), // إجمالي المبلغ الخام قبل الخصومات
  totalAmount: doublePrecision("total_amount").notNull(), // إجمالي قيمة المستخلص
  previousAmount: doublePrecision("previous_amount").default(0), // إجمالي المستخلصات السابقة
  currentAmount: doublePrecision("current_amount").notNull(), // قيمة المستخلص الحالي
  
  // الربط مع الحسابات المالية
  vendorAccountId: integer("vendor_account_id").references(() => chartOfAccounts.id), // حساب المورد/المقاول
  revenueAccountId: integer("revenue_account_id").references(() => chartOfAccounts.id), // حساب الإيرادات
  journalEntryId: integer("journal_entry_id").references(() => journalEntries.id), // القيد المحاسبي المرتبط
  
  // الخصومات والإضافات
  advancePaymentAmount: doublePrecision("advance_payment_amount").default(0), // مبلغ الدفعة المقدمة المحتجزة
  advancePaymentDeduction: doublePrecision("advance_payment_deduction").default(0), // خصم الدفعة المقدمة في هذا المستخلص
  retentionAmount: doublePrecision("retention_amount").default(0), // قيمة المحتجزات
  taxAmount: doublePrecision("tax_amount").default(0), // قيمة الضرائب
  otherDeductions: doublePrecision("other_deductions").default(0), // خصومات أخرى
  materialsOnSite: doublePrecision("materials_on_site").default(0), // قيمة المواد في الموقع
  otherAdditions: doublePrecision("other_additions").default(0), // إضافات أخرى
  
  // المبلغ النهائي
  finalAmount: doublePrecision("final_amount").notNull(), // المبلغ النهائي بعد الخصومات
  
  // معلومات إضافية
  completionPercentage: doublePrecision("completion_percentage").default(0), // نسبة الإنجاز الكلي للمشروع
  contractorId: integer("contractor_id"), // معرف المقاول
  contractorName: text("contractor_name"), // اسم المقاول إذا لم يكن مسجلاً
  contractNumber: text("contract_number"), // رقم العقد
  
  // ملاحظات ومرفقات
  notes: text("notes"), // ملاحظات
  attachmentPath: text("attachment_path"), // مسار مرفق المستخلص
  
  // معلومات الموافقة والتتبع
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  submittedAt: timestamp("submitted_at"), // تاريخ تقديم المستخلص
  submittedBy: integer("submitted_by").references(() => users.id), // من قدم المستخلص
  supervisorApprovedAt: timestamp("supervisor_approved_at"), // تاريخ موافقة المشرف
  supervisorApprovedBy: integer("supervisor_approved_by").references(() => users.id),
  pmApprovedAt: timestamp("pm_approved_at"), // تاريخ موافقة مدير المشروع
  pmApprovedBy: integer("pm_approved_by").references(() => users.id),
  financeApprovedAt: timestamp("finance_approved_at"), // تاريخ موافقة المالية
  financeApprovedBy: integer("finance_approved_by").references(() => users.id),
  gmApprovedAt: timestamp("gm_approved_at"), // تاريخ موافقة المدير العام
  gmApprovedBy: integer("gm_approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"), // تاريخ الاعتماد النهائي
  approvedBy: integer("approved_by").references(() => users.id),
  paidAt: timestamp("paid_at"), // تاريخ الدفع
  paidBy: integer("paid_by").references(() => users.id), // من سجل الدفع
  paymentReference: text("payment_reference"), // مرجع الدفع
});

// بنود المستخلص - Payment Certificate Items
export const paymentCertificateItems = pgTable("payment_certificate_items", {
  id: serial("id").primaryKey(),
  certificateId: integer("certificate_id").references(() => paymentCertificates.id).notNull(),
  contractItemId: integer("contract_item_id").references(() => contractItems.id), // يمكن أن يكون null في حالة البنود الإضافية
  
  // بيانات البند
  itemNumber: text("item_number"), // رقم البند
  description: text("description").notNull(), // وصف البند
  unit: text("unit").notNull(), // وحدة القياس
  
  // الكميات
  contractQuantity: doublePrecision("contract_quantity"), // الكمية في العقد
  previousQuantity: doublePrecision("previous_quantity").default(0), // الكمية المنجزة في المستخلصات السابقة
  currentQuantity: doublePrecision("current_quantity").notNull(), // الكمية المنجزة في المستخلص الحالي
  totalQuantity: doublePrecision("total_quantity").notNull(), // إجمالي الكمية المنجزة حتى تاريخه
  remainingQuantity: doublePrecision("remaining_quantity"), // الكمية المتبقية
  
  // الأسعار والمبالغ
  unitPrice: doublePrecision("unit_price").notNull(), // سعر الوحدة
  amount: doublePrecision("amount").notNull(), // القيمة المالية (الكمية الحالية × سعر الوحدة)
  
  // نسب الإنجاز
  completionPercentage: doublePrecision("completion_percentage").notNull(), // نسبة الإنجاز
  
  // معلومات إضافية
  isVariation: boolean("is_variation").default(false), // هل هذا بند إضافي خارج جدول الكميات
  isDeduction: boolean("is_deduction").default(false), // هل هذا بند خصم
  approvalReference: text("approval_reference"), // مرجع الموافقة لبند خارج جدول الكميات
  
  notes: text("notes"), // ملاحظات
  supportingDocumentPath: text("supporting_document_path"), // مسار مستند داعم
});

// مسار الموافقات - Approval Workflows
export const certificateApprovals = pgTable("certificate_approvals", {
  id: serial("id").primaryKey(),
  certificateId: integer("certificate_id").references(() => paymentCertificates.id).notNull(),
  approvalLevel: text("approval_level").notNull(), // مستوى الموافقة (مشرف، مدير مشروع، إلخ)
  status: text("status").notNull(), // حالة الموافقة (معلق، موافق، مرفوض)
  approvedBy: integer("approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  comments: text("comments"), // تعليقات الموافقة
  signaturePath: text("signature_path"), // مسار صورة التوقيع
});

// Journal Entries (القيود اليومية)
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  
  // البيانات الأساسية للقيد المحاسبي
  journalNumber: text("journal_number").notNull(), // رقم القيد المحاسبي
  journalDate: timestamp("journal_date").defaultNow().notNull(), // تاريخ القيد
  description: text("description").notNull(), // وصف القيد
  
  // العلاقات المرجعية الأساسية
  projectId: integer("project_id").references(() => projects.id), // المشروع المرتبط
  certificateId: integer("certificate_id").references(() => paymentCertificates.id), // المستخلص المرتبط
  
  // بيانات الفترة المالية
  fiscalYear: integer("fiscal_year").notNull(), // السنة المالية
  fiscalPeriod: integer("fiscal_period").notNull(), // الفترة المالية
  
  // حالة القيد المحاسبي
  isPosted: boolean("is_posted").default(false), // هل تم ترحيل القيد
  postingDate: timestamp("posting_date"), // تاريخ الترحيل
  postedBy: integer("posted_by").references(() => users.id), // من قام بالترحيل
  
  // قيم إحصائية إجمالية (يحسب بشكل آلي ويستخدم للتحقق)
  totalDebit: doublePrecision("total_debit").default(0), // إجمالي المدين
  totalCredit: doublePrecision("total_credit").default(0), // إجمالي الدائن
  isBalanced: boolean("is_balanced").default(false), // هل القيد متوازن
  
  // بيانات المعاملة الأصلية
  documentType: text("document_type"), // نوع المستند المصدر (مستخلص، فاتورة، دفعة، إلخ)
  sourceReference: text("source_reference"), // رقم المستند المصدر
  
  // علامات خاصة
  isRecurring: boolean("is_recurring").default(false), // هل هو قيد دوري
  isAdjustment: boolean("is_adjustment").default(false), // هل هو قيد تسوية
  isClosing: boolean("is_closing").default(false), // هل هو قيد إقفال
  isCorrective: boolean("is_corrective").default(false), // هل هو قيد تصحيحي
  
  // المرفقات والملاحظات
  attachmentPath: text("attachment_path"), // مسار ملف مرفق
  notes: text("notes"), // ملاحظات
  
  // معلومات المتابعة
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Journal Entry Lines (سطور القيود المحاسبية)
export const journalEntryLines = pgTable("journal_entry_lines", {
  id: serial("id").primaryKey(),
  
  // العلاقة مع القيد اليومي الرئيسي
  journalEntryId: integer("journal_entry_id").references(() => journalEntries.id).notNull(),
  lineNumber: integer("line_number").notNull(), // رقم السطر في القيد
  
  // معلومات الحساب المالي
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(), // رمز الحساب
  description: text("description"), // وصف السطر
  
  // مبالغ الحركة
  debitAmount: doublePrecision("debit_amount").default(0), // المبلغ المدين
  creditAmount: doublePrecision("credit_amount").default(0), // المبلغ الدائن
  
  // المراكز المالية والمشروع
  projectId: integer("project_id").references(() => projects.id), // المشروع المرتبط
  certificateId: integer("certificate_id").references(() => paymentCertificates.id), // المستخلص المرتبط
  contractItemId: integer("contract_item_id").references(() => contractItems.id), // بند العقد المرتبط
  costCenter: text("cost_center"), // مركز التكلفة
  costCategory: costCategoryEnum("cost_category"), // تصنيف التكلفة
  budget: jsonb("budget"), // معلومات الميزانية المرتبطة
  
  // المعلومات الإضافية
  notes: text("notes"), // ملاحظات
  
  // معلومات المتابعة
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Financial Transactions (المعاملات المالية)
export const financialTransactions = pgTable("financial_transactions", {
  id: serial("id").primaryKey(),
  
  // العلاقات المرجعية الأساسية
  projectId: integer("project_id").references(() => projects.id), // المشروع المرتبط
  taskId: integer("task_id").references(() => tasks.id), // المهمة المرتبطة
  contractItemId: integer("contract_item_id").references(() => contractItems.id), // بند العقد المرتبط
  certificateId: integer("certificate_id").references(() => paymentCertificates.id), // المستخلص المرتبط
  journalEntryId: integer("journal_entry_id").references(() => journalEntries.id), // القيد المحاسبي المرتبط
  
  // معلومات الحسابات المالية - القيد المزدوج
  debitAccountId: integer("debit_account_id").references(() => chartOfAccounts.id).notNull(), // حساب المدين
  creditAccountId: integer("credit_account_id").references(() => chartOfAccounts.id).notNull(), // حساب الدائن

  // بيانات المعاملة
  referenceNumber: text("reference_number"), // رقم المرجع أو الفاتورة
  amount: doublePrecision("amount").notNull(), // المبلغ
  description: text("description"), // الوصف
  transactionDate: timestamp("transaction_date").defaultNow(), // تاريخ المعاملة
  dueDate: timestamp("due_date"), // تاريخ الاستحقاق
  type: transactionTypeEnum("type").notNull(), // نوع المعاملة: إيرادات، مصروفات، تحويل، دفع، تسوية
  
  // تصنيفات المعاملة
  costCategory: costCategoryEnum("cost_category"), // تصنيف التكلفة
  costCenter: text("cost_center"), // مركز التكلفة
  budgetLineId: integer("budget_line_id").references(() => projectBudgets.id), // بند الميزانية المرتبط
  budgetAmount: doublePrecision("budget_amount"), // المبلغ المعتمد في الميزانية
  varianceFromBudget: doublePrecision("variance_from_budget"), // الفرق عن الميزانية
  
  // حالة المعاملة ومعلومات إضافية
  status: transactionStatusEnum("status").default("completed"), // حالة المعاملة
  isReconciled: boolean("is_reconciled").default(false), // هل تمت مطابقتها
  reconciliationDate: timestamp("reconciliation_date"), // تاريخ المطابقة
  isRecurring: boolean("is_recurring").default(false), // هل هي معاملة متكررة
  recurrencePattern: text("recurrence_pattern"), // نمط التكرار (شهري، أسبوعي، إلخ)
  
  // الملفات والمرفقات
  attachmentPath: text("attachment_path"), // مسار ملف مرفق (مثل صورة الفاتورة)
  
  // معلومات المتابعة
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  
  // علاقات داخلية في المعاملات
  parentTransactionId: integer("parent_transaction_id"), // للمعاملات المرتبطة (مثل المعاملات المتكررة)
  reconciliationTransactionId: integer("reconciliation_transaction_id"), // معاملة التسوية المرتبطة
});

// أنواع التقارير المالية
export const financialReportTypeEnum = pgEnum('financial_report_type', [
  'budget_vs_actual', // مقارنة الميزانية بالمصروفات الفعلية
  'income_statement', // قائمة الدخل
  'balance_sheet', // الميزانية العمومية
  'cash_flow', // التدفقات النقدية
  'accounts_receivable', // الذمم المدينة
  'accounts_payable', // الذمم الدائنة
  'project_profitability', // ربحية المشاريع
  'payment_certificates', // تقرير المستخلصات
  'tax_report', // التقارير الضريبية
  'expense_distribution', // توزيع المصروفات
  'revenue_distribution', // توزيع الإيرادات
  'custom', // تقرير مخصص
]);

// Financial Periods (الفترات المالية)
export const financialPeriods = pgTable("financial_periods", {
  id: serial("id").primaryKey(),
  periodNumber: integer("period_number").notNull(), // رقم الفترة
  name: text("name").notNull(), // اسم الفترة
  fiscalYear: integer("fiscal_year").notNull(), // السنة المالية
  startDate: timestamp("start_date").notNull(), // تاريخ بداية الفترة
  endDate: timestamp("end_date").notNull(), // تاريخ نهاية الفترة
  
  // حالة الفترة المالية
  status: text("status").default("open"), // مفتوحة، معلقة، مغلقة، مقفلة
  isClosed: boolean("is_closed").default(false), // هل الفترة مغلقة
  closedAt: timestamp("closed_at"), // تاريخ إغلاق الفترة
  closedBy: integer("closed_by").references(() => users.id), // من أغلق الفترة
  
  // المطابقة والتسوية
  isReconciled: boolean("is_reconciled").default(false), // هل تمت مطابقة الفترة
  reconciledAt: timestamp("reconciled_at"), // تاريخ المطابقة
  reconciledBy: integer("reconciled_by").references(() => users.id), // من أجرى المطابقة
  
  // معلومات الإنشاء والتحديث
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  
  // ملاحظات
  notes: text("notes"), // ملاحظات عامة
});

// Financial Reports (التقارير المالية المخصصة)
export const financialReports = pgTable("financial_reports", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: financialReportTypeEnum("type").notNull(), // نوع التقرير
  description: text("description"), // وصف التقرير
  
  // نطاق التقرير
  projectId: integer("project_id").references(() => projects.id), // المشروع المرتبط (إذا كان محدداً)
  fromDate: timestamp("from_date"), // تاريخ بداية نطاق التقرير
  toDate: timestamp("to_date"), // تاريخ نهاية نطاق التقرير
  fiscalYear: integer("fiscal_year"), // السنة المالية (إذا كان محدداً)
  fiscalQuarter: integer("fiscal_quarter"), // الربع المالي (إذا كان محدداً)
  
  // بيانات ومعلمات التقرير
  parameters: jsonb("parameters"), // معلمات التقرير (تصفية، فرز، إلخ)
  template: text("template"), // قالب التقرير
  format: text("format").default('pdf'), // تنسيق التقرير (PDF, Excel, CSV, etc.)
  isRecurring: boolean("is_recurring").default(false), // هل هو تقرير دوري
  recurrencePattern: text("recurrence_pattern"), // نمط التكرار (يومي، أسبوعي، شهري، إلخ)
  enableEmail: boolean("enable_email").default(false), // إرسال التقرير بالبريد الإلكتروني
  emailRecipients: text("email_recipients").array(), // قائمة مستلمي البريد الإلكتروني
  
  // اخر مرة تم انشاء التقرير
  lastGeneratedAt: timestamp("last_generated_at"),
  lastGeneratedBy: integer("last_generated_by").references(() => users.id),
  lastGeneratedPath: text("last_generated_path"), // مسار آخر تقرير تم إنشاؤه

  // معلومات أخرى
  isSystem: boolean("is_system").default(false), // هل هو تقرير نظامي (غير قابل للتعديل)
  isPublic: boolean("is_public").default(false), // هل يمكن الوصول إليه من قبل جميع المستخدمين
  isScheduled: boolean("is_scheduled").default(false), // هل مجدول للتشغيل التلقائي
  scheduleParameters: jsonb("schedule_parameters"), // معلمات الجدولة
  
  // معلومات الإنشاء والتحديث
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// سجل إنشاء التقارير المالية
export const financialReportLogs = pgTable("financial_report_logs", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id").references(() => financialReports.id).notNull(),
  generatedAt: timestamp("generated_at").defaultNow(),
  generatedBy: integer("generated_by").references(() => users.id),
  parameters: jsonb("parameters"), // المعلمات المستخدمة لإنشاء التقرير
  filePath: text("file_path"), // مسار ملف التقرير
  status: text("status").default("success"), // حالة إنشاء التقرير (نجاح، فشل)
  errorMessage: text("error_message"), // رسالة الخطأ إذا فشل إنشاء التقرير
  executionTimeMs: integer("execution_time_ms"), // وقت التنفيذ بالمللي ثانية
  isSent: boolean("is_sent").default(false), // هل تم إرساله
  sentAt: timestamp("sent_at"), // وقت الإرسال
  recipients: text("recipients").array(), // المستلمون
});

// Assets
export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: assetTypeEnum("type").notNull(),
  description: text("description"),
  purchaseDate: timestamp("purchase_date"),
  purchaseValue: doublePrecision("purchase_value"),
  status: text("status"), // available, in_use, maintenance, etc.
  currentLocation: jsonb("current_location"), // GeoJSON format
  assignedToProject: integer("assigned_to_project").references(() => projects.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Resources
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: resourceTypeEnum("type").notNull(),
  description: text("description"),
  quantity: integer("quantity").default(1),
  unit: text("unit"), // hours, pieces, etc.
  cost: doublePrecision("cost"),
  assignedToProject: integer("assigned_to_project").references(() => projects.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Documents
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: documentTypeEnum("type").notNull(),
  projectId: integer("project_id").references(() => projects.id),
  path: text("path").notNull(),
  uploadedBy: integer("uploaded_by").references(() => users.id),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  description: text("description"),
});

// صور المشروع (Project Photos)
export const projectPhotos = pgTable("project_photos", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  path: text("path").notNull(),
  uploadedBy: integer("uploaded_by").references(() => users.id),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  captureDate: timestamp("capture_date"), // تاريخ التقاط الصورة
  location: jsonb("location"), // موقع التقاط الصورة (GeoJSON) إذا كان متاحًا
  tags: text("tags").array(), // وسوم للتصنيف والبحث
});

// Risks
export const risks = pgTable("risks", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  level: riskLevelEnum("level").notNull(),
  impact: text("impact"),
  mitigation: text("mitigation"),
  status: text("status").default("active"), // active, resolved, etc.
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// مؤشرات أداء المشروع (Project KPIs)
export const projectKpis = pgTable("project_kpis", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  
  // الفترة الزمنية
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  periodType: text("period_type").default('month'), // نوع الفترة: يوم، أسبوع، شهر، ربع سنوي، سنة
  
  // مؤشرات أداء التكلفة (Cost Performance Indicators)
  plannedValue: doublePrecision("planned_value").default(0), // القيمة المخططة (PV) - BCWS
  earnedValue: doublePrecision("earned_value").default(0), // القيمة المكتسبة (EV) - BCWP
  actualCost: doublePrecision("actual_cost").default(0), // التكلفة الفعلية (AC) - ACWP
  costPerformanceIndex: doublePrecision("cost_performance_index").default(0), // مؤشر أداء التكلفة (CPI = EV/AC)
  costVariance: doublePrecision("cost_variance").default(0), // تباين التكلفة (CV = EV - AC)
  estimateAtCompletion: doublePrecision("estimate_at_completion").default(0), // التقدير عند الإكمال (EAC)
  estimateToComplete: doublePrecision("estimate_to_complete").default(0), // التقدير للإكمال (ETC)
  varianceAtCompletion: doublePrecision("variance_at_completion").default(0), // التباين عند الإكمال (VAC)
  toCPI: doublePrecision("to_cpi").default(0), // مؤشر أداء التكلفة المطلوب للإنجاز ضمن الميزانية
  
  // مؤشرات أداء الجدول الزمني (Schedule Performance Indicators)
  schedulePerformanceIndex: doublePrecision("schedule_performance_index").default(0), // مؤشر أداء الجدول الزمني (SPI = EV/PV)
  scheduleVariance: doublePrecision("schedule_variance").default(0), // تباين الجدول الزمني (SV = EV - PV)
  timeEstimateAtCompletion: doublePrecision("time_estimate_at_completion").default(0), // تقدير الوقت عند الإكمال
  delayedDays: integer("delayed_days").default(0), // عدد الأيام المتأخرة
  remainingDuration: integer("remaining_duration").default(0), // المدة المتبقية (بالأيام)
  criticalPathDelay: integer("critical_path_delay").default(0), // تأخير المسار الحرج
  toComplete: doublePrecision("to_complete").default(0), // النسبة المئوية للعمل المتبقي للإكمال
  
  // مؤشرات اتجاه الأداء (Performance Trend Indicators)
  cpiTrend: doublePrecision("cpi_trend").default(0), // اتجاه مؤشر أداء التكلفة (من الفترة السابقة)
  spiTrend: doublePrecision("spi_trend").default(0), // اتجاه مؤشر أداء الجدول الزمني (من الفترة السابقة)
  progressTrend: doublePrecision("progress_trend").default(0), // اتجاه التقدم (من الفترة السابقة)
  burnRateIndex: doublePrecision("burn_rate_index").default(0), // معدل استهلاك الميزانية
  
  // مؤشرات الانتاجية (Productivity Indicators)
  plannedProductivity: doublePrecision("planned_productivity").default(0), // الإنتاجية المخططة (وحدة/يوم)
  actualProductivity: doublePrecision("actual_productivity").default(0), // الإنتاجية الفعلية (وحدة/يوم)
  productivityVariance: doublePrecision("productivity_variance").default(0), // تباين الإنتاجية
  productivityIndex: doublePrecision("productivity_index").default(0), // مؤشر الإنتاجية
  
  // مؤشرات الجودة (Quality Indicators)
  qualityIndex: doublePrecision("quality_index").default(0), // مؤشر الجودة (0-100%)
  defectsFound: integer("defects_found").default(0), // عدد العيوب المكتشفة
  defectsFix: integer("defects_fix").default(0), // عدد العيوب التي تم إصلاحها
  defectFixRate: doublePrecision("defect_fix_rate").default(0), // معدل إصلاح العيوب
  reworkCost: doublePrecision("rework_cost").default(0), // تكلفة إعادة العمل
  
  // مؤشرات التقدم والإنجاز (Progress Indicators)
  plannedProgress: doublePrecision("planned_progress").default(0), // نسبة التقدم المخطط
  actualProgress: doublePrecision("actual_progress").default(0), // نسبة التقدم الفعلي
  progressVariance: doublePrecision("progress_variance").default(0), // تباين التقدم
  completedTasks: integer("completed_tasks").default(0), // عدد المهام المكتملة
  inProgressTasks: integer("in_progress_tasks").default(0), // عدد المهام قيد التنفيذ
  notStartedTasks: integer("not_started_tasks").default(0), // عدد المهام التي لم تبدأ
  
  // مؤشرات الموارد (Resource Indicators)
  plannedResourceHours: doublePrecision("planned_resource_hours").default(0), // ساعات الموارد المخططة
  actualResourceHours: doublePrecision("actual_resource_hours").default(0), // ساعات الموارد الفعلية
  resourceUtilizationRate: doublePrecision("resource_utilization_rate").default(0), // معدل استخدام الموارد
  resourceVariance: doublePrecision("resource_variance").default(0), // تباين الموارد
  resourcePerformanceIndex: doublePrecision("resource_performance_index").default(0), // مؤشر أداء الموارد
  
  // مؤشرات الإنفاق والميزانية (Budget Indicators)
  budgetedCost: doublePrecision("budgeted_cost").default(0), // التكلفة المعتمدة في الميزانية
  actualSpend: doublePrecision("actual_spend").default(0), // الإنفاق الفعلي
  remainingBudget: doublePrecision("remaining_budget").default(0), // الميزانية المتبقية
  budgetUtilizationRate: doublePrecision("budget_utilization_rate").default(0), // معدل استخدام الميزانية
  
  // مؤشرات مخاطر المشروع (Risk Indicators)
  riskExposure: doublePrecision("risk_exposure").default(0), // التعرض للمخاطر
  activeRisks: integer("active_risks").default(0), // المخاطر النشطة
  mitigatedRisks: integer("mitigated_risks").default(0), // المخاطر التي تم تخفيفها
  riskCostImpact: doublePrecision("risk_cost_impact").default(0), // تأثير المخاطر على التكلفة
  
  // مؤشرات الاستدامة (Sustainability Indicators)
  carbonFootprint: doublePrecision("carbon_footprint").default(0), // البصمة الكربونية (طن)
  energyConsumption: doublePrecision("energy_consumption").default(0), // استهلاك الطاقة
  wasteGenerated: doublePrecision("waste_generated").default(0), // النفايات المتولدة
  recycledMaterials: doublePrecision("recycled_materials").default(0), // المواد المعاد تدويرها
  greenMaterialPercentage: doublePrecision("green_material_percentage").default(0), // نسبة المواد الصديقة للبيئة
  
  // المعلومات المالية المرتبطة بالشهادات (Certificate Related)
  approvedCertificatesAmount: doublePrecision("approved_certificates_amount").default(0), // قيمة المستخلصات المعتمدة
  pendingCertificatesAmount: doublePrecision("pending_certificates_amount").default(0), // قيمة المستخلصات المعلقة
  
  // البيانات الوصفية والتتبع
  version: integer("version").default(1), // نسخة البيانات (للتتبع التاريخي)
  calculatedAt: timestamp("calculated_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  calculatedBy: integer("calculated_by").references(() => users.id),
  notes: text("notes"), // ملاحظات
  dataSource: text("data_source"), // مصدر البيانات (ملف، API، إدخال يدوي)
});



// Schemas for insert
export const insertUserSchema = createInsertSchema(users).omit({ id: true });

// Insert schema for Journal Entries
export const insertJournalEntrySchema = createInsertSchema(journalEntries)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true,
    // Auto-calculated fields
    totalDebit: true,
    totalCredit: true,
    isBalanced: true, 
    // Fields set later
    isPosted: true,
    postingDate: true,
    postedBy: true
  })
  .extend({
    journalDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().default(new Date())
    )
  });

// Insert schema for Journal Entry Lines
export const insertJournalEntryLineSchema = createInsertSchema(journalEntryLines)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true
  });

// Insert schema for Financial Periods
export const insertFinancialPeriodSchema = createInsertSchema(financialPeriods)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true,
    // Auto-set fields
    isClosed: true,
    closedAt: true,
    closedBy: true,
    isReconciled: true,
    reconciledAt: true,
    reconciledBy: true
  })
  .extend({
    startDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date()
    ),
    endDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date()
    )
  });

// تعديل مخطط إدخال المشروع للتعامل مع التواريخ بشكل صحيح
export const insertProjectSchema = createInsertSchema(projects)
  .omit({ id: true, createdAt: true, updatedAt: true })
  .extend({
    // تعريف التواريخ لقبول كل من السلاسل النصية والكائنات من نوع Date
    startDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    endDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
  });

export const insertTaskSchema = createInsertSchema(tasks)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true,
    completedAt: true,
    completedBy: true
  })
  .extend({
    plannedStartDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    plannedEndDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    actualStartDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    actualEndDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    )
  });

export const insertFinancialTransactionSchema = createInsertSchema(financialTransactions)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true,
    // معلومات وقت التنفيذ
    reconciliationDate: true,
    // علاقات اختيارية يمكن إضافتها لاحقًا
    reconciliationTransactionId: true
  }).extend({
    transactionDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().default(new Date())
    ),
    dueDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
  });
export const insertAssetSchema = createInsertSchema(assets).omit({ id: true, createdAt: true, updatedAt: true });
export const insertResourceSchema = createInsertSchema(resources).omit({ id: true, createdAt: true, updatedAt: true });
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, uploadedAt: true });
export const insertProjectPhotoSchema = createInsertSchema(projectPhotos).omit({ id: true, uploadedAt: true });
export const insertRiskSchema = createInsertSchema(risks).omit({ id: true, createdAt: true, updatedAt: true });

// مخطط إدخال مؤشرات أداء المشروع
export const insertProjectKpiSchema = createInsertSchema(projectKpis).omit({ 
  id: true, 
  calculatedAt: true, 
  updatedAt: true,
  // القيم المحسوبة تلقائيًا
  costPerformanceIndex: true,
  costVariance: true,
  schedulePerformanceIndex: true,
  scheduleVariance: true,
  productivityVariance: true,
  defectFixRate: true,
  progressVariance: true,
  resourceUtilizationRate: true,
  // القيم المحسوبة للاتجاه
  cpiTrend: true,
  spiTrend: true,
  progressTrend: true,
  burnRateIndex: true,
  // القيم المحسوبة للقيم المكتسبة
  estimateAtCompletion: true,
  estimateToComplete: true,
  varianceAtCompletion: true,
  toCPI: true,
  toComplete: true,
  // القيم المحسوبة للإنتاجية
  productivityIndex: true,
  // القيم المحسوبة للجدولة
  timeEstimateAtCompletion: true,
  criticalPathDelay: true,
  // القيم المحسوبة للميزانية
  budgetUtilizationRate: true,
  // القيم المتعلقة بالاستدامة - تتطلب حسابات خاصة
  carbonFootprint: true,
  greenMaterialPercentage: true,
  // القيم المحسوبة للموارد
  resourceVariance: true,
  resourcePerformanceIndex: true,
  // version
  version: true
}).extend({
  periodStart: z.preprocess(
    (val) => (typeof val === 'string' ? new Date(val) : val),
    z.date()
  ),
  periodEnd: z.preprocess(
    (val) => (typeof val === 'string' ? new Date(val) : val),
    z.date()
  ),
  periodType: z.enum(['day', 'week', 'month', 'quarter', 'year']).default('month'),
  
  // القيم المطلوبة
  plannedValue: z.number().nonnegative().default(0),
  earnedValue: z.number().nonnegative().default(0),
  actualCost: z.number().nonnegative().default(0),
  
  // قيم المهام
  completedTasks: z.number().int().nonnegative().default(0),
  inProgressTasks: z.number().int().nonnegative().default(0),
  notStartedTasks: z.number().int().nonnegative().default(0),
  
  // قيم التقدم
  plannedProgress: z.number().min(0).max(100).default(0),
  actualProgress: z.number().min(0).max(100).default(0),
  
  // قيم الجدولة
  delayedDays: z.number().int().default(0),
  remainingDuration: z.number().int().nonnegative().default(0),
  
  // قيم المخاطر
  activeRisks: z.number().int().nonnegative().default(0),
  mitigatedRisks: z.number().int().nonnegative().default(0),
  riskExposure: z.number().nonnegative().default(0),
  riskCostImpact: z.number().nonnegative().default(0),
  
  // قيم الميزانية
  budgetedCost: z.number().nonnegative().default(0),
  actualSpend: z.number().nonnegative().default(0),
  remainingBudget: z.number().nonnegative().default(0),
  
  // قيم الإنتاجية
  plannedProductivity: z.number().nonnegative().default(0),
  actualProductivity: z.number().nonnegative().default(0),
  
  // قيم الجودة
  qualityIndex: z.number().min(0).max(100).default(0),
  defectsFound: z.number().int().nonnegative().default(0),
  defectsFix: z.number().int().nonnegative().default(0),
  reworkCost: z.number().nonnegative().default(0),
  
  // قيم الموارد
  plannedResourceHours: z.number().nonnegative().default(0),
  actualResourceHours: z.number().nonnegative().default(0),
  
  // قيم الاستدامة
  energyConsumption: z.number().nonnegative().default(0),
  wasteGenerated: z.number().nonnegative().default(0),
  recycledMaterials: z.number().nonnegative().default(0),
  
  // معلومات المستخلصات
  approvedCertificatesAmount: z.number().nonnegative().default(0),
  pendingCertificatesAmount: z.number().nonnegative().default(0),
  
  // بيانات إضافية
  notes: z.string().optional(),
  dataSource: z.string().optional()
});

// Financial schemas
export const insertChartOfAccountSchema = createInsertSchema(chartOfAccounts).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProjectBudgetSchema = createInsertSchema(projectBudgets)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true,
    approvedAt: true,
    approvedBy: true,
    availableAmount: true // هذا سيتم حسابه تلقائيًا
  })
  .extend({
    fromDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    toDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    plannedAmount: z.number().nonnegative("يجب أن يكون المبلغ المخطط رقماً موجباً أو صفر"),
    actualAmount: z.number().nonnegative("يجب أن يكون المبلغ الفعلي رقماً موجباً أو صفر").optional(),
    committedAmount: z.number().nonnegative("يجب أن يكون المبلغ الملتزم به رقماً موجباً أو صفر").optional(),
  });
export const insertFinancialReportSchema = createInsertSchema(financialReports)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true, 
    lastGeneratedAt: true,
    lastGeneratedBy: true,
    lastGeneratedPath: true
  })
  .extend({
    fromDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    toDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date().optional()
    ),
    emailRecipients: z.array(z.string().email("يجب أن يكون البريد الإلكتروني صحيحاً")).optional(),
  });


// Insert schemas for new tables
export const insertContractItemSchema = createInsertSchema(contractItems)
  .omit({ id: true, createdAt: true, updatedAt: true })
  .extend({
    itemNumber: z.string().min(1, "رقم البند مطلوب"),
    description: z.string().min(1, "وصف البند مطلوب"),
    unit: z.string().min(1, "وحدة القياس مطلوبة"),
    quantity: z.number().positive("يجب أن تكون الكمية رقماً موجباً"),
    unitPrice: z.number().positive("يجب أن يكون سعر الوحدة رقماً موجباً"),
    // يتم حساب إجمالي السعر تلقائيًا (الكمية × سعر الوحدة)
    totalPrice: z.number().positive("يجب أن يكون إجمالي السعر رقماً موجباً"),
    // قيم اختيارية
    completed: z.number().nonnegative().optional(),
    completionPercentage: z.number().min(0).max(100).optional(),
    notes: z.string().optional(),
  });

export const insertPaymentCertificateSchema = createInsertSchema(paymentCertificates)
  .omit({ 
    id: true, 
    createdAt: true, 
    updatedAt: true, 
    submittedAt: true,
    submittedBy: true,
    supervisorApprovedAt: true,
    supervisorApprovedBy: true,
    pmApprovedAt: true,
    pmApprovedBy: true,
    financeApprovedAt: true,
    financeApprovedBy: true,
    gmApprovedAt: true,
    gmApprovedBy: true,
    approvedAt: true, 
    approvedBy: true,
    paidAt: true,
    paidBy: true
  })
  .extend({
    fromDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date()
    ),
    toDate: z.preprocess(
      (val) => (typeof val === 'string' ? new Date(val) : val),
      z.date()
    ),
    // Campos requeridos con validaciones
    grossAmount: z.number().nonnegative("يجب أن يكون المبلغ رقماً موجباً أو صفر"),
    totalAmount: z.number().nonnegative("يجب أن يكون المبلغ رقماً موجباً أو صفر"),
    currentAmount: z.number().nonnegative("يجب أن يكون المبلغ رقماً موجباً أو صفر"),
    finalAmount: z.number().nonnegative("يجب أن يكون المبلغ رقماً موجباً أو صفر"),
    
    // Campos opcionales
    previousAmount: z.number().nonnegative().optional(),
    advancePaymentAmount: z.number().nonnegative().optional(),
    advancePaymentDeduction: z.number().nonnegative().optional(),
    retentionAmount: z.number().nonnegative().optional(),
    taxAmount: z.number().nonnegative().optional(),
    otherDeductions: z.number().nonnegative().optional(),
    materialsOnSite: z.number().nonnegative().optional(),
    otherAdditions: z.number().nonnegative().optional(),
    completionPercentage: z.number().min(0).max(100).optional(),
    contractorId: z.number().optional(),
    contractorName: z.string().optional(),
    contractNumber: z.string().optional(),
    notes: z.string().optional(),
    attachmentPath: z.string().optional(),
    paymentReference: z.string().optional(),
  });

export const insertPaymentCertificateItemSchema = createInsertSchema(paymentCertificateItems)
  .omit({ id: true })
  .extend({
    contractItemId: z.number().nullable().optional(), // Opcional para permitir items manuales
    description: z.string().min(1, "الوصف مطلوب"),
    unit: z.string().min(1, "الوحدة مطلوبة"),
    currentQuantity: z.number().positive("يجب أن تكون الكمية رقماً موجباً"),
    unitPrice: z.number().positive("يجب أن يكون سعر الوحدة رقماً موجباً"),
    amount: z.number().positive("يجب أن يكون المبلغ رقماً موجباً"),
    completionPercentage: z.number().min(0).max(100, "يجب أن تكون نسبة الإنجاز بين 0 و 100"),
    isVariation: z.boolean().optional(),
    isDeduction: z.boolean().optional(),
  });

export const insertCertificateApprovalSchema = createInsertSchema(certificateApprovals)
  .omit({ id: true, approvedAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Journal Entry Types
export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;

export type JournalEntryLine = typeof journalEntryLines.$inferSelect;
export type InsertJournalEntryLine = z.infer<typeof insertJournalEntryLineSchema>;

// Financial Period Types
export type FinancialPeriod = typeof financialPeriods.$inferSelect;
export type InsertFinancialPeriod = z.infer<typeof insertFinancialPeriodSchema>;

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type FinancialTransaction = typeof financialTransactions.$inferSelect;
export type InsertFinancialTransaction = z.infer<typeof insertFinancialTransactionSchema>;

export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type ProjectPhoto = typeof projectPhotos.$inferSelect;
export type InsertProjectPhoto = z.infer<typeof insertProjectPhotoSchema>;

export type Risk = typeof risks.$inferSelect;
export type InsertRisk = z.infer<typeof insertRiskSchema>;

// مؤشرات أداء المشروع
export type ProjectKpi = typeof projectKpis.$inferSelect;
export type InsertProjectKpi = z.infer<typeof insertProjectKpiSchema>;

// Financial types
export type ChartOfAccount = typeof chartOfAccounts.$inferSelect & { balance?: number };
export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountSchema>;

export type ProjectBudget = typeof projectBudgets.$inferSelect;
export type InsertProjectBudget = z.infer<typeof insertProjectBudgetSchema>;

export type FinancialReport = typeof financialReports.$inferSelect;
export type InsertFinancialReport = z.infer<typeof insertFinancialReportSchema>;

// Payment Certificate types
export type ContractItem = typeof contractItems.$inferSelect;
export type InsertContractItem = z.infer<typeof insertContractItemSchema>;

export type PaymentCertificate = typeof paymentCertificates.$inferSelect;
export type InsertPaymentCertificate = z.infer<typeof insertPaymentCertificateSchema>;

export type PaymentCertificateItem = typeof paymentCertificateItems.$inferSelect;
export type InsertPaymentCertificateItem = z.infer<typeof insertPaymentCertificateItemSchema>;

export type CertificateApproval = typeof certificateApprovals.$inferSelect;
export type InsertCertificateApproval = z.infer<typeof insertCertificateApprovalSchema>;

// أنواع بيانات بنود ميزانية المشروع
export const insertProjectBudgetItemSchema = createInsertSchema(projectBudgetItems).omit({
  id: true,
  usedAmount: true,
  remainingAmount: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProjectBudgetItem = z.infer<typeof insertProjectBudgetItemSchema>;
export type ProjectBudgetItem = typeof projectBudgetItems.$inferSelect;

// أنواع بيانات المصروفات
export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  journalEntryId: true,
  status: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

// Payment Certificate type and status mappings
export const paymentCertificateTypeMap = {
  subcontractor: { ar: "مقاول باطن", en: "Subcontractor" },
  main_contractor: { ar: "مقاول رئيسي", en: "Main Contractor" },
  consultant: { ar: "استشاري", en: "Consultant" },
  internal: { ar: "صرف داخلي", en: "Internal" },
  interim: { ar: "مستخلص مرحلي", en: "Interim Certificate" },
  final: { ar: "مستخلص نهائي", en: "Final Certificate" }
};

export const paymentCertificateStatusMap = {
  draft: { ar: "مسودة", en: "Draft" },
  submitted: { ar: "مقدم", en: "Submitted" },
  supervisor_approved: { ar: "موافقة المشرف", en: "Supervisor Approved" },
  pm_approved: { ar: "موافقة مدير المشروع", en: "PM Approved" },
  finance_approved: { ar: "موافقة المالية", en: "Finance Approved" },
  gm_approved: { ar: "موافقة المدير العام", en: "GM Approved" },
  approved: { ar: "معتمد", en: "Approved" },
  paid: { ar: "مدفوع", en: "Paid" },
  rejected: { ar: "مرفوض", en: "Rejected" }
};


// Project type mappings
export const projectTypeMap = {
  road: { ar: "طرق", en: "Roads" },
  water: { ar: "مياه", en: "Water" },
  electricity: { ar: "كهرباء", en: "Electricity" },
  telecom: { ar: "اتصالات", en: "Telecom" },
  building: { ar: "مباني", en: "Buildings" }
};

// Project status mappings
export const projectStatusMap = {
  planning: { ar: "تخطيط", en: "Planning" },
  in_progress: { ar: "قيد التنفيذ", en: "In Progress" },
  delayed: { ar: "متأخر", en: "Delayed" },
  completed: { ar: "مكتمل", en: "Completed" },
  stopped: { ar: "متوقف", en: "Stopped" }
};

// Risk level mappings
export const riskLevelMap = {
  low: { ar: "منخفض", en: "Low" },
  medium: { ar: "متوسط", en: "Medium" },
  high: { ar: "مرتفع", en: "High" }
};

// Financial account type mappings
export const financialAccountTypeMap = {
  asset: { ar: "أصول", en: "Assets" },
  liability: { ar: "خصوم", en: "Liabilities" },
  equity: { ar: "حقوق ملكية", en: "Equity" },
  revenue: { ar: "إيرادات", en: "Revenue" },
  expense: { ar: "مصروفات", en: "Expenses" },
  cost_of_sales: { ar: "تكلفة المبيعات", en: "Cost of Sales" },
  tax: { ar: "ضرائب", en: "Taxes" },
  control: { ar: "حسابات رقابية", en: "Control Accounts" }
};

// Transaction type mappings
export const transactionTypeMap = {
  income: { ar: "إيراد", en: "Income" },
  expense: { ar: "مصروف", en: "Expense" },
  transfer: { ar: "تحويل", en: "Transfer" },
  payment: { ar: "دفعة", en: "Payment" },
  adjustment: { ar: "تسوية", en: "Adjustment" }
};

// Cost category mappings
export const costCategoryMap = {
  direct_labor: { ar: "تكلفة العمالة المباشرة", en: "Direct Labor" },
  materials: { ar: "المواد", en: "Materials" },
  equipment: { ar: "المعدات", en: "Equipment" },
  subcontractors: { ar: "مقاولي الباطن", en: "Subcontractors" },
  administrative: { ar: "إدارية", en: "Administrative" },
  overhead: { ar: "نفقات عامة", en: "Overhead" },
  transportation: { ar: "النقل", en: "Transportation" },
  consulting: { ar: "استشارات", en: "Consulting" },
  miscellaneous: { ar: "متفرقات", en: "Miscellaneous" }
};

// Transaction status mappings
export const transactionStatusMap = {
  pending: { ar: "معلق", en: "Pending" },
  completed: { ar: "مكتمل", en: "Completed" },
  cancelled: { ar: "ملغي", en: "Cancelled" },
  reconciled: { ar: "مسوى", en: "Reconciled" },
  disputed: { ar: "متنازع عليه", en: "Disputed" }
};

// Task type mappings
export const taskTypeMap = {
  milestone: { ar: "معلم رئيسي", en: "Milestone" },
  task: { ar: "مهمة", en: "Task" },
  subtask: { ar: "مهمة فرعية", en: "Subtask" },
  deliverable: { ar: "مخرج", en: "Deliverable" },
  package: { ar: "حزمة عمل", en: "Work Package" },
};

// Task status mappings
export const taskStatusMap = {
  not_started: { ar: "لم تبدأ", en: "Not Started" },
  in_progress: { ar: "قيد التنفيذ", en: "In Progress" },
  delayed: { ar: "متأخرة", en: "Delayed" },
  completed: { ar: "مكتملة", en: "Completed" },
  on_hold: { ar: "متوقفة مؤقتا", en: "On Hold" },
  cancelled: { ar: "ملغاة", en: "Cancelled" },
};

// Task priority mappings
export const taskPriorityMap = {
  low: { ar: "منخفضة", en: "Low", color: "bg-blue-100 text-blue-800" },
  medium: { ar: "متوسطة", en: "Medium", color: "bg-amber-100 text-amber-800" },
  high: { ar: "عالية", en: "High", color: "bg-orange-100 text-orange-800" },
  critical: { ar: "حرجة", en: "Critical", color: "bg-red-100 text-red-800" },
};

// Recurring Journal Entries (القيود المتكررة)
export const recurringJournalEntries = pgTable("recurring_journal_entries", {
  id: serial("id").primaryKey(),
  
  // معلومات أساسية
  title: text("title").notNull(), // عنوان القيد المتكرر
  description: text("description"), // وصف القيد المتكرر
  amount: doublePrecision("amount").notNull(), // المبلغ الإجمالي
  
  // الحسابات المستخدمة
  accountDebit: integer("account_debit").references(() => chartOfAccounts.id).notNull(), // الحساب المدين
  accountCredit: integer("account_credit").references(() => chartOfAccounts.id).notNull(), // الحساب الدائن
  
  // العلاقات المرجعية الأساسية
  projectId: integer("project_id").references(() => projects.id), // المشروع المرتبط
  
  // بيانات الجدولة
  frequency: text("frequency").notNull(), // تكرار (يومي، أسبوعي، شهري، ربع سنوي، سنوي)
  startDate: timestamp("start_date").notNull(), // تاريخ البدء
  nextRunDate: timestamp("next_run_date").notNull(), // تاريخ التشغيل القادم
  lastRunDate: timestamp("last_run_date"), // تاريخ آخر تشغيل
  dayOfMonth: integer("day_of_month"), // اليوم من الشهر (للتكرار الشهري)
  dayOfWeek: integer("day_of_week"), // يوم الأسبوع (للتكرار الأسبوعي)
  
  // إعدادات النظام
  autoPost: boolean("auto_post").default(true), // هل يتم ترحيل القيد تلقائياً
  autoBalance: boolean("auto_balance").default(true), // هل يتم موازنة القيد تلقائياً
  isActive: boolean("is_active").default(true), // هل القيد المتكرر نشط
  
  // معلومات المتابعة
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// إنشاء نوع القيد المتكرر
export type RecurringJournalEntry = typeof recurringJournalEntries.$inferSelect;
export type InsertRecurringJournalEntry = typeof recurringJournalEntries.$inferInsert;

// إنشاء مخطط Zod للتحقق من القيد المتكرر
export const insertRecurringJournalEntrySchema = createInsertSchema(recurringJournalEntries, {
  title: z.string().min(3, { message: "يجب أن يكون العنوان 3 أحرف على الأقل" }),
  amount: z.string().transform((val) => parseFloat(val) || 0),
  accountDebit: z.string(),
  accountCredit: z.string(),
  frequency: z.enum(["daily", "weekly", "monthly", "quarterly", "yearly"]),
  startDate: z.date(),
  projectId: z.string().optional().transform((val) => val === "none" ? undefined : parseInt(val) || undefined),
  dayOfMonth: z.string().optional().transform((val) => parseInt(val) || undefined),
  dayOfWeek: z.string().optional().transform((val) => parseInt(val) || undefined),
});


