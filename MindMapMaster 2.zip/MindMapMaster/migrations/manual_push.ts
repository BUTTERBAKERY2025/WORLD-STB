import pg from 'pg';
import fs from 'fs';

async function main() {
  console.log("Starting schema migration...");
  
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL must be set");
  }
  
  const pool = new pg.Pool({ 
    connectionString: process.env.DATABASE_URL,
    ssl: {
      rejectUnauthorized: false
    }
  });
  
  console.log("Connected to database. Starting migration...");
  
  try {
    console.log("Creating new tables...");
    
    // Create Journal Entries table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS journal_entries (
        id SERIAL PRIMARY KEY,
        journal_number TEXT NOT NULL,
        journal_date TIMESTAMP DEFAULT NOW() NOT NULL,
        description TEXT NOT NULL,
        project_id INTEGER REFERENCES projects(id),
        certificate_id INTEGER REFERENCES payment_certificates(id),
        fiscal_year INTEGER NOT NULL,
        fiscal_period INTEGER NOT NULL,
        is_posted BOOLEAN DEFAULT FALSE,
        posting_date TIMESTAMP,
        posted_by INTEGER REFERENCES users(id),
        total_debit DOUBLE PRECISION DEFAULT 0,
        total_credit DOUBLE PRECISION DEFAULT 0,
        is_balanced BOOLEAN DEFAULT FALSE,
        document_type TEXT,
        source_reference TEXT,
        is_recurring BOOLEAN DEFAULT FALSE,
        is_adjustment BOOLEAN DEFAULT FALSE,
        is_closing BOOLEAN DEFAULT FALSE,
        is_corrective BOOLEAN DEFAULT FALSE,
        attachment_path TEXT,
        notes TEXT,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Create Journal Entry Lines table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS journal_entry_lines (
        id SERIAL PRIMARY KEY,
        journal_entry_id INTEGER REFERENCES journal_entries(id) NOT NULL,
        line_number INTEGER NOT NULL,
        account_id INTEGER REFERENCES chart_of_accounts(id) NOT NULL,
        description TEXT,
        debit_amount DOUBLE PRECISION DEFAULT 0,
        credit_amount DOUBLE PRECISION DEFAULT 0,
        project_id INTEGER REFERENCES projects(id),
        cost_center TEXT,
        cost_category cost_category,
        notes TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Create Financial Periods table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS financial_periods (
        id SERIAL PRIMARY KEY,
        period_number INTEGER NOT NULL,
        name TEXT NOT NULL,
        fiscal_year INTEGER NOT NULL,
        start_date TIMESTAMP NOT NULL,
        end_date TIMESTAMP NOT NULL,
        status TEXT DEFAULT 'open',
        is_closed BOOLEAN DEFAULT FALSE,
        closed_at TIMESTAMP,
        closed_by INTEGER REFERENCES users(id),
        is_reconciled BOOLEAN DEFAULT FALSE,
        reconciled_at TIMESTAMP,
        reconciled_by INTEGER REFERENCES users(id),
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        notes TEXT
      );
    `);
    
    // Add journalEntryId column to financialTransactions
    await pool.query(`
      ALTER TABLE financial_transactions 
      ADD COLUMN IF NOT EXISTS journal_entry_id INTEGER REFERENCES journal_entries(id);
    `);
    
    // Add budget_line_id column to financialTransactions
    await pool.query(`
      ALTER TABLE financial_transactions 
      ADD COLUMN IF NOT EXISTS budget_line_id INTEGER REFERENCES project_budget_items(id);
    `);
    
    // Add budget_amount column to financialTransactions
    await pool.query(`
      ALTER TABLE financial_transactions 
      ADD COLUMN IF NOT EXISTS budget_amount DOUBLE PRECISION;
    `);
    
    // Add variance_from_budget column to financialTransactions
    await pool.query(`
      ALTER TABLE financial_transactions 
      ADD COLUMN IF NOT EXISTS variance_from_budget DOUBLE PRECISION;
    `);
    
    // Add certificate_id column to journal_entry_lines
    await pool.query(`
      ALTER TABLE journal_entry_lines 
      ADD COLUMN IF NOT EXISTS certificate_id INTEGER REFERENCES payment_certificates(id);
    `);
    
    // Add contract_item_id column to journal_entry_lines
    await pool.query(`
      ALTER TABLE journal_entry_lines 
      ADD COLUMN IF NOT EXISTS contract_item_id INTEGER REFERENCES contract_items(id);
    `);
    
    // Add budget column to journal_entry_lines
    await pool.query(`
      ALTER TABLE journal_entry_lines 
      ADD COLUMN IF NOT EXISTS budget JSONB;
    `);
    
    // Add document_type column if it doesn't exist
    try {
      await pool.query(`
        ALTER TABLE journal_entries 
        ADD COLUMN IF NOT EXISTS document_type TEXT;
      `);
      console.log("Added document_type column to journal_entries table");
    } catch (error) {
      console.error("Error adding document_type column:", error);
    }
    
    // Create expense status enum type if it doesn't exist
    try {
      await pool.query(`
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'expense_status') THEN
            CREATE TYPE expense_status AS ENUM (
              'pending',
              'approved',
              'rejected',
              'paid'
            );
          END IF;
        END$$;
      `);
    } catch (error) {
      console.log("Note: Error creating expense_status enum:", error.message);
    }
    
    // Create cost category enum type if it doesn't exist
    try {
      await pool.query(`
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'cost_category') THEN
            CREATE TYPE cost_category AS ENUM (
              'direct_labor',
              'materials',
              'equipment',
              'subcontractors',
              'overhead',
              'other'
            );
          END IF;
        END$$;
      `);
    } catch (error) {
      console.log("Note: Error creating cost_category enum:", error.message);
    }
    
    // Create project_budget_items table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS project_budget_items (
        id SERIAL PRIMARY KEY,
        project_id INTEGER REFERENCES projects(id) NOT NULL,
        name TEXT NOT NULL,
        code TEXT,
        description TEXT,
        category cost_category,
        amount DOUBLE PRECISION NOT NULL,
        used_amount DOUBLE PRECISION DEFAULT 0,
        remaining_amount DOUBLE PRECISION,
        account_id INTEGER REFERENCES chart_of_accounts(id),
        parent_id INTEGER REFERENCES project_budget_items(id),
        is_summary BOOLEAN DEFAULT FALSE,
        is_active BOOLEAN DEFAULT TRUE,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Create expenses table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS expenses (
        id SERIAL PRIMARY KEY,
        project_id INTEGER REFERENCES projects(id),
        budget_item_id INTEGER REFERENCES project_budget_items(id),
        account_id INTEGER REFERENCES chart_of_accounts(id),
        payment_account_id INTEGER REFERENCES chart_of_accounts(id),
        journal_entry_id INTEGER REFERENCES journal_entries(id),
        
        expense_date TIMESTAMP NOT NULL,
        description TEXT NOT NULL,
        amount DOUBLE PRECISION NOT NULL,
        category cost_category,
        status expense_status DEFAULT 'pending',
        
        payment_method TEXT,
        payment_reference TEXT,
        vendor_id INTEGER,
        vendor_name TEXT,
        
        fiscal_year INTEGER,
        fiscal_period INTEGER,
        
        notes TEXT,
        receipt_path TEXT,
        
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        
        reviewed_at TIMESTAMP,
        reviewed_by INTEGER REFERENCES users(id),
        finance_approved_at TIMESTAMP,
        finance_approved_by INTEGER REFERENCES users(id),
        approved_at TIMESTAMP,
        approved_by INTEGER REFERENCES users(id),
        rejected_at TIMESTAMP,
        rejected_by INTEGER REFERENCES users(id),
        rejection_reason TEXT
      );
    `);
    
    // Update enum types with new values
    try {
      await pool.query(`
        ALTER TYPE financial_account_type ADD VALUE IF NOT EXISTS 'cost_of_sales';
        ALTER TYPE financial_account_type ADD VALUE IF NOT EXISTS 'tax';
        ALTER TYPE financial_account_type ADD VALUE IF NOT EXISTS 'control';
      `);
      
      // Add 'draft' to transaction_status enum
      await pool.query(`
        ALTER TYPE transaction_status ADD VALUE IF NOT EXISTS 'draft';
      `);
      
      console.log("Updated enum types successfully");
    } catch (error) {
      console.log("Note: Could not update enum types. This is often normal if they already exist:", error.message);
    }
    
    console.log("Schema migration completed successfully");
  } catch (error) {
    console.error("Error during schema migration:", error);
  } finally {
    await pool.end();
  }
}

main().catch(console.error);