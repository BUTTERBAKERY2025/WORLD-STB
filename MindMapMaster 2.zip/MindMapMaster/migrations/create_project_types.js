import { sql } from 'drizzle-orm';
import { db } from '../server/db.js';

// Fix: Convert the file to CommonJS format
// This is a temporary solution to work around ESM/CommonJS compatibility issues

async function main() {
  console.log('Creating project_types table...');
  
  await sql`
    CREATE TABLE IF NOT EXISTS project_types (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
    );
  `.execute(db);
  
  console.log('Project types table created successfully');
  
  // إدخال البيانات الافتراضية
  const existingTypes = await db.execute(sql`SELECT COUNT(*) FROM project_types`);
  if (existingTypes.rows[0].count === '0') {
    console.log('Inserting default project types...');
    
    await sql`
      INSERT INTO project_types (name, description)
      VALUES 
        ('road', 'مشاريع الطرق والجسور'),
        ('water', 'مشاريع المياه والصرف الصحي'),
        ('electricity', 'مشاريع الكهرباء والطاقة'),
        ('telecom', 'مشاريع الاتصالات والتقنية'),
        ('building', 'مشاريع المباني والإنشاءات')
    `.execute(db);
    
    console.log('Default project types inserted successfully');
  } else {
    console.log('Project types already exist, skipping default data insertion');
  }
}

main()
  .then(() => {
    console.log('Migration completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration failed:', error);
    process.exit(1);
  });