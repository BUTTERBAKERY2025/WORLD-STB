import { db } from '../db';
import {
  chartOfAccounts,
  journalEntries,
  journalEntryLines,
  projects,
  projectBudgetItems,
  expenses,
  paymentCertificates,
  paymentCertificateItems,
  users,
  financialTransactions,
  type Project,
  type JournalEntry,
  type JournalEntryLine,
  type InsertJournalEntry,
  type InsertJournalEntryLine,
  type PaymentCertificate,
  type PaymentCertificateItem,
  type Expense,
  type InsertExpense,
  type ChartOfAccount,
  type FinancialTransaction,
  type InsertFinancialTransaction
} from '@shared/schema';
import { eq, and, sql, desc, sum, count, isNull, lte, gte, or, between, like } from 'drizzle-orm';
import { alias } from 'drizzle-orm/pg-core';

/**
 * خدمة المحاسبة والمعاملات المالية
 * Accounting and Financial Transactions Service
 */
export class AccountingService {
  /**
   * الحصول على قائمة المعاملات المالية
   * Get list of financial transactions
   */
  async getTransactions(params: {
    page: number;
    limit: number;
    type?: string;
    projectId?: number;
    accountId?: number;
    status?: string;
    search?: string;
    startDate?: string;
    endDate?: string;
    minAmount?: number;
    maxAmount?: number;
  }) {
    try {
      // تحديد بداية ونهاية الصفحة
      const offset = (params.page - 1) * params.limit;
      
      // بناء الاستعلام الأساسي مع استخدام الاسم المستعار بشكل صحيح
      // تعريف الجدول المستعار
      const creditAccountsAlias = alias(chartOfAccounts, 'credit_accounts');
      
      let query = db
        .select({
          transaction: financialTransactions,
          debitAccount: chartOfAccounts,
          creditAccount: creditAccountsAlias,
          project: projects
        })
        .from(financialTransactions)
        .leftJoin(
          chartOfAccounts,
          eq(financialTransactions.debitAccountId, chartOfAccounts.id)
        )
        .leftJoin(
          creditAccountsAlias,
          eq(financialTransactions.creditAccountId, creditAccountsAlias.id)
        )
        .leftJoin(
          projects,
          eq(financialTransactions.projectId, projects.id)
        );
        
      // إضافة شروط التصفية
      let conditions = [];
      
      if (params.type) {
        conditions.push(eq(financialTransactions.type, params.type as any));
      }
      
      if (params.projectId) {
        conditions.push(eq(financialTransactions.projectId, params.projectId));
      }
      
      if (params.accountId) {
        conditions.push(
          or(
            eq(financialTransactions.debitAccountId, params.accountId),
            eq(financialTransactions.creditAccountId, params.accountId)
          )
        );
      }
      
      if (params.status) {
        conditions.push(eq(financialTransactions.status, params.status as any));
      }
      
      if (params.search) {
        conditions.push(
          or(
            like(financialTransactions.description, `%${params.search}%`),
            like(financialTransactions.referenceNumber, `%${params.search}%`)
          )
        );
      }
      
      if (params.startDate) {
        const startDate = new Date(params.startDate);
        conditions.push(gte(financialTransactions.transactionDate, startDate));
      }
      
      if (params.endDate) {
        const endDate = new Date(params.endDate);
        endDate.setHours(23, 59, 59, 999); // End of day
        conditions.push(lte(financialTransactions.transactionDate, endDate));
      }
      
      if (params.minAmount && params.minAmount > 0) {
        conditions.push(gte(financialTransactions.amount, params.minAmount));
      }
      
      if (params.maxAmount && params.maxAmount > 0) {
        conditions.push(lte(financialTransactions.amount, params.maxAmount));
      }
      
      // تطبيق جميع الشروط إذا كانت موجودة
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      
      // الحصول على إجمالي عدد السجلات
      const countResult = await db
        .select({ count: count() })
        .from(financialTransactions)
        .where(conditions.length > 0 ? and(...conditions) : undefined);
      
      const total = Number(countResult[0]?.count || 0);
        
      // ترتيب النتائج حسب أحدث تاريخ معاملة
      query = query.orderBy(desc(financialTransactions.transactionDate));
      
      // تطبيق ترقيم الصفحات
      query = query.limit(params.limit).offset(offset);
      
      // تنفيذ الاستعلام
      const results = await query;
      
      // معالجة النتائج
      const transactions = results.map(row => {
        // استخراج المعلومات الأساسية للمعاملة
        const transaction = row.transaction;
        
        // إضافة معلومات الحسابات
        const debitAccount = row.debitAccount
          ? {
              id: row.debitAccount.id,
              name: row.debitAccount.name,
              code: row.debitAccount.code,
              type: row.debitAccount.type
            }
          : null;
        
        const creditAccount = row.creditAccount
          ? {
              id: row.creditAccount.id,
              name: row.creditAccount.name,
              code: row.creditAccount.code,
              type: row.creditAccount.type
            }
          : null;
        
        // إضافة معلومات المشروع
        const project = row.project
          ? {
              id: row.project.id,
              name: row.project.name
            }
          : null;
        
        // إعادة بناء الكائن النهائي
        return {
          ...transaction,
          debitAccount,
          creditAccount,
          project
        };
      });
      
      // إعادة النتائج مع معلومات الترقيم
      return {
        data: transactions,
        pagination: {
          total,
          page: params.page,
          limit: params.limit,
          totalPages: Math.ceil(total / params.limit)
        }
      };
    } catch (error) {
      console.error("Error getting transactions:", error);
      throw error;
    }
  }
  
  /**
   * الحصول على معاملة مالية محددة
   * Get a specific transaction by ID
   */
  async getTransactionById(id: number) {
    try {
      // استعلام للحصول على معاملة محددة باستخدام المعرف الخاص بها
      // تعريف الجدول المستعار
      const creditAccountsAlias = alias(chartOfAccounts, 'credit_accounts');
      
      const query = db
        .select({
          transaction: financialTransactions,
          debitAccount: chartOfAccounts,
          creditAccount: creditAccountsAlias,
          project: projects
        })
        .from(financialTransactions)
        .leftJoin(
          chartOfAccounts,
          eq(financialTransactions.debitAccountId, chartOfAccounts.id)
        )
        .leftJoin(
          creditAccountsAlias,
          eq(financialTransactions.creditAccountId, creditAccountsAlias.id)
        )
        .leftJoin(
          projects,
          eq(financialTransactions.projectId, projects.id)
        )
        .where(eq(financialTransactions.id, id));
      
      // تنفيذ الاستعلام
      const results = await query;
      
      // إذا لم يتم العثور على المعاملة
      if (results.length === 0) {
        return undefined;
      }
      
      const row = results[0];
      
      // استخراج المعلومات الأساسية للمعاملة
      const transaction = row.transaction;
      
      // إضافة معلومات الحسابات
      const debitAccount = row.debitAccount
        ? {
            id: row.debitAccount.id,
            name: row.debitAccount.name,
            code: row.debitAccount.code,
            type: row.debitAccount.type
          }
        : null;
      
      const creditAccount = row.creditAccount
        ? {
            id: row.creditAccount.id,
            name: row.creditAccount.name,
            code: row.creditAccount.code,
            type: row.creditAccount.type
          }
        : null;
      
      // إضافة معلومات المشروع
      const project = row.project
        ? {
            id: row.project.id,
            name: row.project.name
          }
        : null;
      
      // استعلام للحصول على القيد المحاسبي المرتبط (إن وجد)
      let journalEntry = undefined;
      if (transaction.journalEntryId) {
        const journalQuery = db
          .select({
            journal: journalEntries,
            lines: journalEntryLines
          })
          .from(journalEntries)
          .leftJoin(
            journalEntryLines,
            eq(journalEntries.id, journalEntryLines.journalEntryId)
          )
          .where(eq(journalEntries.id, transaction.journalEntryId));
          
        const journalResult = await journalQuery;
        
        if (journalResult.length > 0) {
          // تنظيم سطور القيد
          const lines = journalResult.map(j => j.lines).filter(Boolean);
          
          journalEntry = {
            ...journalResult[0].journal,
            lines
          };
        }
      }
      
      // إعادة بناء الكائن النهائي
      return {
        ...transaction,
        debitAccount,
        creditAccount,
        project,
        journalEntry
      };
    } catch (error) {
      console.error(`Error getting transaction ${id}:`, error);
      throw error;
    }
  }
  
  /**
   * إنشاء معاملة مالية جديدة
   * Create a new financial transaction
   */
  async createTransaction(transactionData: any) {
    try {
      // إنشاء رقم مرجعي إذا لم يتم تقديمه
      const referenceNumber = transactionData.referenceNumber || 
        `TR-${new Date().getFullYear()}-${Date.now().toString().substring(7, 13)}`;
      
      // إضافة القيم الافتراضية
      const formattedData = {
        ...transactionData,
        referenceNumber,
        status: transactionData.status || "pending",
        // التأكد من أن التاريخ هو كائن Date صالح
        transactionDate: transactionData.transactionDate ? new Date(transactionData.transactionDate) : new Date(),
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // إذا تم طلب إنشاء قيد محاسبي مرتبط
      let journalEntryId = null;
      if (transactionData.createJournalEntry) {
        // إنشاء رقم مرجعي للقيد المحاسبي
        const journalNumber = `JE-${new Date().getFullYear()}-${Date.now().toString().substring(7, 13)}`;
        
        // إدخال بيانات القيد
        // إعداد بيانات القيد المحاسبي بشكل كامل
        const currentDate = new Date();
        const transactionDate = transactionData.transactionDate ? new Date(transactionData.transactionDate) : currentDate;
        
        const journalData = {
          journalNumber,
          journalDate: transactionDate,
          description: transactionData.description || `قيد آلي من معاملة ${referenceNumber}`,
          
          // العلاقات المرجعية
          projectId: transactionData.projectId || null,
          certificateId: transactionData.relatedCertificateId || null,
          
          // بيانات الفترة المالية
          fiscalYear: transactionDate.getFullYear(),
          fiscalPeriod: Math.floor(transactionDate.getMonth() / 3) + 1, // تقدير الربع السنوي
          
          // حالة القيد
          isPosted: false,
          
          // قيم إحصائية
          totalDebit: transactionData.amount,
          totalCredit: transactionData.amount,
          isBalanced: true,
          
          // بيانات المعاملة الأصلية
          documentType: "transaction", // نوع المستند: معاملة مالية
          sourceReference: referenceNumber, // المرجع: رقم المعاملة
          
          // علامات خاصة - افتراضية
          isRecurring: false,
          isAdjustment: false,
          isClosing: false,
          isCorrective: false,
          
          // معلومات المتابعة
          createdBy: transactionData.createdBy || null,
          createdAt: currentDate,
          updatedAt: currentDate
        };
        
        // إدخال القيد في قاعدة البيانات
        const [journal] = await db.insert(journalEntries).values(journalData).returning();
        
        // تحديث معرف القيد
        journalEntryId = journal.id;
        
        // إنشاء سطور القيد مع إضافة كل الحقول المطلوبة
        await db.insert(journalEntryLines).values([
          {
            journalEntryId: journal.id,
            lineNumber: 1, // رقم السطر الأول
            accountId: transactionData.debitAccountId,
            description: transactionData.description || `قيد آلي من معاملة ${referenceNumber}`,
            debitAmount: transactionData.amount,
            creditAmount: 0,
            // العلاقات المرجعية الإضافية
            projectId: transactionData.projectId || null,
            certificateId: transactionData.relatedCertificateId || null,
            costCategory: transactionData.costCategory || null,
            createdAt: new Date(),
            updatedAt: new Date()
          },
          {
            journalEntryId: journal.id,
            lineNumber: 2, // رقم السطر الثاني
            accountId: transactionData.creditAccountId,
            description: transactionData.description || `قيد آلي من معاملة ${referenceNumber}`,
            debitAmount: 0,
            creditAmount: transactionData.amount,
            // العلاقات المرجعية الإضافية
            projectId: transactionData.projectId || null,
            certificateId: transactionData.relatedCertificateId || null,
            costCategory: transactionData.costCategory || null,
            createdAt: new Date(),
            updatedAt: new Date()
          }
        ]);
      }
      
      // إدخال بيانات المعاملة في قاعدة البيانات مع ربطها بالقيد المحاسبي إذا تم إنشاؤه
      const transactionInsertData = {
        ...formattedData,
        journalEntryId
      };
      
      // إدخال المعاملة في قاعدة البيانات
      const [newTransaction] = await db
        .insert(financialTransactions)
        .values(transactionInsertData)
        .returning();
      
      // الآن نقوم بإرجاع المعاملة مع البيانات المرتبطة بها
      return this.getTransactionById(newTransaction.id);
    } catch (error) {
      console.error("Error creating transaction:", error);
      throw error;
    }
  }
  
  /**
   * تحديث معاملة مالية
   * Update a financial transaction
   */
  async updateTransaction(id: number, updates: any) {
    try {
      // الحصول على المعاملة الحالية
      const transaction = await this.getTransactionById(id);
      
      if (!transaction) {
        return null;
      }
      
      // إعداد بيانات التحديث
      const updateData = {
        ...updates,
        updatedAt: new Date()
      };
      
      // تحديث القيد المحاسبي إذا كان موجودًا والمبلغ تغير
      if (transaction.journalEntryId && updates.amount && updates.amount !== transaction.amount) {
        // تحديث بيانات القيد الرئيسي
        await db.update(journalEntries)
          .set({
            totalDebit: updates.amount,
            totalCredit: updates.amount,
            updatedAt: new Date()
          })
          .where(eq(journalEntries.id, transaction.journalEntryId));
        
        // تحديث سطور القيد المحاسبي
        const journalLines = await db
          .select()
          .from(journalEntryLines)
          .where(eq(journalEntryLines.journalEntryId, transaction.journalEntryId));
        
        // التحقق من سطور القيد قبل التحديث
        if (journalLines.length >= 2) {
          // تحديث السطر الأول (الطرف المدين)
          await db.update(journalEntryLines)
            .set({
              debitAmount: updates.amount,
              updatedAt: new Date()
            })
            .where(and(
              eq(journalEntryLines.journalEntryId, transaction.journalEntryId),
              eq(journalEntryLines.accountId, transaction.debitAccountId)
            ));
          
          // تحديث السطر الثاني (الطرف الدائن)
          await db.update(journalEntryLines)
            .set({
              creditAmount: updates.amount,
              updatedAt: new Date()
            })
            .where(and(
              eq(journalEntryLines.journalEntryId, transaction.journalEntryId),
              eq(journalEntryLines.accountId, transaction.creditAccountId)
            ));
        }
      }
      
      // تحديث بيانات المعاملة في قاعدة البيانات
      await db
        .update(financialTransactions)
        .set(updateData)
        .where(eq(financialTransactions.id, id));
      
      // إرجاع البيانات المحدثة مع العلاقات
      return this.getTransactionById(id);
    } catch (error) {
      console.error(`Error updating transaction ${id}:`, error);
      throw error;
    }
  }
  
  /**
   * حذف معاملة مالية
   * Delete a financial transaction
   */
  async deleteTransaction(id: number) {
    try {
      // الحصول على المعاملة للتأكد من وجودها
      const transaction = await this.getTransactionById(id);
      
      if (!transaction) {
        return null;
      }
      
      // حذف القيد المحاسبي المرتبط إذا كان موجوداً
      if (transaction.journalEntryId) {
        // حذف سطور القيد أولاً (لمراعاة قيود الـ foreign key)
        await db.delete(journalEntryLines)
          .where(eq(journalEntryLines.journalEntryId, transaction.journalEntryId));
        
        // ثم حذف القيد نفسه
        await db.delete(journalEntries)
          .where(eq(journalEntries.id, transaction.journalEntryId));
      }
      
      // حذف المعاملة نفسها
      const result = await db.delete(financialTransactions)
        .where(eq(financialTransactions.id, id))
        .returning();
      
      return result.length > 0;
    } catch (error) {
      console.error(`Error deleting transaction ${id}:`, error);
      throw error;
    }
  }
  
  /**
   * حذف مجموعة من المعاملات المالية
   * Delete multiple financial transactions
   */
  async batchDeleteTransactions(ids: number[]) {
    try {
      const validIds = [];
      const deletedIds = [];
      
      // التحقق من وجود المعاملات والحصول على معرفات القيود المحاسبية المرتبطة
      for (const id of ids) {
        const transaction = await this.getTransactionById(id);
        if (transaction) {
          validIds.push({
            id: transaction.id,
            journalEntryId: transaction.journalEntryId
          });
        }
      }
      
      // عدم إجراء أي عملية إذا لم يتم العثور على معاملات صالحة
      if (validIds.length === 0) {
        return {
          success: true,
          count: 0,
          deletedIds: []
        };
      }
      
      // حذف المعاملات مع القيود المحاسبية المرتبطة
      for (const item of validIds) {
        try {
          // حذف القيد المحاسبي المرتبط إذا كان موجوداً
          if (item.journalEntryId) {
            // حذف سطور القيد أولاً (لمراعاة قيود الـ foreign key)
            await db.delete(journalEntryLines)
              .where(eq(journalEntryLines.journalEntryId, item.journalEntryId));
            
            // ثم حذف القيد نفسه
            await db.delete(journalEntries)
              .where(eq(journalEntries.id, item.journalEntryId));
          }
          
          // حذف المعاملة نفسها
          const result = await db.delete(financialTransactions)
            .where(eq(financialTransactions.id, item.id))
            .returning();
          
          if (result.length > 0) {
            deletedIds.push(item.id);
          }
        } catch (innerError) {
          console.error(`Error deleting transaction ${item.id}:`, innerError);
          // استمر في المحاولة مع المعاملات الأخرى
        }
      }
      
      return {
        success: true,
        count: deletedIds.length,
        deletedIds
      };
    } catch (error) {
      console.error("Error batch deleting transactions:", error);
      throw error;
    }
  }
  
  /**
   * نسخ معاملة مالية
   * Duplicate a financial transaction
   */
  async duplicateTransaction(id: number) {
    try {
      // الحصول على المعاملة الأصلية
      const transaction = await this.getTransactionById(id);
      
      if (!transaction) {
        return null;
      }
      
      // استخراج البيانات الأساسية وتجاهل المعرفات والبيانات المُنشأة تلقائيًا
      const { 
        id: _, 
        referenceNumber: __, 
        createdAt: ___, 
        updatedAt: ____, 
        journalEntryId: _____,
        journalEntry: ______,
        debitAccount: _______,
        creditAccount: ________,
        project: _________,
        ...transactionData 
      } = transaction;
      
      // تعديل بعض البيانات للمعاملة الجديدة
      const newTransactionData = {
        ...transactionData,
        status: "pending", // تعيين الحالة للمعاملة الجديدة إلى "قيد الانتظار"
        description: `${transactionData.description || ''} (نسخة)`, // إضافة كلمة "نسخة" للوصف
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // إنشاء المعاملة الجديدة في قاعدة البيانات
      return await this.createTransaction(newTransactionData);
    } catch (error) {
      console.error(`Error duplicating transaction ${id}:`, error);
      throw error;
    }
  }
  
  /**
   * الحصول على قائمة الحسابات
   * Get chart of accounts
   */
  async getAccounts() {
    try {
      // استرجاع الحسابات من قاعدة البيانات
      const accountsList = await db
        .select()
        .from(chartOfAccounts)
        .orderBy(chartOfAccounts.code);
      
      return accountsList;
    } catch (error) {
      console.error("Error getting accounts:", error);
      throw error;
    }
  }
  
  /**
   * الحصول على قائمة المشاريع
   * Get projects list
   */
  async getProjects() {
    try {
      // الحصول على المشاريع من قاعدة البيانات
      const projectsList = await db
        .select()
        .from(projects)
        .orderBy(projects.name);
      
      return projectsList;
    } catch (error) {
      console.error("Error getting projects:", error);
      // في حالة حدوث خطأ، نرجع مصفوفة فارغة لمنع توقف النظام
      return [];
    }
  }
  
  /**
   * الحصول على قائمة المستخلصات
   * Get certificates list
   */
  async getCertificates() {
    try {
      // استرجاع المستخلصات من قاعدة البيانات
      const certificatesList = await db
        .select({
          id: paymentCertificates.id,
          certificateNumber: paymentCertificates.certificateNumber,
          projectId: paymentCertificates.projectId,
          amount: paymentCertificates.totalAmount, // نستخدم إجمالي قيمة المستخلص
          status: paymentCertificates.status,
          fromDate: paymentCertificates.fromDate,
          toDate: paymentCertificates.toDate,
          // تأكد من أن العمود موجود فعلياً في قاعدة البيانات
          // fiscalYear: paymentCertificates.fiscalYear,
          type: paymentCertificates.type
        })
        .from(paymentCertificates)
        .orderBy(paymentCertificates.certificateNumber);
      
      return certificatesList;
    } catch (error) {
      console.error("Error getting certificates:", error);
      // في حالة حدوث خطأ، نرجع مصفوفة فارغة لمنع توقف النظام
      return [];
    }
  }
  
  /**
   * الحصول على قائمة بنود الميزانية
   * Get budget items list
   */
  async getBudgetItems() {
    try {
      // استرجاع بنود الميزانية من قاعدة البيانات
      const budgetItemsList = await db
        .select({
          id: projectBudgetItems.id,
          projectId: projectBudgetItems.projectId,
          name: projectBudgetItems.name,
          budgetedAmount: projectBudgetItems.amount,
          category: projectBudgetItems.category,
          usedAmount: projectBudgetItems.usedAmount,
          remainingAmount: projectBudgetItems.remainingAmount,
          code: projectBudgetItems.code,
          accountId: projectBudgetItems.accountId
        })
        .from(projectBudgetItems)
        .orderBy(projectBudgetItems.projectId, projectBudgetItems.name);
      
      return budgetItemsList;
    } catch (error) {
      console.error("Error getting budget items:", error);
      // في حالة حدوث خطأ، نرجع مصفوفة فارغة لمنع توقف النظام
      return [];
    }
  }
  
  /**
   * الحصول على قائمة الدخل
   * Get income statement
   */
  async getIncomeStatement(startDate: string, endDate: string, fiscalYear: number) {
    try {
      // تحويل التواريخ لتنسيق مناسب
      const fromDate = new Date(startDate);
      const toDate = new Date(endDate);
      
      // الحصول على الإيرادات من القيود المحاسبية
      const revenueAccounts = await db
        .select({
          accountId: journalEntryLines.accountId,
          accountName: chartOfAccounts.name,
          accountCode: chartOfAccounts.code,
          totalAmount: sql`SUM(CASE WHEN ${journalEntryLines.creditAmount} > 0 THEN ${journalEntryLines.creditAmount} ELSE 0 END)`
        })
        .from(journalEntryLines)
        .innerJoin(
          journalEntries,
          eq(journalEntryLines.journalEntryId, journalEntries.id)
        )
        .innerJoin(
          chartOfAccounts,
          eq(journalEntryLines.accountId, chartOfAccounts.id)
        )
        .where(
          and(
            eq(chartOfAccounts.type, 'revenue'),
            gte(journalEntries.journalDate, fromDate),
            lte(journalEntries.journalDate, toDate),
            ...(fiscalYear ? [eq(journalEntries.fiscalYear, fiscalYear)] : [])
          )
        )
        .groupBy(journalEntryLines.accountId, chartOfAccounts.name, chartOfAccounts.code);
      
      // الحصول على المصروفات من القيود المحاسبية
      const expenseAccounts = await db
        .select({
          accountId: journalEntryLines.accountId,
          accountName: chartOfAccounts.name,
          accountCode: chartOfAccounts.code,
          totalAmount: sql`SUM(CASE WHEN ${journalEntryLines.debitAmount} > 0 THEN ${journalEntryLines.debitAmount} ELSE 0 END)`
        })
        .from(journalEntryLines)
        .innerJoin(
          journalEntries,
          eq(journalEntryLines.journalEntryId, journalEntries.id)
        )
        .innerJoin(
          chartOfAccounts,
          eq(journalEntryLines.accountId, chartOfAccounts.id)
        )
        .where(
          and(
            eq(chartOfAccounts.type, 'expense'),
            gte(journalEntries.journalDate, fromDate),
            lte(journalEntries.journalDate, toDate),
            ...(fiscalYear ? [eq(journalEntries.fiscalYear, fiscalYear)] : [])
          )
        )
        .groupBy(journalEntryLines.accountId, chartOfAccounts.name, chartOfAccounts.code);
      
      // حساب المجاميع
      const revenueTotal = revenueAccounts.reduce((sum, item) => sum + Number(item.totalAmount), 0);
      const expenseTotal = expenseAccounts.reduce((sum, item) => sum + Number(item.totalAmount), 0);
      const grossProfit = revenueTotal - expenseTotal;
      const profitMargin = revenueTotal > 0 ? Math.round((grossProfit / revenueTotal) * 100) : 0;
      
      // تنسيق البيانات للعرض
      return {
        startDate,
        endDate,
        fiscalYear,
        revenue: {
          total: revenueTotal,
          details: revenueAccounts.map(item => ({
            accountId: item.accountId,
            account: item.accountName,
            code: item.accountCode,
            amount: Number(item.totalAmount)
          }))
        },
        expenses: {
          total: expenseTotal,
          details: expenseAccounts.map(item => ({
            accountId: item.accountId,
            account: item.accountName,
            code: item.accountCode,
            amount: Number(item.totalAmount)
          }))
        },
        grossProfit,
        netProfit: grossProfit, // يمكن تعديل هذا لاحقًا إذا كانت هناك مصروفات أو إيرادات أخرى
        profitMargin
      };
    } catch (error) {
      console.error("Error getting income statement:", error);
      // في حالة حدوث خطأ، نرجع هيكل بيانات فارغ لمنع توقف النظام
      return {
        startDate,
        endDate,
        fiscalYear,
        revenue: { total: 0, details: [] },
        expenses: { total: 0, details: [] },
        grossProfit: 0,
        netProfit: 0,
        profitMargin: 0
      };
    }
  }
}

export const accountingService = new AccountingService();