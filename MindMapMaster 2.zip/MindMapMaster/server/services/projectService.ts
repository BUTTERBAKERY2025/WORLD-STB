import { storage } from "../storage";
import { Project, Task, ProjectBudget, Expense } from "@shared/schema";

interface ProjectKPI {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  delayedProjects: number;
  totalBudget: number;
  spentBudget: number;
  averageProgress: number;
  projectsByStatus: {
    name: string;
    value: number;
    color: string;
  }[];
  projectsByType: {
    name: string;
    value: number;
    color: string;
  }[];
  recentProjects: Project[];
  budgetPerformance: {
    name: string;
    planned: number;
    actual: number;
  }[];
  schedulePerformance: {
    name: string;
    planned: number;
    actual: number;
  }[];
}

const STATUS_COLORS = {
  planning: '#6366f1',    // Indigo
  in_progress: '#0ea5e9', // Sky
  delayed: '#f97316',     // Orange
  completed: '#22c55e',   // Green  
  stopped: '#f43f5e',     // Rose
};

const TYPE_COLORS = {
  road: '#3b82f6',       // Blue
  water: '#06b6d4',      // Cyan
  electricity: '#facc15', // Yellow
  telecom: '#a855f7',    // Purple
  building: '#22c55e',   // Green
};

export const projectService = {
  // استخراج بيانات مؤشرات الأداء للمشاريع
  async getProjectsKPIs(): Promise<ProjectKPI> {
    try {
      // جلب كل المشاريع
      const projects = await storage.listProjects();
      
      // جلب المهام والميزانيات والمصروفات المرتبطة بالمشاريع
      // في الحالات الحقيقية، هذه البيانات ستكون أكثر تعقيدًا وستحتاج لجلب بيانات أكثر من قاعدة البيانات
      const projectIds = projects.map(p => p.id);
      
      // لن نقوم بمحاولة استدعاء البيانات التي تتطلب جداول غير موجودة
      // وبدلاً من ذلك سنستخدم بيانات فارغة للتأكد من استمرار التطبيق
      const tasks: any[] = [];
      const expenses: any[] = [];
      
      // إجمالي عدد المشاريع
      const totalProjects = projects.length;
      
      // عدد المشاريع حسب الحالة
      const statusCounts: Record<string, number> = {
        planning: 0,
        in_progress: 0,
        delayed: 0,
        completed: 0,
        stopped: 0,
      };
      
      // عدد المشاريع حسب النوع
      const typeCounts: Record<string, number> = {
        road: 0,
        water: 0,
        electricity: 0,
        telecom: 0,
        building: 0,
      };
      
      // بيانات أداء الميزانية والجدول الزمني
      // في هذا المثال، نحن نستخدم بيانات افتراضية، لكن في الحالات الحقيقية سيتم حسابها من البيانات الفعلية
      const budgetPerformance = [
        { name: 'Jan', planned: 1000000, actual: 900000 },
        { name: 'Feb', planned: 2000000, actual: 1800000 },
        { name: 'Mar', planned: 3000000, actual: 2700000 },
        { name: 'Apr', planned: 4000000, actual: 3500000 },
        { name: 'May', planned: 5000000, actual: 4800000 },
        { name: 'Jun', planned: 6000000, actual: 5900000 },
      ];
      
      const schedulePerformance = [
        { name: 'Jan', planned: 10, actual: 8 },
        { name: 'Feb', planned: 20, actual: 18 },
        { name: 'Mar', planned: 30, actual: 27 },
        { name: 'Apr', planned: 40, actual: 35 },
        { name: 'May', planned: 50, actual: 48 },
        { name: 'Jun', planned: 60, actual: 59 },
      ];
      
      // حساب الإحصائيات
      let totalProgress = 0;
      let totalBudget = 0;
      let spentBudget = 0;
      
      for (const project of projects) {
        // عدد المشاريع حسب الحالة
        if (project.status && statusCounts.hasOwnProperty(project.status)) {
          statusCounts[project.status]++;
        }
        
        // عدد المشاريع حسب النوع
        if (project.type && typeCounts.hasOwnProperty(project.type)) {
          typeCounts[project.type]++;
        }
        
        // إضافة للإحصائيات
        totalProgress += project.progress || 0;
        totalBudget += project.budget || 0;
        
        // تقدير المصروفات (في النظام الحقيقي، ستكون هناك طريقة أفضل لحساب المصروفات الفعلية)
        if (project.progress) {
          spentBudget += (project.budget || 0) * (project.progress / 100);
        }
      }
      
      // حساب متوسط التقدم
      const averageProgress = totalProjects > 0 ? Math.round(totalProgress / totalProjects) : 0;
      
      // المشاريع النشطة (التخطيط + قيد التنفيذ + متأخرة)
      const activeProjects = statusCounts.planning + statusCounts.in_progress + statusCounts.delayed;
      
      // المشاريع المكتملة
      const completedProjects = statusCounts.completed;
      
      // المشاريع المتأخرة
      const delayedProjects = statusCounts.delayed;
      
      // تحويل التعدادات إلى مصفوفات للرسوم البيانية
      const projectsByStatus = Object.entries(statusCounts).map(([status, count]) => ({
        name: status, // سيتم ترجمة هذا في واجهة المستخدم باستخدام i18n
        value: count,
        color: STATUS_COLORS[status as keyof typeof STATUS_COLORS],
      }));
      
      const projectsByType = Object.entries(typeCounts).map(([type, count]) => ({
        name: type, // سيتم ترجمة هذا في واجهة المستخدم باستخدام i18n
        value: count,
        color: TYPE_COLORS[type as keyof typeof TYPE_COLORS],
      }));
      
      // المشاريع الأخيرة (أحدث 5 مشاريع)
      const recentProjects = [...projects]
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, 5);
      
      // إعادة البيانات
      return {
        totalProjects,
        activeProjects,
        completedProjects,
        delayedProjects,
        totalBudget,
        spentBudget,
        averageProgress,
        projectsByStatus,
        projectsByType,
        recentProjects,
        budgetPerformance,
        schedulePerformance,
      };
    } catch (error) {
      console.error("Error calculating project KPIs:", error);
      throw error;
    }
  },
  
  // استخراج مؤشرات الأداء لمشروع معين
  async getProjectKPIs(projectId: number) {
    try {
      const project = await storage.getProject(projectId);
      if (!project) {
        throw new Error("Project not found");
      }
      
      // جلب المهام والميزانيات والمصروفات المرتبطة بالمشروع
      // نستخدم بيانات بديلة مؤقتة في حالة فشل استدعاء قاعدة البيانات
      let tasks: any[] = [];
      let expenses: any[] = [];
      
      try {
        tasks = await storage.listTasksByProject(projectId) || [];
      } catch (error) {
        console.log("Error fetching tasks, using empty array instead:", error);
        tasks = [];
      }
      
      try {
        // محاولة جلب المصروفات إذا كان الجدول موجودًا
        expenses = await storage.listProjectExpenses(projectId) || [];
      } catch (error) {
        console.log("Error listing project expenses:", error);
        // استخدام مصفوفة فارغة لمنع توقف التطبيق
        expenses = [];
      }
      
      // بيانات الأداء المالي
      const totalBudget = project.budget || 0;
      const totalExpense = expenses.reduce((sum: number, expense: any) => sum + (expense.amount || 0), 0);
      const budgetRemaining = totalBudget - totalExpense;
      const budgetUtilization = totalBudget > 0 ? (totalExpense / totalBudget) * 100 : 0;
      
      // مؤشرات الجدول الزمني
      // حساب تقدم الجدول الزمني استنادًا إلى المدة المنقضية من المشروع
      let timeProgress = 0;
      if (project.startDate && project.endDate) {
        const now = new Date();
        const start = new Date(project.startDate);
        const end = new Date(project.endDate);
        const totalDuration = end.getTime() - start.getTime();
        const elapsedDuration = now.getTime() - start.getTime();
        
        if (totalDuration > 0) {
          timeProgress = Math.min(100, Math.max(0, (elapsedDuration / totalDuration) * 100));
        }
      }
      
      // مؤشر أداء الجدول الزمني (SPI)
      // SPI = تقدم العمل الفعلي / تقدم الجدول الزمني المخطط
      const schedulePerformanceIndex = timeProgress > 0 ? (project.progress || 0) / timeProgress : 0;
      
      // تصنيف أداء المشروع
      let performanceStatus = 'on_track'; // on_track, ahead_of_schedule, slightly_behind, severely_behind
      
      if (schedulePerformanceIndex >= 1.1) {
        performanceStatus = 'ahead_of_schedule';
      } else if (schedulePerformanceIndex >= 0.9 && schedulePerformanceIndex < 1.1) {
        performanceStatus = 'on_track';
      } else if (schedulePerformanceIndex >= 0.7 && schedulePerformanceIndex < 0.9) {
        performanceStatus = 'slightly_behind';
      } else {
        performanceStatus = 'severely_behind';
      }
      
      return {
        financialMetrics: {
          totalBudget,
          totalExpense,
          budgetRemaining,
          budgetUtilization: Math.round(budgetUtilization),
        },
        scheduleMetrics: {
          workProgress: project.progress || 0,
          timeProgress: Math.round(timeProgress),
          schedulePerformanceIndex: schedulePerformanceIndex.toFixed(2),
          performanceStatus,
        },
        taskMetrics: {
          totalTasks: tasks.length,
          completedTasks: tasks.filter((task: any) => task.status === 'completed').length,
          inProgressTasks: tasks.filter((task: any) => task.status === 'in_progress').length,
          delayedTasks: tasks.filter((task: any) => task.status === 'delayed').length,
        },
        riskMetrics: {
          highRisks: 0, // ستحتاج إلى تنفيذ وظيفة للحصول على المخاطر الفعلية
          mediumRisks: 0,
          lowRisks: 0,
        }
      };
    } catch (error) {
      console.error(`Error calculating KPIs for project ${projectId}:`, error);
      throw error;
    }
  }
};