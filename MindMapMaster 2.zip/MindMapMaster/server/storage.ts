import { eq, and, sql, desc, count, asc, inArray } from 'drizzle-orm';
import { db } from './db';

import {
  users, User, InsertUser,
  projects, Project, InsertProject, 
  tasks, Task, InsertTask,
  financialTransactions, FinancialTransaction, InsertFinancialTransaction,
  assets, Asset, InsertAsset,
  resources, Resource, InsertResource,
  documents, Document, InsertDocument,
  risks, Risk, InsertRisk,
  chartOfAccounts, ChartOfAccount, InsertChartOfAccount,
  projectBudgets, ProjectBudget, InsertProjectBudget,
  financialReports, FinancialReport, InsertFinancialReport,
  contractItems, ContractItem, InsertContractItem,
  paymentCertificates, PaymentCertificate, InsertPaymentCertificate,
  paymentCertificateItems, PaymentCertificateItem, InsertPaymentCertificateItem,
  certificateApprovals, CertificateApproval, InsertCertificateApproval,
  projectPhotos, ProjectPhoto, InsertProjectPhoto,
  journalEntries, JournalEntry, InsertJournalEntry,
  journalEntryLines, JournalEntryLine, InsertJournalEntryLine,
  financialPeriods, FinancialPeriod, InsertFinancialPeriod,
  expenses, Expense, InsertExpense,
  projectBudgetItems, ProjectBudgetItem, InsertProjectBudgetItem
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  listUsers(): Promise<User[]>;

  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  listProjects(): Promise<Project[]>;
  listProjectsByType(type: string): Promise<Project[]>;
  listProjectsByStatus(status: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Task operations
  getTask(id: number): Promise<Task | undefined>;
  listTasksByProject(projectId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;

  // Financial operations
  getFinancialTransaction(id: number): Promise<FinancialTransaction | undefined>;
  listFinancialTransactions(): Promise<FinancialTransaction[]>;
  listFinancialTransactionsByProject(projectId: number): Promise<FinancialTransaction[]>;
  createFinancialTransaction(transaction: InsertFinancialTransaction): Promise<FinancialTransaction>;
  deleteFinancialTransaction(id: number): Promise<boolean>;

  // Asset operations
  getAsset(id: number): Promise<Asset | undefined>;
  listAssets(): Promise<Asset[]>;
  listAssetsByProject(projectId: number): Promise<Asset[]>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAsset(id: number, asset: Partial<Asset>): Promise<Asset | undefined>;
  deleteAsset(id: number): Promise<boolean>;

  // Resource operations
  getResource(id: number): Promise<Resource | undefined>;
  listResources(): Promise<Resource[]>;
  listResourcesByProject(projectId: number): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
  updateResource(id: number, resource: Partial<Resource>): Promise<Resource | undefined>;
  deleteResource(id: number): Promise<boolean>;

  // Document operations
  getDocument(id: number): Promise<Document | undefined>;
  listDocuments(): Promise<Document[]>;
  listDocumentsByProject(projectId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  deleteDocument(id: number): Promise<boolean>;

  // Risk operations
  getRisk(id: number): Promise<Risk | undefined>;
  listRisks(): Promise<Risk[]>;
  listRisksByProject(projectId: number): Promise<Risk[]>;
  listRisksByLevel(level: string): Promise<Risk[]>;
  createRisk(risk: InsertRisk): Promise<Risk>;
  updateRisk(id: number, risk: Partial<Risk>): Promise<Risk | undefined>;
  deleteRisk(id: number): Promise<boolean>;

  // Chart of Accounts operations
  getAccount(id: number): Promise<ChartOfAccount | undefined>;
  getAccountByCode(code: string): Promise<ChartOfAccount | undefined>;
  listAccounts(): Promise<ChartOfAccount[]>;
  listAccountsByType(type: string): Promise<ChartOfAccount[]>;
  listRootAccounts(): Promise<ChartOfAccount[]>;
  listChildAccounts(parentId: number): Promise<ChartOfAccount[]>;
  createAccount(account: InsertChartOfAccount): Promise<ChartOfAccount>;
  updateAccount(id: number, account: Partial<ChartOfAccount>): Promise<ChartOfAccount | undefined>;
  deleteAccount(id: number): Promise<boolean>;
  
  // Project Budget operations
  getProjectBudget(id: number): Promise<ProjectBudget | undefined>;
  listProjectBudgets(): Promise<ProjectBudget[]>;
  listProjectBudgetsByProject(projectId: number): Promise<ProjectBudget[]>;
  listProjectBudgetsByYear(fiscalYear: number): Promise<ProjectBudget[]>;
  createProjectBudget(budget: InsertProjectBudget): Promise<ProjectBudget>;
  updateProjectBudget(id: number, budget: Partial<ProjectBudget>): Promise<ProjectBudget | undefined>;
  deleteProjectBudget(id: number): Promise<boolean>;
  
  // Financial Reports operations
  getFinancialReport(id: number): Promise<FinancialReport | undefined>;
  listFinancialReports(): Promise<FinancialReport[]>;
  createFinancialReport(report: InsertFinancialReport): Promise<FinancialReport>;
  updateFinancialReport(id: number, report: Partial<FinancialReport>): Promise<FinancialReport | undefined>;
  deleteFinancialReport(id: number): Promise<boolean>;
  
  // Contract Items operations
  getContractItem(id: number): Promise<ContractItem | undefined>;
  listContractItems(): Promise<ContractItem[]>;
  listContractItemsByProject(projectId: number): Promise<ContractItem[]>;
  createContractItem(item: InsertContractItem): Promise<ContractItem>;
  updateContractItem(id: number, item: Partial<ContractItem>): Promise<ContractItem | undefined>;
  deleteContractItem(id: number): Promise<boolean>;
  
  // Payment Certificates operations
  getPaymentCertificate(id: number): Promise<PaymentCertificate | undefined>;
  listPaymentCertificates(): Promise<PaymentCertificate[]>;
  listPaymentCertificatesByProject(projectId: number): Promise<PaymentCertificate[]>;
  listPaymentCertificatesByType(type: string): Promise<PaymentCertificate[]>;
  listPaymentCertificatesByStatus(status: string): Promise<PaymentCertificate[]>;
  createPaymentCertificate(certificate: InsertPaymentCertificate): Promise<PaymentCertificate>;
  updatePaymentCertificate(id: number, certificate: Partial<PaymentCertificate>): Promise<PaymentCertificate | undefined>;
  deletePaymentCertificate(id: number): Promise<boolean>;
  submitPaymentCertificate(id: number): Promise<PaymentCertificate | undefined>;
  approvePaymentCertificate(id: number, level: string, approverId: number, comments?: string): Promise<PaymentCertificate | undefined>;
  rejectPaymentCertificate(id: number, level: string, approverId: number, comments: string): Promise<PaymentCertificate | undefined>;
  markPaymentCertificateAsPaid(id: number): Promise<PaymentCertificate | undefined>;
  
  // Payment Certificate Items operations
  getPaymentCertificateItem(id: number): Promise<PaymentCertificateItem | undefined>;
  listPaymentCertificateItems(certificateId: number): Promise<PaymentCertificateItem[]>;
  createPaymentCertificateItem(item: InsertPaymentCertificateItem): Promise<PaymentCertificateItem>;
  updatePaymentCertificateItem(id: number, item: Partial<PaymentCertificateItem>): Promise<PaymentCertificateItem | undefined>;
  deletePaymentCertificateItem(id: number): Promise<boolean>;
  
  // Certificate Approvals operations
  getCertificateApproval(id: number): Promise<CertificateApproval | undefined>;
  listCertificateApprovals(certificateId: number): Promise<CertificateApproval[]>;
  createCertificateApproval(approval: InsertCertificateApproval): Promise<CertificateApproval>;
  updateCertificateApproval(id: number, approval: Partial<CertificateApproval>): Promise<CertificateApproval | undefined>;
  
  // Project Photos operations
  getProjectPhoto(id: number): Promise<ProjectPhoto | undefined>;
  listProjectPhotosByProject(projectId: number): Promise<ProjectPhoto[]>;
  createProjectPhoto(photo: InsertProjectPhoto): Promise<ProjectPhoto>;
  deleteProjectPhoto(id: number): Promise<boolean>;

  // Financial Statistics
  getFinancialStats(): Promise<{
    totalIncome: number;
    totalExpenses: number;
    currentBalance: number;
    transactionsByType: Record<string, number>;
    recentTransactions: FinancialTransaction[];
  }>;
  
  // Payment Certificate Statistics
  getPaymentCertificateStats(projectId?: number): Promise<{
    totalCertificates: number;
    totalPaid: number;
    totalAmount: number;
    paidAmount: number;
    certificatesByType: Record<string, number>;
    certificatesByStatus: Record<string, number>;
  }>;
  
  // Journal Entries operations
  getJournalEntry(id: number): Promise<JournalEntry | undefined>;
  listJournalEntries(): Promise<JournalEntry[]>;
  listJournalEntriesByProject(projectId: number): Promise<JournalEntry[]>;
  listJournalEntriesByFiscalPeriod(fiscalYear: number, fiscalPeriod: number): Promise<JournalEntry[]>;
  listJournalEntriesByStatus(isPosted: boolean): Promise<JournalEntry[]>;
  listJournalEntriesByCertificate(certificateId: number): Promise<JournalEntry[]>;
  createJournalEntry(entry: InsertJournalEntry, lines: InsertJournalEntryLine[]): Promise<JournalEntry>;
  updateJournalEntry(id: number, entry: Partial<JournalEntry>): Promise<JournalEntry | undefined>;
  deleteJournalEntry(id: number): Promise<boolean>;
  postJournalEntry(id: number, userId: number): Promise<JournalEntry | undefined>;
  
  // Journal Entry Lines operations
  getJournalEntryLine(id: number): Promise<JournalEntryLine | undefined>;
  listJournalEntryLines(journalEntryId: number): Promise<JournalEntryLine[]>;
  createJournalEntryLine(line: InsertJournalEntryLine): Promise<JournalEntryLine>;
  updateJournalEntryLine(id: number, line: Partial<JournalEntryLine>): Promise<JournalEntryLine | undefined>;
  deleteJournalEntryLine(id: number): Promise<boolean>;
  
  // Financial Periods operations
  getFinancialPeriod(id: number): Promise<FinancialPeriod | undefined>;
  listFinancialPeriods(): Promise<FinancialPeriod[]>;
  listFinancialPeriodsByYear(fiscalYear: number): Promise<FinancialPeriod[]>;
  createFinancialPeriod(period: InsertFinancialPeriod): Promise<FinancialPeriod>;
  updateFinancialPeriod(id: number, period: Partial<FinancialPeriod>): Promise<FinancialPeriod | undefined>;
  closeFinancialPeriod(id: number, userId: number): Promise<FinancialPeriod | undefined>;
  reopenFinancialPeriod(id: number): Promise<FinancialPeriod | undefined>;
  reconcileFinancialPeriod(id: number, userId: number): Promise<FinancialPeriod | undefined>;

  // Dashboard statistics
  getProjectStats(): Promise<{ 
    totalProjects: number;
    activeProjects: number;
    totalBudget: number;
    totalResources: number;
    projectsByType: Record<string, number>;
    projectsByStatus: Record<string, number>;
  }>;
  
  getRiskStats(): Promise<{
    totalRisks: number;
    risksByLevel: Record<string, number>;
  }>;

  // Project Budget Items operations
  listProjectBudgetItems(projectId: number): Promise<ProjectBudgetItem[]>;
  createProjectBudgetItem(item: InsertProjectBudgetItem): Promise<ProjectBudgetItem>;
  getProjectBudgetItem(id: number): Promise<ProjectBudgetItem | undefined>;
  updateProjectBudgetItem(id: number, item: Partial<ProjectBudgetItem>): Promise<ProjectBudgetItem | undefined>;
  deleteProjectBudgetItem(id: number): Promise<boolean>;

  // Project Expenses operations
  listProjectExpenses(projectId: number): Promise<Expense[]>;
  getExpense(id: number): Promise<Expense | undefined>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<Expense>): Promise<Expense | undefined>;
  approveExpense(id: number, approverId: number, comments?: string): Promise<Expense | undefined>;
  rejectExpense(id: number, approverId: number, comments: string): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<boolean>;
}

/**
 * In-memory storage implementation for development and testing
 * This class is kept for reference and as a fallback, and is no longer used
 * as we've transitioned to a full PostgreSQL database implementation.
 */
// @ts-ignore - We're ignoring the implementation errors since this class is no longer used
export class MemStorage implements IStorage {
  private usersData: Map<number, User>;
  private projectsData: Map<number, Project>;
  private tasksData: Map<number, Task>;
  private financialTransactionsData: Map<number, FinancialTransaction>;
  private assetsData: Map<number, Asset>;
  private resourcesData: Map<number, Resource>;
  private documentsData: Map<number, Document>;
  private risksData: Map<number, Risk>;
  
  private userCurrentId: number;
  private projectCurrentId: number;
  private taskCurrentId: number;
  private financialTransactionCurrentId: number;
  private assetCurrentId: number;
  private resourceCurrentId: number;
  private documentCurrentId: number;
  private riskCurrentId: number;

  constructor() {
    this.usersData = new Map();
    this.projectsData = new Map();
    this.tasksData = new Map();
    this.financialTransactionsData = new Map();
    this.assetsData = new Map();
    this.resourcesData = new Map();
    this.documentsData = new Map();
    this.risksData = new Map();
    
    this.userCurrentId = 1;
    this.projectCurrentId = 1;
    this.taskCurrentId = 1;
    this.financialTransactionCurrentId = 1;
    this.assetCurrentId = 1;
    this.resourceCurrentId = 1;
    this.documentCurrentId = 1;
    this.riskCurrentId = 1;

    // Initialize with sample admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      fullName: "م. أحمد الخالدي",
      email: "admin@example.com",
      role: "admin",
      language: "ar",
      profileImage: "",
      lastLogin: new Date()
    });

    // Initialize with some sample projects
    this.initializeSampleData();
  }

  // Initialize some sample data for development
  private initializeSampleData() {
    // Implementation details hidden for brevity
  }

  // User methods - implementation details hidden for brevity
  async getUser(id: number): Promise<User | undefined> {
    return this.usersData.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersData.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id } as User;
    this.usersData.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.usersData.set(id, updatedUser);
    return updatedUser;
  }

  async listUsers(): Promise<User[]> {
    return Array.from(this.usersData.values());
  }

  // Project methods - implementation details hidden for brevity
  async getProject(id: number): Promise<Project | undefined> {
    return this.projectsData.get(id);
  }

  async listProjects(): Promise<Project[]> {
    return Array.from(this.projectsData.values());
  }

  async listProjectsByType(type: string): Promise<Project[]> {
    return Array.from(this.projectsData.values()).filter(
      project => project.type === type
    );
  }

  async listProjectsByStatus(status: string): Promise<Project[]> {
    return Array.from(this.projectsData.values()).filter(
      project => project.status === status
    );
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.projectCurrentId++;
    const now = new Date();
    const project: Project = { 
      ...insertProject, 
      id, 
      createdAt: now, 
      updatedAt: now 
    } as Project;
    this.projectsData.set(id, project);
    return project;
  }

  async updateProject(id: number, projectData: Partial<Project>): Promise<Project | undefined> {
    const project = await this.getProject(id);
    if (!project) return undefined;
    
    const updatedProject = { 
      ...project, 
      ...projectData,
      updatedAt: new Date()
    };
    this.projectsData.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projectsData.delete(id);
  }

  // Other methods - implementation details hidden for brevity
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasksData.get(id);
  }

  async listTasksByProject(projectId: number): Promise<Task[]> {
    return Array.from(this.tasksData.values()).filter(
      task => task.projectId === projectId
    );
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskCurrentId++;
    const now = new Date();
    const task: Task = {
      ...insertTask,
      id,
      createdAt: now,
      updatedAt: now
    } as Task;
    this.tasksData.set(id, task);
    return task;
  }

  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const task = await this.getTask(id);
    if (!task) return undefined;
    
    const updatedTask = {
      ...task,
      ...taskData,
      updatedAt: new Date()
    };
    this.tasksData.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasksData.delete(id);
  }

  // Financial methods
  async getFinancialTransaction(id: number): Promise<FinancialTransaction | undefined> {
    return this.financialTransactionsData.get(id);
  }

  async listFinancialTransactions(): Promise<FinancialTransaction[]> {
    return Array.from(this.financialTransactionsData.values());
  }

  async listFinancialTransactionsByProject(projectId: number): Promise<FinancialTransaction[]> {
    return Array.from(this.financialTransactionsData.values()).filter(
      transaction => transaction.projectId === projectId
    );
  }

  async createFinancialTransaction(insertTransaction: InsertFinancialTransaction): Promise<FinancialTransaction> {
    const id = this.financialTransactionCurrentId++;
    const now = new Date();
    const transaction: FinancialTransaction = {
      ...insertTransaction,
      id,
      createdAt: now,
      updatedAt: now
    } as FinancialTransaction;
    this.financialTransactionsData.set(id, transaction);
    return transaction;
  }

  async deleteFinancialTransaction(id: number): Promise<boolean> {
    return this.financialTransactionsData.delete(id);
  }

  // Additional methods - implementation details hidden for brevity
  async getAsset(id: number): Promise<Asset | undefined> {
    return this.assetsData.get(id);
  }

  async listAssets(): Promise<Asset[]> {
    return Array.from(this.assetsData.values());
  }

  async listAssetsByProject(projectId: number): Promise<Asset[]> {
    return Array.from(this.assetsData.values()).filter(
      asset => asset.assignedToProject === projectId
    );
  }

  async createAsset(insertAsset: InsertAsset): Promise<Asset> {
    const id = this.assetCurrentId++;
    const now = new Date();
    const asset: Asset = {
      ...insertAsset,
      id,
      createdAt: now,
      updatedAt: now
    } as Asset;
    this.assetsData.set(id, asset);
    return asset;
  }

  async updateAsset(id: number, assetData: Partial<Asset>): Promise<Asset | undefined> {
    const asset = await this.getAsset(id);
    if (!asset) return undefined;
    
    const updatedAsset = {
      ...asset,
      ...assetData,
      updatedAt: new Date()
    };
    this.assetsData.set(id, updatedAsset);
    return updatedAsset;
  }

  async deleteAsset(id: number): Promise<boolean> {
    return this.assetsData.delete(id);
  }

  // Resource methods
  async getResource(id: number): Promise<Resource | undefined> {
    return this.resourcesData.get(id);
  }

  async listResources(): Promise<Resource[]> {
    return Array.from(this.resourcesData.values());
  }

  async listResourcesByProject(projectId: number): Promise<Resource[]> {
    return Array.from(this.resourcesData.values()).filter(
      resource => resource.assignedToProject === projectId
    );
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = this.resourceCurrentId++;
    const now = new Date();
    const resource: Resource = {
      ...insertResource,
      id,
      createdAt: now,
      updatedAt: now
    } as Resource;
    this.resourcesData.set(id, resource);
    return resource;
  }

  async updateResource(id: number, resourceData: Partial<Resource>): Promise<Resource | undefined> {
    const resource = await this.getResource(id);
    if (!resource) return undefined;
    
    const updatedResource = {
      ...resource,
      ...resourceData,
      updatedAt: new Date()
    };
    this.resourcesData.set(id, updatedResource);
    return updatedResource;
  }

  async deleteResource(id: number): Promise<boolean> {
    return this.resourcesData.delete(id);
  }

  // Document methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documentsData.get(id);
  }

  async listDocuments(): Promise<Document[]> {
    return Array.from(this.documentsData.values());
  }

  async listDocumentsByProject(projectId: number): Promise<Document[]> {
    return Array.from(this.documentsData.values()).filter(
      document => document.projectId === projectId
    );
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.documentCurrentId++;
    const now = new Date();
    const document: Document = {
      ...insertDocument,
      id,
      uploadedAt: now
    } as Document;
    this.documentsData.set(id, document);
    return document;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documentsData.delete(id);
  }

  // Risk methods
  async getRisk(id: number): Promise<Risk | undefined> {
    return this.risksData.get(id);
  }

  async listRisks(): Promise<Risk[]> {
    return Array.from(this.risksData.values());
  }

  async listRisksByProject(projectId: number): Promise<Risk[]> {
    return Array.from(this.risksData.values()).filter(
      risk => risk.projectId === projectId
    );
  }

  async listRisksByLevel(level: string): Promise<Risk[]> {
    return Array.from(this.risksData.values()).filter(
      risk => risk.level === level
    );
  }

  async createRisk(insertRisk: InsertRisk): Promise<Risk> {
    const id = this.riskCurrentId++;
    const now = new Date();
    const risk: Risk = {
      ...insertRisk,
      id,
      createdAt: now,
      updatedAt: now
    } as Risk;
    this.risksData.set(id, risk);
    return risk;
  }

  async updateRisk(id: number, riskData: Partial<Risk>): Promise<Risk | undefined> {
    const risk = await this.getRisk(id);
    if (!risk) return undefined;
    
    const updatedRisk = {
      ...risk,
      ...riskData,
      updatedAt: new Date()
    };
    this.risksData.set(id, updatedRisk);
    return updatedRisk;
  }

  async deleteRisk(id: number): Promise<boolean> {
    return this.risksData.delete(id);
  }

  // Dashboard statistics
  async getProjectStats(): Promise<{ 
    totalProjects: number;
    activeProjects: number;
    totalBudget: number;
    totalResources: number;
    projectsByType: Record<string, number>;
    projectsByStatus: Record<string, number>;
  }> {
    const allProjects = await this.listProjects();
    const assets = await this.listAssets();
    
    // Count by type
    const projectsByType: Record<string, number> = {};
    allProjects.forEach(project => {
      projectsByType[project.type] = (projectsByType[project.type] || 0) + 1;
    });
    
    // Count by status
    const projectsByStatus: Record<string, number> = {};
    allProjects.forEach(project => {
      projectsByStatus[project.status] = (projectsByStatus[project.status] || 0) + 1;
    });
    
    // Calculate total budget
    const totalBudget = allProjects.reduce((sum, project) => {
      return sum + (project.budget || 0);
    }, 0);
    
    // Count active projects (in progress)
    const activeProjects = allProjects.filter(project => project.status === 'in_progress').length;
    
    return {
      totalProjects: allProjects.length,
      activeProjects,
      totalBudget,
      totalResources: assets.length,
      projectsByType,
      projectsByStatus
    };
  }
  
  async getRiskStats(): Promise<{
    totalRisks: number;
    risksByLevel: Record<string, number>;
  }> {
    const allRisks = await this.listRisks();
    
    // Count by level
    const risksByLevel: Record<string, number> = {};
    allRisks.forEach(risk => {
      risksByLevel[risk.level] = (risksByLevel[risk.level] || 0) + 1;
    });
    
    return {
      totalRisks: allRisks.length,
      risksByLevel
    };
  }
}

// Using the DatabaseStorage implementation with Drizzle ORM
export class DatabaseStorage implements IStorage {
  // اضافة خصائص خاصة للفئة من أجل اعدادات قاعدة البيانات
  private readonly transactionsLimit = 10;
  private readonly recentTransactionsLimit = 5;
  
  // Chart of Accounts operations
  async getAccount(id: number): Promise<ChartOfAccount | undefined> {
    const [account] = await db.select().from(chartOfAccounts).where(eq(chartOfAccounts.id, id));
    return account || undefined;
  }
  
  async getAccountByCode(code: string): Promise<ChartOfAccount | undefined> {
    const [account] = await db.select().from(chartOfAccounts).where(eq(chartOfAccounts.code, code));
    return account || undefined;
  }
  
  async listAccounts(): Promise<ChartOfAccount[]> {
    return await db.select().from(chartOfAccounts).orderBy(chartOfAccounts.code);
  }
  
  async listAccountsByType(type: string): Promise<ChartOfAccount[]> {
    return await db
      .select()
      .from(chartOfAccounts)
      .where(sql`${chartOfAccounts.type} = ${type}`)
      .orderBy(chartOfAccounts.code);
  }
  
  async listRootAccounts(): Promise<ChartOfAccount[]> {
    return await db
      .select()
      .from(chartOfAccounts)
      .where(sql`${chartOfAccounts.parentId} IS NULL`)
      .orderBy(chartOfAccounts.code);
  }
  
  async listChildAccounts(parentId: number): Promise<ChartOfAccount[]> {
    return await db
      .select()
      .from(chartOfAccounts)
      .where(eq(chartOfAccounts.parentId, parentId))
      .orderBy(chartOfAccounts.code);
  }
  
  async createAccount(account: InsertChartOfAccount): Promise<ChartOfAccount> {
    // تطوير مسار الحساب (path) بناءً على الكود ورقم الأب إن وجد
    let path = account.code;
    
    if (account.parentId) {
      const parent = await this.getAccount(account.parentId);
      if (parent && parent.path) {
        path = `${parent.path}/${account.code}`;
      }
    }
    
    const [newAccount] = await db
      .insert(chartOfAccounts)
      .values({
        ...account,
        path,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
      
    return newAccount;
  }
  
  async updateAccount(id: number, accountData: Partial<ChartOfAccount>): Promise<ChartOfAccount | undefined> {
    // إذا تغير الكود أو الأب، نحتاج لتحديث المسار
    let additionalData: Partial<ChartOfAccount> = {};
    
    if (accountData.code || accountData.parentId) {
      const currentAccount = await this.getAccount(id);
      if (currentAccount) {
        let newCode = accountData.code || currentAccount.code;
        let newPath = newCode;
        
        const parentId = accountData.parentId !== undefined ? accountData.parentId : currentAccount.parentId;
        
        if (parentId) {
          const parent = await this.getAccount(parentId);
          if (parent && parent.path) {
            newPath = `${parent.path}/${newCode}`;
          }
        }
        
        additionalData.path = newPath;
      }
    }
    
    const [account] = await db
      .update(chartOfAccounts)
      .set({
        ...accountData,
        ...additionalData,
        updatedAt: new Date()
      })
      .where(eq(chartOfAccounts.id, id))
      .returning();
      
    return account || undefined;
  }
  
  async deleteAccount(id: number): Promise<boolean> {
    // تحقق ما إذا كان الحساب لديه أطفال
    const children = await this.listChildAccounts(id);
    if (children.length > 0) {
      // لا يمكن حذف حساب به حسابات فرعية
      return false;
    }
    
    const [result] = await db
      .delete(chartOfAccounts)
      .where(eq(chartOfAccounts.id, id))
      .returning({ id: chartOfAccounts.id });
      
    return !!result;
  }
  
  // Project Budget operations
  async getProjectBudget(id: number): Promise<ProjectBudget | undefined> {
    const [budget] = await db.select().from(projectBudgets).where(eq(projectBudgets.id, id));
    return budget || undefined;
  }
  
  async listProjectBudgets(): Promise<ProjectBudget[]> {
    return await db.select().from(projectBudgets).orderBy(desc(projectBudgets.updatedAt));
  }
  
  async listProjectBudgetsByProject(projectId: number): Promise<ProjectBudget[]> {
    return await db
      .select()
      .from(projectBudgets)
      .where(eq(projectBudgets.projectId, projectId))
      .orderBy(asc(projectBudgets.fiscalYear), asc(projectBudgets.fiscalQuarter));
  }
  
  async listProjectBudgetsByYear(fiscalYear: number): Promise<ProjectBudget[]> {
    return await db
      .select()
      .from(projectBudgets)
      .where(eq(projectBudgets.fiscalYear, fiscalYear))
      .orderBy(asc(projectBudgets.projectId), asc(projectBudgets.fiscalQuarter));
  }
  
  async createProjectBudget(budget: InsertProjectBudget): Promise<ProjectBudget> {
    const [newBudget] = await db
      .insert(projectBudgets)
      .values({
        ...budget,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
      
    return newBudget;
  }
  
  async updateProjectBudget(id: number, budgetData: Partial<ProjectBudget>): Promise<ProjectBudget | undefined> {
    const [budget] = await db
      .update(projectBudgets)
      .set({
        ...budgetData,
        updatedAt: new Date()
      })
      .where(eq(projectBudgets.id, id))
      .returning();
      
    return budget || undefined;
  }
  
  async deleteProjectBudget(id: number): Promise<boolean> {
    const [result] = await db
      .delete(projectBudgets)
      .where(eq(projectBudgets.id, id))
      .returning({ id: projectBudgets.id });
      
    return !!result;
  }
  
  // Financial Reports operations
  async getFinancialReport(id: number): Promise<FinancialReport | undefined> {
    const [report] = await db.select().from(financialReports).where(eq(financialReports.id, id));
    return report || undefined;
  }
  
  async listFinancialReports(): Promise<FinancialReport[]> {
    return await db.select().from(financialReports).orderBy(desc(financialReports.updatedAt));
  }
  
  async createFinancialReport(report: InsertFinancialReport): Promise<FinancialReport> {
    const [newReport] = await db
      .insert(financialReports)
      .values({
        ...report,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
      
    return newReport;
  }
  
  async updateFinancialReport(id: number, reportData: Partial<FinancialReport>): Promise<FinancialReport | undefined> {
    const [report] = await db
      .update(financialReports)
      .set({
        ...reportData,
        updatedAt: new Date()
      })
      .where(eq(financialReports.id, id))
      .returning();
      
    return report || undefined;
  }
  
  async deleteFinancialReport(id: number): Promise<boolean> {
    const [result] = await db
      .delete(financialReports)
      .where(eq(financialReports.id, id))
      .returning({ id: financialReports.id });
      
    return !!result;
  }
  
  // Financial Statistics
  async getFinancialStats(): Promise<{
    totalIncome: number;
    totalExpenses: number;
    currentBalance: number;
    transactionsByType: Record<string, number>;
    recentTransactions: FinancialTransaction[];
  }> {
    // حصر المعاملات حسب النوع وحساب المجاميع
    const transactions = await this.listFinancialTransactions();
    
    let totalIncome = 0;
    let totalExpenses = 0;
    const transactionsByType: Record<string, number> = {
      income: 0,
      expense: 0,
      transfer: 0
    };
    
    for (const transaction of transactions) {
      transactionsByType[transaction.type] = (transactionsByType[transaction.type] || 0) + 1;
      
      if (transaction.type === 'income') {
        totalIncome += transaction.amount || 0;
      } else if (transaction.type === 'expense') {
        totalExpenses += transaction.amount || 0;
      }
    }
    
    // الرصيد الحالي هو الفرق بين الإيرادات والمصروفات
    const currentBalance = totalIncome - totalExpenses;
    
    // أحدث المعاملات
    const recentTransactions = transactions.slice(0, this.recentTransactionsLimit);
    
    return {
      totalIncome,
      totalExpenses,
      currentBalance,
      transactionsByType,
      recentTransactions
    };
  }
  
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async listUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Project operations
  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async listProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.updatedAt));
  }

  async listProjectsByType(type: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(sql`${projects.type} = ${type}`)
      .orderBy(desc(projects.updatedAt));
  }

  async listProjectsByStatus(status: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(sql`${projects.status} = ${status}`)
      .orderBy(desc(projects.updatedAt));
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values({
        ...insertProject,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return project;
  }

  async updateProject(id: number, projectData: Partial<Project>): Promise<Project | undefined> {
    console.log(`Storage.updateProject - Project ID: ${id}`);
    console.log(`Storage.updateProject - Data to update:`, JSON.stringify(projectData));
    
    try {
      const [project] = await db
        .update(projects)
        .set({
          ...projectData,
          updatedAt: new Date()
        })
        .where(eq(projects.id, id))
        .returning();
      
      console.log(`Storage.updateProject - Updated project:`, JSON.stringify(project));
      return project || undefined;
    } catch (error) {
      console.error(`Storage.updateProject - Error updating project ${id}:`, error);
      throw error;
    }
  }

  async deleteProject(id: number): Promise<boolean> {
    const [result] = await db
      .delete(projects)
      .where(eq(projects.id, id))
      .returning({ id: projects.id });
    return !!result;
  }

  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async listTasksByProject(projectId: number): Promise<Task[]> {
    try {
      // التحقق من وجود عمود parent_id
      return await db
        .select()
        .from(tasks)
        .where(eq(tasks.projectId, projectId))
        .orderBy(desc(tasks.updatedAt));
    } catch (error) {
      // في حالة عدم وجود عمود parent_id، استخدم استعلام أساسي بدون إشارة إلى هذا العمود
      const result = await db.execute(
        sql`SELECT * FROM tasks WHERE project_id = ${projectId} ORDER BY updated_at DESC`
      );
      return result.rows as Task[];
    }
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const [task] = await db
      .insert(tasks)
      .values({
        ...insertTask,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return task;
  }

  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const [task] = await db
      .update(tasks)
      .set({
        ...taskData,
        updatedAt: new Date()
      })
      .where(eq(tasks.id, id))
      .returning();
    return task || undefined;
  }

  async deleteTask(id: number): Promise<boolean> {
    const [result] = await db
      .delete(tasks)
      .where(eq(tasks.id, id))
      .returning({ id: tasks.id });
    return !!result;
  }

  // Financial operations
  async getFinancialTransaction(id: number): Promise<FinancialTransaction | undefined> {
    const [transaction] = await db
      .select()
      .from(financialTransactions)
      .where(eq(financialTransactions.id, id));
    return transaction || undefined;
  }

  async listFinancialTransactions(): Promise<FinancialTransaction[]> {
    return await db
      .select()
      .from(financialTransactions)
      .orderBy(desc(financialTransactions.transactionDate));
  }

  async listFinancialTransactionsByProject(projectId: number): Promise<FinancialTransaction[]> {
    return await db
      .select()
      .from(financialTransactions)
      .where(eq(financialTransactions.projectId, projectId))
      .orderBy(desc(financialTransactions.transactionDate));
  }

  async createFinancialTransaction(insertTransaction: InsertFinancialTransaction): Promise<FinancialTransaction> {
    const [transaction] = await db
      .insert(financialTransactions)
      .values({
        ...insertTransaction,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return transaction;
  }

  async deleteFinancialTransaction(id: number): Promise<boolean> {
    const [result] = await db
      .delete(financialTransactions)
      .where(eq(financialTransactions.id, id))
      .returning({ id: financialTransactions.id });
    return !!result;
  }

  // Asset operations
  async getAsset(id: number): Promise<Asset | undefined> {
    const [asset] = await db.select().from(assets).where(eq(assets.id, id));
    return asset || undefined;
  }

  async listAssets(): Promise<Asset[]> {
    return await db.select().from(assets).orderBy(desc(assets.updatedAt));
  }

  async listAssetsByProject(projectId: number): Promise<Asset[]> {
    return await db
      .select()
      .from(assets)
      .where(eq(assets.assignedToProject, projectId))
      .orderBy(desc(assets.updatedAt));
  }

  async createAsset(insertAsset: InsertAsset): Promise<Asset> {
    const [asset] = await db
      .insert(assets)
      .values({
        ...insertAsset,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return asset;
  }

  async updateAsset(id: number, assetData: Partial<Asset>): Promise<Asset | undefined> {
    const [asset] = await db
      .update(assets)
      .set({
        ...assetData,
        updatedAt: new Date()
      })
      .where(eq(assets.id, id))
      .returning();
    return asset || undefined;
  }

  async deleteAsset(id: number): Promise<boolean> {
    const [result] = await db
      .delete(assets)
      .where(eq(assets.id, id))
      .returning({ id: assets.id });
    return !!result;
  }

  // Resource operations
  async getResource(id: number): Promise<Resource | undefined> {
    const [resource] = await db.select().from(resources).where(eq(resources.id, id));
    return resource || undefined;
  }

  async listResources(): Promise<Resource[]> {
    return await db.select().from(resources).orderBy(desc(resources.updatedAt));
  }

  async listResourcesByProject(projectId: number): Promise<Resource[]> {
    return await db
      .select()
      .from(resources)
      .where(eq(resources.assignedToProject, projectId))
      .orderBy(desc(resources.updatedAt));
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const [resource] = await db
      .insert(resources)
      .values({
        ...insertResource,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return resource;
  }

  async updateResource(id: number, resourceData: Partial<Resource>): Promise<Resource | undefined> {
    const [resource] = await db
      .update(resources)
      .set({
        ...resourceData,
        updatedAt: new Date()
      })
      .where(eq(resources.id, id))
      .returning();
    return resource || undefined;
  }

  async deleteResource(id: number): Promise<boolean> {
    const [result] = await db
      .delete(resources)
      .where(eq(resources.id, id))
      .returning({ id: resources.id });
    return !!result;
  }

  // Document operations
  async getDocument(id: number): Promise<Document | undefined> {
    const [document] = await db.select().from(documents).where(eq(documents.id, id));
    return document || undefined;
  }

  async listDocuments(): Promise<Document[]> {
    return await db.select().from(documents).orderBy(desc(documents.uploadedAt));
  }

  async listDocumentsByProject(projectId: number): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.projectId, projectId))
      .orderBy(desc(documents.uploadedAt));
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const [document] = await db
      .insert(documents)
      .values({
        ...insertDocument,
        uploadedAt: new Date(),
      })
      .returning();
    return document;
  }

  async deleteDocument(id: number): Promise<boolean> {
    const [result] = await db
      .delete(documents)
      .where(eq(documents.id, id))
      .returning({ id: documents.id });
    return !!result;
  }

  // Risk operations
  async getRisk(id: number): Promise<Risk | undefined> {
    const [risk] = await db.select().from(risks).where(eq(risks.id, id));
    return risk || undefined;
  }

  async listRisks(): Promise<Risk[]> {
    return await db.select().from(risks).orderBy(desc(risks.updatedAt));
  }

  async listRisksByProject(projectId: number): Promise<Risk[]> {
    return await db
      .select()
      .from(risks)
      .where(eq(risks.projectId, projectId))
      .orderBy(desc(risks.updatedAt));
  }

  async listRisksByLevel(level: string): Promise<Risk[]> {
    return await db
      .select()
      .from(risks)
      .where(sql`${risks.level} = ${level}`)
      .orderBy(desc(risks.updatedAt));
  }

  async createRisk(insertRisk: InsertRisk): Promise<Risk> {
    const [risk] = await db
      .insert(risks)
      .values({
        ...insertRisk,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return risk;
  }

  async updateRisk(id: number, riskData: Partial<Risk>): Promise<Risk | undefined> {
    const [risk] = await db
      .update(risks)
      .set({
        ...riskData,
        updatedAt: new Date()
      })
      .where(eq(risks.id, id))
      .returning();
    return risk || undefined;
  }

  async deleteRisk(id: number): Promise<boolean> {
    const [result] = await db
      .delete(risks)
      .where(eq(risks.id, id))
      .returning({ id: risks.id });
    return !!result;
  }

  // Dashboard statistics
  async getProjectStats(): Promise<{
    totalProjects: number;
    activeProjects: number;
    totalBudget: number;
    totalResources: number;
    projectsByType: Record<string, number>;
    projectsByStatus: Record<string, number>;
  }> {
    // Get all projects
    const allProjects = await this.listProjects();
    
    // Count resources
    const [{ count: totalResources }] = await db
      .select({ count: count() })
      .from(resources);
    
    // Calculate types count
    const projectsByType: Record<string, number> = {};
    for (const project of allProjects) {
      projectsByType[project.type] = (projectsByType[project.type] || 0) + 1;
    }
    
    // Calculate status count
    const projectsByStatus: Record<string, number> = {};
    for (const project of allProjects) {
      projectsByStatus[project.status] = (projectsByStatus[project.status] || 0) + 1;
    }
    
    // Calculate total budget
    const totalBudget = allProjects.reduce((sum, project) => {
      return sum + (project.budget || 0);
    }, 0);
    
    return {
      totalProjects: allProjects.length,
      activeProjects: projectsByStatus['in_progress'] || 0,
      totalBudget,
      totalResources,
      projectsByType,
      projectsByStatus
    };
  }
  
  async getRiskStats(): Promise<{
    totalRisks: number;
    risksByLevel: Record<string, number>;
  }> {
    // Get all risks
    const allRisks = await this.listRisks();
    
    // Calculate risk levels
    const risksByLevel: Record<string, number> = {};
    for (const risk of allRisks) {
      risksByLevel[risk.level] = (risksByLevel[risk.level] || 0) + 1;
    }
    
    return {
      totalRisks: allRisks.length,
      risksByLevel
    };
  }
  
  // Contract Items operations
  async getContractItem(id: number): Promise<ContractItem | undefined> {
    const [item] = await db.select().from(contractItems).where(eq(contractItems.id, id));
    return item || undefined;
  }

  async listContractItems(): Promise<ContractItem[]> {
    return await db.select().from(contractItems).orderBy(asc(contractItems.itemNumber));
  }

  async listContractItemsByProject(projectId: number): Promise<ContractItem[]> {
    return await db
      .select()
      .from(contractItems)
      .where(eq(contractItems.projectId, projectId))
      .orderBy(asc(contractItems.itemNumber));
  }

  async createContractItem(insertItem: InsertContractItem): Promise<ContractItem> {
    const [item] = await db
      .insert(contractItems)
      .values({
        ...insertItem,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return item;
  }

  async updateContractItem(id: number, itemData: Partial<ContractItem>): Promise<ContractItem | undefined> {
    const [item] = await db
      .update(contractItems)
      .set({
        ...itemData,
        updatedAt: new Date()
      })
      .where(eq(contractItems.id, id))
      .returning();
    return item || undefined;
  }

  async deleteContractItem(id: number): Promise<boolean> {
    const [result] = await db
      .delete(contractItems)
      .where(eq(contractItems.id, id))
      .returning({ id: contractItems.id });
    return !!result;
  }

  // Payment Certificates operations
  async getPaymentCertificate(id: number): Promise<PaymentCertificate | undefined> {
    // Seleccionamos campos explícitamente basado en los campos que existen en la base de datos
    const [certificate] = await db.select({
      id: paymentCertificates.id,
      projectId: paymentCertificates.projectId,
      certificateNumber: paymentCertificates.certificateNumber,
      type: paymentCertificates.type,
      status: paymentCertificates.status,
      fromDate: paymentCertificates.fromDate,
      toDate: paymentCertificates.toDate,
      totalAmount: paymentCertificates.totalAmount,
      previousAmount: paymentCertificates.previousAmount,
      currentAmount: paymentCertificates.currentAmount,
      finalAmount: paymentCertificates.finalAmount,
      createdAt: paymentCertificates.createdAt,
      updatedAt: paymentCertificates.updatedAt,
      createdBy: paymentCertificates.createdBy,
      notes: paymentCertificates.notes,
      attachmentPath: paymentCertificates.attachmentPath,
      submittedAt: paymentCertificates.submittedAt,
      approvedAt: paymentCertificates.approvedAt,
      paidAt: paymentCertificates.paidAt
    })
    .from(paymentCertificates)
    .where(eq(paymentCertificates.id, id));
    return certificate || undefined;
  }

  async listPaymentCertificates(): Promise<PaymentCertificate[]> {
    // Seleccionamos campos explícitamente basado en los campos que existen en la base de datos
    return await db
      .select({
        id: paymentCertificates.id,
        projectId: paymentCertificates.projectId,
        certificateNumber: paymentCertificates.certificateNumber,
        type: paymentCertificates.type,
        status: paymentCertificates.status,
        fromDate: paymentCertificates.fromDate,
        toDate: paymentCertificates.toDate,
        totalAmount: paymentCertificates.totalAmount,
        previousAmount: paymentCertificates.previousAmount,
        currentAmount: paymentCertificates.currentAmount,
        finalAmount: paymentCertificates.finalAmount,
        createdAt: paymentCertificates.createdAt,
        updatedAt: paymentCertificates.updatedAt,
        createdBy: paymentCertificates.createdBy,
        notes: paymentCertificates.notes,
        attachmentPath: paymentCertificates.attachmentPath,
        submittedAt: paymentCertificates.submittedAt,
        approvedAt: paymentCertificates.approvedAt,
        paidAt: paymentCertificates.paidAt
      })
      .from(paymentCertificates)
      .orderBy(desc(paymentCertificates.createdAt));
  }

  async listPaymentCertificatesByProject(projectId: number): Promise<PaymentCertificate[]> {
    // Seleccionamos campos explícitamente basado en los campos que existen en la base de datos
    return await db
      .select({
        id: paymentCertificates.id,
        projectId: paymentCertificates.projectId,
        certificateNumber: paymentCertificates.certificateNumber,
        type: paymentCertificates.type,
        status: paymentCertificates.status,
        fromDate: paymentCertificates.fromDate,
        toDate: paymentCertificates.toDate,
        totalAmount: paymentCertificates.totalAmount,
        previousAmount: paymentCertificates.previousAmount,
        currentAmount: paymentCertificates.currentAmount,
        finalAmount: paymentCertificates.finalAmount,
        createdAt: paymentCertificates.createdAt,
        updatedAt: paymentCertificates.updatedAt,
        createdBy: paymentCertificates.createdBy,
        notes: paymentCertificates.notes,
        attachmentPath: paymentCertificates.attachmentPath,
        submittedAt: paymentCertificates.submittedAt,
        approvedAt: paymentCertificates.approvedAt,
        paidAt: paymentCertificates.paidAt
      })
      .from(paymentCertificates)
      .where(eq(paymentCertificates.projectId, projectId))
      .orderBy(desc(paymentCertificates.createdAt));
  }

  async listPaymentCertificatesByType(type: string): Promise<PaymentCertificate[]> {
    // Seleccionamos campos explícitamente basado en los campos que existen en la base de datos
    return await db
      .select({
        id: paymentCertificates.id,
        projectId: paymentCertificates.projectId,
        certificateNumber: paymentCertificates.certificateNumber,
        type: paymentCertificates.type,
        status: paymentCertificates.status,
        fromDate: paymentCertificates.fromDate,
        toDate: paymentCertificates.toDate,
        totalAmount: paymentCertificates.totalAmount,
        previousAmount: paymentCertificates.previousAmount,
        currentAmount: paymentCertificates.currentAmount,
        finalAmount: paymentCertificates.finalAmount,
        createdAt: paymentCertificates.createdAt,
        updatedAt: paymentCertificates.updatedAt,
        createdBy: paymentCertificates.createdBy,
        notes: paymentCertificates.notes,
        attachmentPath: paymentCertificates.attachmentPath,
        submittedAt: paymentCertificates.submittedAt,
        approvedAt: paymentCertificates.approvedAt,
        paidAt: paymentCertificates.paidAt
      })
      .from(paymentCertificates)
      .where(sql`${paymentCertificates.type} = ${type}`)
      .orderBy(desc(paymentCertificates.createdAt));
  }

  async listPaymentCertificatesByStatus(status: string): Promise<PaymentCertificate[]> {
    // Seleccionamos campos explícitamente basado en los campos que existen en la base de datos
    return await db
      .select({
        id: paymentCertificates.id,
        projectId: paymentCertificates.projectId,
        certificateNumber: paymentCertificates.certificateNumber,
        type: paymentCertificates.type,
        status: paymentCertificates.status,
        fromDate: paymentCertificates.fromDate,
        toDate: paymentCertificates.toDate,
        totalAmount: paymentCertificates.totalAmount,
        previousAmount: paymentCertificates.previousAmount,
        currentAmount: paymentCertificates.currentAmount,
        finalAmount: paymentCertificates.finalAmount,
        createdAt: paymentCertificates.createdAt,
        updatedAt: paymentCertificates.updatedAt,
        createdBy: paymentCertificates.createdBy,
        notes: paymentCertificates.notes,
        attachmentPath: paymentCertificates.attachmentPath,
        submittedAt: paymentCertificates.submittedAt,
        approvedAt: paymentCertificates.approvedAt,
        paidAt: paymentCertificates.paidAt
      })
      .from(paymentCertificates)
      .where(sql`${paymentCertificates.status} = ${status}`)
      .orderBy(desc(paymentCertificates.createdAt));
  }

  async createPaymentCertificate(insertCertificate: InsertPaymentCertificate): Promise<PaymentCertificate> {
    const [certificate] = await db
      .insert(paymentCertificates)
      .values({
        ...insertCertificate,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return certificate;
  }

  async updatePaymentCertificate(id: number, certificateData: Partial<PaymentCertificate>): Promise<PaymentCertificate | undefined> {
    const [certificate] = await db
      .update(paymentCertificates)
      .set({
        ...certificateData,
        updatedAt: new Date()
      })
      .where(eq(paymentCertificates.id, id))
      .returning();
    return certificate || undefined;
  }

  async deletePaymentCertificate(id: number): Promise<boolean> {
    const [result] = await db
      .delete(paymentCertificates)
      .where(eq(paymentCertificates.id, id))
      .returning({ id: paymentCertificates.id });
    return !!result;
  }

  async submitPaymentCertificate(id: number): Promise<PaymentCertificate | undefined> {
    const status: 'submitted' = 'submitted';
    const [certificate] = await db
      .update(paymentCertificates)
      .set({
        status,
        submittedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(paymentCertificates.id, id))
      .returning();
    return certificate || undefined;
  }

  async approvePaymentCertificate(id: number, level: string, approverId: number, comments?: string): Promise<PaymentCertificate | undefined> {
    let newStatus: 'supervisor_approved' | 'pm_approved' | 'finance_approved' | 'gm_approved' | 'approved' | null = null;
    
    // تحديد الحالة الجديدة بناءً على مستوى الموافقة
    switch (level) {
      case 'supervisor':
        newStatus = 'supervisor_approved';
        break;
      case 'project_manager':
        newStatus = 'pm_approved';
        break;
      case 'financial':
        newStatus = 'finance_approved';
        break;
      case 'general_manager':
        newStatus = 'gm_approved';
        break;
      case 'final':
        newStatus = 'approved';
        break;
      default:
        throw new Error('مستوى موافقة غير صالح');
    }
    
    if (!newStatus) {
      throw new Error('فشل في تحديد حالة المستخلص الجديدة');
    }
    
    // إنشاء سجل موافقة جديد
    await this.createCertificateApproval({
      certificateId: id,
      approvalLevel: level,
      status: 'approved',
      approvedBy: approverId,
      comments: comments || null
    });
    
    // تحديث حالة المستخلص
    const updateData: Partial<PaymentCertificate> = {
      status: newStatus,
      updatedAt: new Date()
    };
    
    // إذا كانت الموافقة النهائية، حدّث تاريخ الموافقة
    if (level === 'final') {
      updateData.approvedAt = new Date();
    }
    
    const [certificate] = await db
      .update(paymentCertificates)
      .set(updateData)
      .where(eq(paymentCertificates.id, id))
      .returning();
    
    return certificate || undefined;
  }

  async rejectPaymentCertificate(id: number, level: string, approverId: number, comments: string): Promise<PaymentCertificate | undefined> {
    // إنشاء سجل رفض جديد
    await this.createCertificateApproval({
      certificateId: id,
      approvalLevel: level,
      status: 'rejected',
      approvedBy: approverId,
      comments: comments
    });
    
    // تحديث حالة المستخلص إلى مرفوض
    const status: 'rejected' = 'rejected';
    const [certificate] = await db
      .update(paymentCertificates)
      .set({
        status,
        updatedAt: new Date()
      })
      .where(eq(paymentCertificates.id, id))
      .returning();
    
    return certificate || undefined;
  }

  async markPaymentCertificateAsPaid(id: number): Promise<PaymentCertificate | undefined> {
    const status: 'paid' = 'paid';
    const [certificate] = await db
      .update(paymentCertificates)
      .set({
        status,
        paidAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(paymentCertificates.id, id))
      .returning();
    
    return certificate || undefined;
  }

  // Payment Certificate Items operations
  async getPaymentCertificateItem(id: number): Promise<PaymentCertificateItem | undefined> {
    const [item] = await db.select().from(paymentCertificateItems).where(eq(paymentCertificateItems.id, id));
    return item || undefined;
  }

  async listPaymentCertificateItems(certificateId: number): Promise<PaymentCertificateItem[]> {
    return await db
      .select()
      .from(paymentCertificateItems)
      .where(eq(paymentCertificateItems.certificateId, certificateId));
  }

  async createPaymentCertificateItem(insertItem: InsertPaymentCertificateItem): Promise<PaymentCertificateItem> {
    const [item] = await db
      .insert(paymentCertificateItems)
      .values(insertItem)
      .returning();
    return item;
  }

  async updatePaymentCertificateItem(id: number, itemData: Partial<PaymentCertificateItem>): Promise<PaymentCertificateItem | undefined> {
    const [item] = await db
      .update(paymentCertificateItems)
      .set(itemData)
      .where(eq(paymentCertificateItems.id, id))
      .returning();
    return item || undefined;
  }

  async deletePaymentCertificateItem(id: number): Promise<boolean> {
    const [result] = await db
      .delete(paymentCertificateItems)
      .where(eq(paymentCertificateItems.id, id))
      .returning({ id: paymentCertificateItems.id });
    return !!result;
  }

  // Certificate Approvals operations
  async getCertificateApproval(id: number): Promise<CertificateApproval | undefined> {
    const [approval] = await db.select().from(certificateApprovals).where(eq(certificateApprovals.id, id));
    return approval || undefined;
  }

  async listCertificateApprovals(certificateId: number): Promise<CertificateApproval[]> {
    return await db
      .select()
      .from(certificateApprovals)
      .where(eq(certificateApprovals.certificateId, certificateId))
      .orderBy(asc(certificateApprovals.approvedAt));
  }

  async createCertificateApproval(insertApproval: InsertCertificateApproval): Promise<CertificateApproval> {
    const [approval] = await db
      .insert(certificateApprovals)
      .values({
        ...insertApproval,
        approvedAt: new Date()
      })
      .returning();
    return approval;
  }

  async updateCertificateApproval(id: number, approvalData: Partial<CertificateApproval>): Promise<CertificateApproval | undefined> {
    const [approval] = await db
      .update(certificateApprovals)
      .set(approvalData)
      .where(eq(certificateApprovals.id, id))
      .returning();
    return approval || undefined;
  }
  
  // Payment Certificate Statistics
  async getPaymentCertificateStats(projectId?: number): Promise<{
    totalCertificates: number;
    totalPaid: number;
    totalAmount: number;
    paidAmount: number;
    certificatesByType: Record<string, number>;
    certificatesByStatus: Record<string, number>;
  }> {
    // الحصول على المستخلصات
    let certificates: PaymentCertificate[] = [];
    
    // إذا تم تحديد مشروع معين، قم بتصفية النتائج
    if (projectId) {
      certificates = await this.listPaymentCertificatesByProject(projectId);
    } else {
      certificates = await this.listPaymentCertificates();
    }
    
    // حساب الإحصائيات
    const totalCertificates = certificates.length;
    const totalPaid = certificates.filter(c => c.status === 'paid').length;
    const totalAmount = certificates.reduce((sum, cert) => sum + cert.totalAmount, 0);
    const paidAmount = certificates
      .filter(c => c.status === 'paid')
      .reduce((sum, cert) => sum + cert.totalAmount, 0);
    
    // تصنيف المستخلصات حسب النوع
    const certificatesByType: Record<string, number> = {};
    certificates.forEach(cert => {
      if (cert.type) {
        certificatesByType[cert.type] = (certificatesByType[cert.type] || 0) + 1;
      }
    });
    
    // تصنيف المستخلصات حسب الحالة
    const certificatesByStatus: Record<string, number> = {};
    certificates.forEach(cert => {
      if (cert.status) {
        certificatesByStatus[cert.status] = (certificatesByStatus[cert.status] || 0) + 1;
      }
    });
    
    return {
      totalCertificates,
      totalPaid,
      totalAmount,
      paidAmount,
      certificatesByType,
      certificatesByStatus
    };
  }

  // Project Photos operations
  async getProjectPhoto(id: number): Promise<ProjectPhoto | undefined> {
    const [photo] = await db.select().from(projectPhotos).where(eq(projectPhotos.id, id));
    return photo || undefined;
  }

  async listProjectPhotosByProject(projectId: number): Promise<ProjectPhoto[]> {
    return await db
      .select()
      .from(projectPhotos)
      .where(eq(projectPhotos.projectId, projectId))
      .orderBy(desc(projectPhotos.uploadedAt));
  }

  async createProjectPhoto(photo: InsertProjectPhoto): Promise<ProjectPhoto> {
    const [newPhoto] = await db
      .insert(projectPhotos)
      .values(photo)
      .returning();
    return newPhoto;
  }

  async deleteProjectPhoto(id: number): Promise<boolean> {
    const result = await db.delete(projectPhotos).where(eq(projectPhotos.id, id));
    return !!result;
  }
  
  // Journal Entries operations
  async getJournalEntry(id: number): Promise<JournalEntry | undefined> {
    const [entry] = await db.select().from(journalEntries).where(eq(journalEntries.id, id));
    return entry || undefined;
  }

  async listJournalEntries(): Promise<JournalEntry[]> {
    return await db
      .select()
      .from(journalEntries)
      .orderBy(journalEntries.journalDate);
  }

  async listJournalEntriesByProject(projectId: number): Promise<JournalEntry[]> {
    return await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.projectId, projectId))
      .orderBy(journalEntries.journalDate);
  }

  async listJournalEntriesByFiscalPeriod(fiscalYear: number, fiscalPeriod: number): Promise<JournalEntry[]> {
    return await db
      .select()
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.fiscalYear, fiscalYear),
          eq(journalEntries.fiscalPeriod, fiscalPeriod)
        )
      )
      .orderBy(journalEntries.journalDate);
  }

  async listJournalEntriesByStatus(isPosted: boolean): Promise<JournalEntry[]> {
    return await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.isPosted, isPosted))
      .orderBy(journalEntries.journalDate);
  }

  async listJournalEntriesByCertificate(certificateId: number): Promise<JournalEntry[]> {
    // جلب القيود المحاسبية المرتبطة بمعرف المستخلص
    // Join with journal entry lines to find entries that have lines referencing this certificate
    const entriesWithLines = await db
      .select({
        entryId: journalEntryLines.journalEntryId,
      })
      .from(journalEntryLines)
      .where(eq(journalEntryLines.certificateId, certificateId))
      .groupBy(journalEntryLines.journalEntryId);
    
    if (entriesWithLines.length === 0) {
      return [];
    }
    
    // Get the full journal entry details for each entry ID
    const entryIds = entriesWithLines.map(e => e.entryId);
    
    return await db
      .select()
      .from(journalEntries)
      .where(inArray(journalEntries.id, entryIds))
      .orderBy(journalEntries.journalDate);
  }

  async createJournalEntry(entry: InsertJournalEntry, lines: InsertJournalEntryLine[]): Promise<JournalEntry> {
    // Start a transaction to ensure both entry and lines are created together
    return await db.transaction(async (tx) => {
      // Insert the journal entry
      const [newEntry] = await tx
        .insert(journalEntries)
        .values(entry)
        .returning();
      
      // Insert the journal entry lines with the entry ID
      if (lines && lines.length > 0) {
        const linesWithEntryId = lines.map(line => ({
          ...line,
          journalEntryId: newEntry.id
        }));
        
        await tx
          .insert(journalEntryLines)
          .values(linesWithEntryId);
      }
      
      return newEntry;
    });
  }

  async updateJournalEntry(id: number, entry: Partial<JournalEntry>): Promise<JournalEntry | undefined> {
    // Don't allow updates to posted journal entries
    const [currentEntry] = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.id, id));
    
    if (!currentEntry || currentEntry.isPosted) {
      return undefined;
    }
    
    const [updatedEntry] = await db
      .update(journalEntries)
      .set({
        ...entry,
        updatedAt: new Date()
      })
      .where(eq(journalEntries.id, id))
      .returning();
    
    return updatedEntry;
  }

  async deleteJournalEntry(id: number): Promise<boolean> {
    // First check if the entry is posted - don't allow deletion of posted entries
    const [entry] = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.id, id));
    
    if (!entry || entry.isPosted) {
      return false;
    }
    
    // Use a transaction to delete both the entry and its lines
    return await db.transaction(async (tx) => {
      // Delete the associated lines first
      await tx
        .delete(journalEntryLines)
        .where(eq(journalEntryLines.journalEntryId, id));
      
      // Then delete the entry
      const result = await tx
        .delete(journalEntries)
        .where(eq(journalEntries.id, id));
      
      return !!result;
    });
  }

  async postJournalEntry(id: number, userId: number): Promise<JournalEntry | undefined> {
    // Check if entry exists and is not already posted
    const [entry] = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.id, id));
    
    if (!entry || entry.isPosted) {
      return undefined;
    }
    
    // Verify that the entry is balanced (sum of debits equals sum of credits)
    const lines = await this.listJournalEntryLines(id);
    
    const totalDebits = lines
      .reduce((sum, line) => sum + (line.debitAmount || 0), 0);
    
    const totalCredits = lines
      .reduce((sum, line) => sum + (line.creditAmount || 0), 0);
    
    // If the entry is not balanced, don't post it
    if (Math.abs(totalDebits - totalCredits) > 0.01) {
      throw new Error('Journal entry is not balanced. Total debits must equal total credits.');
    }
    
    // Post the entry
    const [postedEntry] = await db
      .update(journalEntries)
      .set({
        isPosted: true,
        postedBy: userId,
        postingDate: new Date(),
        updatedAt: new Date()
      })
      .where(eq(journalEntries.id, id))
      .returning();
    
    return postedEntry;
  }
  
  // Journal Entry Lines operations
  async getJournalEntryLine(id: number): Promise<JournalEntryLine | undefined> {
    const [line] = await db
      .select()
      .from(journalEntryLines)
      .where(eq(journalEntryLines.id, id));
    
    return line || undefined;
  }

  async listJournalEntryLines(journalEntryId: number): Promise<JournalEntryLine[]> {
    return await db
      .select()
      .from(journalEntryLines)
      .where(eq(journalEntryLines.journalEntryId, journalEntryId))
      .orderBy(journalEntryLines.lineNumber);
  }

  async createJournalEntryLine(line: InsertJournalEntryLine): Promise<JournalEntryLine> {
    // Check if the journal entry exists and is not posted
    const [entry] = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.id, line.journalEntryId));
    
    if (!entry || entry.isPosted) {
      throw new Error('Cannot add lines to a non-existent or posted journal entry');
    }
    
    // Insert the line
    const [newLine] = await db
      .insert(journalEntryLines)
      .values(line)
      .returning();
    
    return newLine;
  }

  async updateJournalEntryLine(id: number, line: Partial<JournalEntryLine>): Promise<JournalEntryLine | undefined> {
    // First get the line to check the journal entry
    const [currentLine] = await db
      .select()
      .from(journalEntryLines)
      .where(eq(journalEntryLines.id, id));
    
    if (!currentLine) {
      return undefined;
    }
    
    // Check if the journal entry is posted
    const [entry] = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.id, currentLine.journalEntryId));
    
    if (!entry || entry.isPosted) {
      return undefined;
    }
    
    // Update the line
    const [updatedLine] = await db
      .update(journalEntryLines)
      .set(line)
      .where(eq(journalEntryLines.id, id))
      .returning();
    
    return updatedLine;
  }

  async deleteJournalEntryLine(id: number): Promise<boolean> {
    // First get the line to check the journal entry
    const [currentLine] = await db
      .select()
      .from(journalEntryLines)
      .where(eq(journalEntryLines.id, id));
    
    if (!currentLine) {
      return false;
    }
    
    // Check if the journal entry is posted
    const [entry] = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.id, currentLine.journalEntryId));
    
    if (!entry || entry.isPosted) {
      return false;
    }
    
    // Delete the line
    const result = await db
      .delete(journalEntryLines)
      .where(eq(journalEntryLines.id, id));
    
    return !!result;
  }
  
  // Financial Periods operations
  async getFinancialPeriod(id: number): Promise<FinancialPeriod | undefined> {
    const [period] = await db
      .select()
      .from(financialPeriods)
      .where(eq(financialPeriods.id, id));
    
    return period || undefined;
  }

  async listFinancialPeriods(): Promise<FinancialPeriod[]> {
    return await db
      .select()
      .from(financialPeriods)
      .orderBy(financialPeriods.fiscalYear, financialPeriods.periodNumber);
  }

  async listFinancialPeriodsByYear(fiscalYear: number): Promise<FinancialPeriod[]> {
    return await db
      .select()
      .from(financialPeriods)
      .where(eq(financialPeriods.fiscalYear, fiscalYear))
      .orderBy(financialPeriods.periodNumber);
  }

  async createFinancialPeriod(period: InsertFinancialPeriod): Promise<FinancialPeriod> {
    // Validate that there's no overlap with existing periods
    const [existingPeriod] = await db
      .select()
      .from(financialPeriods)
      .where(
        and(
          eq(financialPeriods.fiscalYear, period.fiscalYear),
          eq(financialPeriods.periodNumber, period.periodNumber)
        )
      );
    
    if (existingPeriod) {
      throw new Error('A financial period with the same fiscal year and period already exists');
    }
    
    // Create the new period
    const [newPeriod] = await db
      .insert(financialPeriods)
      .values({
        ...period,
        isOpen: true,
        isClosed: false,
        isReconciled: false,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    
    return newPeriod;
  }

  async updateFinancialPeriod(id: number, period: Partial<FinancialPeriod>): Promise<FinancialPeriod | undefined> {
    // Get the current period
    const [currentPeriod] = await db
      .select()
      .from(financialPeriods)
      .where(eq(financialPeriods.id, id));
    
    if (!currentPeriod) {
      return undefined;
    }
    
    // Don't allow changes to closed periods
    if (currentPeriod.isClosed) {
      throw new Error('Cannot update a closed financial period');
    }
    
    // Update the period
    const [updatedPeriod] = await db
      .update(financialPeriods)
      .set({
        ...period,
        updatedAt: new Date()
      })
      .where(eq(financialPeriods.id, id))
      .returning();
    
    return updatedPeriod;
  }

  async closeFinancialPeriod(id: number, userId: number): Promise<FinancialPeriod | undefined> {
    // Get the current period
    const [currentPeriod] = await db
      .select()
      .from(financialPeriods)
      .where(eq(financialPeriods.id, id));
    
    if (!currentPeriod || !currentPeriod.isOpen || currentPeriod.isClosed) {
      return undefined;
    }
    
    // Check that all journal entries in this period are posted
    const unpostedEntries = await db
      .select({ count: count() })
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.fiscalYear, currentPeriod.fiscalYear),
          eq(journalEntries.fiscalPeriod, currentPeriod.periodNumber),
          eq(journalEntries.isPosted, false)
        )
      );
    
    if (unpostedEntries[0].count > 0) {
      throw new Error('Cannot close period. There are unposted journal entries in this period.');
    }
    
    // Close the period
    const [closedPeriod] = await db
      .update(financialPeriods)
      .set({
        isOpen: false,
        isClosed: true,
        closedBy: userId,
        closedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(financialPeriods.id, id))
      .returning();
    
    return closedPeriod;
  }

  async reopenFinancialPeriod(id: number): Promise<FinancialPeriod | undefined> {
    // Get the current period
    const [currentPeriod] = await db
      .select()
      .from(financialPeriods)
      .where(eq(financialPeriods.id, id));
    
    if (!currentPeriod || !currentPeriod.isClosed) {
      return undefined;
    }
    
    // Don't allow reopening reconciled periods
    if (currentPeriod.isReconciled) {
      throw new Error('Cannot reopen a reconciled financial period');
    }
    
    // Reopen the period
    const [reopenedPeriod] = await db
      .update(financialPeriods)
      .set({
        isOpen: true,
        isClosed: false,
        closedBy: null,
        closedAt: null,
        updatedAt: new Date()
      })
      .where(eq(financialPeriods.id, id))
      .returning();
    
    return reopenedPeriod;
  }

  async reconcileFinancialPeriod(id: number, userId: number): Promise<FinancialPeriod | undefined> {
    // Get the current period
    const [currentPeriod] = await db
      .select()
      .from(financialPeriods)
      .where(eq(financialPeriods.id, id));
    
    if (!currentPeriod || !currentPeriod.isClosed || currentPeriod.isReconciled) {
      return undefined;
    }
    
    // Reconcile the period
    const [reconciledPeriod] = await db
      .update(financialPeriods)
      .set({
        isReconciled: true,
        reconciledBy: userId,
        reconciledAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(financialPeriods.id, id))
      .returning();
    
    return reconciledPeriod;
  }

  // Project Budget Items operations
  async listProjectBudgetItems(projectId: number): Promise<ProjectBudgetItem[]> {
    try {
      return await db
        .select()
        .from(projectBudgetItems)
        .where(eq(projectBudgetItems.projectId, projectId))
        .orderBy(asc(projectBudgetItems.name));
    } catch (error) {
      console.error(`Error listing project budget items:`, error);
      return [];
    }
  }

  async createProjectBudgetItem(item: InsertProjectBudgetItem): Promise<ProjectBudgetItem> {
    try {
      const [newItem] = await db
        .insert(projectBudgetItems)
        .values({
          ...item,
          createdAt: new Date()
        })
        .returning();
      
      return newItem;
    } catch (error) {
      console.error(`Error creating project budget item:`, error);
      throw new Error(`Failed to create project budget item: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async getProjectBudgetItem(id: number): Promise<ProjectBudgetItem | undefined> {
    try {
      const [item] = await db
        .select()
        .from(projectBudgetItems)
        .where(eq(projectBudgetItems.id, id));
      
      return item || undefined;
    } catch (error) {
      console.error(`Error getting project budget item:`, error);
      return undefined;
    }
  }

  async updateProjectBudgetItem(id: number, item: Partial<ProjectBudgetItem>): Promise<ProjectBudgetItem | undefined> {
    try {
      const [updatedItem] = await db
        .update(projectBudgetItems)
        .set({
          ...item,
          updatedAt: new Date()
        })
        .where(eq(projectBudgetItems.id, id))
        .returning();
      
      return updatedItem || undefined;
    } catch (error) {
      console.error(`Error updating project budget item:`, error);
      return undefined;
    }
  }

  async deleteProjectBudgetItem(id: number): Promise<boolean> {
    try {
      const result = await db
        .delete(projectBudgetItems)
        .where(eq(projectBudgetItems.id, id));
      
      return result.rowCount > 0;
    } catch (error) {
      console.error(`Error deleting project budget item:`, error);
      return false;
    }
  }

  // Project Expenses operations
  async listProjectExpenses(projectId: number): Promise<Expense[]> {
    try {
      // التحقق أولاً مما إذا كان جدول المصروفات موجودًا في قاعدة البيانات
      const tableExistsResult = await db.execute(
        sql`SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = 'public' 
          AND table_name = 'expenses'
        )`
      );
      
      const tableExists = tableExistsResult.rows?.[0]?.exists;
      
      // إذا كان الجدول غير موجود، نعيد مصفوفة فارغة بدلاً من محاولة الاستعلام
      if (!tableExists) {
        console.warn(`Table 'expenses' does not exist in the database. Returning empty array.`);
        return [];
      }
      
      // استخدام استعلام SQL مباشر بدلاً من استخدام Drizzle ORM
      // لتجنب خطأ في استخدام alias لجدول chartOfAccounts
      const result = await db.execute(
        sql`
          SELECT e.*, 
                 p.name AS project_name, 
                 pb.name AS budget_item_name, 
                 pb.category AS budget_item_category, 
                 ca.name AS account_name, 
                 ca.code AS account_code, 
                 pa.name AS payment_account_name, 
                 pa.code AS payment_account_code, 
                 u.full_name AS created_by_name 
          FROM expenses e
          LEFT JOIN projects p ON e.project_id = p.id
          LEFT JOIN project_budget_items pb ON e.budget_item_id = pb.id
          LEFT JOIN chart_of_accounts ca ON e.account_id = ca.id
          LEFT JOIN chart_of_accounts pa ON e.payment_account_id = pa.id
          LEFT JOIN users u ON e.created_by = u.id
          WHERE e.project_id = ${projectId}
          ORDER BY e.expense_date DESC
        `
      );
      return result.rows as Expense[];
    } catch (error) {
      console.error(`Error listing project expenses:`, error);
      return [];
    }
  }

  async getExpense(id: number): Promise<Expense | undefined> {
    try {
      const [expense] = await db
        .select({
          ...expenses,
          projectName: projects.name,
          budgetItemName: projectBudgetItems.name,
          budgetItemCategory: projectBudgetItems.category,
          accountName: chartOfAccounts.name,
          accountCode: chartOfAccounts.code,
          paymentAccountName: sql<string>`payment_account.name`.as('paymentAccountName'),
          paymentAccountCode: sql<string>`payment_account.code`.as('paymentAccountCode'),
          createdByName: users.fullName,
          approvedByName: sql<string>`approved_by.fullName`.as('approvedByName')
        })
        .from(expenses)
        .leftJoin(projects, eq(expenses.projectId, projects.id))
        .leftJoin(projectBudgetItems, eq(expenses.budgetItemId, projectBudgetItems.id))
        .leftJoin(chartOfAccounts, eq(expenses.accountId, chartOfAccounts.id))
        .leftJoin(
          chartOfAccounts.as('payment_account'), 
          eq(expenses.paymentAccountId, sql<number>`payment_account.id`)
        )
        .leftJoin(users, eq(expenses.createdBy, users.id))
        .leftJoin(
          users.as('approved_by'),
          eq(expenses.approvedBy, sql<number>`approved_by.id`)
        )
        .where(eq(expenses.id, id));
      
      return expense || undefined;
    } catch (error) {
      console.error(`Error getting expense:`, error);
      return undefined;
    }
  }

  async createExpense(expense: InsertExpense): Promise<Expense> {
    try {
      const [newExpense] = await db
        .insert(expenses)
        .values({
          ...expense,
          status: 'pending',
          createdAt: new Date()
        })
        .returning();
      
      return newExpense;
    } catch (error) {
      console.error(`Error creating expense:`, error);
      throw new Error(`Failed to create expense: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async updateExpense(id: number, expense: Partial<Expense>): Promise<Expense | undefined> {
    try {
      const [updatedExpense] = await db
        .update(expenses)
        .set({
          ...expense,
          updatedAt: new Date()
        })
        .where(eq(expenses.id, id))
        .returning();
      
      return updatedExpense || undefined;
    } catch (error) {
      console.error(`Error updating expense:`, error);
      return undefined;
    }
  }

  async approveExpense(id: number, approverId: number, comments?: string): Promise<Expense | undefined> {
    try {
      const [expense] = await db
        .update(expenses)
        .set({
          status: 'approved',
          approvedBy: approverId,
          approvedAt: new Date(),
          approvalComments: comments || null,
          updatedAt: new Date()
        })
        .where(eq(expenses.id, id))
        .returning();
      
      return expense || undefined;
    } catch (error) {
      console.error(`Error approving expense:`, error);
      return undefined;
    }
  }

  async rejectExpense(id: number, approverId: number, comments: string): Promise<Expense | undefined> {
    try {
      const [expense] = await db
        .update(expenses)
        .set({
          status: 'rejected',
          approvedBy: approverId,
          approvedAt: new Date(),
          approvalComments: comments,
          updatedAt: new Date()
        })
        .where(eq(expenses.id, id))
        .returning();
      
      return expense || undefined;
    } catch (error) {
      console.error(`Error rejecting expense:`, error);
      return undefined;
    }
  }

  async deleteExpense(id: number): Promise<boolean> {
    try {
      const result = await db
        .delete(expenses)
        .where(eq(expenses.id, id));
      
      return result.rowCount > 0;
    } catch (error) {
      console.error(`Error deleting expense:`, error);
      return false;
    }
  }

  /**
   * الحصول على شجرة الحسابات
   * Get chart of accounts
   */
  async getChartOfAccounts() {
    const accounts = await db
      .select()
      .from(chartOfAccounts)
      .orderBy(chartOfAccounts.code);
    
    return accounts;
  }

  /**
   * الحصول على حساب محدد من شجرة الحسابات
   * Get specific account from chart of accounts
   */
  async getChartOfAccountById(id: number) {
    const [account] = await db
      .select()
      .from(chartOfAccounts)
      .where(eq(chartOfAccounts.id, id));
    
    return account;
  }
}

// Use DatabaseStorage as the main storage implementation
export const storage = new DatabaseStorage();