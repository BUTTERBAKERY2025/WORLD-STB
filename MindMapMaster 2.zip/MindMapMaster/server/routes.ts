import type { Express, Request, Response, NextFunction } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";
import multer from "multer";
import fs from "fs";
import { accountingService } from "./services/accountingService";
import { projectService } from "./services/projectService";
import { 
  insertUserSchema, 
  insertProjectSchema, 
  insertTaskSchema, 
  insertFinancialTransactionSchema,
  insertAssetSchema,
  insertResourceSchema,
  insertDocumentSchema,
  insertRiskSchema,
  insertChartOfAccountSchema,
  insertProjectBudgetSchema,
  insertFinancialReportSchema,
  insertContractItemSchema,
  insertExpenseSchema,
  insertProjectBudgetItemSchema,
  insertPaymentCertificateSchema,
  insertPaymentCertificateItemSchema,
  insertCertificateApprovalSchema,
  insertProjectPhotoSchema,
  insertProjectTypeSchema,
  type PaymentCertificateItem,
  projectTypeEnum,
  projectTypes
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handling helper
  const handleError = (res: Response, error: unknown) => {
    console.error("API Error:", error);
    
    if (error instanceof ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ 
        message: "Validation error", 
        errors: validationError.details 
      });
    }
    
    return res.status(500).json({ 
      message: error instanceof Error ? error.message : "An unknown error occurred" 
    });
  };
  
  // API Health Check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });
  
  // Auth routes  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Update last login
      await storage.updateUser(user.id, { lastLogin: new Date() });
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.json({
        user: userWithoutPassword,
        token: "fake-jwt-token" // Just for UI demonstration
      });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // User routes
  app.get("/api/users", async (_req, res) => {
    try {
      const users = await storage.listUsers();
      // Remove passwords from response
      const safeUsers = users.map(({ password, ...user }) => user);
      res.json(safeUsers);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const newUser = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(id, req.body);
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update user" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      // سيتم الحصول على قائمة المشاريع كاملة أولاً
      const allProjects = await storage.listProjects();
      
      // التصفية حسب النوع و/أو الحالة إذا تم تحديد أحدهما
      const type = req.query.type as string | undefined;
      const status = req.query.status as string | undefined;
      
      // إذا لم يتم تحديد أي من الفلاتر، إرجاع كل المشاريع
      if (!type && !status) {
        return res.json(allProjects);
      }
      
      // تطبيق الفلاتر على جانب الخادم
      const filteredProjects = allProjects.filter(project => {
        // التحقق من تطابق النوع إذا تم تحديده
        const matchesType = !type || type === 'all' || project.type === type;
        
        // التحقق من تطابق الحالة إذا تم تحديدها
        const matchesStatus = !status || status === 'all' || project.status === status;
        
        // إرجاع المشاريع التي تطابق جميع الفلاتر المحددة
        return matchesType && matchesStatus;
      });
      
      res.json(filteredProjects);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // إضافة API للحصول على مؤشرات أداء المشاريع - يجب وضعه قبل مسار المشروع الفردي لمنع التعارض
  app.get("/api/projects/kpis", async (req, res) => {
    try {
      const kpis = await projectService.getProjectsKPIs();
      res.json(kpis);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      console.log(`Received request for project with ID: ${id}`);
      
      const project = await storage.getProject(id);
      
      if (!project) {
        console.log(`Project with ID ${id} not found`);
        return res.status(404).json({ message: "Project not found" });
      }
      
      console.log(`Found project: ${project.id} - ${project.name}`);
      console.log(`Project location data:`, JSON.stringify(project.location));
      
      res.json(project);
    } catch (error) {
      console.error(`Error fetching project ${req.params.id}:`, error);
      handleError(res, error);
    }
  });
  
  // إضافة API للحصول على مؤشرات أداء مشروع معين
  app.get("/api/projects/:id/kpis", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const kpis = await projectService.getProjectKPIs(id);
      res.json(kpis);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const newProject = await storage.createProject(projectData);
      res.status(201).json(newProject);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      console.log(`Received PATCH request for project ID ${id}`);
      console.log(`Request body:`, JSON.stringify(req.body));
      
      const project = await storage.getProject(id);
      
      if (!project) {
        console.log(`Project with ID ${id} not found for PATCH operation`);
        return res.status(404).json({ message: "Project not found" });
      }
      
      // تحويل صيغة الموقع إذا كان بتنسيق {type, coordinates}
      let dataToUpdate = {...req.body};
      if (req.body.location) {
        console.log(`Original location data in request:`, JSON.stringify(req.body.location));
        if (req.body.location.type === 'Point' && Array.isArray(req.body.location.coordinates)) {
          dataToUpdate.location = {
            lat: req.body.location.coordinates[1],
            lng: req.body.location.coordinates[0]
          };
          console.log(`Converted location data:`, JSON.stringify(dataToUpdate.location));
        }
      }
      
      const updatedProject = await storage.updateProject(id, dataToUpdate);
      
      if (!updatedProject) {
        console.log(`Failed to update project ${id}`);
        return res.status(500).json({ message: "Failed to update project" });
      }
      
      console.log(`Successfully updated project ${id}`);
      console.log(`Updated project:`, JSON.stringify(updatedProject));
      
      res.json(updatedProject);
    } catch (error) {
      console.error(`Error updating project ${req.params.id}:`, error);
      handleError(res, error);
    }
  });
  
  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const result = await storage.deleteProject(id);
      
      if (!result) {
        return res.status(500).json({ message: "Failed to delete project" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });

  // Project Types routes
  app.get("/api/project-types", async (_req, res) => {
    try {
      // استرجاع قائمة أنواع المشاريع من قاعدة البيانات
      const types = await db.select().from(projectTypes);
      
      // إذا لم تكن هناك أنواع مشاريع في قاعدة البيانات، قم بإنشاء الأنواع الافتراضية
      if (types.length === 0) {
        const defaultTypes = [
          { name: 'road', description: 'مشاريع الطرق والجسور' },
          { name: 'water', description: 'مشاريع المياه والصرف الصحي' },
          { name: 'electricity', description: 'مشاريع الكهرباء والطاقة' },
          { name: 'telecom', description: 'مشاريع الاتصالات والتقنية' },
          { name: 'building', description: 'مشاريع المباني والإنشاءات' }
        ];
        
        // إدخال الأنواع الافتراضية إلى قاعدة البيانات
        const insertedTypes = await db
          .insert(projectTypes)
          .values(defaultTypes)
          .returning();
          
        return res.json(insertedTypes);
      }
      
      res.json(types);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/project-types", async (req, res) => {
    try {
      const typeData = insertProjectTypeSchema.parse(req.body);
      
      // التحقق من عدم وجود نوع مشروع بنفس الاسم
      const existingType = await db
        .select()
        .from(projectTypes)
        .where(sql`lower(${projectTypes.name}) = lower(${typeData.name})`)
        .limit(1);
        
      if (existingType.length > 0) {
        return res.status(400).json({ message: "نوع المشروع موجود بالفعل" });
      }
      
      // إنشاء نوع المشروع الجديد
      const [newType] = await db
        .insert(projectTypes)
        .values(typeData)
        .returning();
        
      res.status(201).json(newType);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/project-types/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const [type] = await db
        .select()
        .from(projectTypes)
        .where(eq(projectTypes.id, id))
        .limit(1);
      
      if (!type) {
        return res.status(404).json({ message: "نوع المشروع غير موجود" });
      }
      
      res.json(type);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/project-types/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // التحقق من وجود نوع المشروع
      const [type] = await db
        .select()
        .from(projectTypes)
        .where(eq(projectTypes.id, id))
        .limit(1);
        
      if (!type) {
        return res.status(404).json({ message: "نوع المشروع غير موجود" });
      }
      
      // تحديث بيانات نوع المشروع
      const [updatedType] = await db
        .update(projectTypes)
        .set(req.body)
        .where(eq(projectTypes.id, id))
        .returning();
        
      res.json(updatedType);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/project-types/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // التحقق من وجود نوع المشروع
      const [type] = await db
        .select()
        .from(projectTypes)
        .where(eq(projectTypes.id, id))
        .limit(1);
        
      if (!type) {
        return res.status(404).json({ message: "نوع المشروع غير موجود" });
      }
      
      // حذف نوع المشروع
      await db
        .delete(projectTypes)
        .where(eq(projectTypes.id, id));
        
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });

  // Tasks routes
  app.get("/api/projects/:projectId/tasks", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const tasks = await storage.listTasksByProject(projectId);
      res.json(tasks);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const newTask = await storage.createTask(taskData);
      res.status(201).json(newTask);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.getTask(id);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const updatedTask = await storage.updateTask(id, req.body);
      
      if (!updatedTask) {
        return res.status(500).json({ message: "Failed to update task" });
      }
      
      res.json(updatedTask);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Financial routes
  app.get("/api/financial", async (_req, res) => {
    try {
      const transactions = await storage.listFinancialTransactions();
      res.json(transactions);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/financial", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const transactions = await storage.listFinancialTransactionsByProject(projectId);
      res.json(transactions);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/financial", async (req, res) => {
    try {
      const transactionData = insertFinancialTransactionSchema.parse(req.body);
      const newTransaction = await storage.createFinancialTransaction(transactionData);
      res.status(201).json(newTransaction);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Project Expenses routes
  app.get("/api/projects/:projectId/expenses", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const expenses = await storage.listProjectExpenses(projectId);
      res.json(expenses);
    } catch (error) {
      handleError(res, error);
    }
  });

  app.post("/api/expenses", async (req, res) => {
    try {
      const expenseData = insertExpenseSchema.parse(req.body);
      const userId = req.body.createdBy || 1; // Default to user 1 if not specified
      
      // Use accounting service to create expense and generate journal entry automatically
      const newExpense = await accountingService.createProjectExpense(expenseData, userId);
      res.status(201).json(newExpense);
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/expenses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const expense = await storage.getExpense(id);
      
      if (!expense) {
        return res.status(404).json({ message: "المصروف غير موجود" });
      }
      
      res.json(expense);
    } catch (error) {
      handleError(res, error);
    }
  });

  app.post("/api/expenses/:id/approve", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.body.approvedBy || 1; // Default to user 1 if not specified
      
      const result = await storage.approveExpense(id, userId);
      
      if (!result) {
        return res.status(500).json({ message: "فشل اعتماد المصروف" });
      }
      
      // Generate journal entry for the approved expense
      await accountingService.generateJournalEntryFromExpense(id, userId);
      
      res.json({ message: "تم اعتماد المصروف بنجاح", expenseId: id });
    } catch (error) {
      handleError(res, error);
    }
  });

  app.post("/api/expenses/:id/reject", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.body.rejectedBy || 1; // Default to user 1 if not specified
      
      const result = await storage.rejectExpense(id, userId);
      
      if (!result) {
        return res.status(500).json({ message: "فشل رفض المصروف" });
      }
      
      res.json({ message: "تم رفض المصروف بنجاح", expenseId: id });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Project Budget Items routes
  app.get("/api/projects/:projectId/budget-items", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const budgetItems = await storage.listProjectBudgetItems(projectId);
      res.json(budgetItems);
    } catch (error) {
      handleError(res, error);
    }
  });

  app.post("/api/budget-items", async (req, res) => {
    try {
      const budgetItemData = insertProjectBudgetItemSchema.parse(req.body);
      const userId = req.body.createdBy || 1; // Default to user 1 if not specified
      
      const newBudgetItem = await storage.createProjectBudgetItem(budgetItemData);
      res.status(201).json(newBudgetItem);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Project Financial Reports routes
  app.get("/api/projects/:projectId/reports/budget-vs-expenses", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const report = await accountingService.getProjectBudgetVsExpensesReport(projectId);
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/projects/:projectId/reports/certificates", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const report = await accountingService.getProjectCertificatesReport(projectId);
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/projects/:projectId/reports/profitability", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const report = await accountingService.getProjectProfitabilityReport(projectId);
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Contract Items routes
  app.get("/api/contract-items", async (_req, res) => {
    try {
      const items = await storage.listContractItems();
      res.json(items);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/contract-items", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const items = await storage.listContractItemsByProject(projectId);
      res.json(items);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/contract-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getContractItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "بند العقد غير موجود" });
      }
      
      res.json(item);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/contract-items", async (req, res) => {
    try {
      const itemData = insertContractItemSchema.parse(req.body);
      const newItem = await storage.createContractItem(itemData);
      res.status(201).json(newItem);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/contract-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getContractItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "بند العقد غير موجود" });
      }
      
      const updatedItem = await storage.updateContractItem(id, req.body);
      
      if (!updatedItem) {
        return res.status(500).json({ message: "فشل تحديث بند العقد" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/contract-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getContractItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "بند العقد غير موجود" });
      }
      
      const result = await storage.deleteContractItem(id);
      
      if (!result) {
        return res.status(500).json({ message: "فشل حذف بند العقد" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Payment Certificates routes
  app.get("/api/certificates", async (req, res) => {
    try {
      let certificates;
      
      if (req.query.type) {
        certificates = await storage.listPaymentCertificatesByType(req.query.type as string);
      } else if (req.query.status) {
        certificates = await storage.listPaymentCertificatesByStatus(req.query.status as string);
      } else {
        certificates = await storage.listPaymentCertificates();
      }
      
      res.json(certificates);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/certificates/stats", async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const stats = await storage.getPaymentCertificateStats(projectId);
      res.json(stats);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/certificates", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const certificates = await storage.listPaymentCertificatesByProject(projectId);
      res.json(certificates);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/certificates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const certificate = await storage.getPaymentCertificate(id);
      
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      res.json(certificate);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/certificates/:id/items", async (req, res) => {
    try {
      const certificateId = parseInt(req.params.id);
      const items = await storage.listPaymentCertificateItems(certificateId);
      res.json(items);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/certificates/:id/journal-entries", async (req, res) => {
    try {
      const certificateId = parseInt(req.params.id);
      const journalEntries = await accountingService.getJournalEntriesByCertificateId(certificateId);
      res.json(journalEntries);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/certificates", async (req, res) => {
    try {
      // 1. Validar los datos básicos del certificado
      const certificateData = insertPaymentCertificateSchema.parse(req.body);
      
      // 2. Obtener el último número de certificado para el proyecto seleccionado
      const projectCertificates = await storage.listPaymentCertificatesByProject(certificateData.projectId);
      const lastCertNumber = projectCertificates.length > 0 
        ? Math.max(...projectCertificates.map(cert => cert.certificateNumber)) 
        : 0;
      
      // 3. Incrementar el número de certificado automáticamente
      const certificateNumber = lastCertNumber + 1;
      
      // 4. Calcular el monto previo de certificados aprobados para este proyecto
      const approvedCertificates = projectCertificates.filter(
        cert => cert.status && ['approved', 'paid'].includes(cert.status)
      );
      const previousAmount = approvedCertificates.reduce(
        (sum, cert) => sum + cert.finalAmount, 
        0
      );
      
      // 5. Preparar el certificado completo con cálculos automáticos
      const completeData = {
        ...certificateData,
        certificateNumber,
        previousAmount,
        version: 1,
        // Calcular montos finales si no se proporcionaron en la solicitud
        currentAmount: certificateData.currentAmount || certificateData.grossAmount,
        
        // Calculamos el monto final si no se proporciona
        finalAmount: certificateData.finalAmount || (
          (certificateData.grossAmount || 0) - 
          (certificateData.advancePaymentDeduction || 0) - 
          (certificateData.retentionAmount || 0) - 
          (certificateData.taxAmount || 0) - 
          (certificateData.otherDeductions || 0) + 
          (certificateData.materialsOnSite || 0) + 
          (certificateData.otherAdditions || 0)
        ),
        
        // Fecha de creación predeterminada
        createdAt: new Date(),
      };
      
      // 6. Crear el certificado en la base de datos
      const newCertificate = await storage.createPaymentCertificate(completeData);
      
      res.status(201).json(newCertificate);
    } catch (error) {
      console.error('Error creating certificate:', error);
      handleError(res, error);
    }
  });
  
  app.patch("/api/certificates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const certificate = await storage.getPaymentCertificate(id);
      
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      const updatedCertificate = await storage.updatePaymentCertificate(id, req.body);
      
      if (!updatedCertificate) {
        return res.status(500).json({ message: "فشل تحديث المستخلص" });
      }
      
      res.json(updatedCertificate);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/certificates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const certificate = await storage.getPaymentCertificate(id);
      
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      const result = await storage.deletePaymentCertificate(id);
      
      if (!result) {
        return res.status(500).json({ message: "فشل حذف المستخلص" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/certificates/:id/submit", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const certificate = await storage.getPaymentCertificate(id);
      
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      const updatedCertificate = await storage.submitPaymentCertificate(id);
      
      if (!updatedCertificate) {
        return res.status(500).json({ message: "فشل تقديم المستخلص" });
      }
      
      res.json(updatedCertificate);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/certificates/:id/approve", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { level, approverId, comments } = req.body;
      
      if (!level || !approverId) {
        return res.status(400).json({ message: "يجب تحديد مستوى الموافقة ومعرف المعتمد" });
      }
      
      const certificate = await storage.getPaymentCertificate(id);
      
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      const updatedCertificate = await storage.approvePaymentCertificate(id, level, approverId, comments);
      
      if (!updatedCertificate) {
        return res.status(500).json({ message: "فشل اعتماد المستخلص" });
      }
      
      // إذا كانت هذه الموافقة النهائية، قم بإنشاء قيد محاسبي تلقائي
      if (level === 'final') {
        try {
          // إنشاء قيد محاسبي تلقائي للمستخلص
          const journalEntryId = await accountingService.generateJournalEntryFromCertificate(id, approverId);
          
          // إذا تم إنشاء القيد بنجاح، قم بإضافة معلومات إضافية للرد
          if (journalEntryId) {
            // يمكن ترحيل القيد تلقائيًا أو تركه كمسودة للمراجعة قبل الترحيل
            // await accountingService.postJournalEntry(journalEntryId, approverId);
            
            return res.json({
              ...updatedCertificate,
              journalEntryId,
              message: "تم اعتماد المستخلص وإنشاء قيد محاسبي بنجاح"
            });
          }
        } catch (journalError) {
          console.error("خطأ أثناء إنشاء القيد المحاسبي التلقائي:", journalError);
          // نستمر بإرجاع نجاح اعتماد المستخلص حتى لو فشل إنشاء القيد المحاسبي
        }
      }
      
      res.json(updatedCertificate);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/certificates/:id/reject", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { level, approverId, comments } = req.body;
      
      if (!level || !approverId || !comments) {
        return res.status(400).json({ message: "يجب تحديد مستوى الموافقة ومعرف المعتمد والتعليقات" });
      }
      
      const certificate = await storage.getPaymentCertificate(id);
      
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      const updatedCertificate = await storage.rejectPaymentCertificate(id, level, approverId, comments);
      
      if (!updatedCertificate) {
        return res.status(500).json({ message: "فشل رفض المستخلص" });
      }
      
      res.json(updatedCertificate);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/certificates/:id/mark-paid", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { paymentAmount, paymentDate, bankAccountId } = req.body;
      const userId = req.body.userId || 1; // استخدام معرف المستخدم من طلب API أو القيمة الافتراضية
      
      // التحقق من البيانات المطلوبة
      if (!paymentAmount || !bankAccountId) {
        return res.status(400).json({ message: "يجب توفير مبلغ الدفعة ومعرف الحساب البنكي" });
      }
      
      const certificate = await storage.getPaymentCertificate(id);
      
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      // تحديث حالة المستخلص إلى مدفوع
      const updatedCertificate = await storage.markPaymentCertificateAsPaid(id);
      
      if (!updatedCertificate) {
        return res.status(500).json({ message: "فشل تحديث حالة المستخلص إلى مدفوع" });
      }
      
      // إنشاء قيد محاسبي للدفعة
      try {
        const journalEntryId = await accountingService.generatePaymentJournalEntry(
          id,
          paymentAmount || updatedCertificate.finalAmount || 0,
          paymentDate || new Date(),
          bankAccountId,
          userId
        );
        
        if (journalEntryId) {
          // يمكن ترحيل القيد تلقائيًا أو تركه كمسودة للمراجعة
          // await accountingService.postJournalEntry(journalEntryId, userId);
          
          return res.json({
            ...updatedCertificate,
            paymentJournalEntryId: journalEntryId,
            message: "تم تحديث المستخلص إلى مدفوع وإنشاء قيد محاسبي للدفعة بنجاح"
          });
        }
      } catch (journalError) {
        console.error("خطأ أثناء إنشاء قيد محاسبي للدفعة:", journalError);
        // نستمر بإرجاع نجاح تحديث المستخلص حتى لو فشل إنشاء القيد المحاسبي
      }
      
      res.json(updatedCertificate);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Payment Certificate Items routes
  app.get("/api/certificates/:certificateId/items", async (req, res) => {
    try {
      const certificateId = parseInt(req.params.certificateId);
      const items = await storage.listPaymentCertificateItems(certificateId);
      res.json(items);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/certificate-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getPaymentCertificateItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "عنصر المستخلص غير موجود" });
      }
      
      res.json(item);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/certificate-items", async (req, res) => {
    try {
      // 1. Validar datos básicos del elemento
      const itemData = insertPaymentCertificateItemSchema.parse(req.body);
      
      // 2. Obtener detalles del certificado y del elemento del contrato si aplica
      const certificate = await storage.getPaymentCertificate(itemData.certificateId);
      if (!certificate) {
        return res.status(404).json({ message: "المستخلص غير موجود" });
      }
      
      let contractItem = null;
      if (itemData.contractItemId) {
        contractItem = await storage.getContractItem(itemData.contractItemId);
        if (!contractItem) {
          return res.status(404).json({ message: "بند العقد غير موجود" });
        }
      }
      
      // 3. Obtener elementos previos para este mismo bnd (si existe) en certificados anteriores
      let previousQuantity = 0;
      
      if (contractItem) {
        const previousCertificates = await storage.listPaymentCertificatesByProject(certificate.projectId);
        const approvedCertificateIds = previousCertificates
          .filter(cert => cert.id !== certificate.id && cert.status && ['approved', 'paid'].includes(cert.status))
          .map(cert => cert.id);
          
        if (approvedCertificateIds.length > 0) {
          // Verificar si existe elemento de contrato en certificados anteriores
          const previousItems = await Promise.all(
            approvedCertificateIds.map(async (certId) => {
              // Obtenemos todos los elementos del certificado anterior
              const items = await storage.listPaymentCertificateItems(certId);
              // Filtramos para encontrar si existe uno con el mismo contractItemId
              return items.find(item => item.contractItemId === itemData.contractItemId);
            })
          );
          
          // Calculamos la cantidad previa total
          previousQuantity = previousItems
            .filter(item => item !== undefined && item !== null)
            .reduce((sum, item) => sum + (item?.currentQuantity || 0), 0);
        }
      }
      
      // 4. Calcular valores derivados
      const totalQuantity = previousQuantity + itemData.currentQuantity;
      
      let completionPercentage = 0;
      let remainingQuantity = 0;
      
      if (contractItem) {
        completionPercentage = (totalQuantity / contractItem.quantity) * 100;
        remainingQuantity = contractItem.quantity - totalQuantity;
      } else if (itemData.completionPercentage) {
        completionPercentage = itemData.completionPercentage;
      }
      
      // Calcula el monto final si no se proporciona
      const amount = itemData.amount || (itemData.currentQuantity * itemData.unitPrice);
      
      // 5. Completar el objeto con todos los campos necesarios
      const completeItemData = {
        ...itemData,
        previousQuantity,
        totalQuantity,
        completionPercentage,
        remainingQuantity,
        amount,
        itemNumber: contractItem?.itemNumber || null,
        // Si no se proporciona descripción, usar la del elemento del contrato
        description: itemData.description || contractItem?.description || '',
        // Si no se proporciona unidad, usar la del elemento del contrato
        unit: itemData.unit || contractItem?.unit || '',
        contractQuantity: contractItem?.quantity || null,
        unitPrice: itemData.unitPrice || contractItem?.unitPrice || 0,
        isVariation: itemData.isVariation || !itemData.contractItemId || false,
      };
      
      // 6. Crear el elemento en la base de datos
      const newItem = await storage.createPaymentCertificateItem(completeItemData);
      
      // 7. Actualizar totales del certificado
      const certificateItems = [
        ...await storage.listPaymentCertificateItems(certificate.id),
        newItem
      ];
      
      const totalGrossAmount = certificateItems.reduce((sum, item) => sum + item.amount, 0);
      
      await storage.updatePaymentCertificate(certificate.id, {
        grossAmount: totalGrossAmount,
        totalAmount: totalGrossAmount,
        finalAmount: (totalGrossAmount || 0) - 
                    (certificate.advancePaymentDeduction || 0) - 
                    (certificate.retentionAmount || 0) - 
                    (certificate.taxAmount || 0) - 
                    (certificate.otherDeductions || 0) + 
                    (certificate.materialsOnSite || 0) + 
                    (certificate.otherAdditions || 0)
      });
      
      res.status(201).json(newItem);
    } catch (error) {
      console.error('Error creating certificate item:', error);
      handleError(res, error);
    }
  });
  
  app.patch("/api/certificate-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getPaymentCertificateItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "عنصر المستخلص غير موجود" });
      }
      
      const updatedItem = await storage.updatePaymentCertificateItem(id, req.body);
      
      if (!updatedItem) {
        return res.status(500).json({ message: "فشل تحديث عنصر المستخلص" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/certificate-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getPaymentCertificateItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "عنصر المستخلص غير موجود" });
      }
      
      const result = await storage.deletePaymentCertificateItem(id);
      
      if (!result) {
        return res.status(500).json({ message: "فشل حذف عنصر المستخلص" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Certificate Approvals routes
  app.get("/api/certificates/:certificateId/approvals", async (req, res) => {
    try {
      const certificateId = parseInt(req.params.certificateId);
      const approvals = await storage.listCertificateApprovals(certificateId);
      res.json(approvals);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Assets routes
  app.get("/api/assets", async (_req, res) => {
    try {
      const assets = await storage.listAssets();
      res.json(assets);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/assets", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const assets = await storage.listAssetsByProject(projectId);
      res.json(assets);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/assets", async (req, res) => {
    try {
      const assetData = insertAssetSchema.parse(req.body);
      const newAsset = await storage.createAsset(assetData);
      res.status(201).json(newAsset);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/assets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const asset = await storage.getAsset(id);
      
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      
      const updatedAsset = await storage.updateAsset(id, req.body);
      
      if (!updatedAsset) {
        return res.status(500).json({ message: "Failed to update asset" });
      }
      
      res.json(updatedAsset);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Resources routes
  app.get("/api/resources", async (_req, res) => {
    try {
      const resources = await storage.listResources();
      res.json(resources);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/resources", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const resources = await storage.listResourcesByProject(projectId);
      res.json(resources);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/resources", async (req, res) => {
    try {
      const resourceData = insertResourceSchema.parse(req.body);
      const newResource = await storage.createResource(resourceData);
      res.status(201).json(newResource);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Documents routes
  app.get("/api/documents", async (_req, res) => {
    try {
      const documents = await storage.listDocuments();
      res.json(documents);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/documents", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const documents = await storage.listDocumentsByProject(projectId);
      res.json(documents);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/documents", async (req, res) => {
    try {
      const documentData = insertDocumentSchema.parse(req.body);
      const newDocument = await storage.createDocument(documentData);
      res.status(201).json(newDocument);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Risks routes
  app.get("/api/risks", async (req, res) => {
    try {
      let risks;
      
      if (req.query.level) {
        risks = await storage.listRisksByLevel(req.query.level as string);
      } else {
        risks = await storage.listRisks();
      }
      
      res.json(risks);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/risks", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const risks = await storage.listRisksByProject(projectId);
      res.json(risks);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/risks", async (req, res) => {
    try {
      const riskData = insertRiskSchema.parse(req.body);
      const newRisk = await storage.createRisk(riskData);
      res.status(201).json(newRisk);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/risks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const risk = await storage.getRisk(id);
      
      if (!risk) {
        return res.status(404).json({ message: "Risk not found" });
      }
      
      const updatedRisk = await storage.updateRisk(id, req.body);
      
      if (!updatedRisk) {
        return res.status(500).json({ message: "Failed to update risk" });
      }
      
      res.json(updatedRisk);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Chart of Accounts routes
  app.get("/api/chart-of-accounts", async (req, res) => {
    try {
      const accounts = await storage.listAccounts();
      res.json(accounts);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/accounts", async (req, res) => {
    try {
      let accounts;
      
      if (req.query.type) {
        accounts = await storage.listAccountsByType(req.query.type as string);
      } else if (req.query.parentId) {
        accounts = await storage.listChildAccounts(parseInt(req.query.parentId as string));
      } else if (req.query.root === 'true') {
        accounts = await storage.listRootAccounts();
      } else {
        accounts = await storage.listAccounts();
      }
      
      res.json(accounts);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/accounts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const account = await storage.getAccount(id);
      
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      res.json(account);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/accounts/code/:code", async (req, res) => {
    try {
      const code = req.params.code;
      const account = await storage.getAccountByCode(code);
      
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      res.json(account);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/accounts", async (req, res) => {
    try {
      const accountData = insertChartOfAccountSchema.parse(req.body);
      const newAccount = await storage.createAccount(accountData);
      res.status(201).json(newAccount);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/accounts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const account = await storage.getAccount(id);
      
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      const updatedAccount = await storage.updateAccount(id, req.body);
      
      if (!updatedAccount) {
        return res.status(500).json({ message: "Failed to update account" });
      }
      
      res.json(updatedAccount);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/accounts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const account = await storage.getAccount(id);
      
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      const result = await storage.deleteAccount(id);
      
      if (!result) {
        return res.status(400).json({ 
          message: "Cannot delete account. It may have child accounts or be referenced elsewhere." 
        });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Project Budget routes
  app.get("/api/budgets", async (req, res) => {
    try {
      let budgets;
      
      if (req.query.projectId) {
        budgets = await storage.listProjectBudgetsByProject(parseInt(req.query.projectId as string));
      } else if (req.query.year) {
        budgets = await storage.listProjectBudgetsByYear(parseInt(req.query.year as string));
      } else {
        budgets = await storage.listProjectBudgets();
      }
      
      res.json(budgets);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/budgets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const budget = await storage.getProjectBudget(id);
      
      if (!budget) {
        return res.status(404).json({ message: "Budget not found" });
      }
      
      res.json(budget);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/projects/:projectId/budgets", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const budgets = await storage.listProjectBudgetsByProject(projectId);
      res.json(budgets);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/budgets", async (req, res) => {
    try {
      const budgetData = insertProjectBudgetSchema.parse(req.body);
      const newBudget = await storage.createProjectBudget(budgetData);
      res.status(201).json(newBudget);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/budgets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const budget = await storage.getProjectBudget(id);
      
      if (!budget) {
        return res.status(404).json({ message: "Budget not found" });
      }
      
      const updatedBudget = await storage.updateProjectBudget(id, req.body);
      
      if (!updatedBudget) {
        return res.status(500).json({ message: "Failed to update budget" });
      }
      
      res.json(updatedBudget);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/budgets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const budget = await storage.getProjectBudget(id);
      
      if (!budget) {
        return res.status(404).json({ message: "Budget not found" });
      }
      
      const result = await storage.deleteProjectBudget(id);
      
      if (!result) {
        return res.status(500).json({ message: "Failed to delete budget" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Financial Reports routes
  app.get("/api/reports", async (_req, res) => {
    try {
      const reports = await storage.listFinancialReports();
      res.json(reports);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const report = await storage.getFinancialReport(id);
      
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/reports", async (req, res) => {
    try {
      const reportData = insertFinancialReportSchema.parse(req.body);
      const newReport = await storage.createFinancialReport(reportData);
      res.status(201).json(newReport);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const report = await storage.getFinancialReport(id);
      
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      const updatedReport = await storage.updateFinancialReport(id, req.body);
      
      if (!updatedReport) {
        return res.status(500).json({ message: "Failed to update report" });
      }
      
      res.json(updatedReport);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const report = await storage.getFinancialReport(id);
      
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      const result = await storage.deleteFinancialReport(id);
      
      if (!result) {
        return res.status(500).json({ message: "Failed to delete report" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Financial Statistics
  app.get("/api/financial/stats", async (_req, res) => {
    try {
      const financialStats = await storage.getFinancialStats();
      res.json(financialStats);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Dashboard statistics
  app.get("/api/dashboard/stats", async (_req, res) => {
    try {
      const projectStats = await storage.getProjectStats();
      const riskStats = await storage.getRiskStats();
      const financialStats = await storage.getFinancialStats();
      
      res.json({
        projects: projectStats,
        risks: riskStats,
        financial: financialStats
      });
    } catch (error) {
      handleError(res, error);
    }
  });

  // تكوين تخزين ملفات الصور باستخدام multer
  const projectPhotoStorage = multer.diskStorage({
    destination: (_req, _file, cb) => {
      const uploadDir = 'uploads/project_photos';
      // إنشاء المجلد إذا لم يكن موجودًا
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (_req, file, cb) => {
      // إنشاء اسم ملف فريد باستخدام الطابع الزمني
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const fileExt = path.extname(file.originalname);
      cb(null, `photo-${uniqueSuffix}${fileExt}`);
    }
  });

  const uploadProjectPhoto = multer({ 
    storage: projectPhotoStorage,
    limits: {
      fileSize: 5 * 1024 * 1024, // 5 ميجابايت كحد أقصى
    },
    fileFilter: (_req, file, cb) => {
      // قبول فقط صور 
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('نوع الملف غير مسموح به. الرجاء تحميل ملف صورة فقط.'));
      }
    }
  });

  // نقاط النهاية API الخاصة بصور المشروع
  
  // الحصول على قائمة صور مشروع معين
  app.get("/api/projects/:projectId/photos", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const photos = await storage.listProjectPhotosByProject(projectId);
      res.json(photos);
    } catch (error) {
      handleError(res, error);
    }
  });

  // تحميل صورة جديدة للمشروع
  app.post("/api/projects/:projectId/photos", uploadProjectPhoto.single('photo'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "لم يتم توفير ملف صورة" });
      }

      const projectId = parseInt(req.params.projectId);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "المشروع غير موجود" });
      }

      // إعداد بيانات الصورة
      const photoData = {
        projectId,
        title: req.body.title || 'صورة بدون عنوان',
        description: req.body.description || '',
        path: req.file.path,
        captureDate: req.body.captureDate ? new Date(req.body.captureDate) : new Date(),
        uploadedBy: req.body.uploadedBy ? parseInt(req.body.uploadedBy) : undefined,
        tags: req.body.tags ? JSON.parse(req.body.tags) : [],
        location: req.body.location ? JSON.parse(req.body.location) : null
      };

      // التحقق من البيانات باستخدام Zod
      const validatedData = insertProjectPhotoSchema.parse(photoData);
      
      // إنشاء سجل الصورة في قاعدة البيانات
      const newPhoto = await storage.createProjectPhoto(validatedData);
      
      res.status(201).json({
        ...newPhoto,
        url: `/uploads/project_photos/${path.basename(newPhoto.path)}`
      });
    } catch (error) {
      // حذف الملف في حالة حدوث خطأ
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      handleError(res, error);
    }
  });

  // الحصول على تفاصيل صورة محددة
  app.get("/api/project-photos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const photo = await storage.getProjectPhoto(id);
      
      if (!photo) {
        return res.status(404).json({ message: "الصورة غير موجودة" });
      }
      
      res.json(photo);
    } catch (error) {
      handleError(res, error);
    }
  });

  // حذف صورة
  app.delete("/api/project-photos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const photo = await storage.getProjectPhoto(id);
      
      if (!photo) {
        return res.status(404).json({ message: "الصورة غير موجودة" });
      }
      
      // حذف ملف الصورة
      if (fs.existsSync(photo.path)) {
        fs.unlinkSync(photo.path);
      }
      
      // حذف سجل الصورة من قاعدة البيانات
      const result = await storage.deleteProjectPhoto(id);
      
      if (!result) {
        return res.status(500).json({ message: "فشل حذف الصورة" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });

  // تقديم الصور المحفوظة
  app.use('/uploads', express.static('uploads'));
  
  // Journal Entries routes
  app.get("/api/journal-entries", async (req, res) => {
    try {
      let entries;
      
      if (req.query.isPosted !== undefined) {
        const isPosted = req.query.isPosted === 'true';
        entries = await storage.listJournalEntriesByStatus(isPosted);
      } else if (req.query.projectId) {
        const projectId = parseInt(req.query.projectId as string);
        entries = await storage.listJournalEntriesByProject(projectId);
      } else if (req.query.certificateId) {
        const certificateId = parseInt(req.query.certificateId as string);
        entries = await storage.listJournalEntriesByCertificate(certificateId);
      } else if (req.query.fiscalYear && req.query.fiscalPeriod) {
        const fiscalYear = parseInt(req.query.fiscalYear as string);
        const fiscalPeriod = parseInt(req.query.fiscalPeriod as string);
        entries = await storage.listJournalEntriesByFiscalPeriod(fiscalYear, fiscalPeriod);
      } else {
        entries = await storage.listJournalEntries();
      }
      
      res.json(entries);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/journal-entries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const entry = await storage.getJournalEntry(id);
      
      if (!entry) {
        return res.status(404).json({ message: "القيد المحاسبي غير موجود" });
      }
      
      res.json(entry);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/journal-entries/:id/lines", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const lines = await storage.listJournalEntryLines(id);
      res.json(lines);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/journal-entries", async (req, res) => {
    try {
      const { entry, lines } = req.body;
      
      if (!entry) {
        return res.status(400).json({ message: "بيانات القيد المحاسبي مطلوبة" });
      }
      
      if (!lines || !Array.isArray(lines) || lines.length === 0) {
        return res.status(400).json({ message: "يجب إضافة سطر واحد على الأقل للقيد المحاسبي" });
      }
      
      // Validate that debits equal credits
      const totalDebits = lines
        .reduce((sum, line) => sum + (line.debitAmount || 0), 0);
      
      const totalCredits = lines
        .reduce((sum, line) => sum + (line.creditAmount || 0), 0);
      
      if (Math.abs(totalDebits - totalCredits) > 0.01) {
        return res.status(400).json({ 
          message: "القيد غير متوازن. يجب أن يتساوى مجموع المدين مع مجموع الدائن",
          totalDebits,
          totalCredits
        });
      }
      
      // Set the default status to draft if not specified
      if (entry.isPosted === undefined) {
        entry.isPosted = false;
      }
      
      // Set the entry date to now if not provided
      if (!entry.entryDate) {
        entry.entryDate = new Date();
      }
      
      // تحويل journalDate إلى كائن Date إذا كان نصاً
      if (typeof entry.journalDate === 'string') {
        entry.journalDate = new Date(entry.journalDate);
      }
      
      // Get the current user if authenticated
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      entry.createdBy = userId;
      
      const newEntry = await storage.createJournalEntry(entry, lines);
      res.status(201).json(newEntry);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/journal-entries/:id/post", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      
      const postedEntry = await storage.postJournalEntry(id, userId);
      
      if (!postedEntry) {
        return res.status(404).json({ message: "لم يتم العثور على القيد المحاسبي أو أنه تم ترحيله بالفعل" });
      }
      
      res.json(postedEntry);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/journal-entries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const entry = await storage.getJournalEntry(id);
      
      if (!entry) {
        return res.status(404).json({ message: "القيد المحاسبي غير موجود" });
      }
      
      if (entry.isPosted) {
        return res.status(400).json({ message: "لا يمكن تعديل قيد محاسبي تم ترحيله" });
      }
      
      const updatedEntry = await storage.updateJournalEntry(id, req.body);
      
      if (!updatedEntry) {
        return res.status(500).json({ message: "فشل تحديث القيد المحاسبي" });
      }
      
      res.json(updatedEntry);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/journal-entries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const entry = await storage.getJournalEntry(id);
      
      if (!entry) {
        return res.status(404).json({ message: "القيد المحاسبي غير موجود" });
      }
      
      if (entry.isPosted) {
        return res.status(400).json({ message: "لا يمكن حذف قيد محاسبي تم ترحيله" });
      }
      
      const result = await storage.deleteJournalEntry(id);
      
      if (!result) {
        return res.status(500).json({ message: "فشل حذف القيد المحاسبي" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Journal Entry Lines routes
  app.post("/api/journal-entry-lines", async (req, res) => {
    try {
      const line = req.body;
      
      if (!line.journalEntryId) {
        return res.status(400).json({ message: "معرف القيد المحاسبي مطلوب" });
      }
      
      const newLine = await storage.createJournalEntryLine(line);
      res.status(201).json(newLine);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/journal-entry-lines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const lineData = req.body;
      
      const updatedLine = await storage.updateJournalEntryLine(id, lineData);
      
      if (!updatedLine) {
        return res.status(404).json({ message: "سطر القيد المحاسبي غير موجود أو لا يمكن تعديله" });
      }
      
      res.json(updatedLine);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.delete("/api/journal-entry-lines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const result = await storage.deleteJournalEntryLine(id);
      
      if (!result) {
        return res.status(404).json({ message: "سطر القيد المحاسبي غير موجود أو لا يمكن حذفه" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Financial Periods routes
  app.get("/api/financial-periods", async (req, res) => {
    try {
      let periods;
      
      if (req.query.fiscalYear) {
        const fiscalYear = parseInt(req.query.fiscalYear as string);
        periods = await storage.listFinancialPeriodsByYear(fiscalYear);
      } else {
        periods = await storage.listFinancialPeriods();
      }
      
      res.json(periods);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.get("/api/financial-periods/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const period = await storage.getFinancialPeriod(id);
      
      if (!period) {
        return res.status(404).json({ message: "الفترة المالية غير موجودة" });
      }
      
      res.json(period);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/financial-periods", async (req, res) => {
    try {
      const periodData = req.body;
      
      // Validate required fields
      if (!periodData.fiscal_year || !periodData.period_number || !periodData.name) {
        return res.status(400).json({ message: "السنة المالية ورقم الفترة واسم الفترة مطلوبة" });
      }
      
      // Set dates from/to if not provided
      if (!periodData.start_date) {
        const startMonth = (periodData.period_number - 1) * 3 + 1;
        periodData.start_date = new Date(periodData.fiscal_year, startMonth - 1, 1);
      }
      
      if (!periodData.end_date) {
        const startMonth = (periodData.period_number - 1) * 3 + 1;
        const endMonth = startMonth + 2;
        periodData.end_date = new Date(periodData.fiscal_year, endMonth, 0); // Last day of the end month
      }
      
      const newPeriod = await storage.createFinancialPeriod(periodData);
      res.status(201).json(newPeriod);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.patch("/api/financial-periods/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const periodData = req.body;
      
      const updatedPeriod = await storage.updateFinancialPeriod(id, periodData);
      
      if (!updatedPeriod) {
        return res.status(404).json({ message: "الفترة المالية غير موجودة أو لا يمكن تعديلها" });
      }
      
      res.json(updatedPeriod);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/financial-periods/:id/close", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      
      const closedPeriod = await storage.closeFinancialPeriod(id, userId);
      
      if (!closedPeriod) {
        return res.status(404).json({ message: "الفترة المالية غير موجودة أو تم إغلاقها بالفعل" });
      }
      
      res.json(closedPeriod);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/financial-periods/:id/reopen", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const reopenedPeriod = await storage.reopenFinancialPeriod(id);
      
      if (!reopenedPeriod) {
        return res.status(404).json({ message: "الفترة المالية غير موجودة أو لم يتم إغلاقها" });
      }
      
      res.json(reopenedPeriod);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  app.post("/api/financial-periods/:id/reconcile", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      
      const reconciledPeriod = await storage.reconcileFinancialPeriod(id, userId);
      
      if (!reconciledPeriod) {
        return res.status(404).json({ message: "الفترة المالية غير موجودة أو لم يتم إغلاقها" });
      }
      
      res.json(reconciledPeriod);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // ========================= Project Financial APIs =========================
  
  // Project Expenses API
  
  /**
   * الحصول على كافة المصروفات الخاصة بمشروع معين
   * Get all expenses for a specific project
   */
  app.get("/api/projects/:id/expenses", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const expenses = await storage.listProjectExpenses(projectId);
      res.json(expenses);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * إضافة مصروف جديد مرتبط بمشروع
   * Add a new expense associated with a project
   */
  app.post("/api/expenses", async (req, res) => {
    try {
      const expenseData = insertExpenseSchema.parse(req.body);
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      
      const newExpense = await accountingService.createProjectExpense(expenseData, userId);
      
      if (!newExpense) {
        return res.status(400).json({ message: "فشل في إنشاء المصروف" });
      }
      
      res.status(201).json(newExpense);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على معلومات مصروف محدد
   * Get a specific expense
   */
  app.get("/api/expenses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const expense = await storage.getExpense(id);
      
      if (!expense) {
        return res.status(404).json({ message: "المصروف غير موجود" });
      }
      
      res.json(expense);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * اعتماد مصروف
   * Approve an expense
   */
  app.post("/api/expenses/:id/approve", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      
      const approvedExpense = await storage.approveExpense(id, userId);
      
      if (!approvedExpense) {
        return res.status(404).json({ message: "المصروف غير موجود أو لا يمكن اعتماده" });
      }
      
      // إنشاء قيد محاسبي للمصروف إذا لم يكن موجوداً بالفعل
      if (!approvedExpense.journalEntryId) {
        const journalEntryId = await accountingService.generateJournalEntryFromExpense(id, userId);
        
        if (journalEntryId) {
          approvedExpense.journalEntryId = journalEntryId;
        }
      }
      
      res.json(approvedExpense);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * رفض مصروف
   * Reject an expense
   */
  app.post("/api/expenses/:id/reject", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      const { comments } = req.body;
      
      const rejectedExpense = await storage.rejectExpense(id, userId, comments);
      
      if (!rejectedExpense) {
        return res.status(404).json({ message: "المصروف غير موجود أو لا يمكن رفضه" });
      }
      
      res.json(rejectedExpense);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على تقرير مصروفات مقابل الميزانية للمشروع
   * Get budget vs. expenses report for a project
   */
  app.get("/api/projects/:id/budget-vs-expenses", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      
      if (isNaN(projectId)) {
        return res.status(400).json({ message: "معرف المشروع غير صالح" });
      }
      
      const report = await accountingService.getProjectBudgetVsExpensesReport(projectId);
      
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Project Budget Items API
  
  /**
   * الحصول على بنود ميزانية مشروع معين
   * Get budget items for a specific project
   */
  app.get("/api/projects/:id/budget-items", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const budgetItems = await storage.listProjectBudgetItems(projectId);
      res.json(budgetItems);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * إضافة بند ميزانية جديد لمشروع
   * Add a new budget item to a project
   */
  app.post("/api/projects/:id/budget-items", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const budgetItemData = insertProjectBudgetItemSchema.parse({
        ...req.body,
        projectId
      });
      
      const userId = req.user?.id || 1; // Default to 1 if not authenticated
      
      const newBudgetItem = await storage.createProjectBudgetItem({
        ...budgetItemData,
        createdBy: userId
      });
      
      res.status(201).json(newBudgetItem);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Project Financial Reports API
  
  /**
   * الحصول على تقرير مصروفات مقابل الميزانية للمشروع
   * Get budget vs. expenses report for a project
   */
  app.get("/api/projects/:id/reports/budget-vs-expenses", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const report = await accountingService.getProjectBudgetVsExpensesReport(projectId);
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على تقرير حالة المستخلصات والمدفوعات للمشروع
   * Get certificates and payments status report for a project
   */
  app.get("/api/projects/:id/reports/certificates", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const report = await accountingService.getProjectCertificatesReport(projectId);
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على تقرير ربحية المشروع
   * Get project profitability report
   */
  app.get("/api/projects/:id/reports/profitability", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const report = await accountingService.getProjectProfitabilityReport(projectId);
      res.json(report);
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * الحصول على قائمة الحسابات للاستخدام في واجهة كشف الحساب
   * Get accounts list for account statement interface
   */
  app.get('/api/financial/accounts', async (req, res) => {
    try {
      const accounts = await storage.getChartOfAccounts();
      const formattedAccounts = accounts.map(account => ({
        id: account.id,
        code: account.code,
        nameAr: account.nameAr,
        nameEn: account.nameEn,
        balance: account.balance || 0,
        type: account.type
      }));
      res.json(formattedAccounts);
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * الحصول على كشف حساب
   * Get account statement
   */
  app.get('/api/financial/account-statement', async (req, res) => {
    try {
      const accountId = Number(req.query.accountId);
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      const transactionType = req.query.transactionType as string || 'all';

      if (!accountId || !startDate || !endDate) {
        return res.status(400).json({ error: 'Missing required parameters' });
      }

      // جلب بيانات الحساب
      const accountDetails = await storage.getChartOfAccountById(accountId);
      if (!accountDetails) {
        return res.status(404).json({ error: 'Account not found' });
      }

      // جلب كشف الحساب من خدمة المحاسبة
      const statement = await accountingService.getAccountStatement(accountId, startDate, endDate, transactionType);
      
      res.json(statement);
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * الحصول على ميزان المراجعة
   * Get trial balance
   */
  app.get('/api/financial/trial-balance', async (req, res) => {
    try {
      const asOfDate = req.query.asOfDate 
        ? new Date(req.query.asOfDate as string) 
        : new Date();
      
      const fiscalYear = req.query.fiscalYear 
        ? parseInt(req.query.fiscalYear as string) 
        : undefined;
        
      const fiscalPeriod = req.query.fiscalPeriod 
        ? parseInt(req.query.fiscalPeriod as string) 
        : undefined;
      
      const trialBalance = await accountingService.getTrialBalance(
        asOfDate,
        fiscalYear,
        fiscalPeriod
      );
      
      return res.json(trialBalance);
    } catch (error) {
      return handleError(res, error);
    }
  });
  
  /**
   * الحصول على الميزانية العمومية
   * Get balance sheet
   */
  app.get('/api/financial/balance-sheet', async (req, res) => {
    try {
      const asOfDate = req.query.asOfDate 
        ? new Date(req.query.asOfDate as string) 
        : new Date();
      
      const fiscalYear = req.query.fiscalYear 
        ? parseInt(req.query.fiscalYear as string) 
        : undefined;
        
      const fiscalPeriod = req.query.fiscalPeriod 
        ? parseInt(req.query.fiscalPeriod as string) 
        : undefined;
      
      const compareWithPrevPeriod = req.query.compareWithPrevPeriod === 'true';
      
      const balanceSheet = await accountingService.getBalanceSheet(
        asOfDate,
        fiscalYear,
        fiscalPeriod,
        compareWithPrevPeriod
      );
      
      return res.json(balanceSheet);
    } catch (error) {
      return handleError(res, error);
    }
  });
  
  /**
   * الحصول على قائمة الدخل
   * Get income statement
   */
  app.get("/api/financial/transactions", async (req, res) => {
    try {
      // Extract query parameters
      const { 
        page = 1, 
        limit = 20, 
        type, 
        projectId, 
        accountId,
        status,
        search,
        startDate,
        endDate,
        minAmount,
        maxAmount
      } = req.query;
      
      // Get transactions from database
      const transactions = await accountingService.getTransactions({
        page: Number(page),
        limit: Number(limit),
        type: type as string,
        projectId: projectId ? Number(projectId) : undefined,
        accountId: accountId ? Number(accountId) : undefined,
        status: status as string,
        search: search as string,
        startDate: startDate as string,
        endDate: endDate as string,
        minAmount: minAmount ? Number(minAmount) : undefined,
        maxAmount: maxAmount ? Number(maxAmount) : undefined
      });
      
      // Return transactions
      res.json(transactions);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على معاملة مالية محددة
   * Get a specific financial transaction
   */
  app.get("/api/financial/transactions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Get transaction details
      const transaction = await accountingService.getTransactionById(Number(id));
      
      if (!transaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      // Return transaction details
      res.json(transaction);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * إنشاء معاملة مالية جديدة
   * Create a new financial transaction
   */
  app.post("/api/financial/transactions", async (req, res) => {
    try {
      const transactionData = req.body;
      
      // Create transaction in the database
      const transaction = await accountingService.createTransaction(transactionData);
      
      // Return created transaction
      res.status(201).json(transaction);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * تحديث معاملة مالية
   * Update a financial transaction
   */
  app.patch("/api/financial/transactions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      // Update transaction in the database
      const updated = await accountingService.updateTransaction(Number(id), updates);
      
      if (!updated) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      // Return updated transaction
      res.json(updated);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * حذف معاملة مالية
   * Delete a financial transaction
   */
  app.delete("/api/financial/transactions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Delete transaction from the database
      const deleted = await accountingService.deleteTransaction(Number(id));
      
      if (!deleted) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      // Return success response
      res.json({ success: true, message: "Transaction deleted successfully" });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * حذف مجموعة من المعاملات المالية
   * Delete multiple financial transactions
   */
  app.post("/api/financial/transactions/batch-delete", async (req, res) => {
    try {
      const { ids } = req.body;
      
      if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ message: "Invalid transaction IDs" });
      }
      
      // Delete transactions from the database
      const result = await accountingService.batchDeleteTransactions(ids);
      
      // Return success response
      res.json({ 
        success: true, 
        message: `Successfully deleted ${result.count} transactions`,
        deletedIds: result.deletedIds
      });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * نسخ معاملة مالية
   * Duplicate a financial transaction
   */
  app.post("/api/financial/transactions/:id/duplicate", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Duplicate transaction in the database
      const newTransaction = await accountingService.duplicateTransaction(Number(id));
      
      if (!newTransaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      // Return duplicated transaction
      res.status(201).json(newTransaction);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على قائمة الحسابات
   * Get chart of accounts
   */
  app.get("/api/financial/accounts", async (req, res) => {
    try {
      // Get accounts from database
      const accounts = await accountingService.getAccounts();
      
      // Return accounts
      res.json(accounts);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على قائمة المشاريع
   * Get projects list
   */
  app.get("/api/financial/projects", async (req, res) => {
    try {
      // Get projects from database
      const projects = await accountingService.getProjects();
      
      // Return projects
      res.json(projects);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على قائمة تصنيفات التكلفة
   * Get cost categories list
   */
  app.get("/api/financial/cost-categories", async (req, res) => {
    try {
      // For demo purposes, return some static cost categories
      // In a real application, this would come from the database
      const costCategories = [
        { id: "direct_labor", name: "تكاليف العمالة المباشرة" },
        { id: "materials", name: "المواد والخامات" },
        { id: "equipment", name: "المعدات" },
        { id: "subcontractor", name: "المقاولين من الباطن" },
        { id: "fees", name: "الرسوم والتراخيص" },
        { id: "office", name: "مصاريف المكتب" },
        { id: "travel", name: "السفر والتنقلات" },
        { id: "marketing", name: "التسويق والإعلان" },
        { id: "training", name: "التدريب والتطوير" },
        { id: "utilities", name: "المرافق والخدمات" },
        { id: "insurance", name: "التأمين" },
        { id: "rent", name: "الإيجار" },
        { id: "other", name: "مصاريف أخرى" }
      ];
      
      // Return cost categories
      res.json(costCategories);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على قائمة المستخلصات
   * Get certificates list
   */
  app.get("/api/financial/certificates", async (req, res) => {
    try {
      // Get certificates from database
      const certificates = await accountingService.getCertificates();
      
      // Return certificates
      res.json(certificates);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على قائمة بنود الميزانية
   * Get budget items list
   */
  app.get("/api/financial/budget-items", async (req, res) => {
    try {
      // Get budget items from database
      const budgetItems = await accountingService.getBudgetItems();
      
      // Return budget items
      res.json(budgetItems);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  /**
   * الحصول على قائمة الدخل
   * Get income statement
   */
  app.get('/api/financial/income-statement', async (req, res) => {
    try {
      // تحديد افتراضي للفترة إذا لم يتم تحديدها (شهر واحد)
      const endDate = req.query.endDate 
        ? new Date(req.query.endDate as string) 
        : new Date();
      
      let startDate;
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
      } else {
        // افتراضيًا، آخر شهر
        startDate = new Date(endDate);
        startDate.setMonth(startDate.getMonth() - 1);
      }
      
      const fiscalYear = req.query.fiscalYear 
        ? parseInt(req.query.fiscalYear as string) 
        : undefined;
        
      const fiscalPeriod = req.query.fiscalPeriod 
        ? parseInt(req.query.fiscalPeriod as string) 
        : undefined;
      
      const compareWithPrevPeriod = req.query.compareWithPrevPeriod === 'true';
      
      const incomeStatement = await accountingService.getIncomeStatement(
        startDate,
        endDate,
        fiscalYear,
        fiscalPeriod,
        compareWithPrevPeriod
      );
      
      return res.json(incomeStatement);
    } catch (error) {
      return handleError(res, error);
    }
  });

  /**
   * الحصول على قائمة القيود المتكررة
   * Get recurring journal entries list
   */
  app.get("/api/recurring-journal-entries", async (req, res) => {
    try {
      // استعلام قائمة القيود المتكررة من قاعدة البيانات
      // في هذه المرحلة سنستخدم بيانات وهمية حتى يتم إنشاء الجدول في قاعدة البيانات
      const recurringEntries = [
        {
          id: 1,
          title: "رواتب الموظفين الشهرية",
          description: "قيد آلي لتسجيل رواتب الموظفين الشهرية",
          amount: 45000,
          accountDebit: "5001",
          accountDebitName: "مصروفات الرواتب",
          accountCredit: "2001",
          accountCreditName: "مستحقات الموظفين",
          frequency: "monthly",
          startDate: "2025-01-01",
          nextRunDate: "2025-05-01",
          lastRunDate: "2025-04-01",
          projectId: 4,
          projectName: "تمديدات مواسير طريق المطار ابها",
          autoPost: true,
          autoBalance: true,
          isActive: true,
          dayOfMonth: 1,
          createdAt: "2025-01-01T08:30:00"
        },
        {
          id: 2,
          title: "إيجار المكتب الشهري",
          description: "قيد آلي لتسجيل إيجار المكتب الشهري",
          amount: 8500,
          accountDebit: "5005",
          accountDebitName: "مصروفات الإيجار",
          accountCredit: "1001",
          accountCreditName: "البنك الأهلي - حساب جاري",
          frequency: "monthly",
          startDate: "2025-01-15",
          nextRunDate: "2025-05-15",
          lastRunDate: "2025-04-15",
          projectId: null,
          projectName: null,
          autoPost: true,
          autoBalance: true,
          isActive: true,
          dayOfMonth: 15,
          createdAt: "2025-01-10T14:20:00"
        },
        {
          id: 3,
          title: "اشتراكات البرمجيات الربع سنوية",
          description: "قيد آلي لتسجيل اشتراكات البرمجيات والخدمات السحابية",
          amount: 12000,
          accountDebit: "5008",
          accountDebitName: "مصروفات تقنية المعلومات",
          accountCredit: "1002",
          accountCreditName: "بنك الرياض - حساب جاري",
          frequency: "quarterly",
          startDate: "2025-01-01",
          nextRunDate: "2025-07-01",
          lastRunDate: "2025-04-01",
          projectId: null,
          projectName: null,
          autoPost: false,
          autoBalance: true,
          isActive: true,
          dayOfMonth: 1,
          createdAt: "2025-01-01T09:45:00"
        }
      ];

      res.status(200).json(recurringEntries);
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * إنشاء قيد متكرر جديد
   * Create a new recurring journal entry
   */
  app.post("/api/recurring-journal-entries", async (req, res) => {
    try {
      // في هذه المرحلة سنتظاهر بإنشاء قيد متكرر جديد حتى يتم إنشاء الجدول في قاعدة البيانات
      const newEntry = {
        id: Date.now(),
        ...req.body,
        nextRunDate: req.body.startDate, // تعيين تاريخ التشغيل القادم كتاريخ البدء
        createdAt: new Date().toISOString(),
        isActive: true
      };

      res.status(201).json(newEntry);
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * الحصول على معلومات قيد متكرر محدد
   * Get a specific recurring journal entry
   */
  app.get("/api/recurring-journal-entries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      // في هذه المرحلة سنتظاهر بإيجاد قيد متكرر حتى يتم إنشاء الجدول في قاعدة البيانات
      const entry = {
        id: id,
        title: "رواتب الموظفين الشهرية",
        description: "قيد آلي لتسجيل رواتب الموظفين الشهرية",
        amount: 45000,
        accountDebit: "5001",
        accountDebitName: "مصروفات الرواتب",
        accountCredit: "2001",
        accountCreditName: "مستحقات الموظفين",
        frequency: "monthly",
        startDate: "2025-01-01",
        nextRunDate: "2025-05-01",
        lastRunDate: "2025-04-01",
        projectId: 4,
        projectName: "تمديدات مواسير طريق المطار ابها",
        autoPost: true,
        autoBalance: true,
        isActive: true,
        dayOfMonth: 1,
        createdAt: "2025-01-01T08:30:00"
      };

      if (!entry) {
        return res.status(404).json({ message: "Recurring entry not found" });
      }

      res.status(200).json(entry);
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * تحديث قيد متكرر
   * Update a recurring journal entry
   */
  app.patch("/api/recurring-journal-entries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      // في هذه المرحلة سنتظاهر بتحديث قيد متكرر حتى يتم إنشاء الجدول في قاعدة البيانات
      const updatedEntry = {
        id: id,
        ...req.body,
        updatedAt: new Date().toISOString()
      };

      res.status(200).json(updatedEntry);
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * حذف قيد متكرر
   * Delete a recurring journal entry
   */
  app.delete("/api/recurring-journal-entries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      // في هذه المرحلة سنتظاهر بحذف قيد متكرر حتى يتم إنشاء الجدول في قاعدة البيانات
      
      res.status(200).json({ message: "Recurring entry deleted successfully" });
    } catch (error) {
      handleError(res, error);
    }
  });

  /**
   * تفعيل أو تعطيل قيد متكرر
   * Activate or deactivate a recurring journal entry
   */
  app.patch("/api/recurring-journal-entries/:id/toggle-status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { isActive } = req.body;

      // في هذه المرحلة سنتظاهر بتغيير حالة قيد متكرر حتى يتم إنشاء الجدول في قاعدة البيانات

      res.status(200).json({ 
        id, 
        isActive,
        message: isActive 
          ? "Recurring entry activated successfully" 
          : "Recurring entry deactivated successfully" 
      });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
