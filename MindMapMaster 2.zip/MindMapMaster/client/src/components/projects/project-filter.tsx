import * as React from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import { Check, ChevronDown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

interface ProjectFilterProps {
  projectTypes?: string[];
  projectStatuses?: string[];
  initialType?: string;
  initialStatus?: string;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  className?: string;
}

export function ProjectFilter({
  projectTypes = ['roads', 'water', 'electricity'],
  projectStatuses = ['active', 'completed', 'suspended', 'canceled'],
  initialType = 'all',
  initialStatus = 'all',
  searchValue = '',
  onSearchChange,
  className
}: ProjectFilterProps) {
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();
  const [open, setOpen] = React.useState(false);
  const [statusOpen, setStatusOpen] = React.useState(false);
  const [type, setType] = React.useState(initialType);
  const [status, setStatus] = React.useState(initialStatus);
  const [search, setSearch] = React.useState(searchValue);

  // تحديث الرابط عند تغيير الفلترة
  const updateFilters = (newType?: string, newStatus?: string, newSearch?: string) => {
    const updatedType = newType !== undefined ? newType : type;
    const updatedStatus = newStatus !== undefined ? newStatus : status;
    const updatedSearch = newSearch !== undefined ? newSearch : search;
    
    const params = new URLSearchParams();
    if (updatedType !== 'all') params.set('type', updatedType);
    if (updatedStatus !== 'all') params.set('status', updatedStatus);
    if (updatedSearch) params.set('search', updatedSearch);
    
    const url = location.split('?')[0];
    const queryString = params.toString();
    setLocation(`${url}${queryString ? `?${queryString}` : ''}`);
  };

  const handleTypeSelect = (value: string) => {
    setType(value);
    updateFilters(value);
    setOpen(false);
  };

  const handleStatusSelect = (value: string) => {
    setStatus(value);
    updateFilters(undefined, value);
    setStatusOpen(false);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearch(value);
    if (onSearchChange) onSearchChange(value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateFilters(undefined, undefined, search);
  };

  return (
    <div className={cn("flex flex-col gap-4 md:flex-row md:items-end", className)}>
      <div className="space-y-2 flex-1">
        <Label htmlFor="search-project">{t('search')}</Label>
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <Input
            id="search-project"
            placeholder={t('project.search_placeholder') || "البحث عن مشروع..."}
            value={search}
            onChange={handleSearchChange}
          />
          <Button type="submit" variant="secondary" className="shrink-0">
            {t('search')}
          </Button>
        </form>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>{t('project.filter_by_type') || "تصفية حسب النوع"}</Label>
          <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                role="combobox"
                aria-expanded={open}
                className="justify-between w-full"
              >
                {type === 'all'
                  ? t('project.filter.all') || "الكل"
                  : t(`project.type.${type}`) || type}
                <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-full p-0">
              <Command>
                <CommandInput placeholder={t('project.filter_by_type') || "تصفية حسب النوع"} />
                <CommandList>
                  <CommandEmpty>{t('no_results') || "لا توجد نتائج"}</CommandEmpty>
                  <CommandGroup>
                    <CommandItem
                      onSelect={() => handleTypeSelect('all')}
                      className="cursor-pointer"
                    >
                      <Check
                        className={cn(
                          "mr-2 h-4 w-4",
                          type === 'all' ? "opacity-100" : "opacity-0"
                        )}
                      />
                      {t('project.filter.all') || "الكل"}
                    </CommandItem>
                    {projectTypes.map((projectType) => (
                      <CommandItem
                        key={projectType}
                        onSelect={() => handleTypeSelect(projectType)}
                        className="cursor-pointer"
                      >
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            type === projectType ? "opacity-100" : "opacity-0"
                          )}
                        />
                        {t(`project.type.${projectType}`) || projectType}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label>{t('project.filter_by_status') || "تصفية حسب الحالة"}</Label>
          <Popover open={statusOpen} onOpenChange={setStatusOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                role="combobox"
                aria-expanded={statusOpen}
                className="justify-between w-full"
              >
                {status === 'all'
                  ? t('project.filter.all') || "الكل"
                  : t(`project.status.${status}`) || status}
                <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-full p-0">
              <Command>
                <CommandInput placeholder={t('project.filter_by_status') || "تصفية حسب الحالة"} />
                <CommandList>
                  <CommandEmpty>{t('no_results') || "لا توجد نتائج"}</CommandEmpty>
                  <CommandGroup>
                    <CommandItem
                      onSelect={() => handleStatusSelect('all')}
                      className="cursor-pointer"
                    >
                      <Check
                        className={cn(
                          "mr-2 h-4 w-4",
                          status === 'all' ? "opacity-100" : "opacity-0"
                        )}
                      />
                      {t('project.filter.all') || "الكل"}
                    </CommandItem>
                    {projectStatuses.map((projectStatus) => (
                      <CommandItem
                        key={projectStatus}
                        onSelect={() => handleStatusSelect(projectStatus)}
                        className="cursor-pointer"
                      >
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            status === projectStatus ? "opacity-100" : "opacity-0"
                          )}
                        />
                        {t(`project.status.${projectStatus}`) || projectStatus}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>
      </div>
    </div>
  );
}