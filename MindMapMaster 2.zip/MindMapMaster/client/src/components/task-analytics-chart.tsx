import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { useTranslation } from "react-i18next";

interface TaskStatusCount {
  name: string;
  value: number;
  color: string;
}

interface TaskAnalyticsChartProps {
  completed: number;
  inProgress: number;
  notStarted: number;
  delayed: number;
  onHold: number;
  className?: string;
}

export function TaskAnalyticsChart({
  completed,
  inProgress,
  notStarted,
  delayed,
  onHold,
  className,
}: TaskAnalyticsChartProps) {
  const { t } = useTranslation();
  
  // إعداد بيانات المخطط
  const data: TaskStatusCount[] = [
    {
      name: t("task.completed"),
      value: completed,
      color: "#22c55e", // green-500
    },
    {
      name: t("task.in_progress"),
      value: inProgress,
      color: "#3b82f6", // blue-500
    },
    {
      name: t("task.not_started"),
      value: notStarted,
      color: "#94a3b8", // slate-400
    },
    {
      name: t("task.delayed"),
      value: delayed,
      color: "#ef4444", // red-500
    },
    {
      name: t("task.on_hold"),
      value: onHold,
      color: "#f59e0b", // amber-500
    },
  ].filter((item) => item.value > 0); // تصفية الحالات التي ليس لديها قيم
  
  // حساب إجمالي المهام
  const totalTasks = data.reduce((sum, item) => sum + item.value, 0);
  
  // تخصيص شكل تلميح المخطط (Tooltip)
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border rounded p-2 shadow-md">
          <p className="font-medium">{data.name}</p>
          <p className="text-sm">{`${data.value} (${Math.round((data.value / totalTasks) * 100)}%)`}</p>
        </div>
      );
    }
    
    return null;
  };
  
  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">{t("task.task_analytics")}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[200px]">
          {totalTasks > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                  nameKey="name"
                  label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  layout="horizontal"
                  verticalAlign="bottom"
                  align="center"
                  formatter={(value, entry, index) => (
                    <span className="text-xs">{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
              <p>{t("task.no_data")}</p>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-3 gap-2 mt-4">
          <div className="text-center">
            <div className="text-2xl font-bold">{totalTasks}</div>
            <div className="text-xs text-muted-foreground">{t("task.total")}</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{completed}</div>
            <div className="text-xs text-muted-foreground">{t("task.completed")}</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{inProgress}</div>
            <div className="text-xs text-muted-foreground">{t("task.in_progress")}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}