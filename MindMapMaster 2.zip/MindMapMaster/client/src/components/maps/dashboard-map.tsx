import { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import { Icon, LatLngExpression, Map as LeafletMap } from "leaflet";
import { Project } from "@shared/schema";
import { formatCurrency } from "@/lib/utils";
import { useTranslation } from "react-i18next";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { Link } from "wouter";

// Import CSS for Leaflet
import "leaflet/dist/leaflet.css";

// Default icon for map markers
const customIcon = new Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Generate custom SVG icons for different project types
const createSVGIcon = (color: string) => {
  const svgTemplate = `
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="35" viewBox="0 0 28 40">
      <path fill="${color}" stroke="#fff" stroke-width="1.5" d="M14 0C6.3 0 0 6.3 0 14c0 10.5 14 26 14 26s14-15.5 14-26C28 6.3 21.7 0 14 0z"/>
      <circle fill="white" cx="14" cy="14" r="7"/>
    </svg>
  `;
  
  return `data:image/svg+xml;base64,${btoa(svgTemplate)}`;
};

// Map type icons with different colors
const mapTypeIcons = {
  road: new Icon({
    iconUrl: createSVGIcon('#3b82f6'), // blue
    iconSize: [24, 35],
    iconAnchor: [12, 35],
    popupAnchor: [0, -30]
  }),
  water: new Icon({
    iconUrl: createSVGIcon('#06b6d4'), // cyan
    iconSize: [24, 35],
    iconAnchor: [12, 35],
    popupAnchor: [0, -30]
  }),
  electricity: new Icon({
    iconUrl: createSVGIcon('#eab308'), // yellow
    iconSize: [24, 35],
    iconAnchor: [12, 35],
    popupAnchor: [0, -30]
  }),
  telecom: new Icon({
    iconUrl: createSVGIcon('#a855f7'), // purple
    iconSize: [24, 35],
    iconAnchor: [12, 35],
    popupAnchor: [0, -30]
  }),
  building: new Icon({
    iconUrl: createSVGIcon('#84cc16'), // lime
    iconSize: [24, 35],
    iconAnchor: [12, 35],
    popupAnchor: [0, -30]
  })
};

// Default center for the map (Saudi Arabia)
const DEFAULT_CENTER: LatLngExpression = [24.7136, 46.6753];
const DEFAULT_ZOOM = 5;

// Utility function to parse GeoJSON location
function parseLocation(location: any): LatLngExpression | null {
  if (!location) return null;
  
  try {
    // If it's a GeoJSON Point
    if (location.type === 'Point' && Array.isArray(location.coordinates)) {
      // GeoJSON uses [longitude, latitude] format, but Leaflet uses [latitude, longitude]
      return [location.coordinates[1], location.coordinates[0]];
    }
    
    // If it's already in the right format
    if (Array.isArray(location) && location.length === 2) {
      return location as LatLngExpression;
    }
    
    // If it's an object with lat and lng
    if (location.lat && location.lng) {
      return [location.lat, location.lng];
    }
  } catch (error) {
    console.error("Error parsing location:", error);
  }
  
  return null;
}

interface DashboardMapProps {
  projects: Project[];
  className?: string;
  height?: string;
}

// MapControl component to set view on mount
function MapControl({ center, zoom, projects }: { center: LatLngExpression, zoom: number, projects: Project[] }) {
  const map = useMap();
  
  useEffect(() => {
    // First set default center and zoom
    map.setView(center, zoom);
    
    // Filter projects with valid locations
    const projectsWithLocation = projects.filter(project => {
      const location = parseLocation(project.location);
      return location !== null;
    });
    
    if (projectsWithLocation.length === 1) {
      const location = parseLocation(projectsWithLocation[0].location);
      if (location) {
        map.setView(location, 10);
      }
    } else if (projectsWithLocation.length > 1) {
      // Just use default center and zoom for multiple projects
      map.setView(DEFAULT_CENTER, 5);
    }
    
  }, [map, center, zoom, projects]);
  
  return null;
}

export function DashboardMap({ projects, className = "", height = "400px" }: DashboardMapProps) {
  const { t } = useTranslation();
  
  // Filter projects with valid locations
  const projectsWithLocation = projects.filter(project => {
    const location = parseLocation(project.location);
    return location !== null;
  });
  
  return (
    <div className={`rounded-lg overflow-hidden ${className}`} style={{ height }}>
      <MapContainer
        center={DEFAULT_CENTER}
        zoom={DEFAULT_ZOOM}
        style={{ height: "100%", width: "100%" }}
      >
        <MapControl center={DEFAULT_CENTER} zoom={DEFAULT_ZOOM} projects={projects} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {projectsWithLocation.map(project => {
          const location = parseLocation(project.location);
          if (!location) return null;
          
          return (
            <Marker 
              key={project.id} 
              position={location}
              icon={mapTypeIcons[project.type] || customIcon}
            >
              <Popup>
                <div className="text-sm">
                  <h3 className="font-bold mb-1">{project.name}</h3>
                  <p className="text-zinc-600 mb-2">{project.description}</p>
                  <div className="flex items-center justify-between mb-1">
                    <span>{t("project.type")}:</span>
                    <ProjectTypeBadge type={project.type} size="sm" />
                  </div>
                  <div className="flex items-center justify-between mb-1">
                    <span>{t("project.status")}:</span>
                    <StatusBadge status={project.status} size="sm" />
                  </div>
                  <div className="flex items-center justify-between mb-1">
                    <span>{t("project.budget")}:</span>
                    <span className="font-medium">{formatCurrency(project.budget || 0)}</span>
                  </div>
                  <div className="mt-2">
                    <Link href={`/projects/${project.id}`} className="text-primary hover:underline">
                      {t("project.details")}
                    </Link>
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}