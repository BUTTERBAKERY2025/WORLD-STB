import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { useTranslation } from "react-i18next";

// تعريف نموذج البيانات لمؤشرات الأداء
interface PerformanceIndexData {
  period: string; // الفترة الزمنية (مثل تاريخ أو شهر)
  cpi: number; // مؤشر أداء التكلفة
  spi: number; // مؤشر أداء الجدول
}

interface PerformanceIndicesChartProps {
  data: PerformanceIndexData[];
  title?: string;
  showLegend?: boolean;
  height?: number;
  className?: string;
}

export function PerformanceIndicesChart({
  data,
  title = "مؤشرات الأداء",
  showLegend = true,
  height = 300,
  className,
}: PerformanceIndicesChartProps) {
  const { t } = useTranslation();
  
  // تخصيص تلميح المخطط (Tooltip)
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded p-2 shadow-md">
          <p className="font-medium">{`${label}`}</p>
          {payload.map((entry: any) => (
            <p
              key={entry.dataKey}
              className="text-sm"
              style={{ color: entry.color }}
            >
              {`${entry.name}: ${entry.value.toFixed(2)}`}
              <span className="text-xs text-muted-foreground ml-1 rtl:ml-0 rtl:mr-1">
                ({entry.value > 1
                  ? t("project.performing_well")
                  : entry.value === 1
                  ? t("project.on_track")
                  : t("project.underperforming")})
              </span>
            </p>
          ))}
        </div>
      );
    }
    
    return null;
  };
  
  // تحديد لون مؤشر الأداء بناءً على قيمته
  const getColor = (value: number) => {
    if (value >= 1.1) return "#22c55e"; // ممتاز - أخضر
    if (value >= 0.95) return "#84cc16"; // جيد - أخضر فاتح
    if (value >= 0.9) return "#facc15"; // معتدل - أصفر
    if (value >= 0.8) return "#f97316"; // ضعيف - برتقالي
    return "#ef4444"; // سيء - أحمر
  };
  
  // إضافة ألوان للمؤشرات لكل نقطة بيانات
  const coloredData = data.map((item) => ({
    ...item,
    cpiColor: getColor(item.cpi),
    spiColor: getColor(item.spi),
  }));
  
  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div style={{ width: "100%", height }}>
          {data.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={coloredData}
                margin={{
                  top: 10,
                  right: 30,
                  left: 0,
                  bottom: 0,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="period" 
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => value.length > 8 ? value.substring(0, 8) + '...' : value}
                />
                <YAxis
                  domain={[0, 2]}
                  ticks={[0, 0.5, 0.8, 0.9, 1, 1.1, 1.2, 1.5, 2]}
                  tick={{ fontSize: 12 }}
                />
                <Tooltip content={<CustomTooltip />} />
                {showLegend && (
                  <Legend
                    formatter={(value) => {
                      switch (value) {
                        case "cpi":
                          return t("project.cost_performance_index");
                        case "spi":
                          return t("project.schedule_performance_index");
                        default:
                          return value;
                      }
                    }}
                  />
                )}
                
                {/* خط مرجعي عند القيمة 1 (مثالي) */}
                <ReferenceLine
                  y={1}
                  stroke="#9ca3af"
                  strokeDasharray="3 3"
                  label={{
                    value: t("project.ideal"),
                    position: "insideTopRight",
                    fill: "#9ca3af",
                    fontSize: 12,
                  }}
                />
                
                {/* خط مرجعي للقيمة المنخفضة 0.8 (حرج) */}
                <ReferenceLine
                  y={0.8}
                  stroke="#f87171"
                  strokeDasharray="3 3"
                  label={{
                    value: t("project.critical"),
                    position: "insideBottomRight",
                    fill: "#f87171",
                    fontSize: 12,
                  }}
                />
                
                <Area
                  type="monotone"
                  dataKey="cpi"
                  name={t("project.cost_performance_index")}
                  stroke="#3b82f6"
                  fill="#93c5fd"
                  fillOpacity={0.3}
                />
                <Area
                  type="monotone"
                  dataKey="spi"
                  name={t("project.schedule_performance_index")}
                  stroke="#8b5cf6"
                  fill="#c4b5fd"
                  fillOpacity={0.3}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
              <p>{t("common.no_data_available")}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}