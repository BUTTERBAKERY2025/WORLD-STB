import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { ArrowUp, ArrowDown, AlertCircle, CheckCircle2, Building2, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

interface Project {
  id: number;
  name: string;
  totalBudget?: number;
  totalExpenses?: number;
  remainingBudget?: number;
}

interface BudgetItem {
  id: number;
  name: string;
  budgetedAmount: number;
  spentAmount: number;
  remainingAmount: number;
  category: string;
}

interface ProjectBudgetImpactProps {
  projectId: number | null;
  amount: number;
  budgetItemId?: number | null;
  transactionType: "income" | "expense" | "transfer";
  className?: string;
}

export function ProjectBudgetImpact({
  projectId,
  amount,
  budgetItemId,
  transactionType,
  className
}: ProjectBudgetImpactProps) {
  const { t } = useTranslation();
  const [showBudgetDetails, setShowBudgetDetails] = useState(false);
  
  // Only expenses impact project budgets
  const impactsProject = transactionType === "expense" && projectId !== null;
  
  // Fetch project details if we have a project ID
  const { data: project } = useQuery({
    queryKey: ['/api/projects', projectId],
    enabled: !!projectId && impactsProject,
    refetchOnWindowFocus: false
  });
  
  // Fetch project budget details
  const { data: projectBudget } = useQuery({
    queryKey: ['/api/projects', projectId, 'budget'],
    enabled: !!projectId && impactsProject,
    refetchOnWindowFocus: false
  });
  
  // Fetch specific budget item if we have an ID
  const { data: budgetItem } = useQuery({
    queryKey: ['/api/budget-items', budgetItemId],
    enabled: !!budgetItemId && impactsProject,
    refetchOnWindowFocus: false
  });
  
  // Format currency amount
  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // Calculate project budget impact
  const calculateProjectImpact = () => {
    if (!project || !projectBudget) return null;
    
    const totalBudget = projectBudget.totalBudget || 0;
    const currentExpenses = projectBudget.totalExpenses || 0;
    const currentRemaining = projectBudget.remainingBudget || totalBudget - currentExpenses;
    
    const newExpenses = currentExpenses + amount;
    const newRemaining = totalBudget - newExpenses;
    const percentBefore = totalBudget > 0 ? (currentExpenses / totalBudget) * 100 : 0;
    const percentAfter = totalBudget > 0 ? (newExpenses / totalBudget) * 100 : 0;
    
    return {
      totalBudget,
      currentExpenses,
      currentRemaining,
      newExpenses,
      newRemaining,
      percentBefore: Math.min(100, Math.round(percentBefore)),
      percentAfter: Math.min(100, Math.round(percentAfter)),
      exceededBefore: currentExpenses > totalBudget,
      exceededAfter: newExpenses > totalBudget
    };
  };
  
  // Calculate budget item impact
  const calculateBudgetItemImpact = () => {
    if (!budgetItem) return null;
    
    const budgetedAmount = budgetItem.budgetedAmount || 0;
    const currentSpent = budgetItem.spentAmount || 0;
    const currentRemaining = budgetItem.remainingAmount || budgetedAmount - currentSpent;
    
    const newSpent = currentSpent + amount;
    const newRemaining = budgetedAmount - newSpent;
    const percentBefore = budgetedAmount > 0 ? (currentSpent / budgetedAmount) * 100 : 0;
    const percentAfter = budgetedAmount > 0 ? (newSpent / budgetedAmount) * 100 : 0;
    
    return {
      budgetedAmount,
      currentSpent,
      currentRemaining,
      newSpent,
      newRemaining,
      percentBefore: Math.min(100, Math.round(percentBefore)),
      percentAfter: Math.min(100, Math.round(percentAfter)),
      exceededBefore: currentSpent > budgetedAmount,
      exceededAfter: newSpent > budgetedAmount
    };
  };
  
  const projectImpact = calculateProjectImpact();
  const budgetItemImpact = calculateBudgetItemImpact();
  
  if (!impactsProject || !project) {
    return null;
  }
  
  return (
    <Card className={cn("mt-4", className)}>
      <CardHeader>
        <CardTitle className="text-lg flex items-center justify-between">
          {t("financial.transactions.projectImpact")}
          <button 
            onClick={() => setShowBudgetDetails(prev => !prev)}
            className="text-sm font-normal text-muted-foreground hover:text-foreground"
          >
            {showBudgetDetails ? t("common.hideDetails") : t("common.showDetails")}
          </button>
        </CardTitle>
        <CardDescription>
          {t("financial.transactions.projectImpactDescription")}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Project Information */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-muted-foreground" />
            <div>
              <div className="font-medium">{project.name}</div>
              <div className="text-sm text-muted-foreground">{t("projects.project")} #{project.id}</div>
            </div>
          </div>
          
          {budgetItem && (
            <Badge variant="outline" className="ml-auto">
              {budgetItem.category}
            </Badge>
          )}
        </div>
        
        {/* Overall Project Budget Impact */}
        {projectImpact && (
          <div className="space-y-2 mt-4">
            <div className="flex justify-between text-sm">
              <span>{t("projects.totalBudget")}</span>
              <span className="font-medium">{formatAmount(projectImpact.totalBudget)}</span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <div className="space-y-1 flex-1 mr-4">
                <div className="flex justify-between mb-1">
                  <span className="text-muted-foreground">{t("projects.currentExpenses")}</span>
                  <span className={cn(
                    "font-medium",
                    projectImpact.exceededBefore ? "text-red-500" : "text-foreground"
                  )}>
                    {formatAmount(projectImpact.currentExpenses)}
                  </span>
                </div>
                <Progress 
                  value={projectImpact.percentBefore} 
                  className={cn(
                    "h-2",
                    projectImpact.exceededBefore ? "bg-red-100" : "bg-muted"
                  )}
                  indicatorClassName={projectImpact.exceededBefore ? "bg-red-500" : ""}
                />
              </div>
              
              <div className="w-6 flex justify-center">
                <ArrowDown className="h-4 w-4 text-foreground" />
              </div>
              
              <div className="space-y-1 flex-1 ml-4">
                <div className="flex justify-between mb-1">
                  <span className="text-muted-foreground">{t("projects.afterTransaction")}</span>
                  <span className={cn(
                    "font-medium",
                    projectImpact.exceededAfter ? "text-red-500" : "text-foreground"
                  )}>
                    {formatAmount(projectImpact.newExpenses)}
                  </span>
                </div>
                <Progress 
                  value={projectImpact.percentAfter} 
                  className={cn(
                    "h-2",
                    projectImpact.exceededAfter ? "bg-red-100" : "bg-muted"
                  )}
                  indicatorClassName={projectImpact.exceededAfter ? "bg-red-500" : ""}
                />
              </div>
            </div>
            
            <div className="flex justify-between text-sm mt-2">
              <span>{t("projects.remainingBudget")}</span>
              <span className={cn(
                "font-medium",
                projectImpact.newRemaining < 0 ? "text-red-500" : "text-green-500"
              )}>
                {formatAmount(projectImpact.newRemaining)}
              </span>
            </div>
            
            {/* Warning for budget exceedance */}
            {projectImpact.exceededAfter && !projectImpact.exceededBefore && (
              <div className="rounded-md bg-amber-50 border border-amber-200 p-2 mt-2 flex items-center gap-2 text-amber-600 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{t("projects.budgetExceededWarning")}</span>
              </div>
            )}
          </div>
        )}
        
        {/* Budget Item Impact */}
        {showBudgetDetails && budgetItemImpact && budgetItem && (
          <div className="mt-4 pt-4 border-t">
            <div className="flex items-center gap-2 mb-3">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <h4 className="font-medium">{budgetItem.name}</h4>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{t("projects.budgetedAmount")}</span>
                <span className="font-medium">{formatAmount(budgetItemImpact.budgetedAmount)}</span>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <div className="space-y-1 flex-1 mr-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-muted-foreground">{t("projects.currentSpent")}</span>
                    <span className={cn(
                      "font-medium",
                      budgetItemImpact.exceededBefore ? "text-red-500" : "text-foreground"
                    )}>
                      {formatAmount(budgetItemImpact.currentSpent)}
                    </span>
                  </div>
                  <Progress 
                    value={budgetItemImpact.percentBefore} 
                    className={cn(
                      "h-2",
                      budgetItemImpact.exceededBefore ? "bg-red-100" : "bg-muted"
                    )}
                    indicatorClassName={budgetItemImpact.exceededBefore ? "bg-red-500" : ""}
                  />
                </div>
                
                <div className="w-6 flex justify-center">
                  <ArrowDown className="h-4 w-4 text-foreground" />
                </div>
                
                <div className="space-y-1 flex-1 ml-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-muted-foreground">{t("projects.afterTransaction")}</span>
                    <span className={cn(
                      "font-medium",
                      budgetItemImpact.exceededAfter ? "text-red-500" : "text-foreground"
                    )}>
                      {formatAmount(budgetItemImpact.newSpent)}
                    </span>
                  </div>
                  <Progress 
                    value={budgetItemImpact.percentAfter} 
                    className={cn(
                      "h-2",
                      budgetItemImpact.exceededAfter ? "bg-red-100" : "bg-muted"
                    )}
                    indicatorClassName={budgetItemImpact.exceededAfter ? "bg-red-500" : ""}
                  />
                </div>
              </div>
              
              <div className="flex justify-between text-sm mt-2">
                <span>{t("projects.remainingInItem")}</span>
                <span className={cn(
                  "font-medium",
                  budgetItemImpact.newRemaining < 0 ? "text-red-500" : "text-green-500"
                )}>
                  {formatAmount(budgetItemImpact.newRemaining)}
                </span>
              </div>
              
              {/* Warning for budget item exceedance */}
              {budgetItemImpact.exceededAfter && !budgetItemImpact.exceededBefore && (
                <div className="rounded-md bg-amber-50 border border-amber-200 p-2 mt-2 flex items-center gap-2 text-amber-600 text-sm">
                  <AlertCircle className="h-4 w-4" />
                  <span>{t("projects.budgetItemExceededWarning")}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}