import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { Search, ChevronsUpDown, Check } from "lucide-react";
import { useTranslation } from "react-i18next";

interface Account {
  id: number;
  code: string;
  name?: string;
  nameEn?: string;
  type: string;
  level: number;
  hasChildren: boolean;
  parentId: number | null;
}

interface AccountTreeSelectorProps {
  accounts: Account[];
  value: number | null;
  onChange: (accountId: number) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  direction?: "rtl" | "ltr";
  accountTypes?: string[];
  triggerLabel?: string;
  isLoading?: boolean;
}

export function AccountTreeSelector({
  accounts,
  value,
  onChange,
  placeholder = "اختر حساب...",
  className,
  disabled = false,
  direction = "rtl",
  accountTypes,
  triggerLabel,
  isLoading = false,
}: AccountTreeSelectorProps) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Debug accounts data
  console.log("AccountTreeSelector received accounts:", accounts);
  
  // Filter accounts by type if specified
  const filteredAccounts = accountTypes && Array.isArray(accounts)
    ? accounts.filter((account) => accountTypes.includes(account.type))
    : Array.isArray(accounts) ? accounts : [];

  // Organize accounts in a tree structure
  const rootAccounts = Array.isArray(filteredAccounts) 
    ? filteredAccounts.filter((account) => account.level === 1 || account.parentId === null)
    : [];
  
  // Get child accounts with safety checks
  const getChildAccounts = (parentId: number) => {
    if (!Array.isArray(filteredAccounts)) {
      console.log("Filtered accounts is not an array:", filteredAccounts);
      return [];
    }
    return filteredAccounts.filter((account) => account.parentId === parentId);
  };
  
  // Get selected account with safety check
  const selectedAccount = Array.isArray(filteredAccounts)
    ? filteredAccounts.find((account) => account.id === value)
    : undefined;

  // Handle search filtering with safety check
  const getFilteredAccounts = () => {
    // Safety check for array
    if (!Array.isArray(filteredAccounts)) {
      console.log("getFilteredAccounts: filteredAccounts is not an array");
      return [];
    }
    
    // If search query is empty, return all accounts
    if (!searchQuery.trim()) return filteredAccounts;
    
    return filteredAccounts.filter((account) => 
      ((account.name || account.nameEn || '').toLowerCase().includes(searchQuery.toLowerCase())) || 
      account.code.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  // Recursive function to render account tree
  const renderAccountTree = (accounts: Account[], depth = 0) => {
    return accounts.map((account) => {
      const children = getChildAccounts(account.id);
      const hasChildren = children.length > 0;
      
      return (
        <div key={account.id} className="flex flex-col">
          <CommandItem
            value={`${account.code}-${account.name || account.nameEn}`}
            onSelect={() => {
              if (!account.hasChildren) {
                onChange(account.id);
                setOpen(false);
              }
            }}
            className={cn(
              "flex items-center gap-2 px-2",
              { 
                "text-muted-foreground cursor-default": account.hasChildren && children.length === 0,
                "opacity-50": account.hasChildren && !hasChildren,
                "pr-8": direction === "rtl",
                "pl-8": direction === "ltr"
              },
              depth > 0 && direction === "rtl" && `mr-${depth * 4}`,
              depth > 0 && direction === "ltr" && `ml-${depth * 4}`
            )}
            disabled={account.hasChildren && children.length === 0}
          >
            <div className={cn("flex justify-between w-full items-center", 
              direction === "rtl" ? "flex-row-reverse" : "flex-row")}>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">
                  {account.code}
                </span>
                <span className={account.hasChildren ? "font-semibold" : ""}>
                  {account.name || account.nameEn}
                </span>
              </div>
              
              {!account.hasChildren && (
                value === account.id && <Check className="h-4 w-4 ml-2" />
              )}
            </div>
          </CommandItem>
          
          {hasChildren && (
            <div className={cn(
              "border-r border-dashed", 
              direction === "rtl" ? "mr-3" : "ml-3",
              depth > 0 && direction === "rtl" && `mr-${depth * 4 + 3}`,
              depth > 0 && direction === "ltr" && `ml-${depth * 4 + 3}`
            )}>
              {renderAccountTree(children, depth + 1)}
            </div>
          )}
        </div>
      );
    });
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            "justify-between w-full font-normal py-6 text-[15px]",
            !value && "text-muted-foreground",
            className
          )}
          disabled={disabled || isLoading}
        >
          {triggerLabel ? (
            <div className="flex flex-col items-start gap-1 text-right">
              <span className="text-xs text-muted-foreground">{triggerLabel}</span>
              <span className="font-medium">
                {selectedAccount
                  ? `${selectedAccount.code} - ${selectedAccount.name || selectedAccount.nameEn}`
                  : placeholder}
              </span>
            </div>
          ) : (
            <span>
              {selectedAccount
                ? `${selectedAccount.code} - ${selectedAccount.name || selectedAccount.nameEn}`
                : placeholder}
            </span>
          )}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-[400px]" align="start">
        <Command dir={direction} className="w-full" shouldFilter={false}>
          <CommandInput 
            placeholder={t("common.search")} 
            onValueChange={setSearchQuery}
            value={searchQuery}
            className="h-9"
          />
          <CommandList className="max-h-[300px] overflow-auto">
            <CommandEmpty>{t("common.noResults")}</CommandEmpty>
            
            {searchQuery ? (
              <CommandGroup heading={t("common.searchResults")}>
                {getFilteredAccounts().map((account) => (
                  <CommandItem
                    key={account.id}
                    value={`${account.code}-${account.name || account.nameEn}`}
                    onSelect={() => {
                      if (!account.hasChildren) {
                        onChange(account.id);
                        setOpen(false);
                      }
                    }}
                    className="flex items-center gap-2"
                    disabled={account.hasChildren}
                  >
                    <div className={cn("flex justify-between w-full items-center",
                      direction === "rtl" ? "flex-row-reverse" : "flex-row")}>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-muted-foreground">
                          {account.code}
                        </span>
                        <span>
                          {account.name || account.nameEn}
                        </span>
                      </div>
                      
                      {value === account.id && <Check className="h-4 w-4 ml-2" />}
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            ) : (
              <CommandGroup heading={t("common.allAccounts")}>
                {renderAccountTree(rootAccounts)}
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}