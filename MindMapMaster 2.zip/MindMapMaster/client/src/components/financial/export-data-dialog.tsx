import { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  FileText, 
  Download, 
  FileSpreadsheet, 
  FileOutput,
  Check,
  Calendar as CalendarIcon
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ExportDataDialogProps {
  data: any[];
  filename?: string;
  trigger?: React.ReactNode;
  columns: { field: string; title: string }[];
  title?: string;
  description?: string;
  onExportComplete?: () => void;
}

export function ExportDataDialog({
  data,
  filename = "export",
  trigger,
  columns,
  title = "تصدير البيانات",
  description = "اختر تنسيق ملف التصدير والبيانات التي تريد تضمينها",
  onExportComplete
}: ExportDataDialogProps) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [exportFormat, setExportFormat] = useState<"excel" | "pdf" | "csv">("excel");
  const [dateRange, setDateRange] = useState<any>({
    from: undefined,
    to: undefined,
  });
  const [selectedColumns, setSelectedColumns] = useState<string[]>(
    columns.map((col) => col.field)
  );

  // Handle column selection
  const toggleColumn = (field: string) => {
    setSelectedColumns((prev) =>
      prev.includes(field)
        ? prev.filter((col) => col !== field)
        : [...prev, field]
    );
  };

  // Format filename with date
  const getFormattedFilename = () => {
    const today = format(new Date(), "yyyy-MM-dd");
    return `${filename}_${today}`;
  };

  // Filter data based on date range
  const getFilteredData = () => {
    if (!dateRange.from) return data;
    
    return data.filter((item) => {
      const itemDate = new Date(item.transactionDate || item.date);
      if (dateRange.from && !dateRange.to) {
        return itemDate >= dateRange.from;
      }
      if (dateRange.from && dateRange.to) {
        return itemDate >= dateRange.from && itemDate <= dateRange.to;
      }
      return true;
    });
  };

  // Get selected data with only selected columns
  const getSelectedData = () => {
    const filteredData = getFilteredData();
    return filteredData.map((item) => {
      const newItem: any = {};
      selectedColumns.forEach((col) => {
        newItem[col] = item[col];
      });
      return newItem;
    });
  };

  // Export to Excel
  const exportToExcel = () => {
    const selectedData = getSelectedData();
    const ws = XLSX.utils.json_to_sheet(selectedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Data");
    XLSX.writeFile(wb, `${getFormattedFilename()}.xlsx`);
  };

  // Export to CSV
  const exportToCSV = () => {
    const selectedData = getSelectedData();
    const ws = XLSX.utils.json_to_sheet(selectedData);
    const csv = XLSX.utils.sheet_to_csv(ws);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${getFormattedFilename()}.csv`;
    link.click();
  };

  // Export to PDF
  const exportToPDF = () => {
    const selectedData = getSelectedData();
    const doc = new jsPDF({
      orientation: "landscape",
      unit: "mm",
      format: "a4",
    });
    
    // Add title
    doc.setFont("courier", "bold");
    doc.text(title, 14, 15);
    doc.setFontSize(10);
    
    // Add date
    const dateStr = format(new Date(), "yyyy/MM/dd");
    doc.text(`تاريخ التصدير: ${dateStr}`, 14, 22);
    
    // Add filters if date range is selected
    if (dateRange.from) {
      const fromDateStr = format(dateRange.from, "yyyy/MM/dd");
      const toDateStr = dateRange.to ? format(dateRange.to, "yyyy/MM/dd") : "الآن";
      doc.text(`نطاق الفترة: ${fromDateStr} إلى ${toDateStr}`, 14, 28);
    }
    
    // Create table with selected columns
    const selectedColumnDefs = columns.filter((col) => 
      selectedColumns.includes(col.field)
    );
    
    const tableHeaders = selectedColumnDefs.map((col) => col.title);
    const tableRows = selectedData.map((item) => 
      selectedColumnDefs.map((col) => {
        // Format values for better readability
        if (typeof item[col.field] === 'boolean') {
          return item[col.field] ? 'نعم' : 'لا';
        }
        // Format dates
        if (col.field.includes('date') && item[col.field]) {
          return format(new Date(item[col.field]), "yyyy/MM/dd");
        }
        return item[col.field];
      })
    );
    
    // Generate the PDF table
    autoTable(doc, {
      startY: 35,
      head: [tableHeaders],
      body: tableRows,
      theme: 'grid',
      styles: { 
        fontSize: 8,
        cellPadding: 2
      },
      headStyles: {
        fillColor: [41, 128, 185],
        textColor: [255, 255, 255],
        halign: 'center'
      },
      alternateRowStyles: {
        fillColor: [240, 240, 240]
      }
    });
    
    doc.save(`${getFormattedFilename()}.pdf`);
  };

  // Handle export based on selected format
  const handleExport = async () => {
    try {
      setLoading(true);
      
      switch(exportFormat) {
        case "excel":
          exportToExcel();
          break;
        case "pdf":
          exportToPDF();
          break;
        case "csv":
          exportToCSV();
          break;
        default:
          exportToExcel();
      }
      
      if (onExportComplete) {
        onExportComplete();
      }
      
      setOpen(false);
    } catch (error) {
      console.error("Export error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            {t("common.export")}
          </Button>
        )}
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <FileText className="h-5 w-5" />
            {title}
          </DialogTitle>
          <DialogDescription>
            {description}
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="format" className="pt-2">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="format">{t("export.format")}</TabsTrigger>
            <TabsTrigger value="columns">{t("export.columns")}</TabsTrigger>
            <TabsTrigger value="filters">{t("export.filters")}</TabsTrigger>
          </TabsList>
          
          {/* Format Options */}
          <TabsContent value="format" className="pt-4">
            <div className="space-y-4">
              <Label className="text-base">{t("export.selectFormat")}</Label>
              <RadioGroup
                value={exportFormat}
                onValueChange={(value: "excel" | "pdf" | "csv") => setExportFormat(value)}
                className="grid grid-cols-3 gap-4"
              >
                <div>
                  <RadioGroupItem
                    value="excel"
                    id="excel"
                    className="peer sr-only"
                  />
                  <Label
                    htmlFor="excel"
                    className={cn(
                      "flex flex-col items-center justify-between rounded-md border-2 border-muted p-4",
                      "hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary",
                      "cursor-pointer transition-colors [&:has([data-state=checked])]:border-primary"
                    )}
                  >
                    <FileSpreadsheet className="h-12 w-12 mb-2 text-green-600" />
                    <div className="text-center space-y-1">
                      <h4 className="font-medium">Excel</h4>
                      <p className="text-xs text-muted-foreground">
                        {t("export.excelDescription")}
                      </p>
                    </div>
                    {exportFormat === "excel" && (
                      <Check className="absolute top-2 right-2 h-4 w-4 text-primary" />
                    )}
                  </Label>
                </div>
                
                <div>
                  <RadioGroupItem
                    value="pdf"
                    id="pdf"
                    className="peer sr-only"
                  />
                  <Label
                    htmlFor="pdf"
                    className={cn(
                      "flex flex-col items-center justify-between rounded-md border-2 border-muted p-4",
                      "hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary",
                      "cursor-pointer transition-colors [&:has([data-state=checked])]:border-primary"
                    )}
                  >
                    <FileOutput className="h-12 w-12 mb-2 text-red-600" />
                    <div className="text-center space-y-1">
                      <h4 className="font-medium">PDF</h4>
                      <p className="text-xs text-muted-foreground">
                        {t("export.pdfDescription")}
                      </p>
                    </div>
                    {exportFormat === "pdf" && (
                      <Check className="absolute top-2 right-2 h-4 w-4 text-primary" />
                    )}
                  </Label>
                </div>
                
                <div>
                  <RadioGroupItem
                    value="csv"
                    id="csv"
                    className="peer sr-only"
                  />
                  <Label
                    htmlFor="csv"
                    className={cn(
                      "flex flex-col items-center justify-between rounded-md border-2 border-muted p-4",
                      "hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary",
                      "cursor-pointer transition-colors [&:has([data-state=checked])]:border-primary"
                    )}
                  >
                    <FileText className="h-12 w-12 mb-2 text-blue-600" />
                    <div className="text-center space-y-1">
                      <h4 className="font-medium">CSV</h4>
                      <p className="text-xs text-muted-foreground">
                        {t("export.csvDescription")}
                      </p>
                    </div>
                    {exportFormat === "csv" && (
                      <Check className="absolute top-2 right-2 h-4 w-4 text-primary" />
                    )}
                  </Label>
                </div>
              </RadioGroup>
              
              <div className="bg-muted/40 p-3 rounded-md text-sm text-muted-foreground mt-4">
                <p>{t("export.formatHelp")}</p>
              </div>
            </div>
          </TabsContent>
          
          {/* Columns Selection */}
          <TabsContent value="columns" className="pt-4">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label className="text-base">{t("export.selectColumns")}</Label>
                <Button
                  variant="link"
                  className="text-sm h-auto p-0"
                  onClick={() => setSelectedColumns(columns.map((col) => col.field))}
                >
                  {t("export.selectAll")}
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto border rounded-md p-3">
                {columns.map((column) => (
                  <div 
                    key={column.field} 
                    className="flex items-center space-x-2 space-x-reverse p-2 hover:bg-accent rounded-md"
                  >
                    <Checkbox
                      id={`column-${column.field}`}
                      checked={selectedColumns.includes(column.field)}
                      onCheckedChange={() => toggleColumn(column.field)}
                    />
                    <Label
                      htmlFor={`column-${column.field}`}
                      className="text-sm cursor-pointer flex-grow"
                    >
                      {column.title}
                    </Label>
                  </div>
                ))}
              </div>
              
              <div className="bg-amber-50 border border-amber-100 p-3 rounded-md text-sm text-amber-800">
                <p className="font-medium mb-1">{t("export.columnsInfo")}</p>
                <p>{t("export.columnsInfoDescription")}</p>
              </div>
            </div>
          </TabsContent>
          
          {/* Filters */}
          <TabsContent value="filters" className="pt-4">
            <div className="space-y-4">
              <Label className="text-base">{t("export.dateRange")}</Label>
              
              <div className="grid gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="date"
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateRange && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange?.from ? (
                        dateRange.to ? (
                          <>
                            {format(dateRange.from, "LLL dd, y")} -{" "}
                            {format(dateRange.to, "LLL dd, y")}
                          </>
                        ) : (
                          format(dateRange.from, "LLL dd, y")
                        )
                      ) : (
                        <span>{t("export.pickDate")}</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      initialFocus
                      mode="range"
                      defaultMonth={dateRange?.from}
                      selected={dateRange}
                      onSelect={setDateRange}
                      numberOfMonths={2}
                    />
                  </PopoverContent>
                </Popover>
                
                {dateRange?.from && (
                  <Button 
                    variant="outline" 
                    className="text-sm"
                    onClick={() => setDateRange({ from: undefined, to: undefined })}
                  >
                    {t("export.clearDates")}
                  </Button>
                )}
              </div>
              
              <div className="bg-blue-50 border border-blue-100 p-3 rounded-md text-sm text-blue-800 mt-4">
                <p>{t("export.dateRangeHelp")}</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        <DialogFooter className="gap-2 sm:gap-0">
          <div className="text-xs text-muted-foreground">
            {data.length}{" "}
            {t("export.records", { count: data.length })}
            {getFilteredData().length !== data.length && 
              ` (${getFilteredData().length} ${t("export.filtered")})`}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button 
              onClick={handleExport} 
              disabled={loading || selectedColumns.length === 0}
              className="gap-2"
            >
              {loading ? (
                <>
                  <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  {t("export.exporting")}
                </>
              ) : (
                <>
                  <Download className="h-4 w-4" />
                  {t("export.exportButton")}
                </>
              )}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}