import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { 
  ArrowRight, ArrowLeft, Check, X, Receipt, CreditCard, Landmark, 
  FileText, Tag, CalendarIcon, BanknoteIcon, Repeat, ArrowUpRight, 
  ArrowDownLeft, ChevronsRight, Clock, BadgeCheck, AlertCircle
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { AccountTreeSelector } from "./account-tree-selector";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface TransactionData {
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: Date;
  description: string;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number | null;
  creditAccountId: number | null;
  referenceNumber: string;
  createJournalEntry: boolean;
  paymentMethod?: string;
  notes?: string;
  tags?: string[];
  relatedCertificateId?: number | null;
  relatedBudgetItemId?: number | null;
  status?: string;
  currencyCode?: string;
  exchangeRate?: number;
  invoiceDate?: Date | null;
  dueDate?: Date | null;
}

interface Account {
  id: number;
  code: string;
  name: string;
  type: string;
  level: number;
  hasChildren: boolean;
  parentId: number | null;
}

interface Project {
  id: number;
  name: string;
}

interface CostCategory {
  id: string;
  name: string;
}

interface Certificate {
  id: number;
  certificateNumber: string;
  projectId: number;
  amount: number;
  status: string;
}

interface BudgetItem {
  id: number;
  projectId: number;
  name: string;
  budgetedAmount: number;
  category: string;
}

interface TransactionStepsProps {
  accounts: Account[];
  projects: Project[];
  costCategories: CostCategory[];
  certificates?: Certificate[];
  budgetItems?: BudgetItem[];
  initialData?: Partial<TransactionData>;
  onSubmit: (data: TransactionData) => void;
  onCancel: () => void;
  isSubmitting?: boolean;
  hasErrors?: Record<string, string>;
}

export default function TransactionSteps({
  accounts,
  projects,
  costCategories,
  certificates = [],
  budgetItems = [],
  initialData,
  onSubmit,
  onCancel,
  isSubmitting = false,
  hasErrors = {}
}: TransactionStepsProps) {
  const { t } = useTranslation();
  const [currentStep, setCurrentStep] = useState(0);
  const [transactionData, setTransactionData] = useState<TransactionData>({
    type: initialData?.type || "income",
    amount: initialData?.amount || 0,
    transactionDate: initialData?.transactionDate || new Date(),
    description: initialData?.description || "",
    costCategory: initialData?.costCategory || null,
    projectId: initialData?.projectId || null,
    debitAccountId: initialData?.debitAccountId || null,
    creditAccountId: initialData?.creditAccountId || null,
    referenceNumber: initialData?.referenceNumber || "",
    createJournalEntry: initialData?.createJournalEntry !== false,
    paymentMethod: initialData?.paymentMethod || "cash",
    notes: initialData?.notes || "",
    tags: initialData?.tags || [],
    relatedCertificateId: initialData?.relatedCertificateId || null,
    relatedBudgetItemId: initialData?.relatedBudgetItemId || null,
    status: initialData?.status || "draft",
    currencyCode: initialData?.currencyCode || "SAR",
    exchangeRate: initialData?.exchangeRate || 1,
    invoiceDate: initialData?.invoiceDate || null,
    dueDate: initialData?.dueDate || null
  });

  // Default values when transaction type changes
  useEffect(() => {
    if (transactionData.type === "income" && accounts && accounts.length > 0) {
      // For income, money comes in - find default cash/bank account
      const cashAccount = accounts.find(a => 
        a.type === "asset" && 
        (a.name?.includes("نقد") || a.name?.includes("بنك") || a.name?.toLowerCase()?.includes("cash"))
      );
      
      // Find revenue account
      const revenueAccount = accounts.find(a => a.type === "revenue");
      
      setTransactionData(prev => ({
        ...prev,
        debitAccountId: cashAccount?.id || prev.debitAccountId,
        creditAccountId: revenueAccount?.id || prev.creditAccountId
      }));
    } else if (transactionData.type === "expense" && accounts && accounts.length > 0) {
      // For expense, money goes out - find expense account and bank/cash account
      const expenseAccount = accounts.find(a => a.type === "expense");
      
      const cashAccount = accounts.find(a => 
        a.type === "asset" && 
        (a.name?.includes("نقد") || a.name?.includes("بنك") || a.name?.toLowerCase()?.includes("cash"))
      );
      
      setTransactionData(prev => ({
        ...prev,
        debitAccountId: expenseAccount?.id || prev.debitAccountId,
        creditAccountId: cashAccount?.id || prev.creditAccountId
      }));
    } else if (transactionData.type === "transfer" && accounts && accounts.length > 0) {
      // For transfer, money moves between accounts - find two bank accounts
      const bankAccounts = accounts.filter(a => 
        a.type === "asset" && 
        (a.name?.includes("بنك") || a.name?.toLowerCase()?.includes("bank"))
      );
      
      if (bankAccounts.length >= 2) {
        setTransactionData(prev => ({
          ...prev,
          debitAccountId: bankAccounts[0].id,
          creditAccountId: bankAccounts[1].id,
          projectId: null, // Transfers typically don't need project
          costCategory: null // Transfers don't need cost category
        }));
      }
    }
  }, [transactionData.type, accounts]);

  const steps = [
    {
      id: "type",
      title: t("financial.transactions.stepType"),
      description: t("financial.transactions.stepTypeDescription"),
      fields: ["type"]
    },
    {
      id: "amount",
      title: t("financial.transactions.stepAmount"),
      description: t("financial.transactions.stepAmountDescription"),
      fields: ["amount", "currencyCode", "exchangeRate", "transactionDate"]
    },
    {
      id: "accounts",
      title: t("financial.transactions.stepAccounts"),
      description: t("financial.transactions.stepAccountsDescription"),
      fields: ["debitAccountId", "creditAccountId"]
    },
    {
      id: "details",
      title: t("financial.transactions.stepDetails"),
      description: t("financial.transactions.stepDetailsDescription"),
      fields: ["description", "referenceNumber", "projectId", "costCategory"]
    },
    {
      id: "additional",
      title: t("financial.transactions.stepAdditional"),
      description: t("financial.transactions.stepAdditionalDescription"),
      fields: ["paymentMethod", "relatedCertificateId", "relatedBudgetItemId", "createJournalEntry", "notes"]
    }
  ];
  
  const currentStepData = steps[currentStep];

  const handleNextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      // We're on the last step, submit the form
      onSubmit(transactionData);
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    } else {
      onCancel();
    }
  };

  const updateField = (field: keyof TransactionData, value: any) => {
    setTransactionData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Check if current step is valid to proceed
  const isCurrentStepValid = () => {
    const currentFields = currentStepData.fields;
    
    // Check if any required field is empty
    if (currentFields.includes("type") && !transactionData.type) {
      return false;
    }
    
    if (currentFields.includes("amount") && 
        (transactionData.amount <= 0 || isNaN(transactionData.amount))) {
      return false;
    }
    
    if (currentFields.includes("transactionDate") && !transactionData.transactionDate) {
      return false;
    }
    
    if (currentFields.includes("debitAccountId") && !transactionData.debitAccountId) {
      return false;
    }
    
    if (currentFields.includes("creditAccountId") && !transactionData.creditAccountId) {
      return false;
    }
    
    if (currentFields.includes("referenceNumber") && !transactionData.referenceNumber.trim()) {
      return false;
    }
    
    // For expense transactions, cost category is required when project is selected
    if (currentFields.includes("costCategory") && 
        transactionData.type === "expense" && 
        transactionData.projectId && 
        !transactionData.costCategory) {
      return false;
    }
    
    return true;
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: transactionData.currencyCode || 'SAR',
      maximumFractionDigits: 0 
    }).format(amount);
  };

  return (
    <div className="w-full">
      {/* Progress header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
        <div>
          <h2 className="text-xl font-bold">{currentStepData.title}</h2>
          <p className="text-muted-foreground">{currentStepData.description}</p>
        </div>
        
        <div className="flex items-center gap-2 bg-muted/50 rounded-full p-1.5">
          {steps.map((step, index) => (
            <div 
              key={step.id}
              className={cn(
                "flex items-center",
                index !== steps.length - 1 && "mr-1"
              )}
            >
              <div 
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium",
                  currentStep === index && "bg-primary text-primary-foreground shadow-sm",
                  currentStep > index && "bg-primary/90 text-primary-foreground",
                  currentStep < index && "bg-muted text-muted-foreground"
                )}
              >
                {currentStep > index ? (
                  <Check className="h-3.5 w-3.5" />
                ) : (
                  index + 1
                )}
              </div>
              
              {index !== steps.length - 1 && (
                <div className={cn(
                  "h-0.5 w-4",
                  currentStep > index ? "bg-primary/90" : "bg-muted-foreground/30"
                )} />
              )}
            </div>
          ))}
        </div>
      </div>
      
      {/* Enhanced Progress bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-xs mb-2">
          <div className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-muted-foreground" />
            <span>{t("financial.transactions.stepsCompleted", { completed: currentStep, total: steps.length })}</span>
          </div>
          
          <div className="flex items-center gap-1.5">
            <span className="text-muted-foreground">{Math.round((currentStep / (steps.length - 1)) * 100)}%</span>
            {currentStep === steps.length - 1 ? (
              <BadgeCheck className="h-3.5 w-3.5 text-green-500" />
            ) : (
              <ChevronsRight className="h-3.5 w-3.5 text-muted-foreground" />
            )}
          </div>
        </div>
        
        <Progress 
          value={Math.round((currentStep / (steps.length - 1)) * 100)} 
          className="h-2" 
        />
      </div>
      
      {/* Step content */}
      <div className="mb-6">
        {/* Step 1: Transaction Type */}
        {currentStep === 0 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <RadioGroup
                value={transactionData.type}
                onValueChange={(value: "income" | "expense" | "transfer") => updateField("type", value)}
                className="grid grid-cols-1 md:grid-cols-3 gap-4"
              >
                <div>
                  <RadioGroupItem
                    value="income"
                    id="income"
                    className="peer sr-only"
                  />
                  <Label
                    htmlFor="income"
                    className={cn(
                      "flex flex-col items-center justify-between rounded-md border-2 border-muted p-4",
                      "hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary",
                      "cursor-pointer transition-colors [&:has([data-state=checked])]:border-primary"
                    )}
                  >
                    <div className={cn(
                      "mb-3 rounded-full p-2 bg-green-100",
                      transactionData.type === "income" && "bg-green-200"
                    )}>
                      <ArrowUpRight className="h-8 w-8 text-green-600" />
                    </div>
                    <div className="space-y-1 text-center">
                      <p className="text-lg font-semibold">
                        {t("financial.transactions.income")}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {t("financial.transactions.incomeDescription")}
                      </p>
                    </div>
                  </Label>
                </div>
                
                <div>
                  <RadioGroupItem
                    value="expense"
                    id="expense"
                    className="peer sr-only"
                  />
                  <Label
                    htmlFor="expense"
                    className={cn(
                      "flex flex-col items-center justify-between rounded-md border-2 border-muted p-4",
                      "hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary",
                      "cursor-pointer transition-colors [&:has([data-state=checked])]:border-primary"
                    )}
                  >
                    <div className={cn(
                      "mb-3 rounded-full p-2 bg-red-100",
                      transactionData.type === "expense" && "bg-red-200"
                    )}>
                      <ArrowDownLeft className="h-8 w-8 text-red-600" />
                    </div>
                    <div className="space-y-1 text-center">
                      <p className="text-lg font-semibold">
                        {t("financial.transactions.expense")}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {t("financial.transactions.expenseDescription")}
                      </p>
                    </div>
                  </Label>
                </div>
                
                <div>
                  <RadioGroupItem
                    value="transfer"
                    id="transfer"
                    className="peer sr-only"
                  />
                  <Label
                    htmlFor="transfer"
                    className={cn(
                      "flex flex-col items-center justify-between rounded-md border-2 border-muted p-4",
                      "hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary",
                      "cursor-pointer transition-colors [&:has([data-state=checked])]:border-primary"
                    )}
                  >
                    <div className={cn(
                      "mb-3 rounded-full p-2 bg-blue-100",
                      transactionData.type === "transfer" && "bg-blue-200"
                    )}>
                      <Repeat className="h-8 w-8 text-blue-600" />
                    </div>
                    <div className="space-y-1 text-center">
                      <p className="text-lg font-semibold">
                        {t("financial.transactions.transfer")}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {t("financial.transactions.transferDescription")}
                      </p>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        )}
        
        {/* Step 2: Amount and Date */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Amount */}
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-base font-medium">
                  {t("financial.transactions.amount")}
                </Label>
                <div className="relative">
                  <BanknoteIcon className="absolute right-3 top-3 h-5 w-5 text-muted-foreground/70" />
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0.00"
                    className="text-lg py-6 pl-6 pr-12 font-medium"
                    value={transactionData.amount || ''}
                    onChange={(e) => updateField("amount", parseFloat(e.target.value) || 0)}
                  />
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-base font-medium">
                    {transactionData.currencyCode || "SAR"}
                  </div>
                </div>
                {hasErrors.amount && (
                  <p className="text-sm text-destructive">{hasErrors.amount}</p>
                )}
              </div>
              
              {/* Transaction Date */}
              <div className="space-y-2">
                <Label className="text-base font-medium">
                  {t("financial.transactions.date")}
                </Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-between text-right py-6 text-base font-normal"
                    >
                      {transactionData.transactionDate ? (
                        format(transactionData.transactionDate, "yyyy/MM/dd")
                      ) : (
                        <span className="text-muted-foreground">{t("financial.transactions.selectDate")}</span>
                      )}
                      <CalendarIcon className="h-5 w-5 opacity-70" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={transactionData.transactionDate}
                      onSelect={(date) => updateField("transactionDate", date as Date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                {hasErrors.transactionDate && (
                  <p className="text-sm text-destructive">{hasErrors.transactionDate}</p>
                )}
              </div>
            </div>
            
            {/* Advanced currency options - conditionally rendered */}
            {transactionData.currencyCode !== "SAR" && (
              <div className="bg-muted/40 p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium">{t("financial.transactions.currencyOptions")}</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Exchange Rate */}
                  <div className="space-y-2">
                    <Label htmlFor="exchangeRate" className="text-sm">
                      {t("financial.transactions.exchangeRate")}
                    </Label>
                    <Input
                      id="exchangeRate"
                      type="number"
                      step="0.0001"
                      value={transactionData.exchangeRate || 1}
                      onChange={(e) => updateField("exchangeRate", parseFloat(e.target.value) || 1)}
                      className="text-sm"
                    />
                  </div>
                  
                  {/* Converted Amount (Calculated) */}
                  <div className="space-y-2">
                    <Label className="text-sm">
                      {t("financial.transactions.convertedAmount")}
                    </Label>
                    <div className="h-10 px-3 py-2 rounded-md border bg-muted/60 flex items-center">
                      <span className="text-sm">
                        {formatCurrency(transactionData.amount * (transactionData.exchangeRate || 1))}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Currency selection */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                {t("financial.transactions.currency")}
              </Label>
              <Select
                value={transactionData.currencyCode || "SAR"}
                onValueChange={(value) => updateField("currencyCode", value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder={t("financial.transactions.selectCurrency")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="SAR">SAR - ريال سعودي</SelectItem>
                  <SelectItem value="USD">USD - دولار أمريكي</SelectItem>
                  <SelectItem value="EUR">EUR - يورو</SelectItem>
                  <SelectItem value="GBP">GBP - جنيه إسترليني</SelectItem>
                  <SelectItem value="AED">AED - درهم إماراتي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Show additional date fields for invoices if expense type */}
            {transactionData.type === "expense" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Invoice Date */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">
                    {t("financial.transactions.invoiceDate")}
                  </Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-between text-right"
                      >
                        {transactionData.invoiceDate ? (
                          format(transactionData.invoiceDate, "yyyy/MM/dd")
                        ) : (
                          <span className="text-muted-foreground">{t("financial.transactions.selectDate")}</span>
                        )}
                        <CalendarIcon className="h-4 w-4 opacity-70" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={transactionData.invoiceDate || undefined}
                        onSelect={(date) => updateField("invoiceDate", date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                {/* Due Date */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">
                    {t("financial.transactions.dueDate")}
                  </Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-between text-right"
                      >
                        {transactionData.dueDate ? (
                          format(transactionData.dueDate, "yyyy/MM/dd")
                        ) : (
                          <span className="text-muted-foreground">{t("financial.transactions.selectDate")}</span>
                        )}
                        <CalendarIcon className="h-4 w-4 opacity-70" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={transactionData.dueDate || undefined}
                        onSelect={(date) => updateField("dueDate", date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* Step 3: Accounts */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-6">
              {/* Visual representation of the flow */}
              <div className="flex flex-col md:flex-row items-center justify-center gap-6 py-4">
                <div className="w-full md:w-2/5 bg-muted/30 rounded-lg p-4 text-center">
                  <p className="text-sm text-muted-foreground mb-2">
                    {t("financial.transactions.from")}
                  </p>
                  {transactionData.debitAccountId ? (
                    <div>
                      <h3 className="font-semibold">
                        {accounts.find(a => a.id === transactionData.debitAccountId)?.name}
                      </h3>
                      <p className="text-xs font-mono text-muted-foreground">
                        {accounts.find(a => a.id === transactionData.debitAccountId)?.code}
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm italic text-muted-foreground">
                      {t("financial.transactions.selectAccount")}
                    </p>
                  )}
                </div>
                
                <div className="flex flex-col items-center">
                  <div className={cn(
                    "h-10 w-10 rounded-full flex items-center justify-center",
                    transactionData.type === "income" && "bg-green-100 text-green-600",
                    transactionData.type === "expense" && "bg-red-100 text-red-600",
                    transactionData.type === "transfer" && "bg-blue-100 text-blue-600"
                  )}>
                    {transactionData.type === "income" && <ArrowUpRight className="h-5 w-5" />}
                    {transactionData.type === "expense" && <ArrowDownLeft className="h-5 w-5" />}
                    {transactionData.type === "transfer" && <Repeat className="h-5 w-5" />}
                  </div>
                  <div className="text-xl font-bold my-2">
                    {formatCurrency(transactionData.amount)}
                  </div>
                </div>
                
                <div className="w-full md:w-2/5 bg-muted/30 rounded-lg p-4 text-center">
                  <p className="text-sm text-muted-foreground mb-2">
                    {t("financial.transactions.to")}
                  </p>
                  {transactionData.creditAccountId ? (
                    <div>
                      <h3 className="font-semibold">
                        {accounts.find(a => a.id === transactionData.creditAccountId)?.name}
                      </h3>
                      <p className="text-xs font-mono text-muted-foreground">
                        {accounts.find(a => a.id === transactionData.creditAccountId)?.code}
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm italic text-muted-foreground">
                      {t("financial.transactions.selectAccount")}
                    </p>
                  )}
                </div>
              </div>
              
              {/* Debit Account */}
              <div className="space-y-2">
                <Label htmlFor="debitAccount" className="text-base font-medium">
                  {transactionData.type === "income" 
                    ? t("financial.transactions.receiveToAccount")
                    : transactionData.type === "expense"
                      ? t("financial.transactions.expenseFromAccount")
                      : t("financial.transactions.fromAccount")
                  }
                </Label>
                <AccountTreeSelector
                  accounts={accounts}
                  value={transactionData.debitAccountId}
                  onChange={(id) => updateField("debitAccountId", id)}
                  placeholder={t("financial.transactions.selectFromAccount")}
                  className="w-full"
                  accountTypes={
                    transactionData.type === "income" 
                      ? ["asset"] // Income usually goes to cash/bank (asset)
                      : transactionData.type === "expense"
                        ? ["expense"] // Expense comes from expense accounts  
                        : ["asset"] // Transfers are between assets (usually banks)
                  }
                />
                {hasErrors.debitAccountId && (
                  <p className="text-sm text-destructive">{hasErrors.debitAccountId}</p>
                )}
              </div>
              
              {/* Credit Account */}
              <div className="space-y-2">
                <Label htmlFor="creditAccount" className="text-base font-medium">
                  {transactionData.type === "income" 
                    ? t("financial.transactions.incomeFromAccount")
                    : transactionData.type === "expense"
                      ? t("financial.transactions.payToAccount")
                      : t("financial.transactions.toAccount")
                  }
                </Label>
                <AccountTreeSelector
                  accounts={accounts}
                  value={transactionData.creditAccountId}
                  onChange={(id) => updateField("creditAccountId", id)}
                  placeholder={t("financial.transactions.selectToAccount")}
                  className="w-full"
                  accountTypes={
                    transactionData.type === "income" 
                      ? ["revenue"] // Income comes from revenue accounts
                      : transactionData.type === "expense"
                        ? ["asset"] // Expense usually paid from cash/bank (asset)
                        : ["asset"] // Transfers are between assets (usually banks)
                  }
                />
                {hasErrors.creditAccountId && (
                  <p className="text-sm text-destructive">{hasErrors.creditAccountId}</p>
                )}
              </div>
              
              {/* Accounting tip */}
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-sm text-blue-800">
                <h4 className="font-medium mb-1">{t("financial.transactions.accountingTip")}</h4>
                <p>
                  {transactionData.type === "income"
                    ? t("financial.transactions.incomeTip")
                    : transactionData.type === "expense"
                      ? t("financial.transactions.expenseTip")
                      : t("financial.transactions.transferTip")
                  }
                </p>
              </div>
            </div>
          </div>
        )}
        
        {/* Step 4: Details */}
        {currentStep === 3 && (
          <div className="space-y-6">
            {/* Reference Number */}
            <div className="space-y-2">
              <Label htmlFor="referenceNumber" className="text-base font-medium">
                {t("financial.transactions.reference")}
              </Label>
              <Input
                id="referenceNumber"
                value={transactionData.referenceNumber}
                onChange={(e) => updateField("referenceNumber", e.target.value)}
                placeholder={t("financial.transactions.referencePlaceholder")}
                className="py-6 text-base"
              />
              {hasErrors.referenceNumber && (
                <p className="text-sm text-destructive">{hasErrors.referenceNumber}</p>
              )}
            </div>
            
            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description" className="text-base font-medium">
                {t("financial.transactions.description")}
              </Label>
              <Textarea
                id="description"
                value={transactionData.description}
                onChange={(e) => updateField("description", e.target.value)}
                placeholder={t("financial.transactions.descriptionPlaceholder")}
                className="min-h-[100px] text-base"
              />
              {hasErrors.description && (
                <p className="text-sm text-destructive">{hasErrors.description}</p>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Project - for income and expenses only */}
              {transactionData.type !== "transfer" && (
                <div className="space-y-2">
                  <Label htmlFor="project" className="text-base font-medium">
                    {t("financial.transactions.project")}
                  </Label>
                  <Select
                    value={transactionData.projectId?.toString() || "null"}
                    onValueChange={(value) => updateField("projectId", value === "null" ? null : parseInt(value))}
                  >
                    <SelectTrigger id="project" className="py-6 text-base">
                      <SelectValue placeholder={t("financial.transactions.selectProject")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="null">
                        {t("financial.transactions.noProject")}
                      </SelectItem>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {hasErrors.projectId && (
                    <p className="text-sm text-destructive">{hasErrors.projectId}</p>
                  )}
                </div>
              )}
              
              {/* Cost Category - for expenses only */}
              {transactionData.type === "expense" && (
                <div className="space-y-2">
                  <Label htmlFor="costCategory" className="text-base font-medium">
                    {t("financial.transactions.category")}
                  </Label>
                  <Select
                    value={transactionData.costCategory || "null"}
                    onValueChange={(value) => updateField("costCategory", value === "null" ? null : value)}
                  >
                    <SelectTrigger id="costCategory" className="py-6 text-base">
                      <SelectValue placeholder={t("financial.transactions.selectCategory")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="null">
                        {t("financial.transactions.noCategory")}
                      </SelectItem>
                      {costCategories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {hasErrors.costCategory && (
                    <p className="text-sm text-destructive">{hasErrors.costCategory}</p>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Step 5: Additional Details */}
        {currentStep === 4 && (
          <div className="space-y-6">
            {/* Payment Method */}
            <div className="space-y-2">
              <Label htmlFor="paymentMethod" className="text-base font-medium">
                {t("financial.transactions.paymentMethod")}
              </Label>
              <Select
                value={transactionData.paymentMethod || "cash"}
                onValueChange={(value) => updateField("paymentMethod", value)}
              >
                <SelectTrigger id="paymentMethod" className="py-6 text-base">
                  <SelectValue placeholder={t("financial.transactions.selectPaymentMethod")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">{t("financial.transactions.paymentMethods.cash")}</SelectItem>
                  <SelectItem value="bank_transfer">{t("financial.transactions.paymentMethods.bankTransfer")}</SelectItem>
                  <SelectItem value="credit_card">{t("financial.transactions.paymentMethods.creditCard")}</SelectItem>
                  <SelectItem value="cheque">{t("financial.transactions.paymentMethods.cheque")}</SelectItem>
                  <SelectItem value="other">{t("financial.transactions.paymentMethods.other")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Related Certificate - if project is selected and transaction is expense */}
            {transactionData.type === "expense" && transactionData.projectId && certificates.length > 0 && (
              <div className="space-y-2">
                <Label htmlFor="relatedCertificateId" className="text-base font-medium">
                  {t("financial.transactions.relatedCertificate")}
                </Label>
                <Select
                  value={transactionData.relatedCertificateId?.toString() || "null"}
                  onValueChange={(value) => updateField("relatedCertificateId", value === "null" ? null : parseInt(value))}
                >
                  <SelectTrigger id="relatedCertificateId" className="py-6 text-base">
                    <SelectValue placeholder={t("financial.transactions.selectCertificate")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="null">
                      {t("financial.transactions.noCertificate")}
                    </SelectItem>
                    {certificates
                      .filter(cert => cert.projectId === transactionData.projectId)
                      .map((certificate) => (
                        <SelectItem key={certificate.id} value={certificate.id.toString()}>
                          {certificate.certificateNumber} - {formatCurrency(certificate.amount)}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            {/* Related Budget Item - if project is selected */}
            {transactionData.projectId && budgetItems.length > 0 && (
              <div className="space-y-2">
                <Label htmlFor="relatedBudgetItemId" className="text-base font-medium">
                  {t("financial.transactions.relatedBudgetItem")}
                </Label>
                <Select
                  value={transactionData.relatedBudgetItemId?.toString() || "null"}
                  onValueChange={(value) => updateField("relatedBudgetItemId", value === "null" ? null : parseInt(value))}
                >
                  <SelectTrigger id="relatedBudgetItemId" className="py-6 text-base">
                    <SelectValue placeholder={t("financial.transactions.selectBudgetItem")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="null">
                      {t("financial.transactions.noBudgetItem")}
                    </SelectItem>
                    {budgetItems
                      .filter(item => item.projectId === transactionData.projectId)
                      .map((item) => (
                        <SelectItem key={item.id} value={item.id.toString()}>
                          {item.name} - {formatCurrency(item.budgetedAmount)}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            {/* Create Journal Entry */}
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="createJournalEntry"
                checked={transactionData.createJournalEntry}
                onChange={(e) => updateField("createJournalEntry", e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
              />
              <Label 
                htmlFor="createJournalEntry" 
                className="text-sm font-medium cursor-pointer"
              >
                {t("financial.transactions.createJournalEntry")}
              </Label>
            </div>
            
            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes" className="text-base font-medium">
                {t("financial.transactions.notes")}
              </Label>
              <Textarea
                id="notes"
                value={transactionData.notes}
                onChange={(e) => updateField("notes", e.target.value)}
                placeholder={t("financial.transactions.notesPlaceholder")}
                className="min-h-[100px] text-base"
              />
            </div>
            
            {/* Tags */}
            <div className="space-y-2">
              <Label className="text-base font-medium">
                {t("financial.transactions.tags")}
              </Label>
              <div className="flex flex-wrap gap-2 p-2 border rounded-md min-h-[80px]">
                {transactionData.tags && transactionData.tags.map((tag, index) => (
                  <Badge 
                    key={index} 
                    className="bg-primary/10 text-primary hover:bg-primary/20 px-3 py-1.5"
                  >
                    {tag}
                    <X 
                      className="h-3 w-3 ml-1 cursor-pointer" 
                      onClick={() => {
                        const newTags = [...transactionData.tags || []];
                        newTags.splice(index, 1);
                        updateField("tags", newTags);
                      }}
                    />
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Navigation buttons */}
      <div className="flex justify-between mt-8">
        <Button
          variant="outline"
          onClick={handlePrevStep}
          className="min-w-[120px]"
        >
          {currentStep === 0 ? (
            t("common.cancel")
          ) : (
            <>
              <ArrowLeft className="h-4 w-4 mr-2" />
              {t("common.previous")}
            </>
          )}
        </Button>
        
        <Button
          onClick={handleNextStep}
          disabled={!isCurrentStepValid() || isSubmitting}
          className="min-w-[120px]"
        >
          {isSubmitting ? (
            <div className="flex items-center">
              <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              {t("common.processing")}
            </div>
          ) : currentStep < steps.length - 1 ? (
            <>
              {t("common.next")}
              <ArrowRight className="h-4 w-4 ml-2" />
            </>
          ) : (
            <>
              <Check className="h-4 w-4 mr-2" />
              {t("common.save")}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}