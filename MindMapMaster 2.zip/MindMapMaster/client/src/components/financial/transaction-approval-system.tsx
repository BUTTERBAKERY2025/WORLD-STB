import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, CheckCircle2, Clock, XCircle, User, UserCheck, Shield, ArrowRight, History } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface TransactionApproval {
  id: number;
  transactionId: number;
  status: "pending" | "approved" | "rejected";
  approverName: string;
  approverId: number;
  approverRole: string;
  approvedAt?: string;
  comments?: string;
}

interface TransactionAuditLog {
  id: number;
  transactionId: number;
  action: string;
  performedBy: string;
  performedAt: string;
  details?: string;
}

interface TransactionApprovalSystemProps {
  transactionId: number;
  status: string;
  amount: number;
  type: "income" | "expense" | "transfer";
  isReadOnly?: boolean;
  className?: string;
  onStatusChange?: (newStatus: string) => void;
}

export function TransactionApprovalSystem({
  transactionId,
  status,
  amount,
  type,
  isReadOnly = false,
  className,
  onStatusChange
}: TransactionApprovalSystemProps) {
  const { t } = useTranslation();
  const [comments, setComments] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [isAuditLogOpen, setIsAuditLogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch approval information
  const { data: approvalData, isLoading: isLoadingApproval } = useQuery({
    queryKey: ['/api/financial/transactions', transactionId, 'approvals'],
    enabled: !!transactionId,
    refetchOnWindowFocus: false
  });
  
  // Fetch audit log
  const { data: auditLog, isLoading: isLoadingAuditLog } = useQuery({
    queryKey: ['/api/financial/transactions', transactionId, 'audit-log'],
    enabled: !!transactionId && isAuditLogOpen,
    refetchOnWindowFocus: false
  });
  
  // Approve transaction mutation
  const approveMutation = useMutation({
    mutationFn: (data: { comments: string }) => {
      return apiRequest("POST", `/api/financial/transactions/${transactionId}/approve`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions', transactionId, 'approvals'] });
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.approvalSuccessTitle"),
        description: t("financial.transactions.approvalSuccessDescription"),
      });
      if (onStatusChange) {
        onStatusChange("approved");
      }
      setComments("");
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.approvalErrorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Reject transaction mutation
  const rejectMutation = useMutation({
    mutationFn: (data: { comments: string }) => {
      return apiRequest("POST", `/api/financial/transactions/${transactionId}/reject`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions', transactionId, 'approvals'] });
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.rejectionSuccessTitle"),
        description: t("financial.transactions.rejectionSuccessDescription"),
      });
      if (onStatusChange) {
        onStatusChange("rejected");
      }
      setComments("");
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.rejectionErrorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Format date
  const formatDate = (date: string | Date | null | undefined) => {
    if (!date) return "-";
    try {
      return format(new Date(date), "yyyy/MM/dd HH:mm");
    } catch (error) {
      console.error("Invalid date format:", date);
      return "-";
    }
  };
  
  // Get approval steps
  const getApprovalSteps = () => {
    if (!approvalData?.approvals) return [];
    
    return approvalData.approvals;
  };
  
  // Determine if the user can approve/reject
  const canApprove = () => {
    if (isReadOnly) return false;
    if (status === "approved" || status === "rejected") return false;
    
    // If there's an approval workflow
    if (approvalData?.currentApprovalStep) {
      return approvalData.canApprove;
    }
    
    // If there's no explicit workflow, users with proper permission can approve
    return approvalData?.hasApprovalPermission || false;
  };
  
  // Format status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline" className="bg-muted text-muted-foreground">{t("financial.transactions.draft")}</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">{t("financial.transactions.pending")}</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">{t("financial.transactions.approved")}</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">{t("financial.transactions.rejected")}</Badge>;
      case "posted":
        return <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">{t("financial.transactions.posted")}</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">{t("financial.transactions.paid")}</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Handle approving transaction
  const handleApprove = () => {
    approveMutation.mutate({ comments });
  };
  
  // Handle rejecting transaction
  const handleReject = () => {
    rejectMutation.mutate({ comments });
  };
  
  // Show empty state if data isn't available yet
  if (isLoadingApproval) {
    return (
      <Card className={cn("mt-4", className)}>
        <CardHeader>
          <CardTitle className="text-lg">{t("financial.transactions.approvalSystem")}</CardTitle>
          <CardDescription>{t("financial.transactions.loading")}</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  const approvalSteps = getApprovalSteps();
  
  return (
    <Card className={cn("mt-4", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle className="text-lg">{t("financial.transactions.approvalSystem")}</CardTitle>
          <CardDescription>{t("financial.transactions.approvalSystemDescription")}</CardDescription>
        </div>
        
        <div className="flex flex-col items-end">
          <div className="flex items-center gap-2">
            {getStatusBadge(status)}
            
            <Dialog open={isAuditLogOpen} onOpenChange={setIsAuditLogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 gap-1">
                  <History className="h-4 w-4" />
                  {t("common.auditLog")}
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>{t("financial.transactions.auditLogTitle")}</DialogTitle>
                  <DialogDescription>
                    {t("financial.transactions.auditLogDescription")}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="max-h-[400px] overflow-y-auto mt-4">
                  {isLoadingAuditLog ? (
                    <div className="py-8 text-center text-muted-foreground">
                      {t("common.loading")}...
                    </div>
                  ) : auditLog?.length === 0 ? (
                    <div className="py-8 text-center text-muted-foreground">
                      {t("financial.transactions.noAuditLogEntries")}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {auditLog?.map((entry: TransactionAuditLog) => (
                        <div key={entry.id} className="border-b pb-3 last:border-0">
                          <div className="flex justify-between mb-1">
                            <div className="font-medium">{entry.action}</div>
                            <div className="text-sm text-muted-foreground">{formatDate(entry.performedAt)}</div>
                          </div>
                          <div className="text-sm flex items-center gap-1 text-muted-foreground mb-1">
                            <User className="h-3 w-3" />
                            {entry.performedBy}
                          </div>
                          {entry.details && (
                            <div className="text-sm mt-1 bg-muted/30 p-2 rounded-sm">
                              {entry.details}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAuditLogOpen(false)}>
                    {t("common.close")}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          {approvalData?.approvalWorkflowName && (
            <div className="text-xs text-muted-foreground mt-1">
              {t("financial.transactions.workflow")}: {approvalData.approvalWorkflowName}
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="pb-6">
        {approvalSteps.length > 0 ? (
          <div className="relative">
            {/* Approval steps timeline */}
            <div className="space-y-0 before:absolute before:inset-0 before:start-5 before:h-full before:w-0.5 before:bg-muted">
              {approvalSteps.map((step: TransactionApproval, index: number) => (
                <div key={step.id} className="relative flex gap-2 pb-5 last-of-type:pb-0">
                  <div className={cn(
                    "relative z-10 flex h-10 w-10 items-center justify-center rounded-full border",
                    step.status === "approved" && "bg-green-50 border-green-200 text-green-600",
                    step.status === "rejected" && "bg-red-50 border-red-200 text-red-600",
                    step.status === "pending" && "bg-muted border-muted-foreground/25 text-muted-foreground"
                  )}>
                    {step.status === "approved" && <CheckCircle2 className="h-5 w-5" />}
                    {step.status === "rejected" && <XCircle className="h-5 w-5" />}
                    {step.status === "pending" && <Clock className="h-5 w-5" />}
                  </div>
                  
                  <div className="flex-1 pt-2">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium leading-none">
                        {step.approverRole}
                      </h3>
                      <div className="text-sm text-muted-foreground">
                        {step.approvedAt ? formatDate(step.approvedAt) : ""}
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1 flex items-center">
                      <User className="h-3.5 w-3.5 mr-1" />
                      {step.approverName}
                    </div>
                    {step.comments && (
                      <div className="mt-2 text-sm bg-muted/30 p-2 rounded-sm">
                        {step.comments}
                      </div>
                    )}
                    
                    {/* Current step indicator */}
                    {approvalData?.currentApprovalStep === index && canApprove() && (
                      <div className="mt-3 rounded-md border border-blue-200 bg-blue-50 p-2 text-sm text-blue-700">
                        {t("financial.transactions.yourApprovalRequired")}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {/* If no explicit workflow, but user can approve */}
            {approvalSteps.length === 0 && approvalData?.hasApprovalPermission && (
              <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-sm text-blue-700 flex items-center gap-2">
                <Shield className="h-5 w-5" />
                <div>
                  <div className="font-medium">{t("financial.transactions.noWorkflowApproval")}</div>
                  <div>{t("financial.transactions.canApproveDirectly")}</div>
                </div>
              </div>
            )}
            
            {/* If user doesn't have permission */}
            {approvalSteps.length === 0 && !approvalData?.hasApprovalPermission && !isReadOnly && (
              <div className="rounded-md border border-muted bg-muted/30 p-3 text-sm text-muted-foreground flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                <div>
                  <div className="font-medium">{t("financial.transactions.noPermissionToApprove")}</div>
                  <div>{t("financial.transactions.waitForApprover")}</div>
                </div>
              </div>
            )}
          </div>
        ) : status === "approved" ? (
          <div className="rounded-md border border-green-200 bg-green-50 p-3 text-sm text-green-700 flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5" />
            <div>
              <div className="font-medium">{t("financial.transactions.alreadyApproved")}</div>
              <div>{t("financial.transactions.approvedOn", { date: approvalData?.approvedAt ? formatDate(approvalData.approvedAt) : "" })}</div>
            </div>
          </div>
        ) : status === "rejected" ? (
          <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700 flex items-center gap-2">
            <XCircle className="h-5 w-5" />
            <div>
              <div className="font-medium">{t("financial.transactions.wasRejected")}</div>
              <div>{t("financial.transactions.rejectedOn", { date: approvalData?.rejectedAt ? formatDate(approvalData.rejectedAt) : "" })}</div>
              {approvalData?.rejectionReason && (
                <div className="mt-2 p-2 bg-white bg-opacity-50 rounded-sm">
                  {approvalData.rejectionReason}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Default pending state */}
            <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-700 flex items-center gap-2">
              <Clock className="h-5 w-5" />
              <div>
                <div className="font-medium">{t("financial.transactions.awaitingApproval")}</div>
                <div>{t("financial.transactions.approvalPending")}</div>
              </div>
            </div>
            
            {/* If user has no permission */}
            {!approvalData?.hasApprovalPermission && !isReadOnly && (
              <div className="rounded-md border border-muted bg-muted/30 p-3 text-sm text-muted-foreground">
                {t("financial.transactions.noApprovalPermission")}
              </div>
            )}
          </div>
        )}
      </CardContent>
      
      {canApprove() && (
        <CardFooter className="flex flex-col pt-0">
          <Separator className="mb-4" />
          
          <div className="space-y-4 w-full">
            <div>
              <Textarea 
                placeholder={t("financial.transactions.enterCommentsPlaceholder")}
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                className="resize-none"
                rows={3}
              />
            </div>
            
            <div className="flex justify-end gap-2">
              <Button
                variant="destructive"
                onClick={handleReject}
                disabled={rejectMutation.isPending}
              >
                <XCircle className="h-4 w-4 mr-2" />
                {t("common.reject")}
              </Button>
              
              <Button
                onClick={handleApprove}
                disabled={approveMutation.isPending}
              >
                <CheckCircle2 className="h-4 w-4 mr-2" />
                {t("common.approve")}
              </Button>
            </div>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}