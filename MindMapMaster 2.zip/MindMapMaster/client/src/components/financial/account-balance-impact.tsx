import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowUpRight, ArrowDownLeft, ChevronsRight, ChevronsLeft, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

interface Account {
  id: number;
  code: string;
  name: string;
  balance?: number;
  previousBalance?: number;
  type: string;
}

interface AccountBalanceImpactProps {
  debitAccountId: number | null;
  creditAccountId: number | null;
  amount: number;
  transactionType: "income" | "expense" | "transfer";
  className?: string;
}

export function AccountBalanceImpact({
  debitAccountId,
  creditAccountId,
  amount,
  transactionType,
  className
}: AccountBalanceImpactProps) {
  const { t } = useTranslation();
  const [showDetailedView, setShowDetailedView] = useState(false);
  
  // Fetch account details if we have IDs
  const { data: debitAccount } = useQuery({
    queryKey: ['/api/financial/accounts', debitAccountId],
    enabled: !!debitAccountId,
    refetchOnWindowFocus: false
  });
  
  const { data: creditAccount } = useQuery({
    queryKey: ['/api/financial/accounts', creditAccountId],
    enabled: !!creditAccountId,
    refetchOnWindowFocus: false
  });
  
  // Format currency amount
  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // Calculate new balances after the transaction
  const getNewBalances = () => {
    const debitNewBalance = debitAccount?.balance ? debitAccount.balance + amount : null;
    const creditNewBalance = creditAccount?.balance ? creditAccount.balance - amount : null;
    
    return { debitNewBalance, creditNewBalance };
  };
  
  const { debitNewBalance, creditNewBalance } = getNewBalances();
  
  // Get direction arrow based on account type and transaction
  const getDirectionArrow = (accountType: string, isDebit: boolean) => {
    // Asset accounts increase with debits, decrease with credits
    // Liability & Equity accounts increase with credits, decrease with debits
    // Revenue accounts increase with credits
    // Expense accounts increase with debits
    
    if (
      (accountType === "asset" && isDebit) || 
      (accountType === "expense" && isDebit) ||
      (accountType === "liability" && !isDebit) || 
      (accountType === "equity" && !isDebit) ||
      (accountType === "revenue" && !isDebit)
    ) {
      return <ChevronUp className="h-4 w-4 text-green-500" />;
    } else {
      return <ChevronDown className="h-4 w-4 text-red-500" />;
    }
  };
  
  // Get change percentage
  const getChangePercentage = (oldBalance: number, newBalance: number) => {
    if (oldBalance === 0) return 100; // Full increase from zero
    return Math.round(((newBalance - oldBalance) / Math.abs(oldBalance)) * 100);
  };
  
  if (!debitAccount || !creditAccount || !amount) {
    return null;
  }
  
  return (
    <Card className={cn("mt-4", className)}>
      <CardHeader>
        <CardTitle className="text-lg flex items-center justify-between">
          {t("financial.transactions.accountImpact")}
          <button 
            onClick={() => setShowDetailedView(prev => !prev)}
            className="text-sm font-normal text-muted-foreground hover:text-foreground"
          >
            {showDetailedView ? t("common.hideDetails") : t("common.showDetails")}
          </button>
        </CardTitle>
        <CardDescription>
          {t("financial.transactions.accountImpactDescription")}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Debit Account Impact */}
          <div className="rounded-lg border p-3">
            <div className="flex flex-col">
              <div className="flex items-start justify-between mb-1">
                <div>
                  <div className="text-sm text-muted-foreground">{t("financial.transactions.from")}</div>
                  <div className="font-medium">{debitAccount.name}</div>
                  <div className="text-xs font-mono text-muted-foreground">{debitAccount.code}</div>
                </div>
                <div className="flex items-center text-sm pt-1">
                  {getDirectionArrow(debitAccount.type, true)}
                  <div className="text-right">
                    <span className="text-muted-foreground mr-1">{t("financial.accounts.debit")}</span> 
                    <span className={cn(
                      "font-medium",
                      debitAccount.type === "asset" || debitAccount.type === "expense" 
                        ? "text-green-600" : "text-red-600"
                    )}>
                      {formatAmount(amount)}
                    </span>
                  </div>
                </div>
              </div>

              {showDetailedView && debitAccount.balance !== undefined && (
                <div className="mt-2 pt-2 border-t border-dashed text-sm">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-muted-foreground">{t("financial.accounts.beforeTransaction")}</span>
                    <span className="font-medium">{formatAmount(debitAccount.balance)}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-muted-foreground">{t("financial.accounts.afterTransaction")}</span>
                    <span className="font-medium">{formatAmount(debitNewBalance ?? 0)}</span>
                  </div>
                  {debitAccount.balance !== 0 && (
                    <div className="flex justify-end items-center text-xs">
                      <span className={cn(
                        "px-1.5 py-0.5 rounded",
                        (debitAccount.type === "asset" || debitAccount.type === "expense") 
                          ? "bg-green-50 text-green-700" 
                          : "bg-red-50 text-red-700"
                      )}>
                        {getChangePercentage(debitAccount.balance, debitNewBalance ?? 0)}%
                      </span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
          
          {/* Credit Account Impact */}
          <div className="rounded-lg border p-3">
            <div className="flex flex-col">
              <div className="flex items-start justify-between mb-1">
                <div>
                  <div className="text-sm text-muted-foreground">{t("financial.transactions.to")}</div>
                  <div className="font-medium">{creditAccount.name}</div>
                  <div className="text-xs font-mono text-muted-foreground">{creditAccount.code}</div>
                </div>
                <div className="flex items-center text-sm pt-1">
                  {getDirectionArrow(creditAccount.type, false)}
                  <div className="text-right">
                    <span className="text-muted-foreground mr-1">{t("financial.accounts.credit")}</span>
                    <span className={cn(
                      "font-medium",
                      creditAccount.type === "liability" || creditAccount.type === "equity" || creditAccount.type === "revenue"
                        ? "text-green-600" : "text-red-600"
                    )}>
                      {formatAmount(amount)}
                    </span>
                  </div>
                </div>
              </div>

              {showDetailedView && creditAccount.balance !== undefined && (
                <div className="mt-2 pt-2 border-t border-dashed text-sm">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-muted-foreground">{t("financial.accounts.beforeTransaction")}</span>
                    <span className="font-medium">{formatAmount(creditAccount.balance)}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-muted-foreground">{t("financial.accounts.afterTransaction")}</span>
                    <span className="font-medium">{formatAmount(creditNewBalance ?? 0)}</span>
                  </div>
                  {creditAccount.balance !== 0 && (
                    <div className="flex justify-end items-center text-xs">
                      <span className={cn(
                        "px-1.5 py-0.5 rounded",
                        (creditAccount.type === "liability" || creditAccount.type === "equity" || creditAccount.type === "revenue")
                          ? "bg-green-50 text-green-700" 
                          : "bg-red-50 text-red-700"
                      )}>
                        {getChangePercentage(creditAccount.balance, creditNewBalance ?? 0)}%
                      </span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Double Entry Accounting Visualization */}
        {showDetailedView && (
          <div className="pt-2 mt-2">
            <h4 className="mb-2 font-medium text-sm">{t("financial.transactions.doubleEntryVisualization")}</h4>
            <div className="bg-muted/30 rounded-lg p-3 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="font-medium mb-1">{t("financial.accounts.debitSide")}</div>
                  <div className="flex justify-between">
                    <span>{debitAccount.name}</span>
                    <span className="font-medium">{formatAmount(amount)}</span>
                  </div>
                </div>
                <div>
                  <div className="font-medium mb-1">{t("financial.accounts.creditSide")}</div>
                  <div className="flex justify-between">
                    <span>{creditAccount.name}</span>
                    <span className="font-medium">{formatAmount(amount)}</span>
                  </div>
                </div>
              </div>
              <div className="border-t border-dashed mt-2 pt-2 text-xs text-muted-foreground">
                {t("financial.transactions.doubleEntryExplanation")}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}