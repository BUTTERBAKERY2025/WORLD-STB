import { useState } from "react";
import { useTranslation } from "react-i18next";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { FileDown, FileText, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { exportDataToPDF, exportTableToPDF, exportToExcel } from "@/utils/exportUtils";

interface ExportMenuProps {
  tableRef: React.RefObject<HTMLElement>;
  data?: any[];
  headers?: { header: string; dataKey: string }[];
  fileName: string;
  reportTitle: string;
  subtitle?: string;
}

export const ExportMenu: React.FC<ExportMenuProps> = ({
  tableRef,
  data,
  headers,
  fileName,
  reportTitle,
  subtitle
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);

  const handleExportPDF = async () => {
    try {
      setIsExporting(true);
      
      if (tableRef.current) {
        await exportTableToPDF(tableRef.current, fileName, reportTitle, subtitle);
        toast({
          title: t("exportSuccess"),
          description: t("exportPdfSuccess"),
        });
      } else if (data && headers) {
        // اذا لم يكن هناك جدول، استخدم البيانات مباشرة
        exportDataToPDF(data, headers, fileName, reportTitle, subtitle);
        toast({
          title: t("exportSuccess"),
          description: t("exportPdfSuccess"),
        });
      } else {
        throw new Error("No table reference or data provided for export");
      }
    } catch (error) {
      console.error('Error exporting PDF:', error);
      toast({
        title: t("exportError"),
        description: t("exportPdfError"),
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportExcel = async () => {
    try {
      setIsExporting(true);
      
      if (data && headers) {
        exportToExcel(data, headers, fileName);
        toast({
          title: t("exportSuccess"),
          description: t("exportExcelSuccess"),
        });
      } else {
        throw new Error("No data or headers provided for Excel export");
      }
    } catch (error) {
      console.error('Error exporting Excel:', error);
      toast({
        title: t("exportError"),
        description: t("exportExcelError"),
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" disabled={isExporting}>
          <Download className="ml-2 w-4 h-4" />
          {isExporting ? t("exporting") : t("export")}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handleExportPDF} disabled={isExporting}>
          <FileText className="ml-2 w-4 h-4" />
          <span>{t("exportPdf")}</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleExportExcel} disabled={isExporting}>
          <FileDown className="ml-2 w-4 h-4" />
          <span>{t("exportExcel")}</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};