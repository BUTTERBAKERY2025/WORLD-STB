import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { FileText, Receipt, CreditCard, CircleDollarSign, CheckCircle2, ArrowDown, Clock, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

interface Certificate {
  id: number;
  certificateNumber: string;
  projectId: number;
  projectName?: string;
  amount: number;
  paidAmount: number;
  remainingAmount: number;
  status: string;
  submissionDate: string;
  approvalDate?: string;
  paymentDueDate?: string;
}

interface CertificatePayment {
  id: number;
  certificateId: number;
  amount: number;
  paymentDate: string;
  referenceNumber: string;
  status: string;
  notes?: string;
}

interface CertificatePaymentTrackerProps {
  certificateId: number | null;
  amount: number;
  transactionType: "income" | "expense" | "transfer";
  className?: string;
}

export function CertificatePaymentTracker({
  certificateId,
  amount,
  transactionType,
  className
}: CertificatePaymentTrackerProps) {
  const { t } = useTranslation();
  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  
  // Only payments (income) are linked to certificates
  const isPaymentTransaction = transactionType === "income" && certificateId !== null;
  
  // Fetch certificate details
  const { data: certificate } = useQuery({
    queryKey: ['/api/certificates', certificateId],
    enabled: !!certificateId && isPaymentTransaction,
    refetchOnWindowFocus: false
  });
  
  // Fetch previous payments for this certificate
  const { data: previousPayments } = useQuery({
    queryKey: ['/api/certificates', certificateId, 'payments'],
    enabled: !!certificateId && isPaymentTransaction,
    refetchOnWindowFocus: false
  });
  
  // Format currency amount
  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // Format date
  const formatDate = (date: string | Date | null | undefined) => {
    if (!date) return "-";
    try {
      return format(new Date(date), "yyyy/MM/dd");
    } catch (error) {
      console.error("Invalid date format:", date);
      return "-";
    }
  };
  
  // Calculate certificate payment impact
  const calculatePaymentImpact = () => {
    if (!certificate) return null;
    
    const totalAmount = certificate.amount;
    const currentPaid = certificate.paidAmount || 0;
    const currentRemaining = certificate.remainingAmount || totalAmount - currentPaid;
    
    const newPaid = currentPaid + amount;
    const newRemaining = totalAmount - newPaid;
    const percentBefore = (currentPaid / totalAmount) * 100;
    const percentAfter = (newPaid / totalAmount) * 100;
    
    return {
      totalAmount,
      currentPaid,
      currentRemaining,
      newPaid,
      newRemaining,
      percentBefore: Math.min(100, Math.round(percentBefore)),
      percentAfter: Math.min(100, Math.round(percentAfter)),
      fullyPaidBefore: currentPaid >= totalAmount,
      fullyPaidAfter: newPaid >= totalAmount,
      overpaidAfter: newPaid > totalAmount
    };
  };
  
  const paymentImpact = calculatePaymentImpact();
  
  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline" className="bg-muted text-muted-foreground">{t("certificates.draft")}</Badge>;
      case "submitted":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">{t("certificates.submitted")}</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">{t("certificates.approved")}</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">{t("certificates.rejected")}</Badge>;
      case "partially_paid":
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">{t("certificates.partiallyPaid")}</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">{t("certificates.paid")}</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Get next status after this payment
  const getNewStatus = () => {
    if (!paymentImpact) return null;
    
    if (paymentImpact.fullyPaidAfter) {
      return "paid";
    } else if (paymentImpact.newPaid > 0 && !paymentImpact.fullyPaidAfter) {
      return "partially_paid";
    }
    
    return certificate?.status;
  };
  
  if (!isPaymentTransaction || !certificate || !paymentImpact) {
    return null;
  }
  
  return (
    <Card className={cn("mt-4", className)}>
      <CardHeader>
        <CardTitle className="text-lg flex items-center justify-between">
          {t("financial.transactions.certificatePayment")}
          <button 
            onClick={() => setShowPaymentHistory(prev => !prev)}
            className="text-sm font-normal text-muted-foreground hover:text-foreground"
          >
            {showPaymentHistory ? t("common.hideHistory") : t("common.showHistory")}
          </button>
        </CardTitle>
        <CardDescription>
          {t("financial.transactions.certificatePaymentDescription")}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Certificate Information */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <Receipt className="h-5 w-5 text-muted-foreground" />
            <div>
              <div className="font-medium">{t("certificates.certificate")} #{certificate.certificateNumber}</div>
              <div className="text-sm text-muted-foreground">
                {certificate.projectName || t("certificates.forProject", { id: certificate.projectId })}
              </div>
            </div>
          </div>
          
          <div>
            {getStatusBadge(certificate.status)}
          </div>
        </div>
        
        {/* Payment Progress */}
        <div className="space-y-2 mt-4">
          <div className="flex justify-between text-sm">
            <span>{t("certificates.totalAmount")}</span>
            <span className="font-medium">{formatAmount(paymentImpact.totalAmount)}</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <div className="space-y-1 flex-1 mr-4">
              <div className="flex justify-between mb-1">
                <span className="text-muted-foreground">{t("certificates.paidAmount")}</span>
                <span className="font-medium">
                  {formatAmount(paymentImpact.currentPaid)}
                </span>
              </div>
              <Progress 
                value={paymentImpact.percentBefore} 
                className="h-2 bg-muted"
              />
            </div>
            
            <div className="w-6 flex justify-center">
              <ArrowDown className="h-4 w-4 text-foreground" />
            </div>
            
            <div className="space-y-1 flex-1 ml-4">
              <div className="flex justify-between mb-1">
                <span className="text-muted-foreground">{t("certificates.afterPayment")}</span>
                <span className={cn(
                  "font-medium",
                  paymentImpact.overpaidAfter ? "text-amber-500" : "text-green-500"
                )}>
                  {formatAmount(paymentImpact.newPaid)}
                </span>
              </div>
              <Progress 
                value={paymentImpact.percentAfter} 
                className={cn(
                  "h-2",
                  paymentImpact.overpaidAfter ? "bg-amber-100" : "bg-muted"
                )}
                indicatorClassName={paymentImpact.overpaidAfter ? "bg-amber-500" : ""}
              />
            </div>
          </div>
          
          <div className="flex justify-between text-sm mt-2">
            <span>{t("certificates.remainingAmount")}</span>
            <span className={cn(
              "font-medium",
              paymentImpact.newRemaining <= 0 ? "text-green-500" : "text-foreground"
            )}>
              {formatAmount(Math.max(0, paymentImpact.newRemaining))}
            </span>
          </div>
          
          {/* Status Change Indication */}
          {!paymentImpact.fullyPaidBefore && paymentImpact.fullyPaidAfter && (
            <div className="rounded-md bg-green-50 border border-green-200 p-2 mt-2 flex items-center gap-2 text-green-600 text-sm">
              <CheckCircle className="h-4 w-4" />
              <span>{t("certificates.willBeMarkedAsPaid")}</span>
            </div>
          )}
          
          {!paymentImpact.fullyPaidBefore && !paymentImpact.fullyPaidAfter && certificate.status !== "partially_paid" && (
            <div className="rounded-md bg-blue-50 border border-blue-200 p-2 mt-2 flex items-center gap-2 text-blue-600 text-sm">
              <Clock className="h-4 w-4" />
              <span>{t("certificates.willBeMarkedAsPartiallyPaid")}</span>
            </div>
          )}
          
          {paymentImpact.overpaidAfter && (
            <div className="rounded-md bg-amber-50 border border-amber-200 p-2 mt-2 flex items-center gap-2 text-amber-600 text-sm">
              <CircleDollarSign className="h-4 w-4" />
              <span>{t("certificates.paymentExceedsCertificateAmount")}</span>
            </div>
          )}
        </div>
        
        {/* Payment History */}
        {showPaymentHistory && previousPayments && previousPayments.length > 0 && (
          <div className="mt-4 pt-4 border-t">
            <h4 className="font-medium mb-3">{t("certificates.paymentHistory")}</h4>
            
            <div className="space-y-3">
              {previousPayments.map((payment: CertificatePayment) => (
                <div key={payment.id} className="flex items-center justify-between border-b pb-2 last:border-0 last:pb-0">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <CreditCard className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="font-medium">{formatAmount(payment.amount)}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {formatDate(payment.paymentDate)}
                    </div>
                  </div>
                  
                  <div className="text-xs">
                    <div className="text-right text-muted-foreground">{t("certificates.reference")}</div>
                    <div className="font-mono">{payment.referenceNumber}</div>
                  </div>
                </div>
              ))}
              
              {/* Current payment (preview) */}
              <div className="flex items-center justify-between border-b pb-2 last:border-0 last:pb-0 bg-muted/20 p-2 rounded">
                <div>
                  <div className="flex items-center gap-1.5">
                    <CreditCard className="h-3.5 w-3.5 text-green-500" />
                    <span className="font-medium text-green-600">{formatAmount(amount)}</span>
                    <Badge variant="outline" className="ml-1 text-[10px] py-0 h-4 bg-green-50 text-green-700 border-green-100">
                      {t("certificates.new")}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {formatDate(new Date().toISOString())}
                  </div>
                </div>
                
                <div className="text-xs">
                  <div className="text-right text-muted-foreground">{t("certificates.newStatus")}</div>
                  <div className="font-medium text-right">{t(`certificates.${getNewStatus()}`)}</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}