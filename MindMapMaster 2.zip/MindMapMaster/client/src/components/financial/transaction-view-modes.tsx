import { useState } from "react";
import { format } from "date-fns";
import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  LayoutGrid, 
  LayoutList, 
  Calendar as CalendarIcon, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Repeat, 
  Eye, 
  FileText,
  Download,
  Copy,
  Clock 
} from "lucide-react";
import {
  Timeline,
  TimelineItem,
  TimelineIcon,
  TimelineContent,
  TimelineTitle,
  TimelineDescription,
  TimelineTime
} from "@/components/ui/timeline";
import { cn } from "@/lib/utils";

interface TransactionViewModesProps {
  transactions: any[];
  onViewDetails: (id: number) => void;
  viewMode?: "table" | "cards" | "timeline";
  onViewModeChange?: (mode: "table" | "cards" | "timeline") => void;
  isLoading?: boolean;
  emptyState?: React.ReactNode;
  className?: string;
  groupBy?: "none" | "date" | "account" | "project";
}

export function TransactionViewModes({
  transactions,
  onViewDetails,
  viewMode = "table",
  onViewModeChange,
  isLoading = false,
  emptyState,
  className,
  groupBy = "none"
}: TransactionViewModesProps) {
  const { t } = useTranslation();
  const [currentViewMode, setCurrentViewMode] = useState<"table" | "cards" | "timeline">(viewMode);

  // Handle view mode change
  const handleViewModeChange = (mode: "table" | "cards" | "timeline") => {
    setCurrentViewMode(mode);
    if (onViewModeChange) {
      onViewModeChange(mode);
    }
  };

  // Helper functions
  const getTypeIcon = (type: "income" | "expense" | "transfer") => {
    switch (type) {
      case "income":
        return <ArrowUpRight className="h-4 w-4 text-green-500" />;
      case "expense":
        return <ArrowDownLeft className="h-4 w-4 text-red-500" />;
      case "transfer":
        return <Repeat className="h-4 w-4 text-blue-500" />;
    }
  };

  // Helper function to get badge for transaction type
  const getTypeBadge = (type: "income" | "expense" | "transfer") => {
    switch (type) {
      case "income":
        return <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-100 border-green-200">{t("financial.transactions.income")}</Badge>;
      case "expense":
        return <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-100 border-red-200">{t("financial.transactions.expense")}</Badge>;
      case "transfer":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 hover:bg-blue-100 border-blue-200">{t("financial.transactions.transfer")}</Badge>;
    }
  };

  // Format currency amount
  const formatAmount = (amount: number, type: "income" | "expense" | "transfer") => {
    const formatted = new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
    
    if (type === "expense") {
      return <span className="text-red-500 font-medium">- {formatted}</span>;
    } else if (type === "income") {
      return <span className="text-green-500 font-medium">{formatted}</span>;
    } else {
      return <span className="text-blue-500 font-medium">{formatted}</span>;
    }
  };
  
  // Format date to display
  const formatDate = (date: string | Date | null | undefined) => {
    if (!date) return "-";
    try {
      return format(new Date(date), "yyyy/MM/dd");
    } catch (error) {
      console.error("Invalid date format:", date);
      return "-";
    }
  };

  // Get time of day
  const getTimeOfDay = (date: string | Date | null | undefined) => {
    if (!date) return "-";
    try {
      return format(new Date(date), "h:mm a");
    } catch (error) {
      console.error("Invalid time format:", date);
      return "-";
    }
  };

  // Empty state for no transactions
  const renderEmptyState = () => {
    if (emptyState) {
      return emptyState;
    }
    
    return (
      <div className="text-center p-10">
        <FileText className="h-10 w-10 text-muted-foreground/40 mx-auto mb-4" />
        <h3 className="text-lg font-medium mb-2">{t("financial.transactions.noTransactions")}</h3>
        <p className="text-muted-foreground mb-4">{t("financial.transactions.noTransactionsDescription")}</p>
      </div>
    );
  };

  // Group transactions by date
  const groupTransactionsByDate = () => {
    const groups: { [key: string]: any[] } = {};
    
    transactions.forEach(transaction => {
      const dateKey = formatDate(transaction.transactionDate);
      if (!groups[dateKey]) {
        groups[dateKey] = [];
      }
      groups[dateKey].push(transaction);
    });
    
    return Object.entries(groups).map(([date, items]) => ({
      title: date,
      items
    }));
  };

  // Group transactions by account
  const groupTransactionsByAccount = () => {
    const groups: { [key: string]: any[] } = {};
    
    transactions.forEach(transaction => {
      // Group by the transaction's main account (debit or credit based on type)
      const accountKey = transaction.type === 'expense' 
        ? `${transaction.creditAccount.code}-${transaction.creditAccount.name}`
        : `${transaction.debitAccount.code}-${transaction.debitAccount.name}`;
      
      if (!groups[accountKey]) {
        groups[accountKey] = [];
      }
      groups[accountKey].push(transaction);
    });
    
    return Object.entries(groups).map(([account, items]) => ({
      title: account,
      items
    }));
  };

  // Group transactions by project
  const groupTransactionsByProject = () => {
    const groups: { [key: string]: any[] } = {};
    const noProjectKey = t("financial.transactions.noProject");
    
    transactions.forEach(transaction => {
      const projectKey = transaction.project 
        ? transaction.project.name
        : noProjectKey;
      
      if (!groups[projectKey]) {
        groups[projectKey] = [];
      }
      groups[projectKey].push(transaction);
    });
    
    return Object.entries(groups).map(([project, items]) => ({
      title: project,
      items
    }));
  };

  // Get grouped transactions based on groupBy prop
  const getGroupedTransactions = () => {
    switch (groupBy) {
      case "date":
        return groupTransactionsByDate();
      case "account":
        return groupTransactionsByAccount();
      case "project":
        return groupTransactionsByProject();
      default:
        return [{ title: "", items: transactions }];
    }
  };

  const groupedTransactions = getGroupedTransactions();

  // If loading or no transactions
  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-10">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (transactions.length === 0) {
    return renderEmptyState();
  }

  return (
    <div className={cn("space-y-4", className)}>
      {onViewModeChange && (
        <div className="flex justify-end">
          <div className="bg-muted/50 rounded-md p-1 flex">
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "rounded-md",
                currentViewMode === "table" && "bg-background text-foreground shadow-sm"
              )}
              onClick={() => handleViewModeChange("table")}
            >
              <LayoutList className="h-4 w-4 mr-2" />
              {t("view.table")}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "rounded-md",
                currentViewMode === "cards" && "bg-background text-foreground shadow-sm"
              )}
              onClick={() => handleViewModeChange("cards")}
            >
              <LayoutGrid className="h-4 w-4 mr-2" />
              {t("view.cards")}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "rounded-md",
                currentViewMode === "timeline" && "bg-background text-foreground shadow-sm"
              )}
              onClick={() => handleViewModeChange("timeline")}
            >
              <Clock className="h-4 w-4 mr-2" />
              {t("view.timeline")}
            </Button>
          </div>
        </div>
      )}

      {/* Table View */}
      {currentViewMode === "table" && (
        <div>
          {groupedTransactions.map((group, groupIndex) => (
            <div key={`group-${groupIndex}`} className="mb-6">
              {group.title && groupBy !== "none" && (
                <h3 className="text-lg font-semibold mb-3 px-2">{group.title}</h3>
              )}
              
              <div className="rounded-md border overflow-hidden">
                <Table dir="rtl">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">{t("financial.transactions.id")}</TableHead>
                      <TableHead className="text-right">{t("financial.transactions.date")}</TableHead>
                      <TableHead className="text-right">{t("financial.transactions.type")}</TableHead>
                      <TableHead className="text-right">{t("financial.transactions.description")}</TableHead>
                      <TableHead className="text-right">{t("financial.transactions.amount")}</TableHead>
                      <TableHead className="text-right">{t("financial.transactions.debitAccount")}</TableHead>
                      <TableHead className="text-right">{t("financial.transactions.creditAccount")}</TableHead>
                      {groupBy !== "project" && (
                        <TableHead className="text-right">{t("financial.transactions.project")}</TableHead>
                      )}
                      <TableHead className="text-right">{t("financial.transactions.reference")}</TableHead>
                      <TableHead className="text-right"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {group.items.map((transaction: any) => (
                      <TableRow key={transaction.id} className="hover:bg-muted/30">
                        <TableCell className="font-medium">{transaction.id}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(transaction.transactionDate)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            {getTypeIcon(transaction.type)}
                            {getTypeBadge(transaction.type)}
                          </div>
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate">
                          {transaction.description || (
                            <span className="text-muted-foreground italic">
                              {t("financial.transactions.noDescription")}
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">
                          {formatAmount(transaction.amount, transaction.type)}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          <div className="flex flex-col">
                            <span className="font-medium text-foreground">{transaction.debitAccount.name}</span>
                            <span className="text-xs font-mono">{transaction.debitAccount.code}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          <div className="flex flex-col">
                            <span className="font-medium text-foreground">{transaction.creditAccount.name}</span>
                            <span className="text-xs font-mono">{transaction.creditAccount.code}</span>
                          </div>
                        </TableCell>
                        {groupBy !== "project" && (
                          <TableCell>
                            {transaction.project ? (
                              <Badge variant="outline" className="font-normal">
                                {transaction.project.name}
                              </Badge>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                        )}
                        <TableCell className="font-mono">
                          {transaction.referenceNumber}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => onViewDetails(transaction.id)}
                              title={t("common.viewDetails")}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              title={t("common.duplicate")}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Cards View */}
      {currentViewMode === "cards" && (
        <div className="space-y-6">
          {groupedTransactions.map((group, groupIndex) => (
            <div key={`group-${groupIndex}`} className="space-y-4">
              {group.title && groupBy !== "none" && (
                <h3 className="text-lg font-semibold mb-3 px-2">{group.title}</h3>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {group.items.map((transaction: any) => (
                  <Card key={transaction.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <div className="p-0">
                      <div className={cn(
                        "h-2",
                        transaction.type === "income" && "bg-green-500",
                        transaction.type === "expense" && "bg-red-500",
                        transaction.type === "transfer" && "bg-blue-500"
                      )} />
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2 mb-3">
                              {getTypeIcon(transaction.type)}
                              {getTypeBadge(transaction.type)}
                            </div>
                            <div className="mb-1">
                              <div className="font-medium line-clamp-1">
                                {transaction.description || t("financial.transactions.noDescription")}
                              </div>
                              <div className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                                <CalendarIcon className="h-3 w-3" />
                                {formatDate(transaction.transactionDate)}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-medium text-lg">
                              {formatAmount(transaction.amount, transaction.type)}
                            </div>
                            <div className="text-xs font-mono text-muted-foreground">
                              {transaction.referenceNumber}
                            </div>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 mt-3 text-sm">
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">
                              {t("financial.transactions.from")}
                            </div>
                            <div className="font-medium">{transaction.debitAccount.name}</div>
                            <div className="text-xs font-mono text-muted-foreground">
                              {transaction.debitAccount.code}
                            </div>
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">
                              {t("financial.transactions.to")}
                            </div>
                            <div className="font-medium">{transaction.creditAccount.name}</div>
                            <div className="text-xs font-mono text-muted-foreground">
                              {transaction.creditAccount.code}
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-3 flex justify-between items-center">
                          {transaction.project ? (
                            <Badge variant="outline" className="font-normal">
                              {transaction.project.name}
                            </Badge>
                          ) : (
                            <div className="text-xs text-muted-foreground">
                              {t("financial.transactions.noProject")}
                            </div>
                          )}
                          
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost" 
                              size="sm" 
                              onClick={() => onViewDetails(transaction.id)}
                              className="h-7 px-2"
                            >
                              <Eye className="h-3.5 w-3.5 mr-1" />
                              {t("common.details")}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 px-2"
                            >
                              <Copy className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Timeline View */}
      {currentViewMode === "timeline" && (
        <div className="space-y-6">
          {groupedTransactions.map((group, groupIndex) => (
            <div key={`group-${groupIndex}`} className="space-y-4">
              {group.title && groupBy !== "none" && (
                <h3 className="text-lg font-semibold mb-3 px-2">{group.title}</h3>
              )}
              
              <Timeline className="mx-4">
                {group.items.map((transaction: any) => (
                  <TimelineItem key={transaction.id}>
                    <TimelineIcon className={cn(
                        transaction.type === "income" && "bg-green-100 text-green-600 border-green-200",
                        transaction.type === "expense" && "bg-red-100 text-red-600 border-red-200",
                        transaction.type === "transfer" && "bg-blue-100 text-blue-600 border-blue-200"
                      )}>
                        {getTypeIcon(transaction.type)}
                    </TimelineIcon>
                    <TimelineContent>
                      <TimelineTitle className="flex items-center gap-2">
                        <div className="font-medium">{formatDate(transaction.transactionDate)}</div>
                        <TimelineTime className="text-sm text-muted-foreground">
                          {getTimeOfDay(transaction.transactionDate)}
                        </TimelineTime>
                        <div className="text-sm">
                          {getTypeBadge(transaction.type)}
                        </div>
                        <div className="font-medium">
                          {formatAmount(transaction.amount, transaction.type)}
                        </div>
                      </TimelineTitle>
                      <TimelineDescription className="pl-0">
                        <div className="p-3 border rounded-lg bg-muted/10">
                          <div className="mb-2 line-clamp-2">
                            {transaction.description || (
                              <span className="text-muted-foreground italic">
                                {t("financial.transactions.noDescription")}
                              </span>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">
                                {t("financial.transactions.from")}
                              </div>
                              <div className="font-medium">{transaction.debitAccount.name}</div>
                              <div className="text-xs font-mono text-muted-foreground">
                                {transaction.debitAccount.code}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">
                                {t("financial.transactions.to")}
                              </div>
                              <div className="font-medium">{transaction.creditAccount.name}</div>
                              <div className="text-xs font-mono text-muted-foreground">
                                {transaction.creditAccount.code}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              {transaction.project && (
                                <Badge variant="outline" className="font-normal">
                                  {transaction.project.name}
                                </Badge>
                              )}
                              <div className="text-xs font-mono text-muted-foreground">
                                {transaction.referenceNumber}
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-1">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => onViewDetails(transaction.id)}
                                className="h-7 px-2"
                              >
                                <Eye className="h-3.5 w-3.5 mr-1" />
                                {t("common.details")}
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 px-2"
                              >
                                <Copy className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </TimelineDescription>
                    </TimelineContent>
                  </TimelineItem>
                ))}
              </Timeline>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}