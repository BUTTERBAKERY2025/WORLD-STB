import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useState } from "react";
import L from "leaflet";

interface ProjectsMapProps {
  className?: string;
}

// Sample project location data for the map
const projectLocations = [
  {
    id: 1,
    name: "مشروع الطريق الدائري",
    location: "الرياض، ٤ كم",
    coordinates: [24.774265, 46.738586],
    type: "road",
  },
  {
    id: 2,
    name: "شبكة مياه الحي الشرقي",
    location: "الدمام، منطقة ١٢",
    coordinates: [26.434517, 50.103782],
    type: "water",
  },
];

export function ProjectsMap({ className }: ProjectsMapProps) {
  const { t } = useTranslation();
  const [icon, setIcon] = useState<L.Icon | null>(null);
  
  // Create custom marker icon
  useEffect(() => {
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    
    const DefaultIcon = L.icon({
      iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
      shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41],
    });
    
    setIcon(DefaultIcon);
  }, []);

  // Fetch projects (not needed for MVP)
  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
    enabled: false, // Disable for now
  });

  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-bold">
          {t("dashboard.projects_map")}
        </CardTitle>
        <Button variant="link" className="p-0 h-auto text-primary">
          {t("common.view_all")}
          <span className="material-icons text-sm mr-1">chevron_left</span>
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        {/* Map Container */}
        <div className="h-64 relative border rounded-md overflow-hidden">
          {icon && (
            <MapContainer
              center={[24.774265, 46.738586]}
              zoom={6}
              style={{ height: "100%", width: "100%" }}
              attributionControl={false}
            >
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              
              {projectLocations.map((project) => (
                <Marker 
                  key={project.id}
                  position={project.coordinates as [number, number]}
                  icon={icon}
                >
                  <Popup>
                    <div className="text-right" dir="rtl">
                      <p className="font-bold">{project.name}</p>
                      <p className="text-sm text-gray-600">{project.location}</p>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          )}
        </div>
        
        {/* Project Locations List */}
        <div className="mt-4 space-y-3 p-4">
          <div className="flex items-center border-r-4 border-primary pr-2">
            <span className="material-icons text-primary">location_on</span>
            <div className="mr-2">
              <p className="text-sm font-medium">مشروع الطريق الدائري</p>
              <p className="text-xs text-gray-500">الرياض، ٤ كم</p>
            </div>
          </div>
          <div className="flex items-center border-r-4 border-success pr-2">
            <span className="material-icons text-success">location_on</span>
            <div className="mr-2">
              <p className="text-sm font-medium">شبكة مياه الحي الشرقي</p>
              <p className="text-xs text-gray-500">الدمام، منطقة ١٢</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
