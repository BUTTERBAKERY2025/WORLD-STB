import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressWithText } from "@/components/ui/progress-with-text";
import { formatCurrency, formatDate, getIconBgByType } from "@/lib/utils";
import { Link } from "wouter";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { Project } from "@shared/schema";

interface ActiveProjectsTableProps {
  className?: string;
}

// Sample project data for the table
const projectData: Project[] = [
  {
    id: 1,
    name: "تطوير الطريق الدائري الشمالي",
    description: "مشروع تطوير وتوسعة الطريق الدائري الشمالي",
    type: "road",
    status: "in_progress",
    startDate: new Date("2023-05-12"),
    endDate: new Date("2023-12-15"),
    budget: 2400000,
    progress: 75,
    location: { type: "Point", coordinates: [46.738586, 24.774265] },
    createdBy: 1,
    managedBy: 1,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 2,
    name: "شبكة مياه الحي الشرقي",
    description: "مشروع إنشاء شبكة مياه للحي الشرقي",
    type: "water",
    status: "delayed",
    startDate: new Date("2023-03-08"),
    endDate: new Date("2023-11-20"),
    budget: 1800000,
    progress: 45,
    location: { type: "Point", coordinates: [50.103782, 26.434517] },
    createdBy: 1,
    managedBy: 1,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 3,
    name: "تحديث شبكة الكهرباء - المنطقة الصناعية",
    description: "مشروع تحديث وتطوير شبكة الكهرباء في المنطقة الصناعية",
    type: "electricity",
    status: "in_progress",
    startDate: new Date("2023-06-22"),
    endDate: new Date("2024-01-30"),
    budget: 3200000,
    progress: 85,
    location: { type: "Point", coordinates: [46.824186, 24.659864] },
    createdBy: 1,
    managedBy: 1,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 4,
    name: "إنشاء برج الاتصالات المركزي",
    description: "مشروع إنشاء برج اتصالات مركزي لتحسين الخدمة",
    type: "telecom",
    status: "stopped",
    startDate: new Date("2023-04-05"),
    endDate: new Date("2023-10-15"),
    budget: 5200000,
    progress: 25,
    location: { type: "Point", coordinates: [46.716667, 24.633333] },
    createdBy: 1,
    managedBy: 1,
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

export function ActiveProjectsTable({ className }: ActiveProjectsTableProps) {
  const { t } = useTranslation();
  const [projectFilter, setProjectFilter] = useState("all");
  
  // Fetch active projects from API (disabled for now)
  const { data: projects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    enabled: false, // Disabled for now
  });
  
  // Filter projects based on selected filter
  const filteredProjects = projectData.filter(project => {
    if (projectFilter === "all") return true;
    return project.type === projectFilter;
  });
  
  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-bold">
          {t("dashboard.active_projects")}
        </CardTitle>
        <div className="flex space-x-2 space-x-reverse">
          <Select onValueChange={setProjectFilter} defaultValue={projectFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t("project.filter.all")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("project.filter.all")}</SelectItem>
              <SelectItem value="road">{t("project.types.road")}</SelectItem>
              <SelectItem value="water">{t("project.types.water")}</SelectItem>
              <SelectItem value="electricity">{t("project.types.electricity")}</SelectItem>
              <SelectItem value="telecom">{t("project.types.telecom")}</SelectItem>
              <SelectItem value="building">{t("project.types.building")}</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="sm" className="flex items-center">
            <span className="material-icons text-sm ml-1">filter_list</span>
            <span>{t("common.filter")}</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                  {t("project.name")}
                </th>
                <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                  {t("project.type")}
                </th>
                <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                  {t("project.progress")}
                </th>
                <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                  {t("project.status")}
                </th>
                <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                  {t("project.budget")}
                </th>
                <th className="py-3 px-4 text-center text-sm font-medium text-gray-500">
                  {t("common.actions")}
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredProjects.map((project) => (
                <tr key={project.id} className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 flex-shrink-0 rounded-md ${getIconBgByType(project.type)} flex items-center justify-center text-white`}>
                        {project.name.charAt(0)}
                      </div>
                      <div className="mr-3">
                        <Link href={`/projects/${project.id}`}>
                          <p className="font-medium text-gray-800 hover:text-primary hover:underline cursor-pointer">
                            {project.name}
                          </p>
                        </Link>
                        <p className="text-xs text-gray-500">
                          {t("project.start_date")}: {project.startDate ? formatDate(project.startDate) : '-'}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <ProjectTypeBadge type={project.type} />
                  </td>
                  <td className="py-3 px-4">
                    <ProgressWithText value={project.progress} />
                  </td>
                  <td className="py-3 px-4">
                    <StatusBadge status={project.status} />
                  </td>
                  <td className="py-3 px-4">
                    <p className="text-gray-800">
                      {project.budget ? formatCurrency(project.budget / 1000000) : '-'} {project.budget ? t("currency.million") : ''}
                    </p>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <span className="material-icons">more_vert</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <span className="material-icons text-sm ml-2">visibility</span>
                          {t("common.view")}
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <span className="material-icons text-sm ml-2">edit</span>
                          {t("common.edit")}
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-danger">
                          <span className="material-icons text-sm ml-2">delete</span>
                          {t("common.delete")}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* View All Link */}
        <div className="mt-4 text-center">
          <Link href="/projects">
            <span className="text-primary font-medium hover:underline cursor-pointer">
              {t("common.view_all_projects")}
            </span>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
