import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Legend, 
  Tooltip 
} from "recharts";
import { ProgressWithText } from "@/components/ui/progress-with-text";

interface RiskAnalysisProps {
  className?: string;
}

// Sample risk data
const riskData = [
  { name: "مخاطر منخفضة", value: 5, color: "#4caf50" },
  { name: "مخاطر متوسطة", value: 4, color: "#ffeb3b" },
  { name: "مخاطر عالية", value: 3, color: "#f44336" },
];

export function RiskAnalysis({ className }: RiskAnalysisProps) {
  const { t } = useTranslation();
  
  // Fetch risk stats from API (disabled for now)
  const { data: riskStats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: false, // Disabled for now
  });
  
  // Calculate total risks
  const totalRisks = riskData.reduce((acc, risk) => acc + risk.value, 0);
  
  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-bold">
          {t("dashboard.risk_analysis")}
        </CardTitle>
        <span className="material-icons text-gray-500">info_outline</span>
      </CardHeader>
      <CardContent className="pt-0">
        {/* Risk Donut Chart */}
        <div className="flex justify-center mb-6" style={{ height: "144px" }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={riskData}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={60}
                paddingAngle={5}
                dataKey="value"
              >
                {riskData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
          
          <div className="absolute inset-0 flex items-center justify-center flex-col" style={{ pointerEvents: "none" }}>
            <span className="text-2xl font-bold text-gray-800">{totalRisks}</span>
            <span className="text-sm text-gray-500">{t("dashboard.potential_risks")}</span>
          </div>
        </div>
        
        {/* Risk Categories */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-success ml-2"></div>
                <span className="text-sm font-medium">{t("risk.level.low")}</span>
              </div>
              <span className="text-sm font-medium">{riskData[0].value}</span>
            </div>
            <ProgressWithText 
              value={Math.round((riskData[0].value / totalRisks) * 100)} 
              width="w-full" 
              showText={false} 
            />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-warning ml-2"></div>
                <span className="text-sm font-medium">{t("risk.level.medium")}</span>
              </div>
              <span className="text-sm font-medium">{riskData[1].value}</span>
            </div>
            <ProgressWithText 
              value={Math.round((riskData[1].value / totalRisks) * 100)} 
              width="w-full" 
              showText={false} 
            />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-danger ml-2"></div>
                <span className="text-sm font-medium">{t("risk.level.high")}</span>
              </div>
              <span className="text-sm font-medium">{riskData[2].value}</span>
            </div>
            <ProgressWithText 
              value={Math.round((riskData[2].value / totalRisks) * 100)} 
              width="w-full" 
              showText={false} 
            />
          </div>
        </div>
        
        {/* View Details Link */}
        <div className="mt-6">
          <Button variant="secondary" className="w-full">
            {t("risk.manage_risks")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
