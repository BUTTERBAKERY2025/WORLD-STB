import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts";
import { useState } from "react";

interface ProjectProgressChartProps {
  className?: string;
}

// Sample data for the chart
const chartData = {
  week: [
    { name: "السبت", projects: 2, completion: 15 },
    { name: "الأحد", projects: 5, completion: 25 },
    { name: "الإثنين", projects: 7, completion: 35 },
    { name: "الثلاثاء", projects: 4, completion: 20 },
    { name: "الأربعاء", projects: 8, completion: 40 },
    { name: "الخميس", projects: 12, completion: 60 },
    { name: "الجمعة", projects: 2, completion: 10 },
  ],
  month: [
    { name: "يناير", projects: 20, completion: 65 },
    { name: "فبراير", projects: 25, completion: 75 },
    { name: "مارس", projects: 35, completion: 85 },
    { name: "أبريل", projects: 30, completion: 70 },
    { name: "مايو", projects: 45, completion: 90 },
    { name: "يونيو", projects: 40, completion: 80 },
  ],
  year: [
    { name: "2018", projects: 120, completion: 65 },
    { name: "2019", projects: 150, completion: 75 },
    { name: "2020", projects: 180, completion: 85 },
    { name: "2021", projects: 200, completion: 90 },
    { name: "2022", projects: 220, completion: 92 },
    { name: "2023", projects: 240, completion: 95 },
  ],
};

type TimeRange = "week" | "month" | "year";

export function ProjectProgressChart({ className }: ProjectProgressChartProps) {
  const { t } = useTranslation();
  const [timeRange, setTimeRange] = useState<TimeRange>("month");
  
  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-bold">
          {t("dashboard.project_progress")}
        </CardTitle>
        <div className="flex space-x-2 space-x-reverse">
          <Button
            variant={timeRange === "week" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeRange("week")}
            className="text-xs h-8"
          >
            {t("time.week")}
          </Button>
          <Button
            variant={timeRange === "month" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeRange("month")}
            className="text-xs h-8"
          >
            {t("time.month")}
          </Button>
          <Button
            variant={timeRange === "year" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeRange("year")}
            className="text-xs h-8"
          >
            {t("time.year")}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="rtl-chart h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData[timeRange]}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="name"
                tick={{ fontSize: 12 }}
                tickMargin={10}
              />
              <YAxis 
                yAxisId="left"
                orientation="left"
                label={{ value: t("dashboard.projects"), angle: -90, position: 'insideLeft' }}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                label={{ value: t("dashboard.completion_percentage"), angle: 90, position: 'insideRight' }}
              />
              <Tooltip />
              <Legend />
              <Bar 
                yAxisId="left"
                dataKey="projects" 
                name={t("dashboard.projects")}
                fill="var(--chart-1)" 
                radius={[4, 4, 0, 0]}
              />
              <Bar 
                yAxisId="right"
                dataKey="completion" 
                name={t("dashboard.completion_percentage")}
                fill="var(--chart-2)" 
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
