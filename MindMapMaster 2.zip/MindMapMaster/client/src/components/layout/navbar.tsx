import { Link } from "wouter";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface NavbarProps {
  onMobileMenuClick: () => void;
}

export function Navbar({ onMobileMenuClick }: NavbarProps) {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState("");
  
  return (
    <header className="bg-white shadow-sm z-20">
      <div className="flex items-center justify-between p-4">
        {/* Mobile menu button */}
        <button
          onClick={onMobileMenuClick}
          className="md:hidden focus:outline-none"
        >
          <span className="material-icons">menu</span>
        </button>

        {/* Search Bar */}
        <div className="relative flex-1 max-w-lg mx-auto md:mx-0 md:max-w-xs lg:max-w-md">
          <Input
            type="text"
            placeholder={t("search.placeholder")}
            className="w-full pr-10 pl-4 py-2"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <span className="material-icons absolute top-2 right-3 text-gray-400">
            search
          </span>
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center">
          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative">
            <span className="material-icons">notifications</span>
            <span className="absolute top-1 right-1 w-4 h-4 bg-danger text-white text-xs rounded-full flex items-center justify-center">
              3
            </span>
          </Button>

          {/* Help */}
          <Button variant="ghost" size="icon" className="mr-4">
            <span className="material-icons">help_outline</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
