import * as React from "react";
import { SidebarNav } from "@/components/ui/sidebar-nav";
import { useTranslation } from "react-i18next";
import { useLanguage } from "@/contexts/language-context";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const { t } = useTranslation();
  const { language, setLanguage } = useLanguage();
  const [isCollapsed, setIsCollapsed] = React.useState(false);
  
  // تقسيم العناصر التنقلية حسب الفئات
  const navigationItems = [
    // قسم اللوحات الرئيسية
    {
      href: "/",
      title: "sidebar.dashboard",
      icon: "home",
      titleDisplay: "الرئيسية",
    },
    
    // قسم المشاريع
    {
      href: "/projects",
      title: "sidebar.projects",
      icon: "engineering",
      children: [
        {
          href: "/projects/dashboard",
          title: "sidebar.project_dashboard",
          icon: "dashboard",
        },
        {
          href: "/projects/list",
          title: "sidebar.all_projects",
          icon: "format_list_bulleted",
        },
        {
          href: "/projects/new",
          title: "sidebar.new_project",
          icon: "add_circle",
        },
        {
          href: "/projects/reports",
          title: "sidebar.project_reports",
          icon: "assessment",
        },
      ],
    },
    
    // أنواع المشاريع (بدون قائمة منسدلة)
    {
      href: "/projects/types",
      title: "projectTypes",
      titleDisplay: "أنواع المشاريع",
      icon: "category",
    },
    // أنواع المشاريع المعاد تصميمها
    {
      href: "/projects/types-redesigned",
      title: "projectTypesRedesigned",
      titleDisplay: "أنواع المشاريع (تصميم جديد)",
      icon: "category",
    },
    
    // قسم المالية
    {
      href: "/financial",
      title: "sidebar.financial",
      icon: "account_balance",
      children: [
        {
          href: "/financial",
          title: "sidebar.financial_dashboard",
          icon: "analytics",
        },
        {
          href: "/financial/accounts",
          title: "sidebar.chart_of_accounts",
          icon: "account_tree",
        },
        {
          href: "/financial/journal-entries",
          title: "sidebar.journal_entries",
          icon: "receipt",
        },
        {
          href: "/financial/transactions",
          title: "sidebar.financial_transactions",
          icon: "receipt_long",
        },
        {
          href: "/financial/certificates",
          title: "sidebar.payment_certificates",
          icon: "request_quote",
        },
        {
          href: "/financial/budgets",
          title: "sidebar.project_budgets",
          icon: "savings",
        },
        {
          href: "/financial/reports",
          title: "sidebar.reports",
          icon: "assessment",
        },
      ],
    },
    
    // قسم الموارد
    {
      href: "#resources",
      title: "resources",
      titleDisplay: "الموارد",
      icon: "inventory_2",
      children: [
        {
          href: "/assets",
          title: "sidebar.assets",
          icon: "precision_manufacturing",
        },
        {
          href: "/documents",
          title: "sidebar.documents",
          icon: "description",
        },
      ],
    },
    
    // قسم الخرائط والمواقع
    {
      href: "/maps",
      title: "sidebar.maps",
      icon: "location_on",
    },
    
    // قسم التقارير
    {
      href: "/reports",
      title: "sidebar.reports",
      icon: "summarize",
      children: [
        {
          href: "/reports/performance",
          title: "performanceReports",
          titleDisplay: "تقارير الأداء",
          icon: "bar_chart",
        },
        {
          href: "/reports/financial",
          title: "financialReports",
          titleDisplay: "التقارير المالية",
          icon: "receipt_long",
        },
        {
          href: "/reports/progress",
          title: "progressReports",
          titleDisplay: "تقارير التقدم",
          icon: "trending_up",
        },
      ],
    },
    
    // قسم الإعدادات
    {
      href: "/settings",
      title: "sidebar.settings",
      icon: "settings",
      children: [
        {
          href: "/settings/profile",
          title: "sidebar.profile",
          icon: "person",
        },
        {
          href: "/settings/account",
          title: "sidebar.account_settings",
          icon: "manage_accounts",
        },
        {
          href: "/settings/system",
          title: "sidebar.system_settings",
          icon: "settings_applications",
        },
        {
          href: "/settings/users",
          title: "sidebar.users",
          icon: "group",
        },
        {
          href: "/settings/roles",
          title: "sidebar.roles",
          icon: "admin_panel_settings",
        },
      ],
    },
  ];

  return (
    <aside className={cn(
      "flex flex-col bg-white shadow-lg z-30 h-screen",
      "fixed inset-y-0 right-0 transition-all duration-300 ease-in-out transform",
      isOpen ? "translate-x-0" : "translate-x-full",
      "md:translate-x-0 md:static tablet-sidebar", 
      "border-l border-gray-100 dark:border-gray-700",
      isCollapsed ? "md:w-[80px]" : "w-[280px]"
    )}>
      {/* Logo */}
      <div className="py-5 px-4 border-b border-gray-100 bg-gradient-to-l from-primary/5 to-white">
        <div className="flex items-center justify-between">
          <div className={cn(
            "flex items-center",
            isCollapsed ? "justify-center w-full" : "space-x-2 rtl:space-x-reverse"
          )}>
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center shadow-sm">
              <span className="material-icons text-white text-2xl">construction</span>
            </div>
            {!isCollapsed && <span className="text-xl font-bold text-primary tracking-wide">{t("app.title")}</span>}
          </div>
          <div className="flex items-center space-x-1 rtl:space-x-reverse">
            <button
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="hidden md:flex touch-button bg-white/90 shadow-sm focus:outline-none hover:bg-white rounded-full w-8 h-8 items-center justify-center btn-elegant"
            >
              <span className="material-icons text-primary text-lg">
                {isCollapsed ? "keyboard_double_arrow_left" : "keyboard_double_arrow_right"}
              </span>
            </button>
            <button
              onClick={onClose}
              className="md:hidden touch-button bg-white/90 shadow-sm focus:outline-none hover:bg-white rounded-full w-10 h-10 flex items-center justify-center btn-elegant"
            >
              <span className="material-icons text-primary">menu_open</span>
            </button>
          </div>
        </div>
      </div>

      {/* User info */}
      <div className={cn(
        "flex items-center border-b border-gray-100 bg-gradient-to-l from-primary/5 to-white",
        isCollapsed ? "justify-center p-3" : "p-4"
      )}>
        <div className="relative">
          <div className="w-14 h-14 rounded-lg bg-primary flex items-center justify-center text-white shadow-md">
            <span className="text-lg font-semibold">م.أ</span>
          </div>
          {/* مؤشر الحالة - نقطة خضراء */}
          <div className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full bg-green-500 border-2 border-white shadow-sm"></div>
        </div>
        {!isCollapsed && (
          <div className="mr-3 flex-1">
            <p className="font-semibold text-gray-800 text-base">م. أحمد الخالدي</p>
            <div className="flex items-center mt-0.5">
              <span className="material-icons text-primary/80 text-sm ml-1">star</span>
              <p className="text-sm text-gray-600">{t("user.role.project_manager")}</p>
            </div>
          </div>
        )}
      </div>

      {/* Search Box */}
      {!isCollapsed ? (
        <div className="px-4 py-3 border-b border-gray-100">
          <div className="relative">
            <span className="absolute top-0 bottom-0 right-3 flex items-center justify-center text-gray-400">
              <span className="material-icons text-lg">search</span>
            </span>
            <input 
              type="text" 
              placeholder={t("search.placeholder")}
              className="w-full h-10 pl-3 pr-10 rounded-lg border border-gray-200 bg-gray-50/80 text-sm placeholder:text-gray-400 focus:outline-none focus:border-primary/30 focus:ring-1 focus:ring-primary/30 transition-colors"
            />
          </div>
        </div>
      ) : (
        <div className="py-3 flex justify-center border-b border-gray-100">
          <button 
            className="w-10 h-10 rounded-lg bg-primary/5 hover:bg-primary/10 transition-all flex items-center justify-center text-primary"
          >
            <span className="material-icons text-xl">search</span>
          </button>
        </div>
      )}

      {/* Navigation Menu */}
      <nav className="flex-1 py-3 px-3 overflow-y-auto scrollbar-hide touch-spacing bg-gray-50/30">
        <SidebarNav items={navigationItems} isCollapsed={isCollapsed} />
      </nav>

      {/* Sustainability Section was removed */}

      {/* Language Switcher */}
      {!isCollapsed ? (
        <div className="p-4 border-t border-gray-100 bg-gradient-to-b from-gray-50/30 to-white">
          <div className="flex justify-around gap-2">
            <Button
              variant={language === 'ar' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setLanguage('ar')}
              className={cn(
                'btn-elegant min-w-[100px] h-10 text-[15px] font-medium transition-all duration-300',
                language === 'ar' 
                  ? 'bg-primary hover:bg-primary/90 text-white shadow-sm' 
                  : 'border-gray-200 text-gray-700 hover:bg-gray-50'
              )}
            >
              العربية
            </Button>
            <Button
              variant={language === 'en' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setLanguage('en')}
              className={cn(
                'btn-elegant min-w-[100px] h-10 text-[15px] font-medium transition-all duration-300',
                language === 'en' 
                  ? 'bg-primary hover:bg-primary/90 text-white shadow-md' 
                  : 'border-gray-200 text-gray-700 hover:bg-gray-50'
              )}
            >
              English
            </Button>
          </div>
        </div>
      ) : (
        <div className="py-3 border-t border-gray-100 bg-gradient-to-b from-gray-50/30 to-white">
          <div className="flex flex-col items-center gap-2">
            <button
              onClick={() => setLanguage('ar')}
              className={cn(
                'w-12 h-9 rounded-lg transition-all duration-200 flex items-center justify-center',
                language === 'ar'
                  ? 'bg-primary text-white shadow-sm' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              )}
            >
              <span className="text-[14px] font-medium">عربي</span>
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={cn(
                'w-12 h-9 rounded-lg transition-all duration-200 flex items-center justify-center',
                language === 'en'
                  ? 'bg-primary text-white shadow-sm' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              )}
            >
              <span className="text-[14px] font-medium">EN</span>
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
