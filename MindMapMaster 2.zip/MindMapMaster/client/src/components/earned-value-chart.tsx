import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useTranslation } from "react-i18next";
import { formatCurrency } from "@/lib/utils";

// تعريف نموذج البيانات لمؤشرات القيمة المكتسبة
interface EarnedValueData {
  period: string; // الفترة الزمنية (مثل تاريخ أو شهر)
  plannedValue: number; // القيمة المخططة (PV)
  earnedValue: number; // القيمة المكتسبة (EV)
  actualCost: number; // التكلفة الفعلية (AC)
}

interface EarnedValueChartProps {
  data: EarnedValueData[];
  title?: string;
  showLegend?: boolean;
  height?: number;
  className?: string;
}

export function EarnedValueChart({
  data,
  title = "تحليل القيمة المكتسبة",
  showLegend = true,
  height = 300,
  className,
}: EarnedValueChartProps) {
  const { t } = useTranslation();
  
  // تخصيص تلميح المخطط (Tooltip)
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded p-2 shadow-md">
          <p className="font-medium">{`${label}`}</p>
          {payload.map((entry: any) => (
            <p key={entry.dataKey} className="text-sm" style={{ color: entry.color }}>
              {`${entry.name}: ${formatCurrency(entry.value)}`}
            </p>
          ))}
          {payload.length >= 2 && (
            <>
              <hr className="my-1 border-muted" />
              <p className="text-xs text-foreground">
                CPI: {(payload[1].value / payload[2].value).toFixed(2)}
              </p>
              <p className="text-xs text-foreground">
                SPI: {(payload[1].value / payload[0].value).toFixed(2)}
              </p>
            </>
          )}
        </div>
      );
    }
    
    return null;
  };
  
  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div style={{ width: "100%", height }}>
          {data.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={data}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="period" 
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => value.length > 8 ? value.substring(0, 8) + '...' : value}
                />
                <YAxis 
                  tickFormatter={(value) => `${formatCurrency(value)}`}
                  tick={{ fontSize: 12 }}
                />
                <Tooltip content={<CustomTooltip />} />
                {showLegend && (
                  <Legend
                    formatter={(value) => {
                      switch (value) {
                        case "plannedValue":
                          return t("project.planned_value");
                        case "earnedValue":
                          return t("project.earned_value");
                        case "actualCost":
                          return t("project.actual_cost");
                        default:
                          return value;
                      }
                    }}
                  />
                )}
                <Line
                  type="monotone"
                  dataKey="plannedValue"
                  name={t("project.planned_value")}
                  stroke="#3b82f6" // blue-500
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="earnedValue"
                  name={t("project.earned_value")}
                  stroke="#22c55e" // green-500
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="actualCost"
                  name={t("project.actual_cost")}
                  stroke="#ef4444" // red-500
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
              <p>{t("common.no_data_available")}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}