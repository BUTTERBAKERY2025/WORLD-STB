import { cn } from "@/lib/utils";

export interface SARSymbolProps extends React.SVGProps<SVGSVGElement> {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | number;
}

/**
 * رمز الريال السعودي (SAR)
 * مكون SVG قابل للتخصيص لعرض رمز العملة السعودية
 */
export function SARSymbol({
  className,
  size = 'md',
  width,
  height,
  ...props
}: SARSymbolProps) {
  // تحويل الحجم إلى قيمة رقمية
  const getNumericSize = () => {
    if (typeof size === 'number') return size;
    
    switch (size) {
      case 'sm': return 14;
      case 'lg': return 20;
      case 'md':
      default: return 16;
    }
  };

  // استخدام الحجم المحسوب إذا لم يتم تحديد عرض وارتفاع مخصص
  const computedSize = getNumericSize();
  const finalWidth = width || computedSize;
  const finalHeight = height || computedSize;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={finalWidth}
      height={finalHeight}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn("", className)}
      {...props}
    >
      <path d="M14.5 4h-4.5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h.5" />
      <path d="M18 12h-6a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h.5" />
      <path d="M9 18h7" />
      <path d="M9 11h7" />
    </svg>
  );
}

// تصدير المكون كافتراضي للاستخدام المباشر
export default SARSymbol;