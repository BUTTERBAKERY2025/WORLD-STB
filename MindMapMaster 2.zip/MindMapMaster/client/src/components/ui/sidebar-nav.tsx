import * as React from "react";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";

interface SidebarNavProps extends React.HTMLAttributes<HTMLElement> {
  items: {
    href: string;
    title: string;
    titleDisplay?: string;
    icon: string;
    children?: { href: string; title: string; titleDisplay?: string; icon: string }[];
  }[];
  isCollapsed?: boolean;
}

export function SidebarNav({ className, items, isCollapsed = false, ...props }: SidebarNavProps) {
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();
  const [openGroups, setOpenGroups] = React.useState<Record<string, boolean>>({});
  const sidebarRef = React.useRef<HTMLElement>(null);
  
  // معالجة النقر خارج القائمة المنسدلة لإغلاقها في وضع القائمة المطوية
  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (isCollapsed && sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        // إغلاق جميع المجموعات عند النقر خارج القائمة المطوية
        setOpenGroups({});
      }
    }
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isCollapsed]);

  // التحقق من الصفحة النشطة وفتح القائمة الخاصة بها تلقائياً
  React.useEffect(() => {
    // فتح المجموعات التي تحتوي على عنصر نشط
    const initialOpenGroups: Record<string, boolean> = {};
    items.forEach(item => {
      if (item.children?.some(child => {
        // يدعم المقارنة الجزئية للمسارات (للعناصر ذات المعلمات)
        if (child.href.includes('?')) {
          const childBasePath = child.href.split('?')[0];
          return location.startsWith(childBasePath);
        }
        return child.href === location;
      })) {
        initialOpenGroups[item.title] = true;
      }
    });
    setOpenGroups(initialOpenGroups);
  }, [location, items]);

  // تبديل حالة فتح/إغلاق المجموعة
  const toggleGroup = (title: string, event?: React.MouseEvent) => {
    // إيقاف انتشار الحدث لمنع تداخل النقرات
    if (event) {
      event.stopPropagation();
    }
    
    // console.log(`Toggling group: ${title}, current state:`, openGroups[title]);
    
    // إغلاق جميع المجموعات الأخرى عند فتح مجموعة
    if (isCollapsed) {
      setOpenGroups((prev) => {
        const newState: Record<string, boolean> = {};
        
        // حفظ القيم الحالية مع إغلاق كل المجموعات عدا المجموعة الحالية
        Object.keys(prev).forEach(key => {
          if (key === title) {
            newState[key] = !prev[key]; // تبديل حالة المجموعة الحالية فقط
          } else {
            newState[key] = false; // إغلاق جميع المجموعات الأخرى
          }
        });
        
        // في حال لم تكن المجموعة الحالية موجودة في الحالة السابقة
        if (!(title in prev)) {
          newState[title] = true;
        }
        
        return newState;
      });
    } else {
      // السلوك العادي عندما تكون القائمة موسعة
      setOpenGroups((prev) => ({
        ...prev,
        [title]: !prev[title],
      }));
    }
  };

  // تحديد المجموعات التي تشكل فئة رئيسية كالمشاريع أو المالية
  const isMainCategory = (href: string) => {
    return ["/projects", "/financial", "/settings", "/reports"].includes(href) || 
           href.startsWith("#");
  };

  // تحديد إذا كان العنصر يمثل بداية قسم جديد
  const isSectionStart = (index: number) => {
    if (index === 0) return true;
    
    // عندما يكون العنصر الحالي رئيسيًا والعنصر السابق ليس رئيسيًا أو العكس
    const currentIsMain = isMainCategory(items[index].href);
    const prevIsMain = index > 0 ? isMainCategory(items[index - 1].href) : false;
    
    // إذا كان هناك تغيير في نوع العنصر (من رئيسي إلى غير رئيسي أو العكس)
    return (currentIsMain && !prevIsMain) || (!currentIsMain && prevIsMain);
  };

  return (
    <nav ref={sidebarRef} className={cn("space-y-1", className)} {...props}>
      {items.map((item, index) => {
        const isActiveMainItem = item.href === location;
        const hasActiveChild = item.children?.some(child => {
          // دعم المقارنة الجزئية
          if (child.href.includes('?')) {
            const childBasePath = child.href.split('?')[0];
            return location.startsWith(childBasePath);
          }
          return child.href === location;
        });
        const isOpen = openGroups[item.title] || hasActiveChild;
        const showSectionDivider = isSectionStart(index) && index > 0;

        return (
          <div key={item.href} className="sidebar-nav-item">
            {/* فاصل القسم - يظهر بين الأقسام المختلفة فقط */}
            {showSectionDivider && (
              <div className="h-0.5 bg-gray-100 my-2 mx-2 rounded-full"></div>
            )}
            
            <div className={cn(
              "overflow-hidden transition-all duration-200 mb-1",
              // إضافة مسافة علوية إضافية عند بداية قسم جديد
              showSectionDivider ? "mt-3" : ""
            )}>
              {item.children ? (
                <div 
                  data-accordion={item.title.toLowerCase()} 
                  className={cn(
                    "rounded-xl overflow-hidden", 
                    (isActiveMainItem || hasActiveChild) ? "shadow-sm" : ""
                  )}
                >
                  <button
                    onClick={(e) => toggleGroup(item.title, e)}
                    className={cn(
                      "flex items-center w-full rounded-xl transition-all touch-target group relative",
                      !isCollapsed ? "justify-between px-5 py-3.5" : "justify-center p-2 flex-col",
                      "hover:bg-gray-100 focus:outline-none border",
                      (isActiveMainItem || hasActiveChild) 
                        ? "bg-primary/5 text-primary font-medium border-primary/20" 
                        : isMainCategory(item.href) 
                          ? "text-gray-900 font-medium bg-gray-50/80 border-gray-100"  // تمييز الفئات الرئيسية
                          : "text-gray-700 border-transparent"
                    )}
                  >
                    {/* مؤشر النشاط */}
                    {(isActiveMainItem || hasActiveChild) && (
                      <span className={cn(
                        "absolute top-0 right-0 w-1.5 h-1.5 rounded-full mr-2.5 mt-2.5",
                        isOpen ? "bg-primary animate-pulse" : "bg-primary"
                      )}></span>
                    )}
                    
                    <div className="flex items-center">
                      <div className={cn(
                        "flex items-center justify-center rounded-lg transition-all",
                        isCollapsed ? "w-12 h-12" : "w-10 h-10 ml-3",
                        (isActiveMainItem || hasActiveChild) 
                          ? "bg-primary/10 text-primary" 
                          : isMainCategory(item.href) 
                            ? "bg-gray-100 text-gray-700" 
                            : "text-gray-500 group-hover:bg-gray-100"
                      )}>
                        <span className="material-icons text-[22px]">
                          {item.icon}
                        </span>
                      </div>
                      
                      {!isCollapsed && (
                        <span className={cn(
                          "text-base transition-all",
                          (isActiveMainItem || hasActiveChild) 
                            ? "font-medium" 
                            : isMainCategory(item.href)
                              ? "font-semibold"
                              : "font-medium group-hover:text-gray-800"
                        )}>
                          {item.titleDisplay || t(item.title)}
                        </span>
                      )}
                    </div>
                    
                    {!isCollapsed ? (
                      <div className={cn(
                        "flex items-center justify-center w-7 h-7 rounded-md transition-all",
                        (isActiveMainItem || hasActiveChild) 
                          ? "bg-primary/10 text-primary" 
                          : "text-gray-400 group-hover:bg-gray-100"
                      )}>
                        <span className={cn(
                          "material-icons transition-transform duration-300 text-lg",
                          isOpen ? "rotate-180" : "rotate-0"
                        )}>
                          expand_more
                        </span>
                      </div>
                    ) : (
                      <span className={cn(
                        "text-xs font-medium text-center line-clamp-1 mt-1",
                        (isActiveMainItem || hasActiveChild) ? "text-primary" : "text-gray-500"
                      )}>
                        {item.titleDisplay?.split(' ')[0] || t(item.title).split(' ')[0]}
                      </span>
                    )}
                  </button>
                  
                  <div className={cn(
                    "overflow-hidden transition-all duration-300 ease-in-out rounded-b-xl",
                    isOpen 
                      ? isCollapsed 
                        ? "max-h-[500px] opacity-100 py-2 px-1 mt-1 bg-white border border-primary/10 shadow-md scale-y-100 origin-top absolute z-10 right-full top-0 mr-2 rounded-lg w-[200px]" 
                        : "max-h-[500px] opacity-100 py-3 px-1 mt-1 bg-white border border-primary/10 shadow-sm scale-y-100 origin-top" 
                      : "max-h-0 opacity-0 scale-y-95 origin-top"
                  )}>
                    <div className={cn(
                      "space-y-2",
                      !isCollapsed && "pr-4 mx-3 border-r-2 border-primary/20"
                    )}>
                      {item.children.map((child) => {
                        // دعم المقارنة الجزئية لمسارات العناصر الفرعية
                        let isActive = location === child.href;
                        if (child.href.includes('?') && !isActive) {
                          const childBasePath = child.href.split('?')[0];
                          isActive = location.startsWith(childBasePath);
                        }
                        
                        // تحديد العنوان بشكل صحيح، خاصةً للعناصر المحتوية على معلمات استعلام
                        const navigateUrl = child.href;
                        
                        return (
                          <Link
                            key={child.href}
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              if (child.href.includes('?')) {
                                const [path, query] = child.href.split('?');
                                const searchParams = new URLSearchParams(query);
                                
                                // تحديث الموقع مباشرة باستخدام setLocation
                                setLocation(path + '?' + searchParams.toString());
                              } else {
                                // للعناوين العادية بدون معلمات استعلام
                                setLocation(child.href);
                              }
                            }}
                            className={cn(
                              "flex items-center rounded-lg transition-all touch-target group relative",
                              isCollapsed ? "px-3 py-2" : "px-4 py-2.5 mx-2",
                              "hover:bg-primary/5 focus:outline-none",
                              isActive 
                                ? "bg-primary/10 text-primary font-medium" 
                                : "text-gray-600"
                            )}
                          >
                            {/* Active indicator */}
                            {isActive && (
                              <span className={cn(
                                "absolute rounded-full bg-primary",
                                isCollapsed 
                                  ? "right-1 top-1/2 -translate-y-1/2 w-1 h-[40%]" 
                                  : "right-0 top-1/2 -translate-y-1/2 w-1 h-[70%]"
                              )}></span>
                            )}
                            
                            <div className={cn(
                              "flex items-center justify-center rounded-lg transition-all",
                              isCollapsed ? "w-7 h-7 ml-0.5" : "w-8 h-8 ml-2",
                              isActive
                                ? "bg-primary/10 text-primary"
                                : "text-gray-500 group-hover:bg-gray-100/80"
                            )}>
                              <span className="material-icons text-xl">
                                {child.icon}
                              </span>
                            </div>
                            
                            <span className={cn(
                              "transition-all",
                              isCollapsed ? "text-xs ml-1.5" : "text-[14px] ml-2",
                              isActive ? "font-medium" : "group-hover:text-gray-800"
                            )}>
                              {child.titleDisplay || t(child.title)}
                            </span>
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                <Link
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    // التوجيه للمسار المطلوب
                    setLocation(item.href);
                  }}
                  className={cn(
                    "btn-elegant flex items-center rounded-xl transition-all touch-target group relative",
                    isCollapsed ? "p-2 flex-col" : "px-5 py-3.5",
                    "hover:bg-gray-100 focus:outline-none",
                    location === item.href
                      ? "bg-primary/90 text-white font-medium shadow-sm border border-primary/30" 
                      : "text-gray-800 border border-transparent"
                  )}
                >
                  {/* مؤشر النشاط */}
                  {location === item.href && (
                    <span className={cn(
                      "absolute rounded-full bg-white animate-pulse",
                      isCollapsed ? "top-1 right-1 w-1.5 h-1.5" : "top-0 right-0 w-2 h-2 mr-2 mt-2"
                    )}></span>
                  )}
                  
                  <div className={cn(
                    "flex items-center justify-center rounded-lg transition-all",
                    isCollapsed ? "w-12 h-12 mb-1" : "w-10 h-10 ml-3",
                    location === item.href 
                      ? "bg-white/20 text-white shadow-sm" 
                      : "bg-primary/5 text-primary group-hover:bg-primary/10 group-hover:shadow-sm"
                  )}>
                    <span className="material-icons text-[22px]">
                      {item.icon}
                    </span>
                  </div>
                  
                  {!isCollapsed ? (
                    <span className={cn(
                      "text-base font-medium transition-all",
                      isMainCategory(item.href) && location !== item.href && "font-semibold"
                    )}>
                      {item.titleDisplay || t(item.title)}
                    </span>
                  ) : (
                    <span className="text-xs font-medium text-center line-clamp-1">
                      {item.titleDisplay?.split(' ')[0] || t(item.title).split(' ')[0]}
                    </span>
                  )}
                </Link>
              )}
            </div>
          </div>
        );
      })}
    </nav>
  );
}
