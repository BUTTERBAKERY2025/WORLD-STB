import React from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TaskPriorityBadge } from "@/components/ui/task-priority-badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Edit, ChevronRight, ChevronDown, AlertCircle } from "lucide-react";
import { formatDate, formatCurrency } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { taskStatusMap, taskTypeMap } from "@shared/schema";
import type { Task } from "@shared/schema";

interface WbsTaskCardProps {
  task: Task;
  level: number;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
  onEdit?: () => void;
  hasChildren?: boolean;
  showChildren?: boolean;
}

export function WbsTaskCard({
  task,
  level,
  isExpanded = false,
  onToggleExpand,
  onEdit,
  hasChildren = false,
  showChildren = false,
}: WbsTaskCardProps) {
  const { t, i18n } = useTranslation();
  const currentLanguage = i18n.language as "ar" | "en";
  
  // القيم المستخرجة من المهمة
  const {
    id,
    name,
    wbsCode,
    type,
    status,
    progress,
    priority,
    plannedStartDate,
    plannedEndDate,
    plannedCost,
    actualCost,
    isOnCriticalPath,
  } = task;
  
  // حساب الإزاحة بناءً على مستوى WBS
  const indentStyle = {
    marginRight: currentLanguage === "ar" ? 0 : level * 20 + "px",
    marginLeft: currentLanguage === "ar" ? level * 20 + "px" : 0,
  };
  
  return (
    <Card className="mb-2 border-0 shadow-sm hover:shadow bg-card">
      <CardContent className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center flex-1" style={indentStyle}>
            {hasChildren && (
              <button
                onClick={onToggleExpand}
                className="mr-2 p-1 rounded-full hover:bg-muted focus:outline-none"
                aria-label={isExpanded ? t("common.collapse") : t("common.expand")}
              >
                {showChildren ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              </button>
            )}
            
            <div className="flex-1">
              <div className="flex items-center mb-1">
                <span className="text-sm font-semibold ml-1 rtl:ml-0 rtl:mr-1">{wbsCode}</span>
                <h3 className="text-base font-medium">{name}</h3>
                
                {isOnCriticalPath && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="ml-2 rtl:ml-0 rtl:mr-2">
                          <AlertCircle size={16} className="text-red-500" />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{t("task.critical_path")}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>
              
              <div className="flex items-center text-sm text-muted-foreground mb-2">
                <Badge variant="outline" className="mr-2 rtl:mr-0 rtl:ml-2">
                  {taskTypeMap[type as keyof typeof taskTypeMap]?.[currentLanguage] || type}
                </Badge>
                
                <Badge
                  variant="outline"
                  className={`mr-2 rtl:mr-0 rtl:ml-2 ${
                    status === "completed"
                      ? "bg-green-100 text-green-800 border-green-200"
                      : status === "in_progress"
                      ? "bg-blue-100 text-blue-800 border-blue-200"
                      : status === "delayed"
                      ? "bg-red-100 text-red-800 border-red-200"
                      : ""
                  }`}
                >
                  {taskStatusMap[status as keyof typeof taskStatusMap]?.[currentLanguage] || status}
                </Badge>
                
                {priority && <TaskPriorityBadge priority={priority} />}
              </div>
              
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <span className="text-xs text-muted-foreground mr-4 rtl:mr-0 rtl:ml-4">
                    {plannedStartDate && plannedEndDate ? (
                      <>
                        {formatDate(new Date(plannedStartDate))} - {formatDate(new Date(plannedEndDate))}
                      </>
                    ) : (
                      t("common.not_scheduled")
                    )}
                  </span>
                  
                  {task.assignedTo && (
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-xs">
                        {task.assignedTo.toString().substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
                
                {/* التحقق من وجود تكلفة مخططة */}
                {(typeof plannedCost === 'number' && plannedCost > 0) && (
                  <div className="text-xs">
                    <span className="text-muted-foreground">{t("common.budget")}:</span>{" "}
                    <span className={`font-medium ${
                      typeof actualCost === 'number' && typeof plannedCost === 'number' && 
                      actualCost > plannedCost ? "text-red-600" : ""
                    }`}>
                      {formatCurrency(typeof actualCost === 'number' ? actualCost : 0)} / {formatCurrency(typeof plannedCost === 'number' ? plannedCost : 0)}
                    </span>
                  </div>
                )}
              </div>
              
              <div className="flex items-center">
                <div className="flex-1 mr-4 rtl:mr-0 rtl:ml-4">
                  <Progress value={progress} className="h-2" />
                </div>
                <span className="text-xs font-medium">{progress}%</span>
              </div>
            </div>
            
            {onEdit && (
              <button
                onClick={onEdit}
                className="p-1 rounded-full hover:bg-muted focus:outline-none ml-2 rtl:ml-0 rtl:mr-2"
                aria-label={t("common.edit")}
              >
                <Edit size={16} />
              </button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}