import React from "react";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
import { 
  Settings, 
  Play, 
  Clock, 
  CheckCircle, 
  StopCircle, 
  HelpCircle 
} from "lucide-react";

export interface StatusBadgeProps {
  status: string;
  size?: "sm" | "md" | "lg";
}

export function StatusBadge({ status, size = "md" }: StatusBadgeProps) {
  const { t } = useTranslation();
  
  const colors = {
    planning: "bg-blue-100 text-blue-800 border border-blue-200",
    in_progress: "bg-emerald-100 text-emerald-800 border border-emerald-200",
    delayed: "bg-amber-100 text-amber-800 border border-amber-200",
    completed: "bg-violet-100 text-violet-800 border border-violet-200",
    stopped: "bg-red-100 text-red-800 border border-red-200",
  };
  
  const iconSizeClass = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  };
  
  const sizeClasses = {
    sm: "text-xs px-2 py-0.5",
    md: "text-sm px-2.5 py-1",
    lg: "text-base px-3 py-1.5",
  };
  
  const IconComponent = () => {
    switch (status) {
      case 'planning':
        return <Settings className={iconSizeClass[size]} />;
      case 'in_progress':
        return <Play className={iconSizeClass[size]} />;
      case 'delayed':
        return <Clock className={iconSizeClass[size]} />;
      case 'completed':
        return <CheckCircle className={iconSizeClass[size]} />;
      case 'stopped':
        return <StopCircle className={iconSizeClass[size]} />;
      default:
        return <HelpCircle className={iconSizeClass[size]} />;
    }
  };
  
  return (
    <span className={cn(
      "inline-flex items-center rounded-full font-medium",
      colors[status as keyof typeof colors] || "bg-gray-100 text-gray-800 border border-gray-200",
      sizeClasses[size]
    )}>
      <span className="ml-0.5 mr-1">
        <IconComponent />
      </span>
      {t(`status_values.${status}`, t(`project.status.${status}`))}
    </span>
  );
}