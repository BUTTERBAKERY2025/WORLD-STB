import * as React from "react";
import { cn } from "@/lib/utils";

export interface TimelineProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

export function Timeline({ className, children, ...props }: TimelineProps) {
  return (
    <div
      className={cn("relative space-y-0 before:absolute before:inset-0 before:start-5 md:before:start-7 before:h-full before:w-0.5 before:bg-border", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export interface TimelineItemProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

export function TimelineItem({ className, children, ...props }: TimelineItemProps) {
  return (
    <div
      className={cn("relative flex gap-2 pb-10 md:gap-4 last-of-type:pb-0", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export interface TimelineIconProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

export function TimelineIcon({ className, children, ...props }: TimelineIconProps) {
  return (
    <div
      className={cn("relative z-10 flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background md:h-14 md:w-14", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export interface TimelineContentProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

export function TimelineContent({ className, children, ...props }: TimelineContentProps) {
  return (
    <div
      className={cn("flex-1 pt-2 md:pt-4", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export interface TimelineTitleProps extends React.HTMLAttributes<HTMLHeadingElement> {
  children: React.ReactNode;
  className?: string;
}

export function TimelineTitle({ className, children, ...props }: TimelineTitleProps) {
  return (
    <h3
      className={cn("mb-1 font-medium leading-none text-foreground", className)}
      {...props}
    >
      {children}
    </h3>
  );
}

export interface TimelineDescriptionProps extends React.HTMLAttributes<HTMLParagraphElement> {
  children: React.ReactNode;
  className?: string;
}

export function TimelineDescription({ className, children, ...props }: TimelineDescriptionProps) {
  return (
    <p
      className={cn("text-muted-foreground", className)}
      {...props}
    >
      {children}
    </p>
  );
}

export interface TimelineTimeProps extends React.HTMLAttributes<HTMLTimeElement> {
  children: React.ReactNode;
  className?: string;
  dateTime?: string;
}

export function TimelineTime({ className, children, ...props }: TimelineTimeProps) {
  return (
    <time
      className={cn("block text-sm text-muted-foreground md:text-base", className)}
      {...props}
    >
      {children}
    </time>
  );
}