import React from "react";
import { Button } from "@/components/ui/button";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "@/lib/utils";

interface TabletButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  size?: "default" | "sm" | "lg" | "icon";
  asChild?: boolean;
  icon?: React.ReactNode;
  iconPosition?: "left" | "right";
  isLoading?: boolean;
  className?: string;
  children?: React.ReactNode;
}

export function TabletButton({
  className,
  variant = "default",
  size = "default",
  asChild = false,
  icon,
  iconPosition = "right",
  isLoading = false,
  children,
  ...props
}: TabletButtonProps) {
  const Comp = asChild ? Slot : Button;
  
  // تحسين حجم الأزرار على الأجهزة اللوحية
  const sizeClasses = {
    default: "py-3 px-5 text-base min-h-[48px]",
    sm: "py-2 px-4 text-sm min-h-[40px]",
    lg: "py-4 px-6 text-lg min-h-[56px]",
    icon: "p-3 min-h-[48px] min-w-[48px]",
  };
  
  return (
    <Comp
      className={cn(
        "rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        "disabled:pointer-events-none disabled:opacity-50",
        "touch-target",
        sizeClasses[size],
        className
      )}
      variant={variant}
      {...props}
    >
      {isLoading ? (
        <div className="flex items-center justify-center">
          <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin mx-2" />
          {children && <span>{children}</span>}
        </div>
      ) : (
        <div className="flex items-center justify-center gap-2">
          {icon && iconPosition === "left" && <span className="rtl:ml-2 ltr:mr-2">{icon}</span>}
          {children}
          {icon && iconPosition === "right" && <span className="rtl:mr-2 ltr:ml-2">{icon}</span>}
        </div>
      )}
    </Comp>
  );
}

// أزرار الإجراءات المصغرة
export function TabletActionButton({
  className,
  icon,
  label,
  variant = "ghost",
  size = "sm",
  ...props
}: TabletButtonProps & { label?: string }) {
  return (
    <Button
      variant={variant}
      size={size}
      className={cn(
        "rounded-full h-10 w-10 p-0 flex items-center justify-center touch-target",
        label && "w-auto px-3 gap-1",
        className
      )}
      {...props}
    >
      {icon}
      {label && <span className="text-sm">{label}</span>}
    </Button>
  );
}

// أزرار العمليات المستخدمة في الجداول والقوائم
export function TabletOperationButton({
  variant = "ghost",
  size = "icon",
  className,
  iconClassName,
  icon,
  label,
  ...props
}: TabletButtonProps & { iconClassName?: string; label?: string }) {
  return (
    <Button
      variant={variant}
      size={size}
      className={cn(
        "h-9 w-9 rounded-full touch-target",
        "hover:bg-muted focus:ring-1 focus:ring-primary",
        className
      )}
      {...props}
    >
      <span className={cn("material-icons text-xl", iconClassName)}>{icon}</span>
      {label && <span className="sr-only">{label}</span>}
    </Button>
  );
}