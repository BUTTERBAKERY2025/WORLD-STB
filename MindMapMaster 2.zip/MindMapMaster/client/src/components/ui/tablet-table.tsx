import React from "react";
import { cn } from "@/lib/utils";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/components/ui/table";

interface TabletTableProps<T> {
  data: T[];
  columns: {
    accessorKey: any;
    header: string | React.ReactElement;
    cell?: (row: T) => React.ReactNode;
    className?: string;
  }[];
  onRowClick?: (row: T) => void;
  className?: string;
  isLoading?: boolean;
  noDataMessage?: string;
}

export function TabletTable<T>({
  data,
  columns,
  onRowClick,
  className,
  isLoading = false,
  noDataMessage = "لا توجد بيانات متاحة"
}: TabletTableProps<T>) {
  // الحصول على قيمة من الصف باستخدام accessorKey
  const getValue = (row: T, accessorKey: any) => {
    if (typeof accessorKey === "function") {
      return accessorKey(row);
    }
    try {
      return row[accessorKey as keyof T];
    } catch (error) {
      return undefined;
    }
  };

  return (
    <div className="tablet-table-container">
      <Table className={cn("w-full border-collapse", className)}>
        <TableHeader className="bg-muted/50">
          <TableRow className="hover:bg-transparent">
            {columns.map((column, index) => (
              <TableHead
                key={index}
                className={cn(
                  "h-12 py-3 px-4 text-sm font-medium text-muted-foreground",
                  "first:rounded-tr-lg last:rounded-tl-lg whitespace-nowrap",
                  column.className
                )}
              >
                {column.header}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={columns.length} className="h-24 text-center">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                  <div className="text-sm text-muted-foreground">جاري التحميل...</div>
                </div>
              </TableCell>
            </TableRow>
          ) : data.length === 0 ? (
            <TableRow>
              <TableCell colSpan={columns.length} className="h-24 text-center text-muted-foreground">
                {noDataMessage}
              </TableCell>
            </TableRow>
          ) : (
            data.map((row, rowIndex) => (
              <TableRow
                key={rowIndex}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                className={cn(
                  "border-b border-dashed border-border transition-colors",
                  onRowClick && "cursor-pointer hover:bg-accent touch-target"
                )}
              >
                {columns.map((column, colIndex) => (
                  <TableCell
                    key={colIndex}
                    className={cn(
                      "py-4 px-4 text-sm",
                      "first:font-medium",
                      column.className
                    )}
                  >
                    {column.cell
                      ? column.cell(row)
                      : getValue(row, column.accessorKey)}
                  </TableCell>
                ))}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}