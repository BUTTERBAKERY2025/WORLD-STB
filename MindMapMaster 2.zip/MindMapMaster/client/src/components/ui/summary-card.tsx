import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

interface SummaryCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconColor: string;
  changeValue?: number;
  changeText?: string;
  className?: string;
  valueUnit?: string;
}

export function SummaryCard({
  title,
  value,
  icon,
  iconColor,
  changeValue,
  changeText,
  className,
  valueUnit
}: SummaryCardProps) {
  const { t } = useTranslation();
  
  // Determine if change is positive, negative, or neutral
  const isPositive = changeValue && changeValue > 0;
  const isNegative = changeValue && changeValue < 0;
  
  const changeIconName = isPositive 
    ? "trending_up" 
    : isNegative 
      ? "trending_down" 
      : "trending_flat";
  
  const changeColor = isPositive 
    ? "text-green-500" 
    : isNegative 
      ? "text-red-500" 
      : "text-gray-500";
  
  return (
    <div className={cn("bg-white rounded-lg shadow p-6 card-shadow", className)}>
      <div className="flex justify-between">
        <div>
          <p className="text-gray-500 text-sm font-medium">{title.startsWith("dashboard.") ? t(title) : title}</p>
          <h3 className="text-3xl font-bold text-gray-800 mt-1">
            {value}
            {valueUnit && <span className="text-gray-600 text-lg mr-1">{valueUnit}</span>}
          </h3>
        </div>
        <div className={cn(
          "w-12 h-12 rounded-full flex items-center justify-center",
          iconColor === "primary" ? "bg-primary/20" : 
          iconColor === "secondary" ? "bg-blue-500/20" : 
          iconColor === "success" ? "bg-green-500/20" : 
          iconColor === "danger" ? "bg-red-500/20" : 
          "bg-gray-500/20"
        )}>
          <span className={cn(
            "material-icons", 
            iconColor === "primary" ? "text-primary" : 
            iconColor === "secondary" ? "text-blue-500" : 
            iconColor === "success" ? "text-green-500" : 
            iconColor === "danger" ? "text-red-500" : 
            "text-gray-500"
          )}>{icon}</span>
        </div>
      </div>
      
      {(changeValue !== undefined && changeText) && (
        <div className="flex items-center mt-4">
          <span className={cn("material-icons text-sm", changeColor)}>{changeIconName}</span>
          <span className={cn("text-sm mr-1", changeColor)}>
            {isPositive ? "+" : ""}{changeValue}٪
          </span>
          <span className="text-gray-500 text-sm mr-2">{changeText.startsWith("dashboard.") ? t(changeText) : changeText}</span>
        </div>
      )}
    </div>
  );
}
