import React from "react";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
// import { Progress } from "@/components/ui/progress";

export interface ProgressWithTextProps {
  value: number;
  size?: "sm" | "md" | "lg";
  colorByValue?: boolean;
  showText?: boolean;
  className?: string;
}

export function ProgressWithText({ 
  value, 
  size = "md", 
  colorByValue = true,
  showText = true,
  className 
}: ProgressWithTextProps) {
  const { t } = useTranslation();
  
  const getProgressColor = (value: number) => {
    if (!colorByValue) return "bg-primary";
    
    if (value < 25) return "bg-red-500";
    if (value < 50) return "bg-amber-500";
    if (value < 75) return "bg-blue-500";
    return "bg-emerald-500";
  };
  
  const textSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  };
  
  const heightClasses = {
    sm: "h-1.5",
    md: "h-2",
    lg: "h-3",
  };
  
  return (
    <div className={cn("w-full", className)}>
      {showText && (
        <div className="flex justify-between mb-1">
          <span className={cn("text-gray-600", textSizeClasses[size])}>
            {t("common.progress")}
          </span>
          <span className={cn("font-medium", textSizeClasses[size])}>
            {value}%
          </span>
        </div>
      )}
      <div className={cn("w-full overflow-hidden rounded-full bg-gray-200", heightClasses[size])}>
        <div 
          className={`h-full ${getProgressColor(value)}`} 
          style={{ width: `${value}%` }} 
        />
      </div>
    </div>
  );
}