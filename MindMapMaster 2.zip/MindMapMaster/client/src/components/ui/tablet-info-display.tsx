import React from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

interface InfoItemProps {
  label: string;
  value?: React.ReactNode;
  className?: string;
  labelClassName?: string;
  valueClassName?: string;
}

// مكون عرض عنصر معلومات واحد (مسمى وقيمة)
export function InfoItem({ label, value, className, labelClassName, valueClassName }: InfoItemProps) {
  return (
    <div className={cn("flex flex-col space-y-1", className)}>
      <p className={cn("text-sm font-medium text-muted-foreground", labelClassName)}>
        {label}
      </p>
      <p className={cn("text-base font-medium text-foreground", valueClassName)}>
        {value || "-"}
      </p>
    </div>
  );
}

// مجموعة من عناصر المعلومات معروضة بشكل صفوف
export function InfoList({
  items,
  className,
}: {
  items: InfoItemProps[];
  className?: string;
}) {
  return (
    <div className={cn("space-y-5", className)}>
      {items.map((item, index) => (
        <InfoItem key={index} {...item} />
      ))}
    </div>
  );
}

// عرض المعلومات في صفوف متوازية
export function InfoGrid({
  items,
  columns = 2,
  className,
}: {
  items: InfoItemProps[];
  columns?: 1 | 2 | 3;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "grid gap-6",
        columns === 1 && "grid-cols-1",
        columns === 2 && "grid-cols-1 sm:grid-cols-2",
        columns === 3 && "grid-cols-1 sm:grid-cols-2 md:grid-cols-3",
        className
      )}
    >
      {items.map((item, index) => (
        <InfoItem key={index} {...item} />
      ))}
    </div>
  );
}

// عرض المعلومات في قائمة بشكل جدول
export function InfoTable({
  items,
  className,
}: {
  items: InfoItemProps[];
  className?: string;
}) {
  return (
    <div className={cn("space-y-0 divide-y", className)}>
      {items.map((item, index) => (
        <div key={index} className="flex justify-between py-4 gap-4">
          <div className="text-sm font-medium text-muted-foreground w-1/3">
            {item.label}
          </div>
          <div className="text-base font-medium text-right flex-1">
            {item.value || "-"}
          </div>
        </div>
      ))}
    </div>
  );
}

// بطاقة معلومات للأجهزة اللوحية
export function TabletInfoCard({
  title,
  icon,
  children,
  className,
  headerClassName,
  contentClassName,
}: {
  title?: React.ReactNode;
  icon?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  headerClassName?: string;
  contentClassName?: string;
}) {
  return (
    <Card className={cn("tablet-friendly-card", className)}>
      {title && (
        <>
          <CardHeader className={cn("flex flex-row items-center gap-4", headerClassName)}>
            {icon && <div className="text-primary">{icon}</div>}
            <CardTitle className="text-lg font-medium">{title}</CardTitle>
          </CardHeader>
          <Separator />
        </>
      )}
      <CardContent
        className={cn(
          "p-5",
          !title && "pt-5",
          contentClassName
        )}
      >
        {children}
      </CardContent>
    </Card>
  );
}

// قسم معلومات للعرض في الصفحات
export function InfoSection({
  title,
  description,
  children,
  className,
  titleClassName,
  descriptionClassName,
  contentClassName,
}: {
  title?: React.ReactNode;
  description?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  titleClassName?: string;
  descriptionClassName?: string;
  contentClassName?: string;
}) {
  return (
    <div className={cn("space-y-4", className)}>
      {title && (
        <div className="space-y-1">
          <h3 className={cn("text-xl font-semibold", titleClassName)}>
            {title}
          </h3>
          {description && (
            <p
              className={cn(
                "text-sm text-muted-foreground",
                descriptionClassName
              )}
            >
              {description}
            </p>
          )}
        </div>
      )}
      <div className={cn(contentClassName)}>{children}</div>
    </div>
  );
}