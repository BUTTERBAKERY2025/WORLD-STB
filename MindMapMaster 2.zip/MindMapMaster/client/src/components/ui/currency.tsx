import React from 'react';
import { useTranslation } from 'react-i18next';
import { cn } from '@/lib/utils';

export interface CurrencyProps {
  amount?: number;
  value?: number;  // Alternative prop name for amount
  className?: string;
  currency?: string;
  locale?: string;
  showCurrencyCode?: boolean;
  symbolSize?: string; // Add support for symbol size in projects/index.tsx
}

export function Currency({
  amount,
  value,
  className,
  currency = "SAR",
  locale,
  showCurrencyCode = false,
  symbolSize,
}: CurrencyProps) {
  const { i18n } = useTranslation();
  
  // Use value if amount is not provided
  const actualAmount = amount !== undefined ? amount : (value !== undefined ? value : 0);
  
  // Use the provided locale or default to the current i18n language
  const currentLocale = locale || (i18n.language === 'ar' ? 'ar-SA' : 'en-US');
  
  // Format the currency with the appropriate locale and currency
  const formattedAmount = new Intl.NumberFormat(currentLocale, {
    style: 'currency',
    currency,
    currencyDisplay: showCurrencyCode ? 'code' : 'symbol',
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(actualAmount);
  
  const sizeClass = symbolSize === 'sm' ? 'text-sm' : symbolSize === 'lg' ? 'text-lg' : '';
  
  return (
    <span className={cn('font-medium', sizeClass, className)}>
      {formattedAmount}
    </span>
  );
}