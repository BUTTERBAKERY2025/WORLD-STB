import React from "react";
import { useTranslation } from "react-i18next";
import { Badge } from "@/components/ui/badge";
import { taskPriorityMap } from "@shared/schema";
import { cn } from "@/lib/utils";

interface TaskPriorityBadgeProps {
  priority: string;
  className?: string;
}

export function TaskPriorityBadge({ priority, className }: TaskPriorityBadgeProps) {
  const { i18n } = useTranslation();
  const currentLanguage = i18n.language as "ar" | "en";
  
  // إيجاد الأولوية من خريطة الأولويات أو استخدام "medium" كقيمة افتراضية
  const priorityInfo = taskPriorityMap[priority as keyof typeof taskPriorityMap] || taskPriorityMap.medium;
  const label = priorityInfo[currentLanguage];
  const colorClass = priorityInfo.color;
  
  return (
    <Badge 
      variant="outline" 
      className={cn("font-medium px-2 py-1 border-0", colorClass, className)}
    >
      {label}
    </Badge>
  );
}