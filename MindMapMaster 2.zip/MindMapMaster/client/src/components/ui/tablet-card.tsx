import React from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";

interface TabletCardProps {
  className?: string;
  onClick?: () => void;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  icon?: React.ReactNode;
  footer?: React.ReactNode;
  children?: React.ReactNode;
  hover?: boolean;
  headerClassName?: string;
  contentClassName?: string;
  footerClassName?: string;
}

export function TabletCard({
  className,
  onClick,
  title,
  subtitle,
  icon,
  footer,
  children,
  hover = true,
  headerClassName,
  contentClassName,
  footerClassName,
}: TabletCardProps) {
  return (
    <Card
      className={cn(
        "tablet-friendly-card border overflow-hidden",
        hover && "transition-all duration-200 hover:shadow-md",
        onClick && "cursor-pointer hover:border-primary/30",
        className
      )}
      onClick={onClick}
    >
      {(title || subtitle || icon) && (
        <CardHeader className={cn("flex flex-row items-center gap-4 p-5", headerClassName)}>
          {icon && <div className="flex-shrink-0 text-primary">{icon}</div>}
          <div className="flex-grow">
            {title && <h3 className="text-lg font-medium text-foreground">{title}</h3>}
            {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
          </div>
        </CardHeader>
      )}
      <CardContent className={cn("p-5 pt-0", !title && !subtitle && !icon && "pt-5", contentClassName)}>
        <div className="tablet-content touch-spacing">
          {children}
        </div>
      </CardContent>
      {footer && (
        <CardFooter className={cn("border-t p-5 touch-spacing", footerClassName)}>
          {footer}
        </CardFooter>
      )}
    </Card>
  );
}

// نسخة مصغرة من البطاقة للاستخدام في الصفحات ذات العديد من البطاقات
export function TabletCardCompact({
  className,
  onClick,
  title,
  subtitle,
  icon,
  footer,
  children,
  hover = true,
  headerClassName,
  contentClassName,
  footerClassName,
}: TabletCardProps) {
  return (
    <Card
      className={cn(
        "tablet-friendly-card border overflow-hidden",
        hover && "transition-all duration-200 hover:shadow-md",
        onClick && "cursor-pointer hover:border-primary/30",
        className
      )}
      onClick={onClick}
    >
      {(title || subtitle || icon) && (
        <CardHeader className={cn("flex flex-row items-center gap-3 p-4", headerClassName)}>
          {icon && <div className="flex-shrink-0 text-primary">{icon}</div>}
          <div className="flex-grow">
            {title && <h3 className="text-base font-medium text-foreground">{title}</h3>}
            {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
          </div>
        </CardHeader>
      )}
      <CardContent className={cn("p-4 pt-0", !title && !subtitle && !icon && "pt-4", contentClassName)}>
        <div className="tablet-content touch-spacing">
          {children}
        </div>
      </CardContent>
      {footer && (
        <CardFooter className={cn("border-t p-4", footerClassName)}>
          {footer}
        </CardFooter>
      )}
    </Card>
  );
}

// بطاقة معلومات للإحصائيات والأرقام
export function TabletStatCard({
  className,
  onClick,
  title,
  value,
  icon,
  trend,
  trendValue,
  trendLabel,
  color = "primary",
  subtitle,
}: {
  className?: string;
  onClick?: () => void;
  title: React.ReactNode;
  value: React.ReactNode;
  icon?: React.ReactNode;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  trendLabel?: string;
  color?: "primary" | "success" | "warning" | "danger" | "info";
  subtitle?: React.ReactNode; // إضافة خاصية subtitle لعرض محتوى إضافي تحت القيمة الرئيسية
}) {
  const getColorClass = (color: string) => {
    switch (color) {
      case "success":
        return "bg-green-50 text-green-600";
      case "warning":
        return "bg-amber-50 text-amber-600";
      case "danger":
        return "bg-red-50 text-red-600";
      case "info":
        return "bg-blue-50 text-blue-600";
      default:
        return "bg-primary-50 text-primary-600";
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <span className="material-icons text-green-500">trending_up</span>;
      case "down":
        return <span className="material-icons text-red-500">trending_down</span>;
      default:
        return <span className="material-icons text-gray-500">trending_flat</span>;
    }
  };

  const getTrendClass = (trend: string) => {
    switch (trend) {
      case "up":
        return "text-green-600 bg-green-50";
      case "down":
        return "text-red-600 bg-red-50";
      default:
        return "text-gray-600 bg-gray-50";
    }
  };

  return (
    <Card
      className={cn(
        "tablet-friendly-card border overflow-hidden",
        "transition-all duration-200 hover:shadow-md",
        onClick && "cursor-pointer hover:border-primary/30",
        className
      )}
      onClick={onClick}
    >
      <CardContent className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="text-sm font-medium text-muted-foreground">{title}</div>
          {icon && (
            <div className={cn("p-2 rounded-full w-10 h-10 flex items-center justify-center", getColorClass(color))}>
              {icon}
            </div>
          )}
        </div>
        <div className="text-2xl font-bold mb-2">{value}</div>
        {trend && trendValue && (
          <div className="flex items-center gap-2">
            <div className={cn("flex items-center text-xs px-2 py-1 rounded-full", getTrendClass(trend))}>
              {getTrendIcon(trend)}
              <span className="ms-1">{trendValue}</span>
            </div>
            {trendLabel && <span className="text-xs text-muted-foreground">{trendLabel}</span>}
          </div>
        )}
        {subtitle && (
          <div className="mt-2">
            {subtitle}
          </div>
        )}
      </CardContent>
    </Card>
  );
}