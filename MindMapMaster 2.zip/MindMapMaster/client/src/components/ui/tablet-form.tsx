import React from "react";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";

interface TabletFormFieldProps {
  label: string;
  name: string;
  description?: string;
  className?: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
}

// حقل النموذج المحسّن للأجهزة اللوحية
export function TabletFormField({
  label,
  name,
  description,
  className,
  error,
  required,
  children,
}: TabletFormFieldProps) {
  return (
    <div className={cn("space-y-2 mb-5", className)}>
      <div className="flex justify-between">
        <Label
          htmlFor={name}
          className="text-base font-medium text-foreground"
        >
          {label}
          {required && <span className="text-red-500 ms-1">*</span>}
        </Label>
        {error && <p className="text-sm font-medium text-destructive">{error}</p>}
      </div>
      {description && (
        <p className="text-sm text-muted-foreground mb-1">{description}</p>
      )}
      {children}
    </div>
  );
}

// حقل إدخال نصي محسّن للأجهزة اللوحية
export function TabletInput({
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <Input
      className={cn(
        "px-4 py-3 h-12 text-base rounded-lg focus:ring-2 focus:ring-primary focus:ring-offset-0",
        "placeholder:text-muted-foreground/60",
        className
      )}
      {...props}
    />
  );
}

// منطقة نص محسّنة للأجهزة اللوحية
export function TabletTextarea({
  className,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <Textarea
      className={cn(
        "px-4 py-3 min-h-[100px] text-base rounded-lg resize-y focus:ring-2 focus:ring-primary focus:ring-offset-0",
        "placeholder:text-muted-foreground/60",
        className
      )}
      {...props}
    />
  );
}

// قائمة منسدلة محسّنة للأجهزة اللوحية
export function TabletSelect({
  children,
  placeholder,
  ...props
}: {
  children: React.ReactNode;
  placeholder?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  defaultValue?: string;
  disabled?: boolean;
}) {
  return (
    <Select {...props}>
      <SelectTrigger
        className="px-4 py-3 h-12 text-base rounded-lg focus:ring-2 focus:ring-primary focus:ring-offset-0"
      >
        <SelectValue placeholder={placeholder || "اختر..."} />
      </SelectTrigger>
      <SelectContent
        align="start"
        sideOffset={8}
        className="p-1 min-w-[200px]"
      >
        {children}
      </SelectContent>
    </Select>
  );
}

// عنصر قائمة منسدلة محسّن للأجهزة اللوحية
export function TabletSelectItem({
  children,
  className,
  ...props
}: React.ComponentProps<typeof SelectItem>) {
  return (
    <SelectItem
      className={cn(
        "px-3 py-2.5 text-base rounded-md cursor-pointer focus:bg-primary/10",
        className
      )}
      {...props}
    >
      {children}
    </SelectItem>
  );
}

// حقول النموذج المحسنة للأجهزة اللوحية باستخدام react-hook-form
export function TabletFormField_HookForm({
  name,
  control,
  label,
  description,
  className,
  required,
  children,
}: {
  name: string;
  control: any;
  label: string;
  description?: string;
  className?: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <FormField
      control={control}
      name={name}
      render={({ field, fieldState }) => (
        <FormItem className={cn("space-y-2 mb-5", className)}>
          <div className="flex justify-between">
            <FormLabel className="text-base font-medium text-foreground">
              {label}
              {required && <span className="text-red-500 ms-1">*</span>}
            </FormLabel>
            {fieldState.error && (
              <p className="text-sm font-medium text-destructive">
                {fieldState.error.message}
              </p>
            )}
          </div>
          {description && (
            <FormDescription className="text-sm text-muted-foreground mb-1">
              {description}
            </FormDescription>
          )}
          <FormControl>{React.cloneElement(children as React.ReactElement, { ...field })}</FormControl>
          <FormMessage className="text-sm text-destructive" />
        </FormItem>
      )}
    />
  );
}