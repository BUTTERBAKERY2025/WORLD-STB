import { useEffect, useState } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Loader2, ChevronLeft, Home, FileText, BarChart4, Clock, Banknote, AlertTriangle, Camera, Map, FileStack, Settings, Truck } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function ProjectLayout({ children }: { children: React.ReactNode }) {
  const { t } = useTranslation();
  const params = useParams<{ id: string }>();
  const projectId = params.id;
  const [activeTab, setActiveTab] = useState<string | null>(null);
  
  const projectQuery = useQuery({
    queryKey: [`/api/projects/${projectId}`],
    enabled: !!projectId,
  });

  // تحديد التبويب النشط من المسار الحالي
  useEffect(() => {
    const path = window.location.pathname;
    if (path.endsWith('/financial-reports')) {
      setActiveTab('financial-reports');
    } else if (path.endsWith('/tasks')) {
      setActiveTab('tasks');
    } else if (path.endsWith('/schedule')) {
      setActiveTab('schedule');
    } else if (path.endsWith('/expenses')) {
      setActiveTab('expenses');
    } else if (path.endsWith('/certificates')) {
      setActiveTab('certificates');
    } else if (path.endsWith('/risks')) {
      setActiveTab('risks');
    } else if (path.endsWith('/photos')) {
      setActiveTab('photos');
    } else if (path.endsWith('/location')) {
      setActiveTab('location');
    } else if (path.endsWith('/documents')) {
      setActiveTab('documents');
    } else if (path.endsWith('/settings')) {
      setActiveTab('settings');
    } else if (path.endsWith('/resources')) {
      setActiveTab('resources');
    } else {
      setActiveTab('overview');
    }
  }, []);

  if (projectQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (projectQuery.error) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Alert variant="destructive">
          <AlertTitle>{t('error')}</AlertTitle>
          <AlertDescription>
            {t('failedToLoadProject')}
          </AlertDescription>
        </Alert>
        <Button variant="outline" className="mt-4" asChild>
          <Link href="/projects">{t('backToProjects')}</Link>
        </Button>
      </div>
    );
  }

  const project = projectQuery.data;

  return (
    <div className="min-h-screen bg-background">
      {/* رأس الصفحة للمشروع */}
      <div className="bg-primary/5 border-b">
        <div className="container mx-auto py-4 px-4">
          <div className="flex items-center mb-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/projects">
                <ChevronLeft className="h-4 w-4 mr-1" />
                {t('backToProjects')}
              </Link>
            </Button>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">{project?.name}</h1>
              <p className="text-muted-foreground">{project?.description}</p>
              
              <div className="flex flex-wrap gap-2 mt-2">
                <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-sm">
                  {t(`projectType.${project?.type}`)}
                </div>
                <div className={`rounded-full px-3 py-1 text-sm ${
                  project?.status === 'completed' ? 'bg-green-100 text-green-800' : 
                  project?.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                  project?.status === 'delayed' ? 'bg-yellow-100 text-yellow-800' : 
                  project?.status === 'stopped' ? 'bg-red-100 text-red-800' : 
                  'bg-gray-100 text-gray-800'
                }`}>
                  {t(`projectStatus.${project?.status}`)}
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" asChild>
                <Link href={`/projects/${projectId}/edit`}>
                  {t('editProject')}
                </Link>
              </Button>
              
              <Button>
                {t('actions')}
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* تبويبات المشروع */}
      <div className="border-b">
        <div className="container mx-auto">
          <Tabs value={activeTab || 'overview'} className="overflow-x-auto flex-no-wrap">
            <TabsList className="flex">
              <TabsTrigger value="overview" asChild>
                <Link href={`/projects/${projectId}`}>
                  <Home className="h-4 w-4 mr-2" />
                  {t('overview')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="tasks" asChild>
                <Link href={`/projects/${projectId}/tasks`}>
                  <FileText className="h-4 w-4 mr-2" />
                  {t('tasks')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="schedule" asChild>
                <Link href={`/projects/${projectId}/schedule`}>
                  <Clock className="h-4 w-4 mr-2" />
                  {t('schedule')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="financial-reports" asChild>
                <Link href={`/projects/${projectId}/financial-reports`}>
                  <BarChart4 className="h-4 w-4 mr-2" />
                  {t('financialReports')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="expenses" asChild>
                <Link href={`/projects/${projectId}/expenses`}>
                  <Banknote className="h-4 w-4 mr-2" />
                  {t('expenses')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="certificates" asChild>
                <Link href={`/projects/${projectId}/certificates`}>
                  <FileStack className="h-4 w-4 mr-2" />
                  {t('certificates')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="risks" asChild>
                <Link href={`/projects/${projectId}/risks`}>
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  {t('risks')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="resources" asChild>
                <Link href={`/projects/${projectId}/resources`}>
                  <Truck className="h-4 w-4 mr-2" />
                  {t('resources')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="photos" asChild>
                <Link href={`/projects/${projectId}/photos`}>
                  <Camera className="h-4 w-4 mr-2" />
                  {t('photos')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="location" asChild>
                <Link href={`/projects/${projectId}/location`}>
                  <Map className="h-4 w-4 mr-2" />
                  {t('location')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="documents" asChild>
                <Link href={`/projects/${projectId}/documents`}>
                  <FileText className="h-4 w-4 mr-2" />
                  {t('documents')}
                </Link>
              </TabsTrigger>
              
              <TabsTrigger value="settings" asChild>
                <Link href={`/projects/${projectId}/settings`}>
                  <Settings className="h-4 w-4 mr-2" />
                  {t('settings')}
                </Link>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>
      
      {/* محتوى المشروع */}
      <div className="container mx-auto py-6 px-4">
        {children}
      </div>
    </div>
  );
}