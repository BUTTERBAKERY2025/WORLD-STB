import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { LucideIcon } from "lucide-react";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";

interface NavItem {
  title: string;
  href: string;
  icon?: LucideIcon;
  isActive?: boolean;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

interface PageLayoutProps {
  children: React.ReactNode;
  title?: string;
  sections?: NavSection[];
  isLoading?: boolean;
}

export default function PageLayout({
  children,
  title,
  sections = [],
  isLoading = false,
}: PageLayoutProps) {
  const [location] = useLocation();
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(true);
  const [activeNavItem, setActiveNavItem] = useState<string | null>(null);

  useEffect(() => {
    // Find active navItem based on current location
    let isNavItemFound = false;
    
    for (const section of sections) {
      for (const item of section.items) {
        if (location === item.href || location.startsWith(`${item.href}/`)) {
          setActiveNavItem(item.href);
          isNavItemFound = true;
          break;
        }
      }
      if (isNavItemFound) break;
    }
    
    if (!isNavItemFound) {
      setActiveNavItem(null);
    }
  }, [location, sections]);

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-accent-foreground lg:hidden"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6"
              >
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
              <span className="sr-only">Toggle Menu</span>
            </button>
            <Link href="/" className="font-semibold">
              نظام إدارة المشاريع
            </Link>
          </div>
          <nav className="hidden gap-6 lg:flex">
            <Link
              href="/"
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                location === "/"
                  ? "text-foreground"
                  : "text-muted-foreground"
              )}
            >
              {t("nav.home")}
            </Link>
            <Link
              href="/projects"
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                location.startsWith("/projects")
                  ? "text-foreground"
                  : "text-muted-foreground"
              )}
            >
              {t("nav.projects")}
            </Link>
            <Link
              href="/financial"
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                location.startsWith("/financial")
                  ? "text-foreground"
                  : "text-muted-foreground"
              )}
            >
              {t("nav.financial")}
            </Link>
            <Link
              href="/reports"
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                location.startsWith("/reports")
                  ? "text-foreground"
                  : "text-muted-foreground"
              )}
            >
              {t("nav.reports")}
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div>
              <Link
                href="/settings"
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location.startsWith("/settings")
                    ? "text-foreground"
                    : "text-muted-foreground"
                )}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </header>
      <div className="container flex-1 items-start md:grid md:grid-cols-[220px_minmax(0,1fr)] md:gap-6 lg:grid-cols-[240px_minmax(0,1fr)] lg:gap-10">
        <aside
          className={cn(
            "fixed top-14 z-30 -mr-2 w-full shrink-0 border-r bg-background md:sticky md:block",
            isOpen ? "block" : "hidden"
          )}
        >
          <div className="h-full py-6 pr-6 md:py-8">
            {sections.map((section) => (
              <div key={section.title} className="mb-6">
                <h3 className="text-lg font-semibold">{section.title}</h3>
                <nav className="mt-3 grid gap-2">
                  {section.items.map((item, index) => (
                    <Link
                      key={index}
                      href={item.href}
                      className={cn(
                        "w-full text-right flex items-center gap-2 p-2 text-muted-foreground text-sm rounded-md",
                        activeNavItem === item.href
                          ? "bg-accent text-accent-foreground font-medium"
                          : "hover:bg-accent/50"
                      )}
                    >
                      {item.icon && (
                        <item.icon className="h-4 w-4 ml-2" />
                      )}
                      {item.title}
                    </Link>
                  ))}
                </nav>
              </div>
            ))}
          </div>
        </aside>
        <main className="flex flex-col flex-1 w-full overflow-hidden py-8">
          {title && <h1 className="text-2xl font-bold mb-6">{title}</h1>}
          {isLoading ? (
            <div className="h-[500px] flex flex-col gap-6 items-center justify-center">
              <div className="w-14 h-14 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
              <p className="text-muted-foreground text-lg">{t("loading")}</p>
            </div>
          ) : (
            children
          )}
        </main>
      </div>
    </div>
  );
}