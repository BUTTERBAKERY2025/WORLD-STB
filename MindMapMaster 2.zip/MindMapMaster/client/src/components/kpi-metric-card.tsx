import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowUpIcon, ArrowDownIcon, MinusIcon } from "lucide-react";
import { cva } from "class-variance-authority";
import { cn, formatNumber } from "@/lib/utils";

// تعريف متغيرات الشكل للمؤشر
const metricVariants = cva("text-2xl font-bold", {
  variants: {
    trend: {
      positive: "text-green-600",
      negative: "text-red-600",
      neutral: "text-gray-700",
    },
    size: {
      sm: "text-lg",
      md: "text-2xl",
      lg: "text-3xl",
    },
  },
  defaultVariants: {
    trend: "neutral",
    size: "md",
  },
});

// تعريف متغيرات شكل أيقونة الاتجاه
const trendIconVariants = cva("ml-1 rtl:ml-0 rtl:mr-1", {
  variants: {
    trend: {
      positive: "text-green-600",
      negative: "text-red-600",
      neutral: "text-gray-500",
    },
    size: {
      sm: "h-3 w-3",
      md: "h-4 w-4",
      lg: "h-5 w-5",
    },
  },
  defaultVariants: {
    trend: "neutral",
    size: "md",
  },
});

interface KpiMetricCardProps {
  title: string;
  value: number;
  target?: number;
  trend?: number;
  unit?: string;
  precision?: number;
  prefix?: string;
  suffix?: string;
  trendLabel?: string;
  className?: string;
  valueSize?: "sm" | "md" | "lg";
  reverseColors?: boolean; // عكس الألوان (مثلا بعض المؤشرات تعتبر الرقم المنخفض إيجابي)
  customTrendThreshold?: number; // عتبة مخصصة للقيم الإيجابية والسلبية
  trendIsPercentage?: boolean; // إذا كان الاتجاه نسبة مئوية
  icon?: React.ReactNode;
}

export function KpiMetricCard({
  title,
  value,
  target,
  trend = 0,
  unit = "",
  precision = 2,
  prefix = "",
  suffix = "",
  trendLabel,
  className,
  valueSize = "md",
  reverseColors = false,
  customTrendThreshold = 0,
  trendIsPercentage = false,
  icon,
}: KpiMetricCardProps) {
  // تحديد اتجاه القيمة (إيجابي، سلبي، محايد)
  let trendType: "positive" | "negative" | "neutral" = "neutral";
  
  if (trend !== 0) {
    if (reverseColors) {
      trendType = trend < customTrendThreshold ? "positive" : trend > customTrendThreshold ? "negative" : "neutral";
    } else {
      trendType = trend > customTrendThreshold ? "positive" : trend < customTrendThreshold ? "negative" : "neutral";
    }
  }
  
  // إعداد أيقونة الاتجاه
  const TrendIcon = trendType === "positive" ? ArrowUpIcon : trendType === "negative" ? ArrowDownIcon : MinusIcon;
  
  // تنسيق القيمة الرقمية
  const formattedValue = `${prefix}${formatNumber(value, precision)}${unit}${suffix}`;
  
  // تنسيق قيمة الاتجاه
  const formattedTrend = trendIsPercentage
    ? `${trend > 0 ? "+" : ""}${formatNumber(trend, 1)}%`
    : `${trend > 0 ? "+" : ""}${formatNumber(trend, precision)}${unit}`;
  
  // تنسيق القيمة المستهدفة
  const formattedTarget = target !== undefined ? `${prefix}${formatNumber(target, precision)}${unit}${suffix}` : null;
  
  return (
    <Card className={cn("overflow-hidden transition-all hover:shadow-md", className)}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <div className="flex items-baseline">
              <p className={cn(metricVariants({ trend: trendType, size: valueSize }))}>
                {formattedValue}
              </p>
              
              {trend !== 0 && (
                <div className="flex items-center ml-2 rtl:ml-0 rtl:mr-2">
                  <TrendIcon className={cn(trendIconVariants({ trend: trendType, size: valueSize }))} />
                  <span className={cn("text-xs font-medium", 
                    trendType === "positive" ? "text-green-600" : 
                    trendType === "negative" ? "text-red-600" : 
                    "text-gray-500"
                  )}>
                    {formattedTrend}
                  </span>
                </div>
              )}
            </div>
            
            {formattedTarget && (
              <p className="text-xs text-muted-foreground">
                {trendLabel || "الهدف"}: {formattedTarget}
              </p>
            )}
          </div>
          
          {icon && (
            <div className="p-2 rounded-full bg-primary/10">
              {icon}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}