import React, { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { WbsTaskCard } from "@/components/ui/wbs-task-card";
import { Button } from "@/components/ui/button";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Task } from "@shared/schema";

// تعريف الهيكل الشجري للمهام
interface TreeNode {
  task: Task;
  children: TreeNode[];
  level: number;
}

interface WbsStructureProps {
  tasks: Task[];
  onAddTask?: (parentId?: number) => void;
  onEditTask?: (taskId: number) => void;
}

export function WbsStructure({ tasks, onAddTask, onEditTask }: WbsStructureProps) {
  const { t } = useTranslation();
  const [search, setSearch] = useState("");
  const [expandedNodes, setExpandedNodes] = useState<Record<number, boolean>>({});
  
  // بناء هيكل شجري للمهام
  const taskTree = useMemo(() => {
    // إنشاء قاموس للمهام
    const taskMap = new Map<number, Task>();
    tasks.forEach((task) => {
      taskMap.set(task.id, task);
    });
    
    // بناء الهيكل الشجري
    const rootNodes: TreeNode[] = [];
    const nodeMap = new Map<number, TreeNode>();
    
    // أولا، إنشاء كل العقد
    tasks.forEach((task) => {
      const node: TreeNode = {
        task,
        children: [],
        level: task.level || 1,
      };
      nodeMap.set(task.id, node);
    });
    
    // ثانيا، ربط العقد مع بعضها
    tasks.forEach((task) => {
      const node = nodeMap.get(task.id);
      if (task.parentId && nodeMap.has(task.parentId)) {
        // إضافة المهمة كطفل للمهمة الأب
        const parentNode = nodeMap.get(task.parentId)!;
        parentNode.children.push(node!);
      } else {
        // لا يوجد أب - إضافتها كعقدة جذر
        rootNodes.push(node!);
      }
    });
    
    // ترتيب العقد على جميع المستويات
    rootNodes.sort((a, b) => (a.task.orderIndex || 0) - (b.task.orderIndex || 0));
    nodeMap.forEach((node) => {
      node.children.sort((a, b) => (a.task.orderIndex || 0) - (b.task.orderIndex || 0));
    });
    
    return rootNodes;
  }, [tasks]);
  
  // تصفية المهام بناءً على البحث
  const filteredTaskTree = useMemo(() => {
    if (!search.trim()) return taskTree;
    
    // تحقق مما إذا كانت المهمة أو أي من أطفالها تطابق البحث
    const containsMatch = (node: TreeNode): boolean => {
      const taskMatches = node.task.name.toLowerCase().includes(search.toLowerCase()) ||
                         (node.task.wbsCode?.toLowerCase().includes(search.toLowerCase())) ||
                         (node.task.description?.toLowerCase().includes(search.toLowerCase()));
      
      if (taskMatches) return true;
      
      // البحث في الأطفال
      return node.children.some(child => containsMatch(child));
    };
    
    return taskTree.filter(node => containsMatch(node));
  }, [taskTree, search]);
  
  // تبديل توسيع العقدة
  const toggleExpand = (taskId: number) => {
    setExpandedNodes(prev => ({
      ...prev,
      [taskId]: !prev[taskId]
    }));
  };
  
  // وظيفة تقديم العقد الشجرية بشكل متكرر
  const renderTaskNodes = (nodes: TreeNode[]) => {
    return nodes.map((node) => {
      const { task, children, level } = node;
      const isExpanded = expandedNodes[task.id] || false;
      
      return (
        <React.Fragment key={task.id}>
          <WbsTaskCard
            task={task}
            level={level}
            hasChildren={children.length > 0}
            isExpanded={isExpanded}
            showChildren={isExpanded}
            onToggleExpand={() => toggleExpand(task.id)}
            onEdit={() => onEditTask?.(task.id)}
          />
          
          {isExpanded && children.length > 0 && (
            <div className="ml-4 rtl:ml-0 rtl:mr-4">{renderTaskNodes(children)}</div>
          )}
        </React.Fragment>
      );
    });
  };
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 rtl:left-auto rtl:right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t("task.search_tasks")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 rtl:pl-4 rtl:pr-8"
          />
        </div>
        
        {onAddTask && (
          <Button onClick={() => onAddTask()} size="sm">
            <Plus className="h-4 w-4 mr-1 rtl:mr-0 rtl:ml-1" />
            {t("task.add_task")}
          </Button>
        )}
      </div>
      
      <ScrollArea className="h-[500px]">
        {filteredTaskTree.length > 0 ? (
          renderTaskNodes(filteredTaskTree)
        ) : (
          <div className="flex flex-col items-center justify-center py-10">
            <p className="text-muted-foreground text-center">
              {search
                ? t("task.no_search_results")
                : t("task.no_tasks_description")}
            </p>
            {!search && onAddTask && (
              <Button onClick={() => onAddTask()} className="mt-4" variant="outline">
                <Plus className="h-4 w-4 mr-1 rtl:mr-0 rtl:ml-1" />
                {t("task.add_first_task")}
              </Button>
            )}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}