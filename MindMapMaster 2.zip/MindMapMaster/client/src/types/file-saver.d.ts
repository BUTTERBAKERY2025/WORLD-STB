declare module 'file-saver' {
  export function saveAs(data: Blob | File, filename?: string, options?: {
    type?: string;
    endings?: 'native' | 'transparent';
  }): void;
}