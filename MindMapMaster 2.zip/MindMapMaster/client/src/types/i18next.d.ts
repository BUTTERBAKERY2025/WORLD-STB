import 'i18next';
import { TFunction } from 'i18next';

declare module 'i18next' {
  // Override the TypeScript definitions for i18next to make it accept any key
  interface TFunction {
    (key: string, options?: any): string;
    (key: string[], options?: any): string;
    (key: string, defaultValue: string, options?: any): string;
  }
}