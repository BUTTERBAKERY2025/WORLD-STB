import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatDate } from "@/lib/utils";
import { Document } from "@shared/schema";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

// Sample documents data
const documentsData: Document[] = [
  {
    id: 1,
    name: "عقد تنفيذ مشروع الطريق الدائري",
    type: "contract",
    projectId: 1,
    path: "/documents/contract_road_project.pdf",
    uploadedBy: 1,
    uploadedAt: new Date("2023-05-10"),
    description: "العقد الرسمي لتنفيذ مشروع تطوير الطريق الدائري الشمالي"
  },
  {
    id: 2,
    name: "تصريح الحفر",
    type: "permit",
    projectId: 1,
    path: "/documents/digging_permit.pdf",
    uploadedBy: 1,
    uploadedAt: new Date("2023-05-15"),
    description: "تصريح الحفر الصادر من البلدية لمشروع تطوير الطريق الدائري الشمالي"
  },
  {
    id: 3,
    name: "تقرير الفحص الأولي للموقع",
    type: "report",
    projectId: 1,
    path: "/documents/initial_site_inspection.pdf",
    uploadedBy: 1,
    uploadedAt: new Date("2023-05-20"),
    description: "تقرير الفحص الأولي لموقع مشروع تطوير الطريق الدائري الشمالي"
  },
  {
    id: 4,
    name: "فاتورة توريد المواد",
    type: "invoice",
    projectId: 1,
    path: "/documents/materials_invoice.pdf",
    uploadedBy: 1,
    uploadedAt: new Date("2023-06-05"),
    description: "فاتورة توريد المواد الخاصة بمشروع تطوير الطريق الدائري الشمالي"
  },
  {
    id: 5,
    name: "عقد تنفيذ مشروع شبكة المياه",
    type: "contract",
    projectId: 2,
    path: "/documents/contract_water_project.pdf",
    uploadedBy: 1,
    uploadedAt: new Date("2023-03-05"),
    description: "العقد الرسمي لتنفيذ مشروع شبكة مياه الحي الشرقي"
  },
  {
    id: 6,
    name: "مخططات شبكة المياه",
    type: "other",
    projectId: 2,
    path: "/documents/water_network_plans.pdf",
    uploadedBy: 1,
    uploadedAt: new Date("2023-03-15"),
    description: "المخططات التفصيلية لشبكة مياه الحي الشرقي"
  }
];

// Get document type display text
const getDocumentTypeText = (type: string): string => {
  switch (type) {
    case 'contract': return "عقد";
    case 'permit': return "تصريح";
    case 'report': return "تقرير";
    case 'invoice': return "فاتورة";
    default: return "أخرى";
  }
};

// Get document type icon
const getDocumentTypeIcon = (type: string): string => {
  switch (type) {
    case 'contract': return "description";
    case 'permit': return "gavel";
    case 'report': return "assessment";
    case 'invoice': return "receipt";
    default: return "insert_drive_file";
  }
};

// Get document type color
const getDocumentTypeColor = (type: string): { bg: string, text: string } => {
  switch (type) {
    case 'contract': return { bg: "bg-blue-100", text: "text-blue-700" };
    case 'permit': return { bg: "bg-purple-100", text: "text-purple-700" };
    case 'report': return { bg: "bg-green-100", text: "text-green-700" };
    case 'invoice': return { bg: "bg-orange-100", text: "text-orange-700" };
    default: return { bg: "bg-gray-100", text: "text-gray-700" };
  }
};

export default function Documents() {
  const { t } = useTranslation();
  const [documentTypeFilter, setDocumentTypeFilter] = useState<string>("all");
  const [projectFilter, setProjectFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [viewMode, setViewMode] = useState<string>("table");
  const [uploadDialogOpen, setUploadDialogOpen] = useState<boolean>(false);
  
  // Fetch documents from API (disabled for MVP)
  const { data: documents } = useQuery<Document[]>({
    queryKey: ['/api/documents'],
    enabled: false // Disabled for MVP
  });
  
  // Filter documents based on selected filters and search query
  const filteredDocuments = documentsData.filter(document => {
    const matchesType = documentTypeFilter === "all" || document.type === documentTypeFilter;
    const matchesProject = projectFilter === "all" || 
      (projectFilter === "none" ? document.projectId === null : 
        document.projectId === parseInt(projectFilter));
    const matchesSearch = searchQuery === "" || 
      document.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      document.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesType && matchesProject && matchesSearch;
  });
  
  // Handle document upload (placeholder function)
  const handleDocumentUpload = () => {
    alert("سيتم رفع المستند");
    setUploadDialogOpen(false);
  };
  
  // Handle document download (placeholder function)
  const handleDocumentDownload = (documentId: number) => {
    alert(`سيتم تنزيل المستند رقم ${documentId}`);
  };
  
  return (
    <div className="container mx-auto">
      {/* Documents Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{t("document.title")}</h1>
          <p className="text-gray-600">إدارة وتنظيم مستندات المشاريع</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-reverse space-x-2">
          <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center">
                <span className="material-icons ml-1 text-sm">upload_file</span>
                <span>{t("document.upload")}</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>رفع مستند جديد</DialogTitle>
                <DialogDescription>
                  قم بإدخال معلومات المستند وتحديد الملف المراد رفعه.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="document-name" className="text-right col-span-1">
                    اسم المستند
                  </Label>
                  <Input
                    id="document-name"
                    className="col-span-3"
                    placeholder="أدخل اسم المستند"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="document-type" className="text-right col-span-1">
                    نوع المستند
                  </Label>
                  <Select>
                    <SelectTrigger id="document-type" className="col-span-3">
                      <SelectValue placeholder="اختر نوع المستند" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="contract">عقد</SelectItem>
                      <SelectItem value="permit">تصريح</SelectItem>
                      <SelectItem value="report">تقرير</SelectItem>
                      <SelectItem value="invoice">فاتورة</SelectItem>
                      <SelectItem value="other">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="document-project" className="text-right col-span-1">
                    المشروع
                  </Label>
                  <Select>
                    <SelectTrigger id="document-project" className="col-span-3">
                      <SelectValue placeholder="اختر المشروع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">تطوير الطريق الدائري الشمالي</SelectItem>
                      <SelectItem value="2">شبكة مياه الحي الشرقي</SelectItem>
                      <SelectItem value="3">تحديث شبكة الكهرباء</SelectItem>
                      <SelectItem value="4">برج الاتصالات المركزي</SelectItem>
                      <SelectItem value="none">غير مرتبط بمشروع</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="document-description" className="text-right col-span-1 pt-2">
                    الوصف
                  </Label>
                  <Textarea
                    id="document-description"
                    className="col-span-3"
                    placeholder="أدخل وصف المستند"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="document-file" className="text-right col-span-1">
                    الملف
                  </Label>
                  <Input
                    id="document-file"
                    type="file"
                    className="col-span-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setUploadDialogOpen(false)}>
                  إلغاء
                </Button>
                <Button onClick={handleDocumentUpload}>
                  رفع المستند
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Filter Controls */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <Select 
                defaultValue={documentTypeFilter} 
                onValueChange={setDocumentTypeFilter}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder={t("document.type")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                  <SelectItem value="contract">{t("document.types.contract")}</SelectItem>
                  <SelectItem value="permit">{t("document.types.permit")}</SelectItem>
                  <SelectItem value="report">{t("document.types.report")}</SelectItem>
                  <SelectItem value="invoice">{t("document.types.invoice")}</SelectItem>
                  <SelectItem value="other">{t("document.types.other")}</SelectItem>
                </SelectContent>
              </Select>
              
              <Select 
                defaultValue={projectFilter} 
                onValueChange={setProjectFilter}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder={t("project.name")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                  <SelectItem value="1">تطوير الطريق الدائري الشمالي</SelectItem>
                  <SelectItem value="2">شبكة مياه الحي الشرقي</SelectItem>
                  <SelectItem value="3">تحديث شبكة الكهرباء</SelectItem>
                  <SelectItem value="4">برج الاتصالات المركزي</SelectItem>
                  <SelectItem value="none">غير مرتبط بمشروع</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="relative flex-1 max-w-sm">
                <Input
                  type="text"
                  placeholder={t("search.placeholder")}
                  className="w-full pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <span className="material-icons absolute top-2 right-3 text-gray-400">
                  search
                </span>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button 
                variant={viewMode === "grid" ? "default" : "outline"} 
                size="icon" 
                onClick={() => setViewMode("grid")}
              >
                <span className="material-icons">grid_view</span>
              </Button>
              <Button 
                variant={viewMode === "table" ? "default" : "outline"} 
                size="icon" 
                onClick={() => setViewMode("table")}
              >
                <span className="material-icons">view_list</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Documents List */}
      {viewMode === "table" ? (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>{t("document.title")}</CardTitle>
            <CardDescription>
              {filteredDocuments.length} {t("document.title")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                      {t("document.name")}
                    </th>
                    <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                      {t("document.type")}
                    </th>
                    <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                      {t("project.name")}
                    </th>
                    <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                      {t("document.upload_date")}
                    </th>
                    <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                      {t("document.uploaded_by")}
                    </th>
                    <th className="py-3 px-4 text-center text-sm font-medium text-gray-500">
                      {t("common.actions")}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredDocuments.map((document) => (
                    <tr key={document.id} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div className="flex items-center">
                          <span className="material-icons ml-2 text-primary">
                            {getDocumentTypeIcon(document.type)}
                          </span>
                          <div>
                            <p className="font-medium text-gray-800">{document.name}</p>
                            <p className="text-xs text-gray-500 max-w-[300px] truncate">{document.description}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs ${getDocumentTypeColor(document.type).bg} ${getDocumentTypeColor(document.type).text}`}>
                          {getDocumentTypeText(document.type)}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {document.projectId ? (
                          <Link href={`/projects/${document.projectId}`}>
                            <p className="text-primary hover:underline">
                              {document.projectId === 1 ? "تطوير الطريق الدائري الشمالي" : 
                               document.projectId === 2 ? "شبكة مياه الحي الشرقي" :
                               document.projectId === 3 ? "تحديث شبكة الكهرباء" :
                               document.projectId === 4 ? "برج الاتصالات المركزي" : 
                               "مشروع غير معروف"}
                            </p>
                          </Link>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <p className="text-gray-600">
                          {formatDate(document.uploadedAt)}
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center">
                          <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-white ml-2">
                            <span className="text-xs">م.أ</span>
                          </div>
                          <span className="text-gray-600">م. أحمد الخالدي</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <span className="material-icons">more_vert</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleDocumentDownload(document.id)}>
                              <span className="material-icons text-sm ml-2">download</span>
                              {t("document.download")}
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <span className="material-icons text-sm ml-2">visibility</span>
                              {t("common.view")}
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <span className="material-icons text-sm ml-2">edit</span>
                              {t("common.edit")}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-danger">
                              <span className="material-icons text-sm ml-2">delete</span>
                              {t("common.delete")}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDocuments.map((document) => (
            <Card key={document.id} className="card-shadow overflow-hidden">
              <div className={`h-2 ${getDocumentTypeColor(document.type).bg}`}></div>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-start">
                    <div className={`w-10 h-10 flex-shrink-0 rounded-md ${getDocumentTypeColor(document.type).bg} flex items-center justify-center ${getDocumentTypeColor(document.type).text} ml-3`}>
                      <span className="material-icons">{getDocumentTypeIcon(document.type)}</span>
                    </div>
                    <div>
                      <CardTitle className="text-lg font-bold hover:text-primary">
                        {document.name}
                      </CardTitle>
                      <CardDescription>
                        {formatDate(document.uploadedAt)}
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-gray-600 mb-4">{document.description}</div>
                
                <div className="flex justify-between items-center mb-4">
                  <span className={`px-2 py-1 rounded-full text-xs ${getDocumentTypeColor(document.type).bg} ${getDocumentTypeColor(document.type).text}`}>
                    {getDocumentTypeText(document.type)}
                  </span>
                  {document.projectId && (
                    <Link href={`/projects/${document.projectId}`}>
                      <span className="text-primary text-sm hover:underline">
                        {document.projectId === 1 ? "تطوير الطريق الدائري الشمالي" : 
                         document.projectId === 2 ? "شبكة مياه الحي الشرقي" :
                         document.projectId === 3 ? "تحديث شبكة الكهرباء" :
                         document.projectId === 4 ? "برج الاتصالات المركزي" : 
                         "مشروع غير معروف"}
                      </span>
                    </Link>
                  )}
                </div>
                
                <div className="flex justify-between">
                  <div className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white ml-2">
                      <span className="text-xs">م.أ</span>
                    </div>
                    <span className="text-gray-600 text-sm">م. أحمد الخالدي</span>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => handleDocumentDownload(document.id)}>
                    <span className="material-icons text-sm ml-1">download</span>
                    {t("document.download")}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {filteredDocuments.length === 0 && (
        <Card className="mt-6">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <span className="material-icons text-4xl text-gray-400 mb-4">description</span>
            <h3 className="text-xl font-medium text-gray-700 mb-2">لا توجد مستندات</h3>
            <p className="text-gray-500 mb-6">لم يتم العثور على أي مستندات تطابق معايير البحث</p>
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <span className="material-icons text-sm ml-2">upload_file</span>
                  {t("document.upload")}
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>رفع مستند جديد</DialogTitle>
                  <DialogDescription>
                    قم بإدخال معلومات المستند وتحديد الملف المراد رفعه.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="document-name-empty" className="text-right col-span-1">
                      اسم المستند
                    </Label>
                    <Input
                      id="document-name-empty"
                      className="col-span-3"
                      placeholder="أدخل اسم المستند"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="document-type-empty" className="text-right col-span-1">
                      نوع المستند
                    </Label>
                    <Select>
                      <SelectTrigger id="document-type-empty" className="col-span-3">
                        <SelectValue placeholder="اختر نوع المستند" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contract">عقد</SelectItem>
                        <SelectItem value="permit">تصريح</SelectItem>
                        <SelectItem value="report">تقرير</SelectItem>
                        <SelectItem value="invoice">فاتورة</SelectItem>
                        <SelectItem value="other">أخرى</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="document-file-empty" className="text-right col-span-1">
                      الملف
                    </Label>
                    <Input
                      id="document-file-empty"
                      type="file"
                      className="col-span-3"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline">
                    إلغاء
                  </Button>
                  <Button onClick={handleDocumentUpload}>
                    رفع المستند
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
