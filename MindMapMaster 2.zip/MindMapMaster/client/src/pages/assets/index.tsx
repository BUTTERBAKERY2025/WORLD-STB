import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useEffect, useState as useStateEffect } from "react";
import L from "leaflet";
import { Asset, Resource } from "@shared/schema";

// Sample assets data
const assetsData: Asset[] = [
  {
    id: 1,
    name: "حفارة كبيرة",
    type: "equipment",
    description: "حفارة هيدروليكية كبيرة لأعمال الحفر",
    purchaseDate: new Date("2022-01-15"),
    purchaseValue: 450000,
    status: "in_use",
    currentLocation: { type: "Point", coordinates: [46.738586, 24.774265] },
    assignedToProject: 1,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 2,
    name: "شاحنة نقل",
    type: "vehicle",
    description: "شاحنة لنقل المواد والمعدات",
    purchaseDate: new Date("2022-03-10"),
    purchaseValue: 350000,
    status: "available",
    currentLocation: { type: "Point", coordinates: [46.716667, 24.633333] },
    assignedToProject: null,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 3,
    name: "جهاز قياس مستوى",
    type: "tool",
    description: "جهاز لقياس مستوى الأسطح بدقة عالية",
    purchaseDate: new Date("2022-06-22"),
    purchaseValue: 75000,
    status: "maintenance",
    currentLocation: { type: "Point", coordinates: [46.675296, 24.713552] },
    assignedToProject: null,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 4,
    name: "رافعة متوسطة",
    type: "equipment",
    description: "رافعة متوسطة الحجم لرفع مواد البناء",
    purchaseDate: new Date("2022-04-18"),
    purchaseValue: 280000,
    status: "in_use",
    currentLocation: { type: "Point", coordinates: [50.103782, 26.434517] },
    assignedToProject: 2,
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

// Sample resources data
const resourcesData: Resource[] = [
  {
    id: 1,
    name: "فريق عمل هندسي",
    type: "human",
    description: "فريق من المهندسين للإشراف على المشروع",
    quantity: 5,
    unit: "شخص",
    cost: 25000,
    assignedToProject: 1,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 2,
    name: "أسمنت",
    type: "material",
    description: "أسمنت بورتلاند مقاوم للأملاح",
    quantity: 200,
    unit: "طن",
    cost: 450,
    assignedToProject: 1,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 3,
    name: "فريق عمل فني",
    type: "human",
    description: "فريق من الفنيين لتنفيذ الأعمال",
    quantity: 10,
    unit: "شخص",
    cost: 15000,
    assignedToProject: 2,
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

export default function Assets() {
  const { t } = useTranslation();
  const [assetTypeFilter, setAssetTypeFilter] = useState<string>("all");
  const [assetStatusFilter, setAssetStatusFilter] = useState<string>("all");
  const [resourceTypeFilter, setResourceTypeFilter] = useState<string>("all");
  const [icon, setIcon] = useStateEffect<L.Icon | null>(null);
  
  // Create custom marker icon
  useEffect(() => {
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    
    const DefaultIcon = L.icon({
      iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
      shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41],
    });
    
    setIcon(DefaultIcon);
  }, []);
  
  // Fetch assets and resources from API (disabled for MVP)
  const { data: assets } = useQuery<Asset[]>({
    queryKey: ['/api/assets'],
    enabled: false // Disabled for MVP
  });
  
  const { data: resources } = useQuery<Resource[]>({
    queryKey: ['/api/resources'],
    enabled: false // Disabled for MVP
  });

  // Filter assets based on selected filters
  const filteredAssets = assetsData.filter(asset => {
    const matchesType = assetTypeFilter === "all" || asset.type === assetTypeFilter;
    const matchesStatus = assetStatusFilter === "all" || asset.status === assetStatusFilter;
    
    return matchesType && matchesStatus;
  });
  
  // Filter resources based on selected filter
  const filteredResources = resourcesData.filter(resource => {
    return resourceTypeFilter === "all" || resource.type === resourceTypeFilter;
  });
  
  // Get asset type display text
  const getAssetTypeText = (type: string): string => {
    switch (type) {
      case 'vehicle': return t("asset.types.vehicle");
      case 'equipment': return t("asset.types.equipment");
      case 'tool': return t("asset.types.tool");
      default: return t("asset.types.other");
    }
  };
  
  // Get asset status display text
  const getAssetStatusText = (status: string): string => {
    switch (status) {
      case 'available': return t("asset.status_values.available");
      case 'in_use': return t("asset.status_values.in_use");
      case 'maintenance': return t("asset.status_values.maintenance");
      default: return t("asset.status_values.out_of_service");
    }
  };
  
  // Get asset status badge style
  const getAssetStatusStyle = (status: string): string => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-700';
      case 'in_use': return 'bg-blue-100 text-blue-700';
      case 'maintenance': return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-red-100 text-red-700';
    }
  };
  
  return (
    <div className="container mx-auto">
      {/* Assets Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{t("asset.title")}</h1>
          <p className="text-gray-600">{t("dashboard.welcome_message")}</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-reverse space-x-2">
          <Button className="flex items-center">
            <span className="material-icons ml-1 text-sm">add</span>
            <span>{t("common.add")} {t("asset.title").split(" ")[0]}</span>
          </Button>
          <Button variant="outline">
            <span>{t("report.export")}</span>
          </Button>
        </div>
      </div>
      
      {/* Tabs Navigation */}
      <Tabs defaultValue="assets" className="mb-6">
        <TabsList className="grid grid-cols-3 w-full max-w-md mb-6">
          <TabsTrigger value="assets">{t("asset.title")}</TabsTrigger>
          <TabsTrigger value="resources">{t("resource.title")}</TabsTrigger>
          <TabsTrigger value="map">{t("map.title")}</TabsTrigger>
        </TabsList>
        
        {/* Assets Tab */}
        <TabsContent value="assets">
          {/* Filter Controls */}
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <Select 
              defaultValue={assetTypeFilter} 
              onValueChange={setAssetTypeFilter}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder={t("asset.type")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                <SelectItem value="vehicle">{t("asset.types.vehicle")}</SelectItem>
                <SelectItem value="equipment">{t("asset.types.equipment")}</SelectItem>
                <SelectItem value="tool">{t("asset.types.tool")}</SelectItem>
                <SelectItem value="other">{t("asset.types.other")}</SelectItem>
              </SelectContent>
            </Select>
            
            <Select 
              defaultValue={assetStatusFilter} 
              onValueChange={setAssetStatusFilter}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder={t("asset.status")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                <SelectItem value="available">{t("asset.status_values.available")}</SelectItem>
                <SelectItem value="in_use">{t("asset.status_values.in_use")}</SelectItem>
                <SelectItem value="maintenance">{t("asset.status_values.maintenance")}</SelectItem>
                <SelectItem value="out_of_service">{t("asset.status_values.out_of_service")}</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="relative flex-1 max-w-sm">
              <Input
                type="text"
                placeholder={t("search.placeholder")}
                className="w-full pr-10"
              />
              <span className="material-icons absolute top-2 right-3 text-gray-400">
                search
              </span>
            </div>
          </div>
          
          {/* Assets Table */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t("asset.title")}</CardTitle>
              <CardDescription>
                {filteredAssets.length} {t("asset.title")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("asset.name")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("asset.type")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("asset.status")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("asset.purchase_date")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("asset.purchase_value")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("asset.assigned_to")}
                      </th>
                      <th className="py-3 px-4 text-center text-sm font-medium text-gray-500">
                        {t("common.actions")}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAssets.map((asset) => (
                      <tr key={asset.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <div className="w-8 h-8 flex-shrink-0 rounded-md bg-primary flex items-center justify-center text-white ml-3">
                              <span className="material-icons text-sm">
                                {asset.type === 'vehicle' ? 'local_shipping' : 
                                 asset.type === 'equipment' ? 'construction' : 
                                 asset.type === 'tool' ? 'handyman' : 'category'}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-800">{asset.name}</p>
                              <p className="text-xs text-gray-500 max-w-[200px] truncate">{asset.description}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">
                            {getAssetTypeText(asset.type)}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs ${getAssetStatusStyle(asset.status)}`}>
                            {getAssetStatusText(asset.status)}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <p className="text-gray-600">
                            {formatDate(asset.purchaseDate)}
                          </p>
                        </td>
                        <td className="py-3 px-4">
                          <p className="text-gray-800">
                            {formatCurrency(asset.purchaseValue)} {t("currency.sar")}
                          </p>
                        </td>
                        <td className="py-3 px-4">
                          {asset.assignedToProject ? (
                            <Link href={`/projects/${asset.assignedToProject}`}>
                              <p className="text-primary hover:underline">
                                {asset.assignedToProject === 1 ? "تطوير الطريق الدائري الشمالي" : 
                                 asset.assignedToProject === 2 ? "شبكة مياه الحي الشرقي" :
                                 asset.assignedToProject === 3 ? "تحديث شبكة الكهرباء" :
                                 asset.assignedToProject === 4 ? "برج الاتصالات المركزي" : 
                                 "مشروع غير معروف"}
                              </p>
                            </Link>
                          ) : (
                            <span className="text-gray-500">-</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <span className="material-icons">more_vert</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <span className="material-icons text-sm ml-2">visibility</span>
                                {t("common.view")}
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <span className="material-icons text-sm ml-2">edit</span>
                                {t("common.edit")}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-danger">
                                <span className="material-icons text-sm ml-2">delete</span>
                                {t("common.delete")}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Resources Tab */}
        <TabsContent value="resources">
          {/* Filter Controls */}
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <Select 
              defaultValue={resourceTypeFilter} 
              onValueChange={setResourceTypeFilter}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder={t("resource.type")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                <SelectItem value="human">موارد بشرية</SelectItem>
                <SelectItem value="material">مواد</SelectItem>
                <SelectItem value="equipment">معدات</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="relative flex-1 max-w-sm">
              <Input
                type="text"
                placeholder={t("search.placeholder")}
                className="w-full pr-10"
              />
              <span className="material-icons absolute top-2 right-3 text-gray-400">
                search
              </span>
            </div>
          </div>
          
          {/* Resources Table */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t("resource.title")}</CardTitle>
              <CardDescription>
                {filteredResources.length} {t("resource.title")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("resource.name")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("resource.type")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("resource.quantity")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("resource.cost")}
                      </th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">
                        {t("resource.assigned_to")}
                      </th>
                      <th className="py-3 px-4 text-center text-sm font-medium text-gray-500">
                        {t("common.actions")}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredResources.map((resource) => (
                      <tr key={resource.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <div className="w-8 h-8 flex-shrink-0 rounded-md bg-secondary flex items-center justify-center text-white ml-3">
                              <span className="material-icons text-sm">
                                {resource.type === 'human' ? 'people' : 
                                 resource.type === 'material' ? 'inventory_2' : 
                                 'construction'}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-800">{resource.name}</p>
                              <p className="text-xs text-gray-500 max-w-[200px] truncate">{resource.description}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            resource.type === 'human' ? 'bg-purple-100 text-purple-700' : 
                            resource.type === 'material' ? 'bg-green-100 text-green-700' : 
                            'bg-orange-100 text-orange-700'
                          }`}>
                            {resource.type === 'human' ? 'موارد بشرية' : 
                             resource.type === 'material' ? 'مواد' : 
                             'معدات'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <p className="text-gray-800">
                            {resource.quantity} {resource.unit}
                          </p>
                        </td>
                        <td className="py-3 px-4">
                          <p className="text-gray-800">
                            {formatCurrency(resource.cost)} {t("currency.sar")}
                          </p>
                        </td>
                        <td className="py-3 px-4">
                          {resource.assignedToProject ? (
                            <Link href={`/projects/${resource.assignedToProject}`}>
                              <p className="text-primary hover:underline">
                                {resource.assignedToProject === 1 ? "تطوير الطريق الدائري الشمالي" : 
                                 resource.assignedToProject === 2 ? "شبكة مياه الحي الشرقي" :
                                 resource.assignedToProject === 3 ? "تحديث شبكة الكهرباء" :
                                 resource.assignedToProject === 4 ? "برج الاتصالات المركزي" : 
                                 "مشروع غير معروف"}
                              </p>
                            </Link>
                          ) : (
                            <span className="text-gray-500">-</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <span className="material-icons">more_vert</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <span className="material-icons text-sm ml-2">visibility</span>
                                {t("common.view")}
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <span className="material-icons text-sm ml-2">edit</span>
                                {t("common.edit")}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-danger">
                                <span className="material-icons text-sm ml-2">delete</span>
                                {t("common.delete")}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Map Tab */}
        <TabsContent value="map">
          <Card>
            <CardHeader>
              <CardTitle>{t("map.title")}</CardTitle>
              <CardDescription>
                عرض مواقع الأصول والمشاريع على الخريطة
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Map Container */}
              <div className="h-[500px] rounded-md overflow-hidden border border-gray-200">
                {icon && (
                  <MapContainer
                    center={[24.774265, 46.738586]}
                    zoom={6}
                    style={{ height: "100%", width: "100%" }}
                  >
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                    
                    {filteredAssets.map((asset) => (
                      asset.currentLocation && (
                        <Marker 
                          key={asset.id}
                          position={[
                            asset.currentLocation.coordinates[1], 
                            asset.currentLocation.coordinates[0]
                          ]}
                          icon={icon}
                        >
                          <Popup>
                            <div className="text-right" dir="rtl">
                              <p className="font-bold">{asset.name}</p>
                              <p className="text-sm text-gray-600">{getAssetTypeText(asset.type)}</p>
                              <p className="text-sm text-gray-600">{getAssetStatusText(asset.status)}</p>
                            </div>
                          </Popup>
                        </Marker>
                      )
                    ))}
                  </MapContainer>
                )}
              </div>
              
              {/* Map Legend */}
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-md">
                  <h3 className="font-medium mb-2">{t("asset.types.vehicle")}</h3>
                  <div className="flex items-center space-x-reverse space-x-2 mb-1">
                    <span className="material-icons text-primary">local_shipping</span>
                    <span className="text-sm">{filteredAssets.filter(a => a.type === 'vehicle').length} موجودات</span>
                  </div>
                </div>
                
                <div className="p-4 bg-gray-50 rounded-md">
                  <h3 className="font-medium mb-2">{t("asset.types.equipment")}</h3>
                  <div className="flex items-center space-x-reverse space-x-2 mb-1">
                    <span className="material-icons text-primary">construction</span>
                    <span className="text-sm">{filteredAssets.filter(a => a.type === 'equipment').length} موجودات</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
