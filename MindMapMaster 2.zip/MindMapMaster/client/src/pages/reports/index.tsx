import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  LineChart,
  Line,
  CartesianGrid,
  Legend
} from "recharts";
import { formatCurrency, formatDate } from "@/lib/utils";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

// Sample data for project status chart
const projectStatusData = [
  { name: "قيد التنفيذ", value: 12, color: "#4caf50" },
  { name: "متأخر", value: 5, color: "#ffeb3b" },
  { name: "متوقف", value: 3, color: "#f44336" },
  { name: "مكتمل", value: 8, color: "#2196f3" },
  { name: "تخطيط", value: 6, color: "#9c27b0" }
];

// Sample data for project types chart
const projectTypesData = [
  { name: "طرق", value: 10, color: "#1976d2" },
  { name: "مياه", value: 8, color: "#00acc1" },
  { name: "كهرباء", value: 7, color: "#ffb300" },
  { name: "اتصالات", value: 5, color: "#9c27b0" },
  { name: "مباني", value: 4, color: "#5d4037" }
];

// Sample data for financial summary
const financialTimelineData = [
  { month: "يناير", expenses: 350000, income: 500000 },
  { month: "فبراير", expenses: 420000, income: 400000 },
  { month: "مارس", expenses: 380000, income: 600000 },
  { month: "أبريل", expenses: 520000, income: 550000 },
  { month: "مايو", expenses: 480000, income: 700000 },
  { month: "يونيو", expenses: 620000, income: 400000 }
];

// Sample data for risk summary
const riskSummaryData = [
  { month: "يناير", high: 5, medium: 7, low: 3 },
  { month: "فبراير", high: 3, medium: 9, low: 4 },
  { month: "مارس", high: 4, medium: 6, low: 5 },
  { month: "أبريل", high: 2, medium: 8, low: 7 },
  { month: "مايو", high: 3, medium: 4, low: 9 },
  { month: "يونيو", high: 4, medium: 5, low: 8 }
];

export default function Reports() {
  const { t } = useTranslation();
  const [reportType, setReportType] = useState<string>("project-status");
  const [projectFilter, setProjectFilter] = useState<string>("all");
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined;
    to: Date | undefined;
  }>({
    from: new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1),
    to: new Date()
  });
  
  // Fetch projects (not implemented for MVP)
  const { data: projects } = useQuery({
    queryKey: ['/api/projects'],
    enabled: false
  });
  
  // Generate PDF report (placeholder function)
  const generatePDFReport = () => {
    alert('سيتم تنزيل التقرير بصيغة PDF');
  };
  
  // Export to Excel (placeholder function)
  const exportToExcel = () => {
    alert('سيتم تصدير البيانات إلى Excel');
  };
  
  return (
    <div className="container mx-auto">
      {/* Reports Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{t("report.title")}</h1>
          <p className="text-gray-600">تحليلات وتقارير المشاريع والأداء</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-reverse space-x-2">
          <Button className="flex items-center" onClick={generatePDFReport}>
            <span className="material-icons ml-1 text-sm">picture_as_pdf</span>
            <span>{t("report.generate")}</span>
          </Button>
          <Button variant="outline" onClick={exportToExcel}>
            <span>{t("report.export")}</span>
          </Button>
        </div>
      </div>
      
      {/* Report Controls */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <Select 
                defaultValue={reportType} 
                onValueChange={setReportType}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="نوع التقرير" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="project-status">حالة المشاريع</SelectItem>
                  <SelectItem value="project-types">أنواع المشاريع</SelectItem>
                  <SelectItem value="financial">الملخص المالي</SelectItem>
                  <SelectItem value="risk">تحليل المخاطر</SelectItem>
                </SelectContent>
              </Select>
              
              <Select 
                defaultValue={projectFilter} 
                onValueChange={setProjectFilter}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="جميع المشاريع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المشاريع</SelectItem>
                  <SelectItem value="1">تطوير الطريق الدائري الشمالي</SelectItem>
                  <SelectItem value="2">شبكة مياه الحي الشرقي</SelectItem>
                  <SelectItem value="3">تحديث شبكة الكهرباء</SelectItem>
                  <SelectItem value="4">برج الاتصالات المركزي</SelectItem>
                </SelectContent>
              </Select>
              
              <div>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-[240px] justify-start text-right"
                    >
                      {dateRange.from ? (
                        dateRange.to ? (
                          <>
                            {format(dateRange.from, "PPP", { locale: ar })} - {format(dateRange.to, "PPP", { locale: ar })}
                          </>
                        ) : (
                          format(dateRange.from, "PPP", { locale: ar })
                        )
                      ) : (
                        <span>{t("report.date_range")}</span>
                      )}
                      <span className="material-icons mr-auto">calendar_today</span>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      initialFocus
                      mode="range"
                      defaultMonth={dateRange.from}
                      selected={{
                        from: dateRange.from,
                        to: dateRange.to,
                      }}
                      onSelect={(range) => {
                        setDateRange({
                          from: range?.from,
                          to: range?.to,
                        });
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Report Content */}
      {reportType === "project-status" && (
        <Card>
          <CardHeader>
            <CardTitle>تقرير حالة المشاريع</CardTitle>
            <CardDescription>
              توزيع المشاريع حسب الحالة
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Project Status Pie Chart */}
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={projectStatusData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {projectStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} مشروع`, ""]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Project Status Bar Chart */}
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={projectStatusData}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value} مشروع`, ""]} />
                    <Bar dataKey="value" fill="var(--chart-1)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            {/* Status Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">
              {projectStatusData.map((status) => (
                <Card key={status.name}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-500">{status.name}</p>
                        <p className="text-xl font-bold text-gray-800">
                          {status.value} مشروع
                        </p>
                      </div>
                      <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${status.color}20`, color: status.color }}>
                        <span className="material-icons">assignment</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
          <CardFooter className="border-t p-4 flex justify-end">
            <Button variant="outline" size="sm" onClick={exportToExcel} className="flex items-center">
              <span className="material-icons ml-1 text-sm">file_download</span>
              تصدير البيانات
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {reportType === "project-types" && (
        <Card>
          <CardHeader>
            <CardTitle>تقرير أنواع المشاريع</CardTitle>
            <CardDescription>
              توزيع المشاريع حسب النوع
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Project Types Pie Chart */}
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={projectTypesData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {projectTypesData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} مشروع`, ""]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Project Types Bar Chart */}
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={projectTypesData}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value} مشروع`, ""]} />
                    <Bar dataKey="value" fill="var(--chart-2)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            {/* Types Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">
              {projectTypesData.map((type) => (
                <Card key={type.name}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-500">{type.name}</p>
                        <p className="text-xl font-bold text-gray-800">
                          {type.value} مشروع
                        </p>
                      </div>
                      <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${type.color}20`, color: type.color }}>
                        <span className="material-icons">
                          {type.name === "طرق" ? "add_road" : 
                           type.name === "مياه" ? "water_drop" : 
                           type.name === "كهرباء" ? "bolt" :
                           type.name === "اتصالات" ? "cell_tower" :
                           "apartment"}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
          <CardFooter className="border-t p-4 flex justify-end">
            <Button variant="outline" size="sm" onClick={exportToExcel} className="flex items-center">
              <span className="material-icons ml-1 text-sm">file_download</span>
              تصدير البيانات
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {reportType === "financial" && (
        <Card>
          <CardHeader>
            <CardTitle>{t("financial.title")}</CardTitle>
            <CardDescription>
              الملخص المالي للإيرادات والمصروفات
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Financial Timeline Chart */}
            <div className="h-80 rtl-chart">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={financialTimelineData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `${formatCurrency(value as number)} ${t("currency.sar")}`} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="income" 
                    name="الإيرادات" 
                    stroke="#4caf50" 
                    strokeWidth={2}
                    activeDot={{ r: 8 }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="expenses" 
                    name="المصروفات" 
                    stroke="#f44336" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            
            {/* Financial Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">إجمالي الإيرادات</p>
                      <p className="text-xl font-bold text-success">
                        {formatCurrency(financialTimelineData.reduce((sum, item) => sum + item.income, 0))} {t("currency.sar")}
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="material-icons text-success">trending_up</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">إجمالي المصروفات</p>
                      <p className="text-xl font-bold text-danger">
                        {formatCurrency(financialTimelineData.reduce((sum, item) => sum + item.expenses, 0))} {t("currency.sar")}
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                      <span className="material-icons text-danger">trending_down</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">صافي الربح</p>
                      <p className="text-xl font-bold text-primary">
                        {formatCurrency(
                          financialTimelineData.reduce((sum, item) => sum + item.income, 0) - 
                          financialTimelineData.reduce((sum, item) => sum + item.expenses, 0)
                        )} {t("currency.sar")}
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="material-icons text-primary">account_balance</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
          <CardFooter className="border-t p-4 flex justify-end">
            <Button variant="outline" size="sm" onClick={exportToExcel} className="flex items-center">
              <span className="material-icons ml-1 text-sm">file_download</span>
              تصدير البيانات
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {reportType === "risk" && (
        <Card>
          <CardHeader>
            <CardTitle>تحليل المخاطر</CardTitle>
            <CardDescription>
              تقرير مفصل بالمخاطر وتصنيفاتها
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Risk Timeline Chart */}
            <div className="h-80 rtl-chart">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskSummaryData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="high" name="مخاطر عالية" stackId="a" fill="#f44336" />
                  <Bar dataKey="medium" name="مخاطر متوسطة" stackId="a" fill="#ffeb3b" />
                  <Bar dataKey="low" name="مخاطر منخفضة" stackId="a" fill="#4caf50" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            {/* Risk Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">مخاطر عالية</p>
                      <p className="text-xl font-bold text-danger">
                        {riskSummaryData.reduce((sum, item) => sum + item.high, 0)} مخاطر
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                      <span className="material-icons text-danger">warning</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">مخاطر متوسطة</p>
                      <p className="text-xl font-bold text-warning">
                        {riskSummaryData.reduce((sum, item) => sum + item.medium, 0)} مخاطر
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                      <span className="material-icons text-warning">error_outline</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">مخاطر منخفضة</p>
                      <p className="text-xl font-bold text-success">
                        {riskSummaryData.reduce((sum, item) => sum + item.low, 0)} مخاطر
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="material-icons text-success">info</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Top Risks Table */}
            <div className="mt-6">
              <h3 className="text-lg font-medium mb-4">أهم المخاطر</h3>
              <div className="border rounded-md overflow-hidden">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">المخاطرة</th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">المستوى</th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">المشروع</th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-500">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="py-3 px-4 text-gray-800">تأخر التوريدات</td>
                      <td className="py-3 px-4">
                        <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs">متوسطة</span>
                      </td>
                      <td className="py-3 px-4 text-primary">تطوير الطريق الدائري الشمالي</td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">تمت المعالجة</span>
                      </td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="py-3 px-4 text-gray-800">تسرب المياه</td>
                      <td className="py-3 px-4">
                        <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs">عالية</span>
                      </td>
                      <td className="py-3 px-4 text-primary">شبكة مياه الحي الشرقي</td>
                      <td className="py-3 px-4">
                        <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">قيد المعالجة</span>
                      </td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="py-3 px-4 text-gray-800">انقطاع التيار</td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">منخفضة</span>
                      </td>
                      <td className="py-3 px-4 text-primary">تحديث شبكة الكهرباء</td>
                      <td className="py-3 px-4">
                        <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs">قيد المراقبة</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t p-4 flex justify-end">
            <Button variant="outline" size="sm" onClick={exportToExcel} className="flex items-center">
              <span className="material-icons ml-1 text-sm">file_download</span>
              تصدير البيانات
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
