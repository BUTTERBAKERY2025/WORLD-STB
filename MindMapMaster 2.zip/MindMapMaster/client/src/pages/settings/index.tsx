import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/language-context";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { t } = useTranslation();
  const { language, setLanguage } = useLanguage();
  const { toast } = useToast();
  const [theme, setTheme] = useState("light");
  
  // Form states
  const [userInfo, setUserInfo] = useState({
    fullName: "م. أحمد الخالدي",
    email: "ahmad@example.com",
    phone: "0512345678",
    role: "admin"
  });
  
  const [passwordInfo, setPasswordInfo] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    projectUpdates: true,
    financialAlerts: true,
    systemNotices: false,
    riskAlerts: true
  });
  
  const [systemSettings, setSystemSettings] = useState({
    dateFormat: "hijri",
    timeFormat: "24hour",
    currency: "sar",
    defaultLanguage: language
  });
  
  // Fetch user info (disabled for MVP)
  const { data: user } = useQuery({
    queryKey: ['/api/users/1'],
    enabled: false
  });
  
  // Handle profile save
  const handleProfileSave = () => {
    toast({
      title: "تم حفظ التغييرات",
      description: "تم تحديث بيانات الملف الشخصي بنجاح",
    });
  };
  
  // Handle password change
  const handlePasswordChange = () => {
    if (passwordInfo.newPassword !== passwordInfo.confirmPassword) {
      toast({
        title: "خطأ في تغيير كلمة المرور",
        description: "كلمة المرور الجديدة وتأكيدها غير متطابقين",
        variant: "destructive"
      });
      return;
    }
    
    if (passwordInfo.newPassword.length < 8) {
      toast({
        title: "خطأ في تغيير كلمة المرور",
        description: "يجب أن تكون كلمة المرور الجديدة 8 أحرف على الأقل",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "تم تغيير كلمة المرور",
      description: "تم تغيير كلمة المرور بنجاح",
    });
    
    setPasswordInfo({
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    });
  };
  
  // Handle notification settings save
  const handleNotificationSettingsSave = () => {
    toast({
      title: "تم حفظ الإعدادات",
      description: "تم تحديث إعدادات الإشعارات بنجاح",
    });
  };
  
  // Handle system settings save
  const handleSystemSettingsSave = () => {
    setLanguage(systemSettings.defaultLanguage as "ar" | "en");
    
    toast({
      title: "تم حفظ الإعدادات",
      description: "تم تحديث إعدادات النظام بنجاح",
    });
  };
  
  // Handle theme change
  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
    document.documentElement.classList.remove("light", "dark", "system");
    document.documentElement.classList.add(newTheme);
    
    toast({
      title: "تم تغيير المظهر",
      description: `تم تغيير المظهر إلى ${newTheme === "light" ? "الوضع النهاري" : newTheme === "dark" ? "الوضع الليلي" : "إعدادات النظام"}`,
    });
  };
  
  return (
    <div className="container mx-auto">
      {/* Settings Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{t("settings.title")}</h1>
          <p className="text-gray-600">إدارة إعدادات النظام والحساب الشخصي</p>
        </div>
      </div>
      
      {/* Settings Tabs */}
      <Tabs defaultValue="account" className="space-y-6">
        <TabsList className="grid grid-cols-4 w-full max-w-2xl">
          <TabsTrigger value="account">{t("settings.account")}</TabsTrigger>
          <TabsTrigger value="appearance">{t("settings.theme")}</TabsTrigger>
          <TabsTrigger value="notifications">{t("settings.notifications")}</TabsTrigger>
          <TabsTrigger value="system">{t("settings.system")}</TabsTrigger>
        </TabsList>
        
        {/* Account Tab */}
        <TabsContent value="account">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Profile Information */}
            <Card>
              <CardHeader>
                <CardTitle>الملف الشخصي</CardTitle>
                <CardDescription>
                  عرض وتعديل معلومات الملف الشخصي
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="full-name">الاسم الكامل</Label>
                  <Input 
                    id="full-name" 
                    value={userInfo.fullName}
                    onChange={(e) => setUserInfo({...userInfo, fullName: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <Input 
                    id="email"
                    type="email"
                    value={userInfo.email}
                    onChange={(e) => setUserInfo({...userInfo, email: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">رقم الهاتف</Label>
                  <Input 
                    id="phone"
                    value={userInfo.phone}
                    onChange={(e) => setUserInfo({...userInfo, phone: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="role">الدور الوظيفي</Label>
                  <Select 
                    value={userInfo.role}
                    onValueChange={(value) => setUserInfo({...userInfo, role: value})}
                  >
                    <SelectTrigger id="role">
                      <SelectValue placeholder="اختر الدور الوظيفي" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">{t("user.role.admin")}</SelectItem>
                      <SelectItem value="project_manager">{t("user.role.project_manager")}</SelectItem>
                      <SelectItem value="engineer">{t("user.role.engineer")}</SelectItem>
                      <SelectItem value="financial">{t("user.role.financial")}</SelectItem>
                      <SelectItem value="viewer">{t("user.role.viewer")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter className="border-t p-4 flex justify-end">
                <Button onClick={handleProfileSave}>
                  حفظ التغييرات
                </Button>
              </CardFooter>
            </Card>
            
            {/* Password Change */}
            <Card>
              <CardHeader>
                <CardTitle>تغيير كلمة المرور</CardTitle>
                <CardDescription>
                  قم بتغيير كلمة المرور الخاصة بك
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="current-password">كلمة المرور الحالية</Label>
                  <Input 
                    id="current-password" 
                    type="password"
                    value={passwordInfo.currentPassword}
                    onChange={(e) => setPasswordInfo({...passwordInfo, currentPassword: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="new-password">كلمة المرور الجديدة</Label>
                  <Input 
                    id="new-password" 
                    type="password"
                    value={passwordInfo.newPassword}
                    onChange={(e) => setPasswordInfo({...passwordInfo, newPassword: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">تأكيد كلمة المرور الجديدة</Label>
                  <Input 
                    id="confirm-password" 
                    type="password"
                    value={passwordInfo.confirmPassword}
                    onChange={(e) => setPasswordInfo({...passwordInfo, confirmPassword: e.target.value})}
                  />
                </div>
                
                <p className="text-xs text-gray-500">
                  يجب أن تكون كلمة المرور 8 أحرف على الأقل وتحتوي على حرف كبير ورقم على الأقل.
                </p>
              </CardContent>
              <CardFooter className="border-t p-4 flex justify-end">
                <Button onClick={handlePasswordChange}>
                  تغيير كلمة المرور
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* Appearance Tab */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>المظهر</CardTitle>
              <CardDescription>
                تخصيص مظهر التطبيق
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>الوضع</Label>
                <div className="grid grid-cols-3 gap-4">
                  <div 
                    className={`border rounded-md p-4 flex flex-col items-center cursor-pointer ${theme === 'light' ? 'border-primary bg-primary/10' : 'hover:border-gray-400'}`}
                    onClick={() => handleThemeChange('light')}
                  >
                    <span className="material-icons text-3xl mb-2">light_mode</span>
                    <span>فاتح</span>
                  </div>
                  <div 
                    className={`border rounded-md p-4 flex flex-col items-center cursor-pointer ${theme === 'dark' ? 'border-primary bg-primary/10' : 'hover:border-gray-400'}`}
                    onClick={() => handleThemeChange('dark')}
                  >
                    <span className="material-icons text-3xl mb-2">dark_mode</span>
                    <span>داكن</span>
                  </div>
                  <div 
                    className={`border rounded-md p-4 flex flex-col items-center cursor-pointer ${theme === 'system' ? 'border-primary bg-primary/10' : 'hover:border-gray-400'}`}
                    onClick={() => handleThemeChange('system')}
                  >
                    <span className="material-icons text-3xl mb-2">devices</span>
                    <span>تلقائي</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>اللغة</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div 
                    className={`border rounded-md p-4 flex flex-col items-center cursor-pointer ${language === 'ar' ? 'border-primary bg-primary/10' : 'hover:border-gray-400'}`}
                    onClick={() => setLanguage('ar')}
                  >
                    <span className="text-xl mb-2">ع</span>
                    <span>العربية</span>
                  </div>
                  <div 
                    className={`border rounded-md p-4 flex flex-col items-center cursor-pointer ${language === 'en' ? 'border-primary bg-primary/10' : 'hover:border-gray-400'}`}
                    onClick={() => setLanguage('en')}
                  >
                    <span className="text-xl mb-2">EN</span>
                    <span>English</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Notifications Tab */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>{t("settings.notifications")}</CardTitle>
              <CardDescription>
                ضبط تفضيلات الإشعارات
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">إشعارات البريد الإلكتروني</h3>
                  <p className="text-sm text-gray-500">استلام الإشعارات عبر البريد الإلكتروني</p>
                </div>
                <Switch 
                  checked={notificationSettings.emailNotifications}
                  onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, emailNotifications: checked})}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">تحديثات المشاريع</h3>
                  <p className="text-sm text-gray-500">استلام إشعارات عند تحديث حالة المشاريع</p>
                </div>
                <Switch
                  checked={notificationSettings.projectUpdates}
                  onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, projectUpdates: checked})}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">التنبيهات المالية</h3>
                  <p className="text-sm text-gray-500">استلام إشعارات المعاملات المالية والميزانية</p>
                </div>
                <Switch
                  checked={notificationSettings.financialAlerts}
                  onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, financialAlerts: checked})}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">إشعارات النظام</h3>
                  <p className="text-sm text-gray-500">استلام إشعارات عن تحديثات النظام والصيانة</p>
                </div>
                <Switch
                  checked={notificationSettings.systemNotices}
                  onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, systemNotices: checked})}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">تنبيهات المخاطر</h3>
                  <p className="text-sm text-gray-500">استلام إشعارات عن مخاطر المشاريع</p>
                </div>
                <Switch
                  checked={notificationSettings.riskAlerts}
                  onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, riskAlerts: checked})}
                />
              </div>
            </CardContent>
            <CardFooter className="border-t p-4 flex justify-end">
              <Button onClick={handleNotificationSettingsSave}>
                حفظ الإعدادات
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* System Tab */}
        <TabsContent value="system">
          <Card>
            <CardHeader>
              <CardTitle>{t("settings.system")}</CardTitle>
              <CardDescription>
                إعدادات النظام العامة
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="date-format">تنسيق التاريخ</Label>
                <Select 
                  value={systemSettings.dateFormat}
                  onValueChange={(value) => setSystemSettings({...systemSettings, dateFormat: value})}
                >
                  <SelectTrigger id="date-format">
                    <SelectValue placeholder="اختر تنسيق التاريخ" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hijri">التقويم الهجري</SelectItem>
                    <SelectItem value="gregorian">التقويم الميلادي</SelectItem>
                    <SelectItem value="both">كلاهما</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="time-format">تنسيق الوقت</Label>
                <Select 
                  value={systemSettings.timeFormat}
                  onValueChange={(value) => setSystemSettings({...systemSettings, timeFormat: value})}
                >
                  <SelectTrigger id="time-format">
                    <SelectValue placeholder="اختر تنسيق الوقت" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="12hour">12 ساعة (صباحًا/مساءً)</SelectItem>
                    <SelectItem value="24hour">24 ساعة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="currency">العملة</Label>
                <Select 
                  value={systemSettings.currency}
                  onValueChange={(value) => setSystemSettings({...systemSettings, currency: value})}
                >
                  <SelectTrigger id="currency">
                    <SelectValue placeholder="اختر العملة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sar">ريال سعودي (SAR)</SelectItem>
                    <SelectItem value="usd">دولار أمريكي (USD)</SelectItem>
                    <SelectItem value="eur">يورو (EUR)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="default-language">اللغة الافتراضية</Label>
                <Select 
                  value={systemSettings.defaultLanguage}
                  onValueChange={(value) => setSystemSettings({...systemSettings, defaultLanguage: value})}
                >
                  <SelectTrigger id="default-language">
                    <SelectValue placeholder="اختر اللغة الافتراضية" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ar">العربية</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2 pt-4">
                <h3 className="font-medium">معلومات النظام</h3>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="text-sm text-gray-500">إصدار النظام:</div>
                    <div className="text-sm">1.0.0</div>
                    <div className="text-sm text-gray-500">آخر تحديث:</div>
                    <div className="text-sm">15/06/2023</div>
                    <div className="text-sm text-gray-500">الدعم الفني:</div>
                    <div className="text-sm">support@example.com</div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t p-4 flex justify-end">
              <Button onClick={handleSystemSettingsSave}>
                حفظ الإعدادات
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
