import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useTranslation } from "react-i18next";

export default function NotFound() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-b from-white to-gray-50">
      <Card className="w-full max-w-md mx-4 border-2 border-red-100 shadow-lg">
        <CardContent className="pt-6 pb-6">
          <div className="flex flex-col items-center text-center mb-6">
            <span className="material-icons text-red-500 text-6xl mb-4">error_outline</span>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">404</h1>
            <p className="text-xl text-gray-700">
              {t("errors.page_not_found") || "الصفحة غير موجودة"}
            </p>
          </div>

          <p className="mb-6 text-gray-600 text-center">
            {t("errors.page_not_found_description") || "الصفحة التي تبحث عنها قد تمت إزالتها أو تغيير اسمها أو أنها غير متوفرة مؤقتًا."}
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button asChild className="bg-primary hover:bg-primary/90">
              <Link href="/" className="flex items-center justify-center">
                <span className="material-icons ml-2">home</span>
                {t("common.back_to_home") || "العودة للرئيسية"}
              </Link>
            </Button>
            
            <Button asChild variant="outline">
              <Link href="/projects" className="flex items-center justify-center">
                <span className="material-icons ml-2">construction</span>
                {t("sidebar.projects") || "المشاريع"}
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
