import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Project, ProjectKpi } from "@shared/schema";
import { fetchProjects } from "./projects/fetchProjects";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressWithText } from "@/components/ui/progress-with-text";
import { formatCurrency, formatNumber, formatDate } from "@/lib/utils";
import { Currency } from "@/components/ui/currency";
import { DashboardMap } from "@/components/maps/dashboard-map";
import { TabletCard, TabletStatCard } from "@/components/ui/tablet-card";
import { TabletTable } from "@/components/ui/tablet-table";
import { TabletInfoCard } from "@/components/ui/tablet-info-display";
import { apiRequest } from "@/lib/queryClient";
import { useMemo } from "react";

// Component to display a summary of projects with enhanced progress indicators
function ProjectsSummary({ projects }: { projects: Project[] }) {
  const { t } = useTranslation();
  
  // Calculate comprehensive summary statistics
  const totalProjects = projects.length;
  const totalBudget = projects.reduce((sum, project) => sum + (project.budget || 0), 0);
  const inProgressProjects = projects.filter(project => project.status === 'in_progress').length;
  const completedProjects = projects.filter(project => project.status === 'completed').length;
  const delayedProjects = projects.filter(project => project.status === 'delayed').length;
  
  // Calculate overall progress percentage across all projects
  const avgProgress = totalProjects > 0 
    ? Math.round(projects.reduce((sum, project) => sum + (project.progress || 0), 0) / totalProjects) 
    : 0;
  
  // Calculate budget utilization
  const totalExpenditure = projects.reduce((sum, project) => {
    // Calculate project expenditure based on progress percentage and budget
    const projectBudget = project.budget || 0;
    const progressPercent = (project.progress || 0) / 100;
    // Simplified estimation of expenditure based on progress
    return sum + (projectBudget * progressPercent);
  }, 0);
  
  // Calculate budget utilization percentage
  const budgetUtilization = totalBudget > 0 
    ? Math.round((totalExpenditure / totalBudget) * 100) 
    : 0;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <TabletStatCard
        title={t("dashboard.total_projects")}
        value={totalProjects.toString()}
        icon={<span className="material-icons text-xl">construction</span>}
        color="primary"
      />
      
      <TabletStatCard
        title={t("dashboard.total_budget")}
        value={<Currency amount={totalBudget} />}
        icon={<span className="material-icons text-xl">payments</span>}
        color="primary"
        subtitle={
          <div className="mt-2">
            <div className="flex justify-between items-center text-xs mb-1">
              <span>{t("dashboard.budget_utilization")}</span>
              <span>{budgetUtilization}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-1 overflow-hidden">
              <div 
                className={`h-full ${budgetUtilization > 90 ? 'bg-red-500' : budgetUtilization > 70 ? 'bg-amber-500' : 'bg-green-500'}`} 
                style={{ width: `${budgetUtilization}%` }}
              ></div>
            </div>
          </div>
        }
      />
      
      <TabletStatCard
        title={t("dashboard.overall_progress")}
        value={`${avgProgress}%`}
        icon={<span className="material-icons text-xl">trending_up</span>}
        color="success"
        subtitle={
          <div className="mt-2">
            <div className="w-full bg-muted rounded-full h-1 overflow-hidden">
              <div 
                className={`h-full ${
                  avgProgress < 25 ? 'bg-red-500' : 
                  avgProgress < 50 ? 'bg-orange-500' : 
                  avgProgress < 75 ? 'bg-amber-500' : 
                  'bg-green-500'}`} 
                style={{ width: `${avgProgress}%` }}
              ></div>
            </div>
          </div>
        }
      />
      
      <TabletStatCard
        title={t("dashboard.project_status")}
        value={inProgressProjects.toString()}
        icon={<span className="material-icons text-xl">pending_actions</span>}
        subtitle={
          <div className="grid grid-cols-3 gap-1 mt-2">
            <div className="text-center">
              <span className="text-xs font-medium">قيد التنفيذ</span>
              <div className="text-sm font-bold text-green-600">{inProgressProjects}</div>
            </div>
            <div className="text-center">
              <span className="text-xs font-medium">متأخر</span>
              <div className="text-sm font-bold text-amber-600">{delayedProjects}</div>
            </div>
            <div className="text-center">
              <span className="text-xs font-medium">مكتمل</span>
              <div className="text-sm font-bold text-blue-600">{completedProjects}</div>
            </div>
          </div>
        }
        color="primary"
      />
    </div>
  );
}

// Component to display recent projects
function RecentProjects({ projects }: { projects: Project[] }) {
  const { t } = useTranslation();
  
  // Sort projects by createdAt date and take the most recent 5
  const recentProjects = [...projects]
    .sort((a, b) => {
      // Safe handling of null dates
      const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return dateB - dateA;
    })
    .slice(0, 5);
  
  const columns = [
    {
      accessorKey: "name",
      header: "اسم المشروع",
      cell: (project: Project) => (
        <Link 
          href={`/projects/${project.id}`} 
          className="font-medium text-foreground hover:text-primary"
        >
          {project.name}
        </Link>
      ),
    },
    {
      accessorKey: "type",
      header: "نوع المشروع",
      cell: (project: Project) => (
        <ProjectTypeBadge type={project.type} size="sm" />
      ),
    },
    {
      accessorKey: "status",
      header: "حالة المشروع",
      cell: (project: Project) => (
        <StatusBadge status={project.status} size="sm" />
      ),
    },
    {
      accessorKey: "progress",
      header: "نسبة الإنجاز",
      cell: (project: Project) => (
        <ProgressWithText value={project.progress || 0} size="sm" />
      ),
      className: "w-40",
    },
    {
      accessorKey: "budget",
      header: "الميزانية",
      cell: (project: Project) => (
        <Currency amount={project.budget || 0} symbolSize="sm" />
      ),
      className: "text-right",
    },
  ];
  
  return (
    <TabletInfoCard
      title={
        <div className="flex justify-between items-center w-full">
          <div>
            <h3 className="text-lg font-medium">{t("dashboard.recent_projects")}</h3>
            <p className="text-sm text-muted-foreground">{t("dashboard.latest_projects_added")}</p>
          </div>
          <Link href="/projects" className="text-sm text-primary hover:underline">
            {t("common.view_all_projects")}
          </Link>
        </div>
      }
      className="mb-6"
      contentClassName="p-0"
    >
      <TabletTable
        data={recentProjects}
        columns={columns}
        onRowClick={(project) => window.location.href = `/projects/${project.id}`}
        className="touch-target"
      />
    </TabletInfoCard>
  );
}

// Component to display projects by status
function ProjectsByStatus({ projects }: { projects: Project[] }) {
  const { t } = useTranslation();
  
  // Calculate the count of projects by status
  const statusCounts = {
    planning: projects.filter(p => p.status === 'planning').length,
    in_progress: projects.filter(p => p.status === 'in_progress').length,
    delayed: projects.filter(p => p.status === 'delayed').length,
    completed: projects.filter(p => p.status === 'completed').length,
    stopped: projects.filter(p => p.status === 'stopped').length,
  };
  
  // Calculate total for percentages
  const total = Object.values(statusCounts).reduce((sum, count) => sum + count, 0);
  
  // Get the status colors
  const statusColors = {
    planning: "bg-blue-500",
    in_progress: "bg-green-500",
    delayed: "bg-amber-500",
    completed: "bg-purple-500",
    stopped: "bg-red-500",
  };
  
  return (
    <TabletInfoCard
      title={t("dashboard.projects_by_status")}
      icon={<span className="material-icons text-2xl">pie_chart</span>}
      className="mb-6 tablet-friendly-card"
    >
      <p className="text-sm text-muted-foreground mb-4">{t("dashboard.distribution_by_status")}</p>
      <div className="space-y-4 touch-spacing">
        {Object.entries(statusCounts).map(([status, count]) => {
          const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
          return (
            <div key={status} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className={`w-4 h-4 rounded-full ml-3 ${statusColors[status as keyof typeof statusColors]}`}></div>
                  <span className="text-base font-medium">
                    {status === "planning" ? "في مرحلة التخطيط" :
                     status === "in_progress" ? "قيد التنفيذ" : 
                     status === "delayed" ? "متأخر" : 
                     status === "completed" ? "مكتمل" : 
                     status === "stopped" ? "متوقف" : status}
                  </span>
                </div>
                <span className="text-base font-medium">{count} ({percentage}%)</span>
              </div>
              <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                <div 
                  className={`h-full ${statusColors[status as keyof typeof statusColors]}`} 
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>
    </TabletInfoCard>
  );
}

// Component to display projects by type
function ProjectsByType({ projects }: { projects: Project[] }) {
  const { t } = useTranslation();
  
  // Calculate the count of projects by type
  const typeCounts = {
    road: projects.filter(p => p.type === 'road').length,
    water: projects.filter(p => p.type === 'water').length,
    electricity: projects.filter(p => p.type === 'electricity').length,
    telecom: projects.filter(p => p.type === 'telecom').length,
    building: projects.filter(p => p.type === 'building').length,
  };
  
  // Get the type colors
  const typeColors = {
    road: "bg-blue-500",
    water: "bg-cyan-500",
    electricity: "bg-yellow-500",
    telecom: "bg-purple-500",
    building: "bg-green-500",
  };

  // Get the type icons
  const typeIcons = {
    road: 'add_road',
    water: 'water_drop',
    electricity: 'bolt',
    telecom: 'cell_tower',
    building: 'apartment'
  };
  
  return (
    <TabletInfoCard
      title={t("dashboard.projects_by_type")}
      icon={<span className="material-icons text-2xl">category</span>}
      className="mb-6 tablet-friendly-card"
    >
      <p className="text-sm text-muted-foreground mb-4">{t("dashboard.distribution_by_type")}</p>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
        {Object.entries(typeCounts).map(([type, count]) => (
          <div key={type} className="text-center touch-target">
            <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center ${typeColors[type as keyof typeof typeColors]} bg-opacity-20 mb-3`}>
              <span className="material-icons text-2xl text-foreground">
                {typeIcons[type as keyof typeof typeIcons]}
              </span>
            </div>
            <div className="text-base font-medium mb-1">
              {type === "road" ? "طريق" :
               type === "water" ? "مياه" : 
               type === "electricity" ? "كهرباء" : 
               type === "telecom" ? "اتصالات" : 
               type === "building" ? "مبنى" : type}
            </div>
            <div className="text-2xl font-bold">{count}</div>
          </div>
        ))}
      </div>
    </TabletInfoCard>
  );
}

// مكون لعرض مؤشرات الأداء الرئيسية للمشاريع
function ProjectKPIsDisplay({ projectId }: { projectId: number }) {
  const { t } = useTranslation();
  
  // استدعاء بيانات مؤشرات الأداء من الخادم
  const { data, isLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/kpis`],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/projects/${projectId}/kpis`);
      const data = await response.json();
      return data;
    },
    // تعطيل إعادة التحميل تلقائيا
    refetchOnWindowFocus: false,
    staleTime: 300000, // 5 دقائق
  });
  
  // تأكد من أن البيانات موجودة وصالحة للاستخدام
  const kpis = data?.kpis && Array.isArray(data.kpis) ? data.kpis : [];
  
  // اختيار آخر مؤشر أداء (أحدث فترة)
  const latestKpi = useMemo(() => {
    if (kpis.length === 0) return null;
    
    return [...kpis].sort((a, b) => {
      const dateA = a.periodEnd ? new Date(a.periodEnd).getTime() : 0;
      const dateB = b.periodEnd ? new Date(b.periodEnd).getTime() : 0;
      return dateB - dateA;
    })[0];
  }, [kpis]);
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  if (!latestKpi) {
    return null;
  }
  
  // تحديد ألوان مؤشرات الأداء
  const getCPIColor = (cpi: number) => {
    if (cpi >= 1.1) return "text-green-600";
    if (cpi >= 0.9) return "text-green-500";
    if (cpi >= 0.8) return "text-amber-500";
    return "text-red-500";
  };
  
  const getSPIColor = (spi: number) => {
    if (spi >= 1.1) return "text-green-600";
    if (spi >= 0.9) return "text-green-500";
    if (spi >= 0.8) return "text-amber-500";
    return "text-red-500";
  };
  
  const getCVColor = (cv: number) => {
    if (cv > 0) return "text-green-500";
    if (cv === 0) return "text-blue-500";
    return "text-red-500";
  };
  
  const getSVColor = (sv: number) => {
    if (sv > 0) return "text-green-500";
    if (sv === 0) return "text-blue-500";
    return "text-red-500";
  };
  
  // استخراج البيانات مع معالجة القيم الفارغة
  const {
    periodStart = new Date(),
    periodEnd = new Date(),
    costPerformanceIndex = 0,
    schedulePerformanceIndex = 0,
    costVariance = 0,
    scheduleVariance = 0,
    plannedValue = 0,
    earnedValue = 0,
    actualCost = 0,
    estimateAtCompletion = 0,
    varianceAtCompletion = 0,
    plannedProgress = 0,
    actualProgress = 0
  } = latestKpi;

  return (
    <div className="border rounded-lg p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-semibold text-lg">{t("dashboard.performance_metrics")}</h3>
        <div className="text-sm text-muted-foreground">
          {formatDate(periodStart)} - {formatDate(periodEnd)}
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* مؤشر أداء التكلفة */}
        <div className="flex flex-col items-center p-3 border rounded-lg">
          <div className="text-xs text-muted-foreground uppercase mb-1">CPI</div>
          <div className={`text-2xl font-bold ${getCPIColor(costPerformanceIndex)}`}>
            {formatNumber(costPerformanceIndex)}
          </div>
          <div className="text-xs text-center">{t("dashboard.cost_performance_index")}</div>
        </div>
        
        {/* مؤشر أداء الجدول الزمني */}
        <div className="flex flex-col items-center p-3 border rounded-lg">
          <div className="text-xs text-muted-foreground uppercase mb-1">SPI</div>
          <div className={`text-2xl font-bold ${getSPIColor(schedulePerformanceIndex)}`}>
            {formatNumber(schedulePerformanceIndex)}
          </div>
          <div className="text-xs text-center">{t("dashboard.schedule_performance_index")}</div>
        </div>
        
        {/* تباين التكلفة */}
        <div className="flex flex-col items-center p-3 border rounded-lg">
          <div className="text-xs text-muted-foreground uppercase mb-1">CV</div>
          <div className={`text-2xl font-bold ${getCVColor(costVariance)}`}>
            {formatCurrency(costVariance)}
          </div>
          <div className="text-xs text-center">{t("dashboard.cost_variance")}</div>
        </div>
        
        {/* تباين الجدول الزمني */}
        <div className="flex flex-col items-center p-3 border rounded-lg">
          <div className="text-xs text-muted-foreground uppercase mb-1">SV</div>
          <div className={`text-2xl font-bold ${getSVColor(scheduleVariance)}`}>
            {formatCurrency(scheduleVariance)}
          </div>
          <div className="text-xs text-center">{t("dashboard.schedule_variance")}</div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
        {/* القيمة المخططة والمكتسبة والتكلفة الفعلية */}
        <div className="border rounded-lg p-3">
          <h4 className="text-sm font-medium mb-2">{t("dashboard.earned_value_metrics")}</h4>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm">PV</span>
              <span className="text-sm font-medium">{formatCurrency(plannedValue)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">EV</span>
              <span className="text-sm font-medium">{formatCurrency(earnedValue)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">AC</span>
              <span className="text-sm font-medium">{formatCurrency(actualCost)}</span>
            </div>
          </div>
        </div>
        
        {/* تقديرات الإكمال */}
        <div className="border rounded-lg p-3">
          <h4 className="text-sm font-medium mb-2">{t("dashboard.estimate_at_completion")}</h4>
          <div className="text-xl font-bold text-center my-2">
            {formatCurrency(estimateAtCompletion)}
          </div>
          <div className="text-xs text-center text-muted-foreground">
            {t("dashboard.variance_at_completion")}: {formatCurrency(varianceAtCompletion)}
          </div>
        </div>
        
        {/* نسب التقدم الفعلي والمخطط */}
        <div className="border rounded-lg p-3">
          <h4 className="text-sm font-medium mb-2">{t("dashboard.progress_metrics")}</h4>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span>{t("dashboard.planned_progress")}</span>
                <span>{formatNumber(plannedProgress)}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-1.5 overflow-hidden">
                <div 
                  className="h-full bg-blue-500" 
                  style={{ width: `${plannedProgress}%` }}
                ></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span>{t("dashboard.actual_progress")}</span>
                <span>{formatNumber(actualProgress)}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-1.5 overflow-hidden">
                <div 
                  className={`h-full ${actualProgress >= plannedProgress ? 'bg-green-500' : 'bg-red-500'}`}
                  style={{ width: `${actualProgress}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// مكوِّن لعرض المشاريع حسب الأداء
function ProjectsByPerformance({ projects }: { projects: Project[] }) {
  const { t } = useTranslation();
  
  // ترتيب المشاريع حسب التقدم
  const sortedProjects = [...projects]
    .filter(project => project.status === 'in_progress' || project.status === 'delayed')
    .sort((a, b) => (b.progress || 0) - (a.progress || 0))
    .slice(0, 5);
  
  return (
    <TabletInfoCard
      title={t("dashboard.project_progress_tracking")}
      icon={<span className="material-icons text-2xl">assessment</span>}
      className="mb-6 tablet-friendly-card"
    >
      <p className="text-sm text-muted-foreground mb-4">{t("dashboard.performance_analysis")}</p>
      {sortedProjects.length > 0 ? (
        <div className="space-y-6 touch-spacing">
          {sortedProjects.map((project) => {
            // حساب السرعة نسبة إلى المدة الزمنية
            const startDate = project.startDate ? new Date(project.startDate) : null;
            const endDate = project.endDate ? new Date(project.endDate) : null;
            const today = new Date();
            
            let timeProgress = 0;
            let timeProgressLabel = "";
            let performanceIndicator = "neutral";
            
            if (startDate && endDate) {
              const totalDuration = endDate.getTime() - startDate.getTime();
              const elapsedDuration = today.getTime() - startDate.getTime();
              
              if (totalDuration > 0) {
                timeProgress = Math.min(Math.round((elapsedDuration / totalDuration) * 100), 100);
                
                // قياس الأداء بمقارنة نسبة الوقت المنقضي بنسبة التقدم
                const workProgress = project.progress || 0;
                
                if (workProgress >= timeProgress + 10) {
                  performanceIndicator = "excellent";
                  timeProgressLabel = "متقدم عن الجدول";
                } else if (workProgress >= timeProgress) {
                  performanceIndicator = "good";
                  timeProgressLabel = "على المسار الصحيح";
                } else if (workProgress >= timeProgress - 10) {
                  performanceIndicator = "average";
                  timeProgressLabel = "متأخر قليلاً";
                } else {
                  performanceIndicator = "poor";
                  timeProgressLabel = "متأخر عن الجدول";
                }
              }
            }
            
            const performanceColors = {
              excellent: "bg-green-600",
              good: "bg-green-500",
              average: "bg-amber-500",
              poor: "bg-red-500",
              neutral: "bg-blue-500"
            };
            
            const performanceTextColors = {
              excellent: "text-green-600",
              good: "text-green-500",
              average: "text-amber-500",
              poor: "text-red-500",
              neutral: "text-blue-500"
            };
            
            return (
              <div key={project.id} className="border rounded-lg p-4 space-y-3 hover:border-primary/30 transition-all">
                <div className="flex justify-between items-start">
                  <div>
                    <Link 
                      href={`/projects/${project.id}`} 
                      className="font-medium text-base hover:text-primary"
                    >
                      {project.name}
                    </Link>
                    <div className="flex items-center gap-2 mt-1">
                      <ProjectTypeBadge type={project.type} size="sm" />
                      <StatusBadge status={project.status} size="sm" />
                    </div>
                  </div>
                  <div className={`text-sm font-medium ${performanceTextColors[performanceIndicator as keyof typeof performanceTextColors]}`}>
                    {timeProgressLabel}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">تقدم العمل</div>
                      <div className="flex items-center gap-2">
                        <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                          <div 
                            className={`h-full ${project.progress || 0 < 25 ? 'bg-red-500' : project.progress || 0 < 50 ? 'bg-orange-500' : project.progress || 0 < 75 ? 'bg-amber-500' : 'bg-green-500'}`} 
                            style={{ width: `${project.progress || 0}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">{project.progress || 0}%</span>
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">تقدم الوقت</div>
                      <div className="flex items-center gap-2">
                        <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                          <div 
                            className={`h-full ${timeProgress < 25 ? 'bg-green-500' : timeProgress < 50 ? 'bg-blue-500' : timeProgress < 75 ? 'bg-amber-500' : 'bg-red-500'}`} 
                            style={{ width: `${timeProgress}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">{timeProgress}%</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">مؤشر الأداء</div>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${performanceColors[performanceIndicator as keyof typeof performanceColors]}`}></div>
                      <span className="text-sm">{project.progress && timeProgress ? Math.round((project.progress / timeProgress) * 100) / 100 : "—"}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center p-6 text-muted-foreground">
          {t("dashboard.no_active_projects")}
        </div>
      )}
    </TabletInfoCard>
  );
}

export default function Dashboard() {
  const { t } = useTranslation();
  
  // Fetch projects data with improved caching strategy
  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    queryFn: fetchProjects,
    staleTime: 60000, // 1 minute caching
    refetchOnMount: false, // Don't refetch when the component is mounted again
    refetchOnWindowFocus: false, // Don't refetch when window gets focus
  });
  
  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-6 flex items-center">
        <span className="material-icons text-primary text-3xl ml-3">dashboard</span>
        <div>
          <h1 className="text-2xl font-bold">{t("dashboard.title")}</h1>
          <p className="text-muted-foreground">{t("dashboard.subtitle")}</p>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center h-40">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-muted-foreground ml-4 text-base">{t("loading")}</p>
        </div>
      ) : (
        <>
          <ProjectsSummary projects={projects} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <ProjectsByStatus projects={projects} />
            <ProjectsByType projects={projects} />
          </div>
          
          {/* إضافة قسم خاص بالأداء ومؤشرات التقدم */}
          <div className="mb-6">
            <ProjectsByPerformance projects={projects} />
          </div>

          {/* إضافة مؤشرات الأداء الرئيسية KPIs للمشروع الأكثر أهمية */}
          {projects.length > 0 && (
            <div className="mb-6">
              <TabletInfoCard
                title={
                  <div className="flex justify-between items-center w-full">
                    <div className="flex items-center gap-3">
                      <span className="material-icons text-2xl">analytics</span>
                      <div>
                        <h3 className="text-lg font-medium">{t("dashboard.advanced_performance_metrics")}</h3>
                        <p className="text-sm text-muted-foreground">{t("dashboard.project_kpi_description")}</p>
                      </div>
                    </div>
                  </div>
                }
                className="tablet-friendly-card"
              >
                {/* عرض مؤشرات الأداء للمشروع الأول (عادة المشروع الأكثر أهمية) */}
                {projects.length > 0 && <ProjectKPIsDisplay projectId={projects[0].id} />}
              </TabletInfoCard>
            </div>
          )}
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div className="lg:col-span-2">
              <TabletInfoCard
                title={
                  <div className="flex justify-between items-center w-full">
                    <div className="flex items-center gap-3">
                      <span className="material-icons text-2xl">map</span>
                      <div>
                        <h3 className="text-lg font-medium">{t("dashboard.projects_map")}</h3>
                        <p className="text-sm text-muted-foreground">{t("map.project_locations")}</p>
                      </div>
                    </div>
                    <Link href="/maps" className="text-sm text-primary hover:underline">
                      {t("common.view_all")}
                    </Link>
                  </div>
                }
                className="h-full tablet-friendly-card"
                contentClassName="p-0 pt-2"
              >
                <div className="h-[400px] touch-target">
                  {/* Dynamic import to avoid SSR issues with Leaflet */}
                  {typeof window !== 'undefined' && (
                    <div className="h-full">
                      <DashboardMap projects={projects} height="100%" />
                    </div>
                  )}
                </div>
              </TabletInfoCard>
            </div>
            <div>
              <TabletInfoCard
                title={t("dashboard.potential_risks")}
                icon={<span className="material-icons text-2xl">warning</span>}
                className="h-full tablet-friendly-card"
              >
                <p className="text-sm text-muted-foreground mb-4">{t("dashboard.risk_analysis")}</p>
                <div className="space-y-5 touch-spacing">
                  <div className="flex items-center gap-4 p-3 bg-red-50 rounded-lg">
                    <span className="material-icons text-2xl text-red-500">warning</span>
                    <div>
                      <div className="font-medium text-base">{t("risk.level.high")}</div>
                      <div className="text-sm text-muted-foreground">3 مشاريع</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-3 bg-amber-50 rounded-lg">
                    <span className="material-icons text-2xl text-amber-500">warning</span>
                    <div>
                      <div className="font-medium text-base">{t("risk.level.medium")}</div>
                      <div className="text-sm text-muted-foreground">5 مشاريع</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-3 bg-green-50 rounded-lg">
                    <span className="material-icons text-2xl text-green-500">check_circle</span>
                    <div>
                      <div className="font-medium text-base">{t("risk.level.low")}</div>
                      <div className="text-sm text-muted-foreground">8 مشاريع</div>
                    </div>
                  </div>
                  <div className="h-[1px] bg-border my-3"></div>
                  <Link 
                    href="/reports/risks" 
                    className="flex items-center gap-2 text-primary hover:underline p-2 touch-target"
                  >
                    <span className="material-icons">trending_up</span>
                    <span className="text-base">{t("risk.manage_risks")}</span>
                  </Link>
                </div>
              </TabletInfoCard>
            </div>
          </div>
          
          <RecentProjects projects={projects} />
        </>
      )}
    </div>
  );
}