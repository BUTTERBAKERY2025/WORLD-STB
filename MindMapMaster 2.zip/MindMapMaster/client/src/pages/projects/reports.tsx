import * as React from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { ChevronRight, Filter, Download, FileText, RefreshCw, Printer, ArrowDownToLine } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { PageTitle } from '@/components/ui/page-title';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

// ألوان المخططات
const CHART_COLORS = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];
const PIE_COLORS = ['#3b82f6', '#14b8a6', '#f97316', '#f43f5e', '#8b5cf6', '#ec4899'];

// تصدير التقارير إلى PDF باستخدام jsPDF
const exportToPdf = (reportTitle: string, reportData: any) => {
  import('jspdf').then((jsPDFModule) => {
    import('jspdf-autotable').then(() => {
      const jsPDF = jsPDFModule.default;
      const doc = new jsPDF();
      
      // إضافة العنوان والتاريخ
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.text(reportTitle, 105, 15, { align: 'center' });
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      const today = new Date().toLocaleDateString('ar-SA');
      doc.text(`تاريخ التقرير: ${today}`, 105, 25, { align: 'center' });
      
      // بناء الجدول حسب نوع التقرير
      switch(reportTitle) {
        case 'تقرير الميزانية مقابل المصروفات':
          const budgetData = reportData.items.map((item: any) => [
            item.category,
            item.budgetAmount.toLocaleString('ar-SA'),
            item.expenseAmount.toLocaleString('ar-SA'),
            item.varianceAmount.toLocaleString('ar-SA'),
            `${item.variancePercentage.toFixed(2)}%`
          ]);
          
          (doc as any).autoTable({
            head: [['الفئة', 'الميزانية', 'المصروفات', 'الفرق', 'نسبة الفرق %']],
            body: budgetData,
            startY: 35,
            headStyles: { fillColor: [37, 99, 235], halign: 'center' },
            styles: { font: 'helvetica', halign: 'right' },
            theme: 'grid'
          });
          break;
          
        case 'تقرير المستخلصات والمدفوعات':
          const certData = reportData.certificates.map((cert: any) => [
            cert.certificateNumber,
            cert.issueDate,
            cert.grossAmount.toLocaleString('ar-SA'),
            cert.status,
            cert.isPaid ? 'مدفوع' : 'غير مدفوع',
            cert.paidDate || '-'
          ]);
          
          (doc as any).autoTable({
            head: [['رقم المستخلص', 'التاريخ', 'المبلغ', 'الحالة', 'حالة الدفع', 'تاريخ الدفع']],
            body: certData,
            startY: 35,
            headStyles: { fillColor: [37, 99, 235], halign: 'center' },
            styles: { font: 'helvetica', halign: 'right' },
            theme: 'grid'
          });
          break;
          
        case 'تقرير ربحية المشروع':
          const profitData = [
            ['قيمة العقد', reportData.contractValue.toLocaleString('ar-SA')],
            ['إجمالي المصروفات', reportData.totalExpenses.toLocaleString('ar-SA')],
            ['الربح المتوقع', reportData.estimatedProfit.toLocaleString('ar-SA')],
            ['هامش الربح', `${reportData.profitMargin.toFixed(2)}%`],
            ['العائد على الاستثمار', `${reportData.roi.toFixed(2)}%`]
          ];
          
          (doc as any).autoTable({
            body: profitData,
            startY: 35,
            styles: { font: 'helvetica', halign: 'right' },
            theme: 'grid'
          });
          break;
      }
      
      // حفظ الملف
      doc.save(`${reportTitle}-${today}.pdf`);
    });
  });
};

// تصدير التقارير إلى Excel باستخدام xlsx
const exportToExcel = (reportTitle: string, reportData: any) => {
  import('xlsx').then(XLSX => {
    // بناء البيانات حسب نوع التقرير
    let worksheetData: any[] = [];
    
    switch(reportTitle) {
      case 'تقرير الميزانية مقابل المصروفات':
        worksheetData = [
          ['الفئة', 'الميزانية', 'المصروفات', 'الفرق', 'نسبة الفرق %'],
          ...reportData.items.map((item: any) => [
            item.category,
            item.budgetAmount,
            item.expenseAmount,
            item.varianceAmount,
            item.variancePercentage
          ])
        ];
        break;
        
      case 'تقرير المستخلصات والمدفوعات':
        worksheetData = [
          ['رقم المستخلص', 'التاريخ', 'المبلغ', 'الحالة', 'حالة الدفع', 'تاريخ الدفع'],
          ...reportData.certificates.map((cert: any) => [
            cert.certificateNumber,
            cert.issueDate,
            cert.grossAmount,
            cert.status,
            cert.isPaid ? 'مدفوع' : 'غير مدفوع',
            cert.paidDate || '-'
          ])
        ];
        break;
        
      case 'تقرير ربحية المشروع':
        worksheetData = [
          ['البند', 'القيمة'],
          ['قيمة العقد', reportData.contractValue],
          ['إجمالي المصروفات', reportData.totalExpenses],
          ['الربح المتوقع', reportData.estimatedProfit],
          ['هامش الربح', `${reportData.profitMargin.toFixed(2)}%`],
          ['المصروفات المتوقعة المتبقية', reportData.estimatedRemainingExpenses]
        ];
        break;
    }
    
    // إنشاء الملف
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, reportTitle);
    
    // تنزيل الملف
    const today = new Date().toLocaleDateString('ar-SA').replace(/\//g, '-');
    XLSX.writeFile(workbook, `${reportTitle}-${today}.xlsx`);
  });
};

export default function ProjectReportsPage() {
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();
  const [currentProjectId, setCurrentProjectId] = React.useState<number | null>(null);
  const [reportType, setReportType] = React.useState('budget-vs-expenses');
  const [showFilterDialog, setShowFilterDialog] = React.useState(false);
  const [dateRange, setDateRange] = React.useState<{ startDate: string; endDate: string }>({
    startDate: new Date(new Date().getFullYear(), new Date().getMonth() - 3, 1).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0]
  });
  
  // استعلام عن المشاريع
  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ['/api/projects']
  });
  
  // استعلام عن تقرير الميزانية مقابل المصروفات
  const { 
    data: budgetVsExpensesReport, 
    isLoading: isLoadingBudgetReport, 
    refetch: refetchBudgetReport 
  } = useQuery({
    queryKey: ['/api/projects', currentProjectId, 'reports/budget-vs-expenses'],
    queryFn: async () => {
      if (!currentProjectId) return null;
      return apiRequest('GET', `/api/projects/${currentProjectId}/reports/budget-vs-expenses`)
        .then(res => res.json());
    },
    enabled: !!currentProjectId && reportType === 'budget-vs-expenses'
  });
  
  // استعلام عن تقرير المستخلصات والمدفوعات
  const { 
    data: certificatesReport, 
    isLoading: isLoadingCertificatesReport, 
    refetch: refetchCertificatesReport 
  } = useQuery({
    queryKey: ['/api/projects', currentProjectId, 'reports/certificates'],
    queryFn: async () => {
      if (!currentProjectId) return null;
      return apiRequest('GET', `/api/projects/${currentProjectId}/reports/certificates`)
        .then(res => res.json());
    },
    enabled: !!currentProjectId && reportType === 'certificates'
  });
  
  // استعلام عن تقرير ربحية المشروع
  const { 
    data: profitabilityReport, 
    isLoading: isLoadingProfitabilityReport,
    refetch: refetchProfitabilityReport 
  } = useQuery({
    queryKey: ['/api/projects', currentProjectId, 'reports/profitability'],
    queryFn: async () => {
      if (!currentProjectId) return null;
      return apiRequest('GET', `/api/projects/${currentProjectId}/reports/profitability`)
        .then(res => res.json());
    },
    enabled: !!currentProjectId && reportType === 'profitability'
  });
  
  // معالجة اختيار المشروع
  React.useEffect(() => {
    const projectId = new URLSearchParams(location.split('?')[1] || '').get('projectId');
    if (projectId) {
      setCurrentProjectId(parseInt(projectId));
    } else if (projects && Array.isArray(projects) && projects.length > 0) {
      setCurrentProjectId(projects[0].id);
    }
  }, [location, projects]);
  
  // تحديث التقارير
  const refreshCurrentReport = () => {
    switch(reportType) {
      case 'budget-vs-expenses':
        refetchBudgetReport();
        break;
      case 'certificates':
        refetchCertificatesReport();
        break;
      case 'profitability':
        refetchProfitabilityReport();
        break;
    }
  };
  
  // تصدير التقرير الحالي
  const exportCurrentReport = (format: 'pdf' | 'excel') => {
    let reportTitle = '';
    let reportData = null;
    
    switch(reportType) {
      case 'budget-vs-expenses':
        reportTitle = 'تقرير الميزانية مقابل المصروفات';
        reportData = budgetVsExpensesReport;
        break;
      case 'certificates':
        reportTitle = 'تقرير المستخلصات والمدفوعات';
        reportData = certificatesReport;
        break;
      case 'profitability':
        reportTitle = 'تقرير ربحية المشروع';
        reportData = profitabilityReport;
        break;
    }
    
    if (!reportData) return;
    
    if (format === 'pdf') {
      exportToPdf(reportTitle, reportData);
    } else {
      exportToExcel(reportTitle, reportData);
    }
  };
  
  // تحديد عنوان التقرير الحالي
  const getCurrentReportTitle = () => {
    switch(reportType) {
      case 'budget-vs-expenses':
        return 'تقرير الميزانية مقابل المصروفات';
      case 'certificates':
        return 'تقرير المستخلصات والمدفوعات';
      case 'profitability':
        return 'تقرير ربحية المشروع';
      default:
        return 'تقارير المشاريع';
    }
  };
  
  // تحديد المشروع الحالي
  const currentProject = Array.isArray(projects) ? projects.find((p: any) => p.id === currentProjectId) : undefined;
  
  return (
    <div className="container mx-auto py-6 space-y-6 bg-gray-50/30 min-h-[calc(100vh-4rem)] rounded-lg p-6">
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-1 rtl:space-x-reverse text-sm text-muted-foreground mb-2">
              <Button variant="link" className="p-0 h-auto text-muted-foreground" onClick={() => setLocation('/projects')}>
                المشاريع
              </Button>
              <ChevronRight className="h-4 w-4" />
              <span>التقارير</span>
              {currentProject && (
                <>
                  <ChevronRight className="h-4 w-4" />
                  <span>{currentProject.name}</span>
                </>
              )}
            </div>
            <PageTitle 
              title={getCurrentReportTitle()}
              subtitle="عرض وتحليل البيانات المالية وتقارير أداء المشاريع"
            />
          </div>
          
          <div className="flex items-center gap-3">
            <Button 
              variant="outline" 
              className="flex items-center gap-2" 
              onClick={() => setShowFilterDialog(true)}
            >
              <Filter className="h-4 w-4" />
              <span>فلترة</span>
            </Button>
            
            <div className="flex gap-1.5">
              <Button 
                variant="outline" 
                className="h-10 w-10 p-0"
                onClick={refreshCurrentReport}
                title="تحديث"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
              
              <Button 
                variant="outline" 
                className="h-10 w-10 p-0"
                onClick={() => exportCurrentReport('pdf')}
                title="تصدير PDF"
              >
                <FileText className="h-4 w-4" />
              </Button>
              
              <Button 
                variant="outline" 
                className="h-10 w-10 p-0"
                onClick={() => exportCurrentReport('excel')}
                title="تصدير Excel"
              >
                <ArrowDownToLine className="h-4 w-4" />
              </Button>
              
              <Button 
                variant="outline" 
                className="h-10 w-10 p-0"
                onClick={() => window.print()}
                title="طباعة"
              >
                <Printer className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* اختيار المشروع والتقرير */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 print:hidden">
          <div>
            <Label htmlFor="project-select">اختر المشروع</Label>
            <Select 
              value={currentProjectId?.toString() || ''} 
              onValueChange={(value) => {
                setCurrentProjectId(parseInt(value));
                setLocation(`/projects/reports?projectId=${value}`);
              }}
            >
              <SelectTrigger id="project-select" className="w-full">
                <SelectValue placeholder="اختر المشروع" />
              </SelectTrigger>
              <SelectContent>
                {isLoadingProjects ? (
                  <div className="p-2 text-center">جاري التحميل...</div>
                ) : (
                  Array.isArray(projects) ? projects.map((project: any) => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.name}
                    </SelectItem>
                  )) : <div className="p-2 text-center">لا توجد مشاريع</div>
                )}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="report-type">نوع التقرير</Label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger id="report-type" className="w-full">
                <SelectValue placeholder="اختر نوع التقرير" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="budget-vs-expenses">الميزانية مقابل المصروفات</SelectItem>
                <SelectItem value="certificates">المستخلصات والمدفوعات</SelectItem>
                <SelectItem value="profitability">ربحية المشروع</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* عرض التقارير */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden print:shadow-none">
          {/* تقرير الميزانية مقابل المصروفات */}
          {reportType === 'budget-vs-expenses' && (
            <div className="p-6">
              {isLoadingBudgetReport ? (
                <div className="space-y-4">
                  <Skeleton className="h-8 w-1/3" />
                  <Skeleton className="h-[300px] w-full" />
                  <Skeleton className="h-8 w-1/4" />
                  <Skeleton className="h-[200px] w-full" />
                </div>
              ) : !budgetVsExpensesReport ? (
                <div className="text-center py-12">
                  <div className="text-3xl font-semibold text-muted-foreground mb-2">لا توجد بيانات</div>
                  <p className="text-muted-foreground">
                    الرجاء اختيار مشروع آخر أو التأكد من وجود بيانات ميزانية ومصروفات.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">ملخص الميزانية والمصروفات</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">إجمالي الميزانية</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{budgetVsExpensesReport.totalBudget.toLocaleString()} ريال</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">إجمالي المصروفات</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{budgetVsExpensesReport.totalExpenses.toLocaleString()} ريال</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">المتبقي من الميزانية</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{budgetVsExpensesReport.remainingBudget.toLocaleString()} ريال</div>
                          <div className="text-muted-foreground text-sm mt-1">
                            {(budgetVsExpensesReport.budgetConsumptionPercentage).toFixed(1)}% تم استهلاكه
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">الميزانية مقابل المصروفات حسب الفئة</h3>
                      <div className="h-[350px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={budgetVsExpensesReport.items}
                            margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="category" angle={-45} textAnchor="end" height={70} />
                            <YAxis />
                            <Tooltip formatter={(value) => `${value.toLocaleString()} ريال`} />
                            <Legend />
                            <Bar dataKey="budgetAmount" name="الميزانية" fill="#3b82f6" />
                            <Bar dataKey="expenseAmount" name="المصروفات" fill="#10b981" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-4">توزيع المصروفات حسب الفئة</h3>
                      <div className="h-[350px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={budgetVsExpensesReport.items}
                              dataKey="expenseAmount"
                              nameKey="category"
                              cx="50%"
                              cy="50%"
                              innerRadius={70}
                              outerRadius={100}
                              paddingAngle={3}
                              label={({ name, percent }) => `${name} (${(percent * 100).toFixed(1)}%)`}
                              labelLine={true}
                            >
                              {budgetVsExpensesReport.items.map((_entry: any, index: number) => (
                                <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value.toLocaleString()} ريال`} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-4">تفاصيل الميزانية والمصروفات</h3>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="font-semibold">الفئة</TableHead>
                            <TableHead className="font-semibold text-right">الميزانية المخططة</TableHead>
                            <TableHead className="font-semibold text-right">المصروفات الفعلية</TableHead>
                            <TableHead className="font-semibold text-right">الفرق</TableHead>
                            <TableHead className="font-semibold text-right">نسبة الاستهلاك</TableHead>
                            <TableHead className="font-semibold text-right">الحالة</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {budgetVsExpensesReport.items.map((item: any, index: number) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">{item.category}</TableCell>
                              <TableCell className="text-right">{item.budgetAmount.toLocaleString()} ريال</TableCell>
                              <TableCell className="text-right">{item.expenseAmount.toLocaleString()} ريال</TableCell>
                              <TableCell className="text-right">{item.varianceAmount.toLocaleString()} ريال</TableCell>
                              <TableCell className="text-right">{item.consumptionPercentage.toFixed(1)}%</TableCell>
                              <TableCell>
                                <Badge 
                                  variant={item.status === 'overBudget' ? 'destructive' : 
                                          item.status === 'warning' ? 'warning' : 'success'}
                                >
                                  {item.status === 'overBudget' ? 'تجاوز الميزانية' : 
                                   item.status === 'warning' ? 'قرب الحد' : 'ضمن الميزانية'}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* تقرير المستخلصات والمدفوعات */}
          {reportType === 'certificates' && (
            <div className="p-6">
              {isLoadingCertificatesReport ? (
                <div className="space-y-4">
                  <Skeleton className="h-8 w-1/3" />
                  <Skeleton className="h-[300px] w-full" />
                  <Skeleton className="h-8 w-1/4" />
                  <Skeleton className="h-[200px] w-full" />
                </div>
              ) : !certificatesReport ? (
                <div className="text-center py-12">
                  <div className="text-3xl font-semibold text-muted-foreground mb-2">لا توجد بيانات</div>
                  <p className="text-muted-foreground">
                    الرجاء اختيار مشروع آخر أو التأكد من وجود مستخلصات مرتبطة بالمشروع.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">ملخص المستخلصات والمدفوعات</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">قيمة العقد</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{certificatesReport.contractValue.toLocaleString()} ريال</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">إجمالي المستخلصات</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{certificatesReport.totalCertificatesAmount.toLocaleString()} ريال</div>
                          <div className="text-muted-foreground text-sm mt-1">
                            {certificatesReport.certificates.length} مستخلص
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">إجمالي المدفوعات</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{certificatesReport.totalPaidAmount.toLocaleString()} ريال</div>
                          <div className="text-muted-foreground text-sm mt-1">
                            {certificatesReport.paidCertificatesCount} مستخلص مدفوع
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">المتبقي من العقد</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{certificatesReport.remainingContractAmount.toLocaleString()} ريال</div>
                          <div className="text-muted-foreground text-sm mt-1">
                            {certificatesReport.contractExecutionPercentage.toFixed(1)}% تم تنفيذه
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">تقدم المستخلصات</h3>
                      <div className="h-[350px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={certificatesReport.certificates}
                            margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="certificateNumber" angle={-45} textAnchor="end" height={70} />
                            <YAxis />
                            <Tooltip formatter={(value) => `${value.toLocaleString()} ريال`} />
                            <Legend />
                            <Bar dataKey="grossAmount" name="إجمالي المستخلص" fill="#3b82f6" />
                            <Bar dataKey="netAmount" name="صافي المستخلص" fill="#10b981" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-4">حالة المستخلصات</h3>
                      <div className="h-[350px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={certificatesReport.certificatesByStatus}
                              dataKey="count"
                              nameKey="status"
                              cx="50%"
                              cy="50%"
                              innerRadius={70}
                              outerRadius={100}
                              paddingAngle={3}
                              label={({ name, percent }) => `${name} (${(percent * 100).toFixed(1)}%)`}
                              labelLine={true}
                            >
                              {certificatesReport.certificatesByStatus.map((_entry: any, index: number) => (
                                <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value} مستخلص`} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-4">تفاصيل المستخلصات</h3>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="font-semibold">المستخلص</TableHead>
                            <TableHead className="font-semibold">التاريخ</TableHead>
                            <TableHead className="font-semibold text-right">المبلغ الإجمالي</TableHead>
                            <TableHead className="font-semibold text-right">الخصومات</TableHead>
                            <TableHead className="font-semibold text-right">الصافي</TableHead>
                            <TableHead className="font-semibold">الحالة</TableHead>
                            <TableHead className="font-semibold">تاريخ الدفع</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {certificatesReport.certificates.map((certificate: any) => (
                            <TableRow key={certificate.id}>
                              <TableCell className="font-medium">
                                المستخلص {certificate.certificateNumber}
                              </TableCell>
                              <TableCell>{new Date(certificate.issueDate).toLocaleDateString('ar-SA')}</TableCell>
                              <TableCell className="text-right">{certificate.grossAmount ? certificate.grossAmount.toLocaleString() : 0} ريال</TableCell>
                              <TableCell className="text-right">{certificate.grossAmount && certificate.netAmount ? (certificate.grossAmount - certificate.netAmount).toLocaleString() : 0} ريال</TableCell>
                              <TableCell className="text-right">{certificate.netAmount ? certificate.netAmount.toLocaleString() : 0} ريال</TableCell>
                              <TableCell>
                                <Badge 
                                  variant={
                                    certificate.status === 'draft' ? 'outline' :
                                    certificate.status === 'submitted' ? 'secondary' :
                                    certificate.status === 'approved' ? 'success' :
                                    certificate.status === 'paid' ? 'default' : 'outline'
                                  }
                                >
                                  {certificate.status === 'draft' ? 'مسودة' :
                                   certificate.status === 'submitted' ? 'قيد المراجعة' :
                                   certificate.status === 'approved' ? 'معتمد' :
                                   certificate.status === 'paid' ? 'مدفوع' : certificate.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {certificate.paymentDate 
                                  ? new Date(certificate.paymentDate).toLocaleDateString('ar-SA')
                                  : '-'
                                }
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* تقرير ربحية المشروع */}
          {reportType === 'profitability' && (
            <div className="p-6">
              {isLoadingProfitabilityReport ? (
                <div className="space-y-4">
                  <Skeleton className="h-8 w-1/3" />
                  <Skeleton className="h-[300px] w-full" />
                  <Skeleton className="h-8 w-1/4" />
                  <Skeleton className="h-[200px] w-full" />
                </div>
              ) : !profitabilityReport ? (
                <div className="text-center py-12">
                  <div className="text-3xl font-semibold text-muted-foreground mb-2">لا توجد بيانات</div>
                  <p className="text-muted-foreground">
                    الرجاء اختيار مشروع آخر أو التأكد من وجود بيانات مالية كافية للمشروع.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">ملخص الربحية</h3>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">قيمة العقد</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{profitabilityReport.contractValue.toLocaleString()} ريال</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">إجمالي المصروفات</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{profitabilityReport.totalExpenses.toLocaleString()} ريال</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">الربح المتوقع</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{profitabilityReport.estimatedProfit.toLocaleString()} ريال</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">هامش الربح</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{profitabilityReport.profitMargin.toFixed(2)}%</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">نسبة الإنجاز المالي</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{profitabilityReport.financialCompletion.toFixed(2)}%</div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">الإيرادات مقابل التكاليف حسب الفترة</h3>
                      <div className="h-[350px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={profitabilityReport.monthlyProfitability}
                            margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" angle={-45} textAnchor="end" height={70} />
                            <YAxis />
                            <Tooltip formatter={(value) => `${value.toLocaleString()} ريال`} />
                            <Legend />
                            <Bar dataKey="revenue" name="الإيرادات" fill="#3b82f6" />
                            <Bar dataKey="expenses" name="المصروفات" fill="#ef4444" />
                            <Bar dataKey="profit" name="الربح" fill="#10b981" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-4">توزيع المصروفات حسب النوع</h3>
                      <div className="h-[350px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={profitabilityReport.expensesByType}
                              dataKey="amount"
                              nameKey="type"
                              cx="50%"
                              cy="50%"
                              innerRadius={70}
                              outerRadius={100}
                              paddingAngle={3}
                              label={({ name, percent }) => `${name} (${(percent * 100).toFixed(1)}%)`}
                              labelLine={true}
                            >
                              {profitabilityReport.expensesByType.map((_entry: any, index: number) => (
                                <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value.toLocaleString()} ريال`} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">تفاصيل المصروفات حسب النوع</h3>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="font-semibold">نوع المصروف</TableHead>
                              <TableHead className="font-semibold text-right">المبلغ</TableHead>
                              <TableHead className="font-semibold text-right">عدد المعاملات</TableHead>
                              <TableHead className="font-semibold text-right">النسبة من الإجمالي</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {profitabilityReport.expensesByType.map((item: any, index: number) => {
                              const percentage = (item.amount / profitabilityReport.totalExpenses) * 100;
                              return (
                                <TableRow key={index}>
                                  <TableCell className="font-medium">{item.type}</TableCell>
                                  <TableCell className="text-right">{item.amount.toLocaleString()} ريال</TableCell>
                                  <TableCell className="text-right">{item.count}</TableCell>
                                  <TableCell className="text-right">{percentage.toFixed(2)}%</TableCell>
                                </TableRow>
                              );
                            })}
                            <TableRow className="font-semibold bg-muted/50">
                              <TableCell>الإجمالي</TableCell>
                              <TableCell className="text-right">{profitabilityReport.totalExpenses.toLocaleString()} ريال</TableCell>
                              <TableCell className="text-right">{profitabilityReport.expensesByType.reduce((acc, item) => acc + item.count, 0)}</TableCell>
                              <TableCell className="text-right">100%</TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-4">مؤشرات الربحية والتوقعات</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">الهامش المستهدف</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{profitabilityReport.targetMargin}%</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">الانحراف عن الهدف</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{profitabilityReport.marginVariance}%</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">المصروفات المتبقية المتوقعة</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{Math.round(profitabilityReport.estimatedRemainingExpenses).toLocaleString()} ريال</div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-muted-foreground text-base">الربح النهائي المتوقع</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{Math.round(profitabilityReport.estimatedFinalProfit).toLocaleString()} ريال</div>
                          <div className="text-muted-foreground text-sm mt-1">
                            هامش الربح النهائي المتوقع: {profitabilityReport.estimatedFinalMargin}%
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* مربع حوار الفلترة */}
      <Dialog open={showFilterDialog} onOpenChange={setShowFilterDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>فلترة التقارير</DialogTitle>
            <DialogDescription>
              حدد الفترة الزمنية وعوامل الفلترة الأخرى لتخصيص التقارير.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start-date">من تاريخ</Label>
                <Input 
                  id="start-date" 
                  type="date" 
                  value={dateRange.startDate}
                  onChange={(e) => setDateRange(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end-date">إلى تاريخ</Label>
                <Input 
                  id="end-date" 
                  type="date"
                  value={dateRange.endDate}
                  onChange={(e) => setDateRange(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>
            </div>
            
            {reportType === 'budget-vs-expenses' && (
              <div className="space-y-2">
                <Label htmlFor="expense-categories">فئات المصروفات</Label>
                <Select defaultValue="all">
                  <SelectTrigger id="expense-categories">
                    <SelectValue placeholder="اختر فئات المصروفات" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الفئات</SelectItem>
                    <SelectItem value="materials">المواد</SelectItem>
                    <SelectItem value="labor">العمالة</SelectItem>
                    <SelectItem value="equipment">المعدات</SelectItem>
                    <SelectItem value="subcontractors">المقاولين من الباطن</SelectItem>
                    <SelectItem value="overhead">التكاليف العامة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            {reportType === 'certificates' && (
              <div className="space-y-2">
                <Label htmlFor="certificate-status">حالة المستخلصات</Label>
                <Select defaultValue="all">
                  <SelectTrigger id="certificate-status">
                    <SelectValue placeholder="اختر حالة المستخلصات" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الحالات</SelectItem>
                    <SelectItem value="draft">مسودة</SelectItem>
                    <SelectItem value="submitted">قيد المراجعة</SelectItem>
                    <SelectItem value="approved">معتمد</SelectItem>
                    <SelectItem value="paid">مدفوع</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="comparison">المقارنة</Label>
              <Select defaultValue="previous">
                <SelectTrigger id="comparison">
                  <SelectValue placeholder="اختر نوع المقارنة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="previous">المقارنة مع الفترة السابقة</SelectItem>
                  <SelectItem value="annual">المقارنة سنوياً</SelectItem>
                  <SelectItem value="target">المقارنة مع الأهداف</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFilterDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={() => {
              // تطبيق الفلترة هنا
              refreshCurrentReport();
              setShowFilterDialog(false);
            }}>
              تطبيق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}