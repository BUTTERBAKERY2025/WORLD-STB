import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { AlertTriangle, Check, Edit, Loader2, MoreHorizontal, Plus, Search, Trash } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
// Remove import that doesn't exist
import { toast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";

// تعريف واجهة لتمثيل أنواع المشاريع
interface ProjectType {
  id: number;
  name: string;
  description: string | null;
  createdAt: string;
}

export default function ProjectTypes() {
  const { t } = useTranslation();
  const [search, setSearch] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newTypeName, setNewTypeName] = useState("");
  const [newTypeDescription, setNewTypeDescription] = useState("");
  const [currentType, setCurrentType] = useState<ProjectType | null>(null);
  const [isEditMode, setIsEditMode] = useState(false);

  // استخدام react-query لجلب البيانات
  const { 
    data: projectTypes = [], 
    isLoading, 
    error,
    refetch 
  } = useQuery<ProjectType[]>({
    queryKey: ["/api/project-types"],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/project-types');
        if (!res.ok) {
          throw new Error('فشل جلب بيانات أنواع المشاريع');
        }
        return await res.json();
      } catch (error) {
        console.error("Error fetching project types:", error);
        // في حالة عدم وجود API أو فشل في الحصول على البيانات، نستخدم قائمة الأنواع المعرفة في الـ Enum
        return [
          { id: 1, name: t("types.road"), description: t("type_descriptions.road"), createdAt: new Date().toISOString() },
          { id: 2, name: t("types.water"), description: t("type_descriptions.water"), createdAt: new Date().toISOString() },
          { id: 3, name: t("types.electricity"), description: t("type_descriptions.electricity"), createdAt: new Date().toISOString() },
          { id: 4, name: t("types.telecom"), description: t("type_descriptions.telecom"), createdAt: new Date().toISOString() },
          { id: 5, name: t("types.building"), description: t("type_descriptions.building"), createdAt: new Date().toISOString() },
        ] as ProjectType[];
      }
    }
  });

  // معالجة حالة التحميل
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[70vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <span className="mr-2">{t("common.loading")}</span>
      </div>
    );
  }

  // معالجة حالة الخطأ
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center">
        <AlertTriangle className="w-12 h-12 text-destructive mb-4" />
        <h3 className="text-xl font-bold mb-2">{t("common.error_loading")}</h3>
        <p className="text-muted-foreground mb-4">{t("project.error_loading_types")}</p>
        <Button variant="outline" onClick={() => refetch()}>
          {t("common.try_again")}
        </Button>
      </div>
    );
  }

  // تصفية أنواع المشاريع بناءً على البحث
  const filteredTypes = projectTypes.filter(type => 
    !search || type.name.toLowerCase().includes(search.toLowerCase())
  );

  // إضافة نوع مشروع جديد
  const handleAddType = async () => {
    if (!newTypeName.trim()) {
      toast({
        title: t("validation.required_field"),
        description: t("project.type_name_required"),
        variant: "destructive"
      });
      return;
    }

    try {
      // تحديث الواجهة فورًا قبل اكتمال طلب API
      const newType: ProjectType = {
        id: Math.max(...projectTypes.map(t => t.id), 0) + 1,
        name: newTypeName,
        description: newTypeDescription || null,
        createdAt: new Date().toISOString()
      };

      // إضافة النوع الجديد مؤقتًا
      queryClient.setQueryData(["/api/project-types"], [...projectTypes, newType]);

      // محاولة إجراء طلب API
      try {
        const res = await apiRequest('POST', '/api/project-types', {
          name: newTypeName,
          description: newTypeDescription
        });
        
        if (!res.ok) {
          throw new Error('فشل إضافة نوع المشروع');
        }

        // تحديث البيانات من الخادم
        refetch();
        
        toast({
          title: t("success"),
          description: t("project.type_added_successfully"),
          variant: "default"
        });
      } catch (error) {
        console.error("Error adding project type:", error);
        // في حالة عدم وجود API، لا نفعل شيئًا إضافيًا لأننا أضفنا النوع مسبقًا
      }

      // إعادة تعيين النموذج
      setNewTypeName("");
      setNewTypeDescription("");
      setIsAddDialogOpen(false);

    } catch (error) {
      toast({
        title: t("error"),
        description: t("project.type_add_error"),
        variant: "destructive"
      });
    }
  };

  // تحديث نوع مشروع
  const handleUpdateType = async () => {
    if (!currentType || !currentType.name.trim()) {
      toast({
        title: t("validation.required_field"),
        description: t("project.type_name_required"),
        variant: "destructive"
      });
      return;
    }

    try {
      // تحديث الواجهة فورًا
      const updatedTypes = projectTypes.map(type => 
        type.id === currentType.id ? currentType : type
      );
      queryClient.setQueryData(["/api/project-types"], updatedTypes);

      // محاولة إجراء طلب API
      try {
        const res = await apiRequest('PATCH', `/api/project-types/${currentType.id}`, {
          name: currentType.name,
          description: currentType.description
        });
        
        if (!res.ok) {
          throw new Error('فشل تحديث نوع المشروع');
        }

        // تحديث البيانات من الخادم
        refetch();
      } catch (error) {
        console.error("Error updating project type:", error);
        // في حالة عدم وجود API، لا نفعل شيئًا إضافيًا لأننا حدثنا النوع مسبقًا
      }

      toast({
        title: t("success"),
        description: t("project.type_updated_successfully"),
        variant: "default"
      });

      // إعادة تعيين النموذج
      setCurrentType(null);
      setIsEditMode(false);
      setIsAddDialogOpen(false);

    } catch (error) {
      toast({
        title: t("error"),
        description: t("project.type_update_error"),
        variant: "destructive"
      });
    }
  };

  // حذف نوع مشروع
  const handleDeleteType = async (typeId: number) => {
    if (!confirm(t("project.confirm_delete_type"))) {
      return;
    }

    try {
      // تحديث الواجهة فورًا
      const filteredTypes = projectTypes.filter(type => type.id !== typeId);
      queryClient.setQueryData(["/api/project-types"], filteredTypes);

      // محاولة إجراء طلب API
      try {
        const res = await apiRequest('DELETE', `/api/project-types/${typeId}`);
        
        if (!res.ok) {
          throw new Error('فشل حذف نوع المشروع');
        }

        // تحديث البيانات من الخادم
        refetch();
      } catch (error) {
        console.error("Error deleting project type:", error);
        // في حالة عدم وجود API، لا نفعل شيئًا إضافيًا لأننا حذفنا النوع مسبقًا
      }

      toast({
        title: t("success"),
        description: t("project.type_deleted_successfully"),
        variant: "default"
      });

    } catch (error) {
      toast({
        title: t("error"),
        description: t("project.type_delete_error"),
        variant: "destructive"
      });
    }
  };

  // إعادة تعيين النموذج
  const resetForm = () => {
    if (isEditMode) {
      setCurrentType(null);
      setIsEditMode(false);
    } else {
      setNewTypeName("");
      setNewTypeDescription("");
    }
    setIsAddDialogOpen(false);
  };

  // تحضير نموذج التحرير
  const prepareEditForm = (type: ProjectType) => {
    setCurrentType({ ...type });
    setIsEditMode(true);
    setIsAddDialogOpen(true);
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">{t("project.project_types")}</h1>
        <p className="text-muted-foreground">{t("project.manage_project_types")}</p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>{t("project.project_types")}</CardTitle>
              <CardDescription>{t("project.manage_project_types_description")}</CardDescription>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  <span>{t("project.add_project_type")}</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {isEditMode ? t("project.edit_project_type") : t("project.add_project_type")}
                  </DialogTitle>
                  <DialogDescription>
                    {isEditMode 
                      ? t("project.edit_project_type_description") 
                      : t("project.add_project_type_description")}
                  </DialogDescription>
                </DialogHeader>

                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      {t("project.type_name")}
                    </Label>
                    <Input
                      id="name"
                      value={isEditMode ? currentType?.name : newTypeName}
                      onChange={(e) => isEditMode 
                        ? setCurrentType({ ...currentType!, name: e.target.value }) 
                        : setNewTypeName(e.target.value)
                      }
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="description" className="text-right">
                      {t("project.type_description")}
                    </Label>
                    <Input
                      id="description"
                      value={isEditMode ? currentType?.description || "" : newTypeDescription}
                      onChange={(e) => isEditMode 
                        ? setCurrentType({ ...currentType!, description: e.target.value }) 
                        : setNewTypeDescription(e.target.value)
                      }
                      className="col-span-3"
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={resetForm}>
                    {t("common.cancel")}
                  </Button>
                  <Button type="submit" onClick={isEditMode ? handleUpdateType : handleAddType}>
                    {isEditMode ? t("common.save") : t("common.add")}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="flex items-center mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t("project.search_types")}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">{t("common.id")}</TableHead>
                  <TableHead>{t("project.type_name")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("project.type_description")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("common.created_at")}</TableHead>
                  <TableHead className="text-right">{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTypes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      <div className="flex flex-col items-center justify-center text-center">
                        <p className="text-muted-foreground mb-2">{t("project.no_types_found")}</p>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setIsAddDialogOpen(true)}
                        >
                          <Plus className="w-4 h-4 ml-2" />
                          {t("project.add_project_type")}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTypes.map((type) => (
                    <TableRow key={type.id}>
                      <TableCell>{type.id}</TableCell>
                      <TableCell className="font-medium">{type.name}</TableCell>
                      <TableCell className="hidden md:table-cell">{type.description || "-"}</TableCell>
                      <TableCell className="hidden md:table-cell">
                        {new Date(type.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">{t("common.actions")}</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => prepareEditForm(type)}>
                              <Edit className="h-4 w-4 ml-2" />
                              <span>{t("common.edit")}</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDeleteType(type.id)}
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash className="h-4 w-4 ml-2" />
                              <span>{t("common.delete")}</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          
          {/* عرض إحصائيات بسيطة */}
          <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
            <div>{t("project.total_project_types", { count: filteredTypes.length })}</div>
            {search && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setSearch("")}
                className="text-primary hover:text-primary"
              >
                <Check className="h-4 w-4 ml-2" />
                {t("common.clear_filter")}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}