import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Link } from "wouter";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressWithText } from "@/components/ui/progress-with-text";
import { Currency } from "@/components/ui/currency";
import { AlertTriangle, Filter, Edit, Loader2, MoreHorizontal, Plus, Search } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Project } from "@shared/schema";

export default function AllProjects() {
  const { t } = useTranslation();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  // استخدام react-query لجلب البيانات
  const { 
    data: projects = [], 
    isLoading, 
    error 
  } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/projects');
      if (!res.ok) {
        throw new Error('فشل جلب بيانات المشاريع');
      }
      return await res.json();
    }
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[70vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <span className="mr-2">{t("common.loading")}</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center">
        <AlertTriangle className="w-12 h-12 text-destructive mb-4" />
        <h3 className="text-xl font-bold mb-2">{t("common.error_loading")}</h3>
        <p className="text-muted-foreground mb-4">{t("project.error_loading_message")}</p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          {t("common.try_again")}
        </Button>
      </div>
    );
  }

  if (!projects || projects.length === 0) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex flex-col space-y-2 mb-6">
          <h1 className="text-3xl font-bold tracking-tight">{t("project.all_projects")}</h1>
          <p className="text-muted-foreground">{t("project.manage_projects")}</p>
        </div>
        
        <div className="flex flex-col items-center justify-center h-[50vh] text-center">
          <h3 className="text-xl font-bold mb-2">{t("project.no_projects_found")}</h3>
          <p className="text-muted-foreground mb-4">{t("project.no_projects_description")}</p>
          <Button asChild>
            <Link href="/projects/new">
              <Plus className="w-4 h-4 ml-2" />
              {t("project.create")}
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  // تصفية المشاريع استنادًا إلى البحث والنوع والحالة
  const filteredProjects = projects.filter(project => {
    const searchMatch = !search || project.name.toLowerCase().includes(search.toLowerCase());
    const typeMatch = typeFilter === "all" || project.type === typeFilter;
    const statusMatch = statusFilter === "all" || project.status === statusFilter;
    
    return searchMatch && typeMatch && statusMatch;
  });

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">{t("project.all_projects")}</h1>
        <p className="text-muted-foreground">{t("project.manage_projects")}</p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>{t("project.all_projects")}</CardTitle>
              <CardDescription>{t("project.manage_projects")}</CardDescription>
            </div>
            <Button asChild>
              <Link href="/projects/new">
                <Plus className="w-4 h-4 ml-2" />
                {t("project.create")}
              </Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t("search.placeholder")}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:w-2/5">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder={t("project.filter_by_type")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                  <SelectItem value="road">
                    <div className="flex items-center">
                      <span className="ml-2">{t("types.road")}</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="water">
                    <div className="flex items-center">
                      <span className="ml-2">{t("types.water")}</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="electricity">
                    <div className="flex items-center">
                      <span className="ml-2">{t("types.electricity")}</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="telecom">
                    <div className="flex items-center">
                      <span className="ml-2">{t("types.telecom")}</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="building">
                    <div className="flex items-center">
                      <span className="ml-2">{t("types.building")}</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder={t("project.filter_by_status")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                  <SelectItem value="planning">
                    <StatusBadge status="planning" size="sm" />
                  </SelectItem>
                  <SelectItem value="in_progress">
                    <StatusBadge status="in_progress" size="sm" />
                  </SelectItem>
                  <SelectItem value="delayed">
                    <StatusBadge status="delayed" size="sm" />
                  </SelectItem>
                  <SelectItem value="completed">
                    <StatusBadge status="completed" size="sm" />
                  </SelectItem>
                  <SelectItem value="stopped">
                    <StatusBadge status="stopped" size="sm" />
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between mb-4">
            <div className="text-sm text-muted-foreground">
              {t("project.filtered_results", { count: filteredProjects.length })}
            </div>
            {(typeFilter !== "all" || statusFilter !== "all") && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => {
                  setTypeFilter("all");
                  setStatusFilter("all");
                }}
                className="text-primary hover:text-primary"
              >
                <Filter className="h-4 w-4 ml-2" />
                {t("project.clear_filters")}
              </Button>
            )}
          </div>

          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[250px]">{t("project.name")}</TableHead>
                  <TableHead>{t("type")}</TableHead>
                  <TableHead>{t("status")}</TableHead>
                  <TableHead>{t("common.progress")}</TableHead>
                  <TableHead>{t("budget")}</TableHead>
                  <TableHead className="text-right">{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProjects.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">
                      <Link href={`/projects/${project.id}`} className="hover:text-primary hover:underline">
                        {project.name}
                      </Link>
                    </TableCell>
                    <TableCell>
                      <ProjectTypeBadge type={project.type} size="sm" />
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={project.status} size="sm" />
                    </TableCell>
                    <TableCell>
                      <ProgressWithText value={project.progress || 0} size="sm" />
                    </TableCell>
                    <TableCell>
                      <Currency amount={project.budget || 0} symbolSize="sm" />
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">{t("common.actions")}</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link href={`/projects/${project.id}`} className="flex items-center">
                              <Search className="h-4 w-4 ml-2" />
                              <span>{t("common.view")}</span>
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <Link href={`/projects/${project.id}/edit`} className="flex items-center">
                              <Edit className="h-4 w-4 ml-2" />
                              <span>{t("common.edit")}</span>
                            </Link>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}