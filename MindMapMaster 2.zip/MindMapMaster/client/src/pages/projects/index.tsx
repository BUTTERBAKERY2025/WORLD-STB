import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressWithText } from "@/components/ui/progress-with-text";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Currency } from "@/components/ui/currency";
import { Project, projectTypeEnum, projectStatusEnum } from "@shared/schema";
import { Gauge, Building, Construction, Plus, BadgePercent, Filter, RefreshCw, Search, PlusCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

// عملية تحميل البيانات من قاعدة البيانات
// استخدم apiRequest من @/lib/queryClient بدلاً من fetch
const fetchProjects = async (): Promise<Project[]> => {
  try {
    const response = await apiRequest('GET', '/api/projects');
    
    if (!response.ok) {
      throw new Error(`فشل جلب بيانات المشاريع: ${response.status}`);
    }
    
    const data = await response.json();
    return data as Project[];
  } catch (error) {
    console.error("خطأ في جلب المشاريع:", error);
    throw error;
  }
};

// بيانات مؤقتة للعرض
// لقد تم إزالة البيانات الوهمية (sampleProjects) لأنها لم تعد مطلوبة
// نستخدم بدلاً منها بيانات حقيقية من قاعدة البيانات

// مكون إدارة المشاريع
export default function Projects() {
  const { t, i18n } = useTranslation();
  const [projectTypeFilter, setProjectTypeFilter] = useState<string>("all");
  const [projectStatusFilter, setProjectStatusFilter] = useState<string>("all");
  const [viewType, setViewType] = useState<string>("cards"); // cards or table
  const [location] = useLocation();
  
  // استخدام useEffect لمراقبة تغيرات URL وتحديث الفلتر بناء عليها
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const typeParam = urlParams.get('type');
    
    if (typeParam && Object.values(projectTypeEnum).includes(typeParam as any)) {
      setProjectTypeFilter(typeParam);
    } else if (!typeParam) {
      setProjectTypeFilter("all");
    }
  }, [location]);
  
  // لا حاجة لهذا الكود بعد الآن، تم استبداله بـ useEffect أعلاه
  
  // جلب المشاريع من API
  const { data: projects = [], isLoading, error } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    queryFn: fetchProjects,
    staleTime: 60000, // 1 minute
  });
  
  // تصفية المشاريع بناءً على الفلاتر المحددة
  const filteredProjects = projects.filter(project => {
    // استخدام فلتر النوع من قيمة projectTypeFilter فقط
    // هذه القيمة يتم تحديثها تلقائيًا من خلال useEffect عند تغير URL
    const matchesType = projectTypeFilter === "all" || project.type === projectTypeFilter;
    const matchesStatus = projectStatusFilter === "all" || project.status === projectStatusFilter;
    
    return matchesType && matchesStatus;
  });

  const getIconBgByType = (type: string) => {
    switch (type) {
      case "road": return "bg-blue-600";
      case "water": return "bg-cyan-600";
      case "electricity": return "bg-yellow-600";
      case "telecom": return "bg-purple-600";
      case "building": return "bg-green-600";
      default: return "bg-gray-600";
    }
  };

  const getProjectIconByType = (type: string) => {
    switch (type) {
      case "road": return "add_road";
      case "water": return "water_drop";
      case "electricity": return "bolt";
      case "telecom": return "cell_tower";
      case "building": return "apartment";
      default: return "construction";
    }
  };
  
  return (
    <div className="container mx-auto p-4 md:p-6">
      {/* رأس المشاريع */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">{t("project.title")}</h1>
          <p className="text-gray-600 text-sm">{t("project.manage_projects")}</p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Button asChild>
            <Link href="/projects/new">
              <span className="material-icons ml-2">add</span>
              {t("project.create")}
            </Link>
          </Button>
        </div>
      </div>
      
      {/* فلاتر وخيارات العرض */}
      <div className="bg-white p-4 rounded-lg shadow-sm border mb-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-5 lg:col-span-4">
            <label className="text-sm font-medium text-gray-700 mb-1 block">
              {t("project.filter_by_type")}
            </label>
            <Select
              value={projectTypeFilter}
              onValueChange={setProjectTypeFilter}
            >
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder={t("project.filter_by_type")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                <SelectItem value="road">
                  <div className="flex items-center">
                    <span className={`material-icons text-sm ml-1 text-blue-600`}>add_road</span>
                    {t("types.road")}
                  </div>
                </SelectItem>
                <SelectItem value="water">
                  <div className="flex items-center">
                    <span className={`material-icons text-sm ml-1 text-cyan-600`}>water_drop</span>
                    {t("types.water")}
                  </div>
                </SelectItem>
                <SelectItem value="electricity">
                  <div className="flex items-center">
                    <span className={`material-icons text-sm ml-1 text-yellow-600`}>bolt</span>
                    {t("types.electricity")}
                  </div>
                </SelectItem>
                <SelectItem value="telecom">
                  <div className="flex items-center">
                    <span className={`material-icons text-sm ml-1 text-purple-600`}>cell_tower</span>
                    {t("types.telecom")}
                  </div>
                </SelectItem>
                <SelectItem value="building">
                  <div className="flex items-center">
                    <span className={`material-icons text-sm ml-1 text-green-600`}>apartment</span>
                    {t("types.building")}
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="md:col-span-5 lg:col-span-4">
            <label className="text-sm font-medium text-gray-700 mb-1 block">
              {t("project.filter_by_status")}
            </label>
            <Select
              value={projectStatusFilter}
              onValueChange={setProjectStatusFilter}
            >
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder={t("project.filter_by_status")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("project.filter.all")}</SelectItem>
                <SelectItem value="planning">
                  <StatusBadge status="planning" size="sm" />
                </SelectItem>
                <SelectItem value="in_progress">
                  <StatusBadge status="in_progress" size="sm" />
                </SelectItem>
                <SelectItem value="delayed">
                  <StatusBadge status="delayed" size="sm" />
                </SelectItem>
                <SelectItem value="completed">
                  <StatusBadge status="completed" size="sm" />
                </SelectItem>
                <SelectItem value="stopped">
                  <StatusBadge status="stopped" size="sm" />
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="md:col-span-2 lg:col-span-4 flex justify-end items-end">
            <Tabs value={viewType} onValueChange={setViewType} className="min-w-[200px]">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="cards" className="flex items-center">
                  <span className="material-icons text-sm ml-1">grid_view</span>
                  {t("view.cards")}
                </TabsTrigger>
                <TabsTrigger value="table" className="flex items-center">
                  <span className="material-icons text-sm ml-1">view_list</span>
                  {t("view.table")}
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
        
        {/* عرض نتائج التصفية */}
        <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-sm">
          <div className="text-gray-500">
            {t("project.filtered_results", { count: filteredProjects.length })}
          </div>
          {(projectTypeFilter !== "all" || projectStatusFilter !== "all") && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => {
                setProjectTypeFilter("all");
                setProjectStatusFilter("all");
              }}
              className="text-primary hover:text-primary"
            >
              <span className="material-icons text-sm ml-1">filter_alt_off</span>
              {t("project.clear_filters")}
            </Button>
          )}
        </div>
      </div>
      
      {/* عرض شاشة التحميل */}
      {isLoading && (
        <Card className="mb-8">
          <CardContent className="flex items-center justify-center h-40">
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-4 text-gray-600">{t("loading")}</p>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* عرض رسالة الخطأ */}
      {error && (
        <Card className="mb-8 border-red-200">
          <CardContent className="flex flex-col items-center justify-center py-10">
            <div className="rounded-full bg-red-100 p-3 mb-4">
              <span className="material-icons text-red-600 text-2xl">error_outline</span>
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">{t("common.error_loading")}</h3>
            <p className="text-gray-600 mb-6 text-center max-w-md">
              {t("project.error_loading_message", { defaultValue: "حدث خطأ أثناء تحميل بيانات المشاريع. يرجى المحاولة مرة أخرى." })}
            </p>
            <Button 
              onClick={() => window.location.reload()} 
              variant="outline"
              className="flex items-center"
            >
              <span className="material-icons ml-2 text-sm">refresh</span>
              {t("common.try_again")}
            </Button>
          </CardContent>
        </Card>
      )}
      
      {/* عرض المحتوى حسب نوع العرض */}
      {!isLoading && filteredProjects.length > 0 && viewType === "table" && (
        <Card className="mb-8 overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">{t("project.name")}</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">{t("type")}</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">{t("status")}</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">{t("project.progress")}</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">{t("budget")}</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">{t("common.actions")}</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredProjects.map((project) => (
                    <tr key={project.id} className="hover:bg-muted/20">
                      <td className="px-4 py-3 text-right">
                        <Link href={`/projects/${project.id}`} className="font-medium text-primary hover:underline">
                          {project.name}
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <ProjectTypeBadge type={project.type} size="sm" />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <StatusBadge status={project.status} size="sm" />
                      </td>
                      <td className="px-4 py-3 text-right w-40">
                        <ProgressWithText value={project.progress || 0} size="sm" />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Currency amount={project.budget || 0} />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <span className="material-icons">more_vert</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                              <Link href={`/projects/${project.id}`} className="flex items-center">
                                <span className="material-icons text-sm ml-2">visibility</span>
                                {t("common.view")}
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link href={`/projects/${project.id}/edit`} className="flex items-center">
                                <span className="material-icons text-sm ml-2">edit</span>
                                {t("common.edit")}
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600 hover:text-red-700 hover:bg-red-50">
                              <span className="material-icons text-sm ml-2">delete</span>
                              {t("common.delete")}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
      
      {!isLoading && filteredProjects.length > 0 && viewType === "cards" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredProjects.map((project) => (
            <Card 
              key={project.id} 
              className="group overflow-hidden hover:shadow-lg transition-all duration-300 border border-gray-200"
            >
              <div 
                className={`h-2 w-full ${
                  project.status === 'in_progress' ? 'bg-emerald-500' : 
                  project.status === 'delayed' ? 'bg-amber-500' : 
                  project.status === 'completed' ? 'bg-violet-500' : 
                  project.status === 'stopped' ? 'bg-red-500' : 'bg-blue-500'
                }`}
              />
              <CardHeader className="pb-2 pt-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-start">
                    <div className={`w-12 h-12 flex-shrink-0 rounded-lg ${getIconBgByType(project.type)} flex items-center justify-center text-white ml-3 shadow-md transform group-hover:scale-110 transition-transform duration-300`}>
                      <span className="material-icons text-xl">{getProjectIconByType(project.type)}</span>
                    </div>
                    <div>
                      <CardTitle className="text-base hover:text-primary transition-colors mb-1">
                        <Link href={`/projects/${project.id}`} className="block hover:underline">
                          {project.name}
                        </Link>
                      </CardTitle>
                      <CardDescription className="text-xs flex items-center mb-0">
                        <span className="material-icons text-xs ml-0.5 text-gray-400">calendar_today</span>
                        {project.startDate && project.endDate && (
                          <span className="mr-1">
                            {formatDate(project.startDate)} - {formatDate(project.endDate)}
                          </span>
                        )}
                      </CardDescription>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 opacity-70 hover:opacity-100 hover:bg-gray-100">
                        <span className="material-icons">more_vert</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuItem asChild>
                        <Link href={`/projects/${project.id}`} className="flex items-center">
                          <span className="material-icons text-sm ml-2">visibility</span>
                          {t("common.view")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href={`/projects/${project.id}/edit`} className="flex items-center">
                          <span className="material-icons text-sm ml-2">edit</span>
                          {t("common.edit")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        <span className="material-icons text-sm ml-2">delete</span>
                        {t("common.delete")}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-5">
                  <p className="text-sm text-gray-600 line-clamp-2 min-h-[40px]">{project.description}</p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-lg space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <div className="text-gray-500 flex items-center">
                        <Gauge className="h-4 w-4 ml-1 text-gray-400" />
                        {t("project.progress")}
                      </div>
                      <div className="font-medium">{project.progress ?? 0}%</div>
                    </div>
                    {/* استخدام معامل التوسع نلسن (??) بدلاً من (||) للتعامل مع القيم الصفرية بشكل صحيح */}
                    <ProgressWithText 
                      value={project.progress ?? 0} 
                      showText={false} 
                      className={`h-2 ${
                        (project.progress ?? 0) >= 80 ? 'bg-emerald-500' : 
                        (project.progress ?? 0) >= 50 ? 'bg-blue-500' : 
                        (project.progress ?? 0) >= 25 ? 'bg-amber-500' : 'bg-red-500'
                      }`}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between text-sm pt-2">
                    <div className="text-gray-500 flex items-center">
                      <Building className="h-4 w-4 ml-1 text-gray-400" />
                      {t("budget")}
                    </div>
                    <div className="font-medium">
                      <Currency amount={project.budget || 0} symbolSize="sm" />
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between mt-4 pt-3 border-t border-gray-100">
                  <StatusBadge status={project.status} size="sm" />
                  <ProjectTypeBadge type={project.type} size="sm" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* عرض حالة عدم وجود مشاريع */}
      {!isLoading && filteredProjects.length === 0 && (
        <Card className="mt-6">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Construction className="h-20 w-20 text-gray-300 mb-4" />
            <h3 className="text-xl font-medium text-gray-700 mb-2">{t("project.no_projects_found")}</h3>
            <p className="text-gray-500 mb-6">{t("project.no_projects_description")}</p>
            <Button asChild>
              <Link href="/projects/new">
                <Plus className="h-4 w-4 ml-2" />
                {t("project.create")}
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}