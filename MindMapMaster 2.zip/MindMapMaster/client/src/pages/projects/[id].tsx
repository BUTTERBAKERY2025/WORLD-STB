import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { useTranslation } from "react-i18next";
import { useState, useRef, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { ProgressWithText } from "@/components/ui/progress-with-text";
import { Currency } from "@/components/ui/currency";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { useToast } from "@/hooks/use-toast";
import { Project, Task, FinancialTransaction, Document, ProjectPhoto } from "@shared/schema";
import { formatDate, formatCurrency } from "@/lib/utils";

export default function ProjectDetails() {
  const { t } = useTranslation();
  const [, params] = useRoute<{ id: string }>("/projects/:id");
  const projectId = params ? parseInt(params.id) : 0;
  const [activeTab, setActiveTab] = useState("overview");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [photoUploadError, setPhotoUploadError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [photoDescription, setPhotoDescription] = useState("");
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [viewPhoto, setViewPhoto] = useState<ProjectPhoto | null>(null);
  const [cameraMode, setCameraMode] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const { toast } = useToast();
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };
  
  // وظيفة تنزيل الصورة
  const handleDownloadPhoto = (photo: ProjectPhoto | null) => {
    if (!photo) return;
    
    try {
      // إنشاء رابط لتنزيل الصورة
      const link = document.createElement('a');
      link.href = `/${photo.path}`;
      link.download = photo.title || `project-photo-${photo.id}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: t("photo.download_success"),
        variant: "default",
      });
    } catch (err) {
      console.error("Error downloading photo:", err);
      toast({
        title: t("photo.download_error"),
        description: err instanceof Error ? err.message : "",
        variant: "destructive",
      });
    }
  };
  
  // وظائف الكاميرا
  const startCamera = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toast({
          title: t("photo.camera_error"),
          description: t("photo.camera_not_supported"),
          variant: "destructive",
        });
        return;
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "environment" } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      setCameraStream(stream);
      setCameraMode(true);
    } catch (err) {
      console.error("Error accessing camera:", err);
      toast({
        title: t("photo.camera_error"),
        description: err instanceof Error ? err.message : t("photo.camera_error_message"),
        variant: "destructive",
      });
    }
  };
  
  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setCameraMode(false);
  };
  
  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (!context) return;
    
    // ضبط حجم الـ canvas ليناسب الفيديو
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // رسم الصورة على الـ canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // تحويل الـ canvas إلى Blob
    canvas.toBlob((blob) => {
      if (blob) {
        // إنشاء ملف من الـ blob
        const file = new File([blob], `photo_${new Date().getTime()}.jpg`, { type: 'image/jpeg' });
        setSelectedFile(file);
        
        // إيقاف الكاميرا بعد التقاط الصورة
        stopCamera();
      }
    }, 'image/jpeg', 0.8);
  };
  
  // تنظيف موارد الكاميرا عند مغادرة الصفحة
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);
  
  const handleUploadPhoto = async () => {
    if (!selectedFile || !projectId) return;
    
    setUploadingPhoto(true);
    setPhotoUploadError(null);
    
    try {
      const formData = new FormData();
      formData.append('photo', selectedFile);
      formData.append('description', photoDescription);
      formData.append('projectId', projectId.toString());
      formData.append('captureDate', new Date().toISOString());
      
      const response = await fetch(`/api/projects/${projectId}/photos`, {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error(t("photo.upload_error"));
      }
      
      // إعادة تحميل صور المشروع
      await refetchPhotos();
      
      // إعادة تعيين الحقول
      setSelectedFile(null);
      setPhotoDescription("");
      setShowUploadModal(false);
      
    } catch (err) {
      console.error("Error uploading photo:", err);
      setPhotoUploadError(err instanceof Error ? err.message : t("photo.upload_error"));
    } finally {
      setUploadingPhoto(false);
    }
  };

  const { data: project, isLoading, error } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
    queryFn: async () => {
      console.log("Fetching project details with ID:", projectId);
      try {
        const response = await fetch(`/api/projects/${projectId}`);
        if (!response.ok) {
          throw new Error('فشل في تحميل بيانات المشروع');
        }
        const data = await response.json();
        console.log("Project details received:", data);
        return data;
      } catch (err) {
        console.error("Error fetching project details:", err);
        throw err;
      }
    },
    enabled: !!projectId,
    staleTime: 0, // تعطيل التخزين المؤقت
    retry: 1, // عدد محاولات إعادة المحاولة
  });
  
  const { 
    data: projectPhotos,
    isLoading: isLoadingPhotos,
    refetch: refetchPhotos
  } = useQuery<ProjectPhoto[]>({
    queryKey: ["/api/projects/photos", projectId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/projects/${projectId}/photos`);
        if (!response.ok) {
          throw new Error('فشل في تحميل صور المشروع');
        }
        return response.json();
      } catch (err) {
        console.error("Error fetching project photos:", err);
        throw err;
      }
    },
    enabled: !!projectId && activeTab === "photos",
  });

  // فشل تحميل البيانات
  if (error) {
    return (
      <div className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">{t("project.details")}</h1>
          <Button variant="outline" asChild>
            <Link href="/projects">
              <span className="material-icons ml-2">arrow_back</span>
              {t("common.back")}
            </Link>
          </Button>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <div className="text-red-500 mb-4">
              <span className="material-icons text-5xl">error_outline</span>
            </div>
            <h3 className="text-xl font-medium mb-2">{t("common.error_loading")}</h3>
            <p className="text-gray-500 mb-4">{t("common.try_again")}</p>
            <Button asChild>
              <Link href="/projects">
                <span className="material-icons ml-2">arrow_back</span>
                {t("common.back_to_projects")}
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // جاري تحميل البيانات
  if (isLoading || !project) {
    return (
      <div className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-6">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-6 w-full" />
          </CardHeader>
          <CardContent className="space-y-4">
            {Array(5).fill(null).map((_, i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{t("project.details")}</h1>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href={`/projects/${project.id}/edit`}>
              <span className="material-icons ml-2">edit</span>
              {t("common.edit")}
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/projects">
              <span className="material-icons ml-2">arrow_back</span>
              {t("common.back")}
            </Link>
          </Button>
        </div>
      </div>

      <Card className="mb-6">
        <CardHeader className="pb-4">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl mb-2">{project.name}</CardTitle>
              <CardDescription className="text-base">{project.description}</CardDescription>
            </div>
            <div className="flex gap-2">
              <StatusBadge status={project.status} size="lg" />
              <ProjectTypeBadge type={project.type} size="lg" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-gray-500">{t("project.progress")}</h3>
              <ProgressWithText value={project.progress || 0} />
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-gray-500">{t("project.budget")}</h3>
              <p className="text-lg font-semibold">
                <Currency amount={project.budget || 0} />
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-gray-500">{t("project.dates")}</h3>
              <p className="text-base">
                {project.startDate ? formatDate(project.startDate) : t("common.not_set")} - 
                {project.endDate ? formatDate(project.endDate) : t("common.not_set")}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid grid-cols-7 lg:grid-cols-8 w-full max-w-3xl">
          <TabsTrigger value="overview">
            <span className="material-icons mr-2">dashboard</span>
            {t("common.overview")}
          </TabsTrigger>
          <TabsTrigger value="tasks">
            <span className="material-icons mr-2">task_alt</span>
            {t("common.tasks")}
          </TabsTrigger>
          <TabsTrigger value="financial">
            <span className="material-icons mr-2">account_balance</span>
            {t("common.financial")}
          </TabsTrigger>
          <TabsTrigger value="assets">
            <span className="material-icons mr-2">handyman</span>
            {t("common.assets")}
          </TabsTrigger>
          <TabsTrigger value="photos">
            <span className="material-icons mr-2">photo_library</span>
            {t("common.photos")}
          </TabsTrigger>
          <TabsTrigger value="documents">
            <span className="material-icons mr-2">description</span>
            {t("common.documents")}
          </TabsTrigger>
          <TabsTrigger value="risks">
            <span className="material-icons mr-2">warning</span>
            {t("common.risks")}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* بطاقة معلومات المشروع الرئيسية */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>{t("project.project_overview")}</CardTitle>
                  <Badge variant="outline" className="px-3 text-sm font-medium">
                    {t("project.id")}: {project.id}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-muted/30 p-4 rounded-lg border border-muted">
                  <div className="flex items-center mb-4">
                    <span className="material-icons text-primary mr-2">info</span>
                    <h3 className="text-lg font-medium">{t("project.project_info")}</h3>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">{t("project.type")}</p>
                      <div className="font-medium">
                        <ProjectTypeBadge type={project.type} size="md" />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">{t("project.status")}</p>
                      <div className="font-medium">
                        <StatusBadge status={project.status} size="md" />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">{t("project.created_at")}</p>
                      <p className="font-medium">{formatDate(project.createdAt || '')}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">{t("project.timeline")}</p>
                      <p className="font-medium">
                        {project.startDate ? formatDate(project.startDate) : t("common.not_set")} - {" "}
                        {project.endDate ? formatDate(project.endDate) : t("common.not_set")}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center mb-4">
                    <span className="material-icons text-primary mr-2">description</span>
                    <h3 className="text-lg font-medium">{t("project.description")}</h3>
                  </div>
                  <div className="bg-muted/20 p-4 rounded-lg border border-muted">
                    <p className="text-gray-700 whitespace-pre-line">
                      {project.description || t("common.no_description")}
                    </p>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center mb-4">
                    <span className="material-icons text-primary mr-2">location_on</span>
                    <h3 className="text-lg font-medium">{t("project.location")}</h3>
                  </div>
                  {project.location ? (
                    <div className="h-64 bg-muted/20 rounded-lg border border-muted flex items-center justify-center overflow-hidden">
                      <div className="text-center">
                        <span className="material-icons text-5xl text-gray-400 mb-2">map</span>
                        <p className="text-muted-foreground">{t("project.map_placeholder")}</p>
                        <div className="mt-3">
                          <Badge variant="secondary" className="mx-auto">
                            <span className="material-icons text-xs mr-1">pin_drop</span>
                            {/* استخدام تنسيق coordinates من "type": "Point" */}
                            {(project.location.type === "Point" && Array.isArray(project.location.coordinates)) ? 
                            `${project.location.coordinates[1]?.toFixed(6) || 0}, ${project.location.coordinates[0]?.toFixed(6) || 0}` :
                            (project.location.lat && project.location.lng) ? 
                            `${project.location.lat.toFixed(6) || 0}, ${project.location.lng.toFixed(6) || 0}` :
                            "0.000000, 0.000000"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-muted/20 p-6 rounded-lg border border-muted text-center">
                      <span className="material-icons text-3xl text-gray-400 mb-2">location_off</span>
                      <p className="text-gray-500">{t("project.no_location")}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* بطاقات المعلومات الجانبية */}
            <div className="space-y-6">
              {/* تقدم المشروع */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <span className="material-icons text-primary mr-2">trending_up</span>
                    <CardTitle className="text-base">{t("project.progress")}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="text-3xl font-bold mb-2">{project.progress || 0}%</div>
                    <ProgressWithText value={project.progress || 0} size="lg" />
                    
                    <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                      <div className="flex flex-col items-center bg-muted/20 p-2 rounded-md">
                        <span className="text-muted-foreground">{t("project.start_date")}</span>
                        <span className="font-medium">{project.startDate ? formatDate(project.startDate) : t("common.not_set")}</span>
                      </div>
                      <div className="flex flex-col items-center bg-muted/20 p-2 rounded-md">
                        <span className="text-muted-foreground">{t("project.end_date")}</span>
                        <span className="font-medium">{project.endDate ? formatDate(project.endDate) : t("common.not_set")}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* ميزانية المشروع */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <span className="material-icons text-primary mr-2">account_balance_wallet</span>
                    <CardTitle className="text-base">{t("project.budget_info")}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <span className="text-muted-foreground text-sm">{t("project.total_budget")}</span>
                      <div className="text-2xl font-bold">
                        <Currency amount={project.budget || 0} />
                      </div>
                    </div>
                    
                    <HoverCard>
                      <HoverCardTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full">
                          <span className="material-icons mr-2 text-sm">bar_chart</span>
                          {t("financial.view_financial_details")}
                        </Button>
                      </HoverCardTrigger>
                      <HoverCardContent className="w-80">
                        <div className="space-y-4">
                          <h4 className="font-medium">{t("financial.summary")}</h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div className="flex flex-col">
                              <span className="text-muted-foreground">{t("financial.approved_budget")}</span>
                              <span className="font-medium"><Currency amount={project.budget || 0} /></span>
                            </div>
                            <div className="flex flex-col">
                              <span className="text-muted-foreground">{t("financial.spent")}</span>
                              <span className="font-medium"><Currency amount={(project.budget || 0) * (project.progress || 0) / 100} /></span>
                            </div>
                          </div>
                          <Separator />
                          <div className="space-y-2">
                            <Link href={`/financial/budgets?projectId=${project.id}`} className="text-sm text-primary hover:underline flex items-center">
                              <span className="material-icons mr-1 text-sm">launch</span>
                              {t("financial.go_to_budget_details")}
                            </Link>
                            <Link href={`/projects/${project.id}/financial-reports`} className="text-sm text-primary hover:underline flex items-center">
                              <span className="material-icons mr-1 text-sm">bar_chart</span>
                              {t("financial.view_financial_reports") || "عرض التقارير المالية"}
                            </Link>
                          </div>
                        </div>
                      </HoverCardContent>
                    </HoverCard>
                  </div>
                </CardContent>
              </Card>
              
              {/* فريق المشروع */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <span className="material-icons text-primary mr-2">group</span>
                    <CardTitle className="text-base">{t("project.team")}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarFallback>
                            {project.managedBy ? "PM" : "?"}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">
                            {project.managedBy ? t("project.project_manager") : t("project.not_assigned")}
                          </p>
                          <p className="text-xs text-muted-foreground">{t("project.manager")}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <span className="material-icons text-sm">edit</span>
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarFallback>
                            {project.createdBy ? "CR" : "?"}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">
                            {project.createdBy ? t("project.project_creator") : t("project.unknown")}
                          </p>
                          <p className="text-xs text-muted-foreground">{t("project.creator")}</p>
                        </div>
                      </div>
                    </div>
                    
                    <Separator className="my-2" />
                    
                    <Button variant="outline" size="sm" className="w-full">
                      <span className="material-icons mr-2 text-sm">person_add</span>
                      {t("project.manage_team")}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="tasks" className="mt-6">
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <span className="material-icons text-primary mr-2">checklist</span>
                    <CardTitle>{t("task.tasks")}</CardTitle>
                  </div>
                  <div className="flex space-x-2">
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="material-icons text-muted-foreground text-sm">search</span>
                      </div>
                      <input
                        type="text"
                        className="bg-muted/30 border border-muted rounded-md pl-10 pr-3 py-2 text-sm w-60 focus:outline-none focus:ring-1 focus:ring-primary"
                        placeholder={t("task.search_tasks")}
                      />
                    </div>
                    <Button size="sm">
                      <span className="material-icons mr-2 text-sm">add</span>
                      {t("task.add_task")}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* نموذج مع بعض المهام للعرض */}
                <div className="hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-10">{t("task.status")}</TableHead>
                        <TableHead>{t("task.title")}</TableHead>
                        <TableHead>{t("task.assignee")}</TableHead>
                        <TableHead>{t("task.priority")}</TableHead>
                        <TableHead>{t("task.due_date")}</TableHead>
                        <TableHead className="text-right">{t("common.actions")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {[1, 2, 3].map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <Badge 
                              variant={index === 0 ? "default" : index === 1 ? "secondary" : "outline"}
                              className="whitespace-nowrap"
                            >
                              {index === 0 ? t("task.status_inprogress") : 
                               index === 1 ? t("task.status_completed") : 
                               t("task.status_pending")}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-medium">
                            <div className="flex flex-col">
                              <span>{t("task.sample_title_" + (index + 1))}</span>
                              <span className="text-xs text-muted-foreground truncate max-w-[200px]">
                                {t("task.sample_description_" + (index + 1))}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="h-6 w-6 mr-2">
                                <AvatarFallback className="text-xs">
                                  {index === 0 ? "AM" : index === 1 ? "MK" : "SA"}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-sm">
                                {index === 0 ? "أحمد محمد" : index === 1 ? "محمد خالد" : "سمير عبدالله"}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={index === 0 ? "destructive" : index === 1 ? "default" : "secondary"}
                              className="whitespace-nowrap"
                            >
                              {index === 0 ? t("task.priority_high") : 
                               index === 1 ? t("task.priority_medium") : 
                               t("task.priority_low")}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {new Date(
                              new Date().getTime() + (index * 3 * 24 * 60 * 60 * 1000)
                            ).toLocaleDateString('ar-SA')}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <span className="material-icons text-sm">visibility</span>
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <span className="material-icons text-sm">edit</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {/* رسالة عدم وجود مهام (هذا هو ما سيظهر في الواقع) */}
                <div className="bg-muted/20 border border-muted rounded-lg p-8 text-center">
                  <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-muted/30 mb-4">
                    <span className="material-icons text-muted-foreground">task</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-700 mb-2">{t("task.no_tasks")}</h3>
                  <p className="text-muted-foreground max-w-md mx-auto mb-6">{t("task.no_tasks_description")}</p>
                  <Button className="gap-2">
                    <span className="material-icons">add</span>
                    {t("task.add_first_task")}
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* قسم تحليلات المهام والإحصائيات */}
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <span className="material-icons text-primary mr-2">insights</span>
                  <CardTitle className="text-base">{t("task.task_analytics")}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-muted/20 rounded-lg border border-muted p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-muted-foreground text-sm">{t("task.total")}</div>
                    <div className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                      <span className="material-icons text-sm">summarize</span>
                    </div>
                  </div>
                  <div className="text-2xl font-bold">0</div>
                </div>
                
                <div className="bg-muted/20 rounded-lg border border-muted p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-muted-foreground text-sm">{t("task.completed")}</div>
                    <div className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600">
                      <span className="material-icons text-sm">check_circle</span>
                    </div>
                  </div>
                  <div className="text-2xl font-bold">0</div>
                </div>
                
                <div className="bg-muted/20 rounded-lg border border-muted p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-muted-foreground text-sm">{t("task.in_progress")}</div>
                    <div className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-amber-100 text-amber-600">
                      <span className="material-icons text-sm">pending</span>
                    </div>
                  </div>
                  <div className="text-2xl font-bold">0</div>
                </div>
                
                <div className="bg-muted/20 rounded-lg border border-muted p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-muted-foreground text-sm">{t("task.pending")}</div>
                    <div className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-red-100 text-red-600">
                      <span className="material-icons text-sm">schedule</span>
                    </div>
                  </div>
                  <div className="text-2xl font-bold">0</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="financial" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* العمليات المالية */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <span className="material-icons text-primary mr-2">account_balance</span>
                    <CardTitle>{t("financial.transactions")}</CardTitle>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/projects/${project.id}/financial-reports`}>
                        <span className="material-icons mr-2 text-sm">bar_chart</span>
                        {t("financial.view_financial_reports") || "التقارير المالية"}
                      </Link>
                    </Button>
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/financial/budgets?projectId=${project.id}`}>
                        <span className="material-icons mr-2 text-sm">receipt_long</span>
                        {t("financial.view_budgets")}
                      </Link>
                    </Button>
                    <Button size="sm" asChild>
                      <Link href={`/financial/transactions?projectId=${project.id}`}>
                        <span className="material-icons mr-2 text-sm">add</span>
                        {t("financial.add_transaction")}
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* بيانات المعاملات المالية (مخفية لأن لا توجد معاملات بعد) */}
                <div className="hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("financial.date")}</TableHead>
                        <TableHead>{t("financial.description")}</TableHead>
                        <TableHead>{t("financial.type")}</TableHead>
                        <TableHead>{t("financial.account")}</TableHead>
                        <TableHead className="text-left">{t("financial.amount")}</TableHead>
                        <TableHead className="text-right">{t("common.actions")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {[1, 2, 3].map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            {new Date(
                              new Date().getTime() - (index * 7 * 24 * 60 * 60 * 1000)
                            ).toLocaleDateString('ar-SA')}
                          </TableCell>
                          <TableCell className="font-medium">
                            {index === 0 
                              ? t("financial.sample_desc_1") 
                              : index === 1 
                                ? t("financial.sample_desc_2") 
                                : t("financial.sample_desc_3")}
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={index === 0 ? "default" : "destructive"}
                              className="whitespace-nowrap"
                            >
                              {index === 0 || index === 2 
                                ? t("financial.income") 
                                : t("financial.expense")}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {index === 0 
                              ? "110-50" 
                              : index === 1 
                                ? "220-30" 
                                : "310-10"}
                          </TableCell>
                          <TableCell>
                            <span className={index === 1 ? "text-red-600 font-medium" : "text-green-600 font-medium"}>
                              <Currency 
                                amount={
                                  index === 0 
                                    ? 125000 
                                    : index === 1 
                                      ? -45000 
                                      : 75000
                                } 
                              />
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <span className="material-icons text-sm">visibility</span>
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <span className="material-icons text-sm">edit</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                {/* رسالة عدم وجود معاملات مالية (هذا ما سيظهر) */}
                <div className="bg-muted/20 border border-muted rounded-lg p-8 text-center">
                  <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-muted/30 mb-4">
                    <span className="material-icons text-muted-foreground">account_balance</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-700 mb-2">{t("financial.no_transactions")}</h3>
                  <p className="text-muted-foreground max-w-md mx-auto mb-6">{t("financial.no_transactions_description")}</p>
                  <Button asChild>
                    <Link href={`/financial/transactions?projectId=${project.id}`}>
                      <span className="material-icons mr-2">add</span>
                      {t("financial.add_first_transaction")}
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* ملخص مالي جانبي */}
            <div className="space-y-6">
              {/* ملخص الميزانية */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <span className="material-icons text-primary mr-2">pie_chart</span>
                    <CardTitle className="text-base">{t("financial.budget_summary")}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="bg-muted/20 p-3 rounded-md">
                        <div className="text-muted-foreground mb-1">{t("financial.approved")}</div>
                        <div className="text-lg font-semibold">
                          <Currency amount={project.budget || 0} />
                        </div>
                      </div>
                      <div className="bg-muted/20 p-3 rounded-md">
                        <div className="text-muted-foreground mb-1">{t("financial.spent")}</div>
                        <div className="text-lg font-semibold">
                          <Currency amount={(project.budget || 0) * (project.progress || 0) / 100} />
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-muted-foreground">{t("financial.progress")}</span>
                        <span className="text-sm font-medium">{project.progress || 0}%</span>
                      </div>
                      <div className="h-2 bg-muted/20 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary rounded-full" 
                          style={{ width: `${project.progress || 0}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-muted-foreground">{t("financial.remaining")}</span>
                        <span className="text-sm font-medium">
                          <Currency 
                            amount={project.budget ? project.budget - (project.budget * (project.progress || 0) / 100) : 0} 
                          />
                        </span>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <Button variant="outline" size="sm" className="w-full" asChild>
                      <Link href={`/financial/budgets?projectId=${project.id}`}>
                        <span className="material-icons mr-2 text-sm">open_in_new</span>
                        {t("financial.full_budget_details")}
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              {/* إحصائيات مالية سريعة */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <span className="material-icons text-primary mr-2">insights</span>
                    <CardTitle className="text-base">{t("financial.stats")}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-muted/20 p-4 rounded-lg border border-muted">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-muted-foreground text-sm mb-1">{t("financial.total_transactions")}</div>
                          <div className="font-bold text-2xl">0</div>
                        </div>
                        <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                          <span className="material-icons text-sm">receipt</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-muted/20 p-3 rounded-lg border border-muted">
                        <div className="flex items-center justify-between mb-1">
                          <div className="text-muted-foreground text-xs">{t("financial.income")}</div>
                          <div className="h-5 w-5 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                            <span className="material-icons text-xs">trending_up</span>
                          </div>
                        </div>
                        <div className="font-bold text-lg text-green-600">
                          <Currency amount={0} />
                        </div>
                      </div>
                      
                      <div className="bg-muted/20 p-3 rounded-lg border border-muted">
                        <div className="flex items-center justify-between mb-1">
                          <div className="text-muted-foreground text-xs">{t("financial.expenses")}</div>
                          <div className="h-5 w-5 bg-red-100 rounded-full flex items-center justify-center text-red-600">
                            <span className="material-icons text-xs">trending_down</span>
                          </div>
                        </div>
                        <div className="font-bold text-lg text-red-600">
                          <Currency amount={0} />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="assets" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{t("asset.assets")}</CardTitle>
                <Button size="sm">
                  <span className="material-icons mr-2">add</span>
                  {t("asset.add_asset")}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <span className="material-icons text-5xl text-gray-300 mb-4">handyman</span>
                <h3 className="text-xl font-medium text-gray-700 mb-2">{t("asset.no_assets")}</h3>
                <p className="text-gray-500 mb-6">{t("asset.no_assets_description")}</p>
                <Button>
                  <span className="material-icons mr-2">add</span>
                  {t("asset.add_first_asset")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="photos" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <span className="material-icons text-primary mr-2">photo_library</span>
                  <CardTitle>{t("photo.project_photos")}</CardTitle>
                </div>
                <Dialog open={showUploadModal} onOpenChange={setShowUploadModal}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <span className="material-icons mr-2 text-sm">add_a_photo</span>
                      {t("photo.upload_photo")}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>{t("photo.upload_photo")}</DialogTitle>
                      <DialogDescription>
                        {t("photo.upload_photo_description")}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      {cameraMode ? (
                        <div className="space-y-4">
                          <div className="relative rounded-md overflow-hidden bg-black">
                            <video
                              ref={videoRef}
                              autoPlay
                              playsInline
                              muted
                              className="w-full h-auto"
                            />
                            <canvas ref={canvasRef} className="hidden" />
                          </div>
                          <div className="flex justify-center space-x-3">
                            <Button
                              type="button"
                              onClick={capturePhoto}
                              className="bg-primary"
                            >
                              <span className="material-icons mr-2">photo_camera</span>
                              {t("photo.capture")}
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={stopCamera}
                            >
                              <span className="material-icons mr-2">close</span>
                              {t("photo.cancel_camera")}
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2">
                            <Button 
                              onClick={startCamera} 
                              type="button" 
                              variant="outline" 
                              className="flex-1"
                            >
                              <span className="material-icons mr-2">camera_alt</span>
                              {t("photo.open_camera")}
                            </Button>
                            <div className="relative flex-1">
                              <Label htmlFor="photo" className="block mb-2">{t("photo.select_photo")}</Label>
                              <Input 
                                id="photo" 
                                type="file" 
                                accept="image/*" 
                                onChange={handleFileChange}
                                className="cursor-pointer"
                              />
                            </div>
                          </div>
                          
                          {selectedFile && (
                            <div className="mt-2 border rounded-md p-2">
                              <AspectRatio ratio={16/9} className="bg-muted overflow-hidden rounded-md">
                                <img 
                                  src={URL.createObjectURL(selectedFile)} 
                                  alt="Selected" 
                                  className="object-cover w-full h-full"
                                />
                              </AspectRatio>
                              <p className="text-xs text-gray-500 mt-1">{selectedFile.name}</p>
                            </div>
                          )}
                        </div>
                      )}
                      
                      <div className="space-y-2">
                        <Label htmlFor="description">{t("photo.description")}</Label>
                        <Textarea 
                          id="description" 
                          value={photoDescription}
                          onChange={(e) => setPhotoDescription(e.target.value)}
                          placeholder={t("photo.description_placeholder")}
                        />
                      </div>
                      {photoUploadError && (
                        <div className="bg-red-50 text-red-700 p-3 rounded-md text-sm">
                          {photoUploadError}
                        </div>
                      )}
                    </div>
                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setShowUploadModal(false)}
                      >
                        {t("common.cancel")}
                      </Button>
                      <Button 
                        type="button" 
                        onClick={handleUploadPhoto}
                        disabled={!selectedFile || uploadingPhoto}
                      >
                        {uploadingPhoto ? (
                          <>
                            <span className="material-icons animate-spin mr-2 text-sm">refresh</span>
                            {t("common.uploading")}
                          </>
                        ) : (
                          <>
                            <span className="material-icons mr-2 text-sm">upload</span>
                            {t("common.upload")}
                          </>
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingPhotos ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {Array(8).fill(null).map((_, i) => (
                    <div key={i} className="space-y-2">
                      <Skeleton className="h-40 w-full rounded-md" />
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  ))}
                </div>
              ) : projectPhotos && projectPhotos.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {projectPhotos.map((photo) => (
                    <div 
                      key={photo.id} 
                      className="group relative border rounded-md overflow-hidden cursor-pointer"
                      onClick={() => setViewPhoto(photo)}
                    >
                      <AspectRatio ratio={4/3} className="bg-muted">
                        <img
                          src={`/${photo.path}`}
                          alt={photo.description || t("photo.project_photo")}
                          className="object-cover w-full h-full transition-transform group-hover:scale-105"
                        />
                      </AspectRatio>
                      <div className="p-2 bg-white">
                        <p className="font-medium text-sm line-clamp-1">
                          {photo.description || t("photo.no_description")}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {photo.captureDate ? formatDate(photo.captureDate) : formatDate(photo.createdAt || '')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <span className="material-icons text-5xl text-gray-300 mb-4">photo_camera</span>
                  <h3 className="text-xl font-medium text-gray-700 mb-2">{t("photo.no_photos")}</h3>
                  <p className="text-gray-500 mb-6">{t("photo.no_photos_description")}</p>
                  <Button onClick={() => setShowUploadModal(true)}>
                    <span className="material-icons mr-2">upload</span>
                    {t("photo.add_first_photo")}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{t("document.documents")}</CardTitle>
                <Button size="sm">
                  <span className="material-icons mr-2">add</span>
                  {t("document.add_document")}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <span className="material-icons text-5xl text-gray-300 mb-4">description</span>
                <h3 className="text-xl font-medium text-gray-700 mb-2">{t("document.no_documents")}</h3>
                <p className="text-gray-500 mb-6">{t("document.no_documents_description")}</p>
                <Button>
                  <span className="material-icons mr-2">add</span>
                  {t("document.add_first_document")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risks" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{t("risk.risks")}</CardTitle>
                <Button size="sm">
                  <span className="material-icons mr-2">add</span>
                  {t("risk.add_risk")}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <span className="material-icons text-5xl text-gray-300 mb-4">warning</span>
                <h3 className="text-xl font-medium text-gray-700 mb-2">{t("risk.no_risks")}</h3>
                <p className="text-gray-500 mb-6">{t("risk.no_risks_description")}</p>
                <Button>
                  <span className="material-icons mr-2">add</span>
                  {t("risk.add_first_risk")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* نافذة عرض الصورة بحجم كبير */}
      <Dialog open={!!viewPhoto} onOpenChange={(open) => !open && setViewPhoto(null)}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <span className="material-icons text-primary mr-2">photo</span>
              {viewPhoto?.description || t("photo.project_photo")}
            </DialogTitle>
            <DialogDescription>
              {viewPhoto?.captureDate ? formatDate(viewPhoto.captureDate) : viewPhoto?.createdAt ? formatDate(viewPhoto.createdAt) : ''}
            </DialogDescription>
          </DialogHeader>
          
          {viewPhoto && (
            <div className="mt-2">
              <div className="relative bg-black rounded-md overflow-hidden mx-auto">
                <img 
                  src={`/${viewPhoto.path}`}
                  alt={viewPhoto.description || t("photo.project_photo")}
                  className="max-h-[70vh] mx-auto object-contain"
                />
              </div>
              
              {viewPhoto.description && (
                <div className="mt-4 bg-muted/20 p-3 rounded-md">
                  <p className="text-sm whitespace-pre-line">{viewPhoto.description}</p>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter className="flex justify-between items-center">
            <div>
              <span className="text-sm text-muted-foreground">
                {t("photo.capture_date")}: {viewPhoto?.captureDate ? formatDate(viewPhoto.captureDate) : t("common.not_available")}
              </span>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Button 
                variant="secondary" 
                onClick={() => handleDownloadPhoto(viewPhoto)}
              >
                <span className="material-icons mr-2 text-sm">download</span>
                {t("photo.download_photo")}
              </Button>
              <Button variant="outline" onClick={() => setViewPhoto(null)}>
                {t("common.close")}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}