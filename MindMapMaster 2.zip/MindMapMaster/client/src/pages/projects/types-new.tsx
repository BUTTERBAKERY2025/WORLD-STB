import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  Plus, 
  Search, 
  Edit, 
  Trash, 
  MoreHorizontal 
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

// واجهة بيانات نوع المشروع
interface ProjectType {
  id: number;
  name: string;
  description: string;
  createdAt: string;
}

export default function ProjectTypes() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentProjectType, setCurrentProjectType] = useState<ProjectType | null>(null);

  // استعلام للحصول على أنواع المشاريع
  const { data: projectTypes = [] } = useQuery<ProjectType[]>({
    queryKey: ["/api/project-types"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/project-types");
      return response.json();
    },
  });

  // إضافة نوع مشروع جديد
  const addMutation = useMutation({
    mutationFn: async (data: { name: string; description: string }) => {
      const res = await apiRequest("POST", "/api/project-types", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project-types"] });
      setShowAddDialog(false);
      resetForm();
      toast({
        title: t("project.type_added_successfully"),
        variant: "default",
      });
    },
    onError: (error) => {
      console.error("Error adding project type:", error);
      toast({
        title: t("project.type_add_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // تحديث نوع مشروع
  const updateMutation = useMutation({
    mutationFn: async (data: ProjectType) => {
      const res = await apiRequest("PATCH", `/api/project-types/${data.id}`, {
        name: data.name,
        description: data.description,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project-types"] });
      setShowAddDialog(false);
      resetForm();
      toast({
        title: t("project.type_updated_successfully"),
        variant: "default",
      });
    },
    onError: (error) => {
      console.error("Error updating project type:", error);
      toast({
        title: t("project.type_update_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // حذف نوع مشروع
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/project-types/${id}`);
      if (!res.ok) throw new Error(t("project.type_delete_error"));
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project-types"] });
      toast({
        title: t("project.type_deleted_successfully"),
        variant: "default",
      });
    },
    onError: (error) => {
      console.error("Error deleting project type:", error);
      toast({
        title: t("project.type_delete_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // تصفية أنواع المشاريع حسب البحث
  const filteredTypes = projectTypes.filter(type => 
    type.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    type.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // إعادة تعيين النموذج
  const resetForm = () => {
    setCurrentProjectType(null);
    setIsEditMode(false);
  };

  // تحديد نوع مشروع للتحرير
  const handleEdit = (type: ProjectType) => {
    setCurrentProjectType(type);
    setIsEditMode(true);
    setShowAddDialog(true);
  };

  // إرسال النموذج
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentProjectType) return;
    
    if (!currentProjectType.name || !currentProjectType.description) {
      toast({
        title: t("validation.required_field"),
        description: t("project.type_fields_required"),
        variant: "destructive",
      });
      return;
    }
    
    if (isEditMode) {
      updateMutation.mutate(currentProjectType);
    } else {
      addMutation.mutate({
        name: currentProjectType.name,
        description: currentProjectType.description,
      });
    }
  };

  // حذف نوع مشروع
  const handleDelete = (id: number) => {
    if (window.confirm(t("project.confirm_delete_type"))) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="container p-4">
      <div className="flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold">{t("project.project_types")}</h1>
          <div className="flex space-x-2">
            <Button 
              onClick={() => {
                setCurrentProjectType({ id: 0, name: "", description: "", createdAt: "" });
                setIsEditMode(false);
                setShowAddDialog(true);
              }}
              className="flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              <span>{t("project.add_project_type")}</span>
            </Button>
          </div>
        </div>
        
        <div className="bg-white rounded-md shadow">
          <div className="p-4 border-b">
            <p className="text-gray-500">{t("project.manage_project_types_description")}</p>
            <div className="mt-4 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder={t("project.search_types")}
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px] text-right">{t("common.id")}</TableHead>
                  <TableHead>{t("project.type_name")}</TableHead>
                  <TableHead>{t("project.type_description")}</TableHead>
                  <TableHead className="w-[120px]">{t("common.created_at")}</TableHead>
                  <TableHead className="w-[100px] text-center">{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTypes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4">
                      {t("project.no_types_found")}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTypes.map((type) => (
                    <TableRow key={type.id}>
                      <TableCell className="text-right">{type.id}</TableCell>
                      <TableCell>{t(`types.${type.name}`) || type.name}</TableCell>
                      <TableCell>{t(`type_descriptions.${type.name}`) || type.description}</TableCell>
                      <TableCell>{new Date(type.createdAt).toLocaleDateString()}</TableCell>
                      <TableCell className="text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">{t("common.actions")}</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEdit(type)}>
                              <Edit className="h-4 w-4 ml-2" />
                              <span>{t("common.edit")}</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDelete(type.id)}
                              className="text-red-600"
                            >
                              <Trash className="h-4 w-4 ml-2" />
                              <span>{t("common.delete")}</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          
          <div className="p-4 text-sm text-gray-500 border-t">
            {t("project.total_project_types", { count: filteredTypes.length })}
          </div>
        </div>
      </div>

      {/* حوار إضافة/تحرير نوع مشروع */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {isEditMode
                ? t("project.edit_project_type")
                : t("project.add_project_type")}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="type-name" className="text-right">
                  {t("project.type_name")}:
                </label>
                <Input
                  id="type-name"
                  className="col-span-3"
                  value={currentProjectType?.name || ""}
                  onChange={(e) =>
                    setCurrentProjectType({
                      ...currentProjectType!,
                      name: e.target.value,
                    })
                  }
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="type-description" className="text-right">
                  {t("project.type_description")}:
                </label>
                <Input
                  id="type-description"
                  className="col-span-3"
                  value={currentProjectType?.description || ""}
                  onChange={(e) =>
                    setCurrentProjectType({
                      ...currentProjectType!,
                      description: e.target.value,
                    })
                  }
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  resetForm();
                  setShowAddDialog(false);
                }}
              >
                {t("common.cancel")}
              </Button>
              <Button type="submit" disabled={addMutation.isPending || updateMutation.isPending}>
                {isEditMode ? t("common.save") : t("common.add")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}