import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProgressWithText } from "@/components/ui/progress-with-text";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { Currency } from "@/components/ui/currency";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Project, projectTypeEnum, projectStatusEnum } from "@shared/schema";
import { PieChart, Pie, BarChart, Bar, XAxis, YAxis, Cell, Tooltip, Legend, ResponsiveContainer, LineChart, Line, CartesianGrid } from 'recharts';
import { Separator } from "@/components/ui/separator";

// استدعاء API للحصول على المشاريع
const fetchProjects = async (): Promise<Project[]> => {
  try {
    const response = await fetch('/api/projects', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return data as Project[];
  } catch (error) {
    console.error("Error fetching projects:", error);
    throw error;
  }
};

// استدعاء API للحصول على مؤشرات أداء المشاريع - باستخدام محاولة أخرى لتجنب المشكلة السابقة
const fetchProjectsKPIs = async () => {
  try {
    // استخدام وظيفة calculateDashboardData لإنشاء مؤشرات الأداء مباشرة من بيانات المشاريع بدلاً من استدعاء API
    // هذا حل مؤقت لتجاوز المشكلة
    const response = await fetch('/api/projects', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const projects = await response.json();
    
    // مؤشرات الأداء الرئيسية
    // تقوم بحساب البيانات مباشرة من المشاريع
    // إجمالي عدد المشاريع
    const totalProjects = projects.length;
    
    // عدد المشاريع حسب الحالة
    const statusCounts = {
      planning: projects.filter(p => p.status === 'planning').length,
      in_progress: projects.filter(p => p.status === 'in_progress').length,
      delayed: projects.filter(p => p.status === 'delayed').length,
      completed: projects.filter(p => p.status === 'completed').length,
      stopped: projects.filter(p => p.status === 'stopped').length,
    };
    
    // عدد المشاريع حسب النوع
    const typeCounts = {
      road: projects.filter(p => p.type === 'road').length,
      water: projects.filter(p => p.type === 'water').length,
      electricity: projects.filter(p => p.type === 'electricity').length,
      telecom: projects.filter(p => p.type === 'telecom').length,
      building: projects.filter(p => p.type === 'building').length,
    };
    
    // إجمالي الميزانية
    const totalBudget = projects.reduce((sum, project) => sum + (project.budget || 0), 0);
    
    // حساب متوسط التقدم
    let totalProgress = 0;
    let spentBudget = 0;
    
    for (const project of projects) {
      // إضافة للإحصائيات
      totalProgress += project.progress || 0;
      
      // تقدير المصروفات (في النظام الحقيقي، ستكون هناك طريقة أفضل لحساب المصروفات الفعلية)
      if (project.progress) {
        spentBudget += (project.budget || 0) * (project.progress / 100);
      }
    }
    
    // حساب متوسط التقدم
    const averageProgress = totalProjects > 0 ? Math.round(totalProgress / totalProjects) : 0;
    
    // المشاريع النشطة (التخطيط + قيد التنفيذ + متأخرة)
    const activeProjects = statusCounts.planning + statusCounts.in_progress + statusCounts.delayed;
    
    // المشاريع المكتملة
    const completedProjects = statusCounts.completed;
    
    // المشاريع المتأخرة
    const delayedProjects = statusCounts.delayed;
    
    // تحويل التعدادات إلى مصفوفات للرسوم البيانية
    const projectsByStatus = Object.entries(statusCounts).map(([status, count]) => ({
      name: status, // سيتم ترجمة هذا في واجهة المستخدم باستخدام i18n
      value: count,
      color: STATUS_COLORS[status as keyof typeof STATUS_COLORS],
    }));
    
    const projectsByType = Object.entries(typeCounts).map(([type, count]) => ({
      name: type, // سيتم ترجمة هذا في واجهة المستخدم باستخدام i18n
      value: count,
      color: TYPE_COLORS[type as keyof typeof TYPE_COLORS],
    }));
    
    // المشاريع الأخيرة (أحدث 5 مشاريع)
    const recentProjects = [...projects]
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
      .slice(0, 5);
      
    // بيانات أداء الميزانية والجدول الزمني - بيانات نموذجية للعرض
    const budgetPerformance = [
      { name: 'Jan', planned: 1000000, actual: 900000 },
      { name: 'Feb', planned: 2000000, actual: 1800000 },
      { name: 'Mar', planned: 3000000, actual: 2700000 },
      { name: 'Apr', planned: 4000000, actual: 3500000 },
      { name: 'May', planned: 5000000, actual: 4800000 },
      { name: 'Jun', planned: 6000000, actual: 5900000 },
    ];
    
    const schedulePerformance = [
      { name: 'Jan', planned: 10, actual: 8 },
      { name: 'Feb', planned: 20, actual: 18 },
      { name: 'Mar', planned: 30, actual: 27 },
      { name: 'Apr', planned: 40, actual: 35 },
      { name: 'May', planned: 50, actual: 48 },
      { name: 'Jun', planned: 60, actual: 59 },
    ];
      
    // إعادة البيانات
    return {
      totalProjects,
      activeProjects,
      completedProjects,
      delayedProjects,
      totalBudget,
      spentBudget,
      averageProgress,
      projectsByStatus,
      projectsByType,
      recentProjects,
      budgetPerformance,
      schedulePerformance
    };
      
  } catch (error) {
    console.error("Error fetching projects KPIs:", error);
    
    // بيانات افتراضية في حالة فشل الاتصال بالـ API
    return {
      totalProjects: 0,
      activeProjects: 0,
      completedProjects: 0,
      delayedProjects: 0,
      totalBudget: 0,
      spentBudget: 0,
      averageProgress: 0,
      projectsByStatus: [],
      projectsByType: [],
      recentProjects: [],
      budgetPerformance: [],
      schedulePerformance: []
    };
  }
};

// ألوان لاستخدامها في الرسوم البيانية
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];
const STATUS_COLORS = {
  planning: '#6366f1',    // Indigo
  in_progress: '#0ea5e9', // Sky
  delayed: '#f97316',     // Orange
  completed: '#22c55e',   // Green  
  stopped: '#f43f5e',     // Rose
};

const TYPE_COLORS = {
  road: '#3b82f6',       // Blue
  water: '#06b6d4',      // Cyan
  electricity: '#facc15', // Yellow
  telecom: '#a855f7',    // Purple
  building: '#22c55e',   // Green
};

export default function ProjectsDashboard() {
  const { t, i18n } = useTranslation();
  const [dateFilter, setDateFilter] = useState("all");
  const [performanceChartType, setPerformanceChartType] = useState("budget");
  
  // جلب المشاريع
  const { 
    data: projects = [], 
    isLoading: isLoadingProjects, 
    error: projectsError 
  } = useQuery({
    queryKey: ['/api/projects'],
    queryFn: fetchProjects,
    staleTime: 300000, // 5 دقائق
  });
  
  // جلب مؤشرات الأداء بطريقة مباشرة بدلاً من استخدام المسار الذي يسبب المشكلة
  const { 
    data: kpis, 
    isLoading: isLoadingKPIs,
    error: kpisError,
    refetch: refetchKPIs
  } = useQuery({
    queryKey: ['projectKPIs'],
    queryFn: fetchProjectsKPIs,
    staleTime: 300000, // 5 دقائق
  });
  
  // حساب البيانات المعروضة
  const calculateDashboardData = () => {
    if (!projects || projects.length === 0) return null;
    
    // إجمالي عدد المشاريع
    const totalProjects = projects.length;
    
    // عدد المشاريع حسب الحالة
    const statusCounts = {
      planning: projects.filter(p => p.status === 'planning').length,
      in_progress: projects.filter(p => p.status === 'in_progress').length,
      delayed: projects.filter(p => p.status === 'delayed').length,
      completed: projects.filter(p => p.status === 'completed').length,
      stopped: projects.filter(p => p.status === 'stopped').length,
    };
    
    // عدد المشاريع حسب النوع
    const typeCounts = {
      road: projects.filter(p => p.type === 'road').length,
      water: projects.filter(p => p.type === 'water').length,
      electricity: projects.filter(p => p.type === 'electricity').length,
      telecom: projects.filter(p => p.type === 'telecom').length,
      building: projects.filter(p => p.type === 'building').length,
    };
    
    // إجمالي الميزانية
    const totalBudget = projects.reduce((sum, project) => sum + (project.budget || 0), 0);
    
    // متوسط نسبة الإنجاز
    const totalProgress = projects.reduce((sum, project) => sum + (project.progress || 0), 0);
    const averageProgress = totalProjects > 0 ? Math.round(totalProgress / totalProjects) : 0;
    
    // المشاريع النشطة (التي في مرحلة التخطيط أو قيد التنفيذ)
    const activeProjects = projects.filter(p => p.status === 'planning' || p.status === 'in_progress' || p.status === 'delayed').length;
    
    // المشاريع المكتملة
    const completedProjects = projects.filter(p => p.status === 'completed').length;
    
    // المشاريع المتأخرة
    const delayedProjects = projects.filter(p => p.status === 'delayed').length;
    
    // بيانات للرسوم البيانية
    const projectsByStatus = Object.entries(statusCounts).map(([status, count]) => ({
      name: t(`status_values.${status}`),
      value: count,
      color: STATUS_COLORS[status as keyof typeof STATUS_COLORS],
    }));
    
    const projectsByType = Object.entries(typeCounts).map(([type, count]) => ({
      name: t(`types.${type}`),
      value: count,
      color: TYPE_COLORS[type as keyof typeof TYPE_COLORS],
    }));
    
    // المشاريع الأخيرة المضافة (أحدث 5 مشاريع)
    const recentProjects = [...projects]
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
      .slice(0, 5);
    
    return {
      totalProjects,
      activeProjects,
      completedProjects,
      delayedProjects,
      totalBudget,
      averageProgress,
      projectsByStatus,
      projectsByType,
      recentProjects,
    };
  };
  
  const dashboardData = calculateDashboardData();
  
  // تحميل البيانات
  const isLoading = isLoadingProjects || isLoadingKPIs;
  const hasError = projectsError || kpisError;
  
  // مكون عرض القيم الرقمية
  const StatCard = ({ title, value, icon, iconColor, suffix, trend, trendLabel, trendPositive, onClick, isClickable = false }: any) => (
    <Card 
      className={`${isClickable ? 'cursor-pointer transition-all hover:shadow-md' : ''}`}
      onClick={isClickable ? onClick : undefined}
    >
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
            <div className="flex items-end">
              <h3 className="text-2xl font-bold">{value}</h3>
              {suffix && <span className="text-sm mr-2 font-medium text-muted-foreground">{suffix}</span>}
            </div>
            
            {trend && (
              <div className={`mt-2 flex items-center text-xs font-medium ${trendPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                <span className="material-icons text-sm ml-1">
                  {trendPositive ? 'trending_up' : 'trending_down'}
                </span>
                {trend} {trendLabel}
              </div>
            )}
          </div>
          
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${iconColor || 'bg-primary/10'}`}>
            <span className="material-icons text-xl">{icon}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
  
  if (hasError) {
    return (
      <div className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">{t("project_dashboard")}</h1>
          <Button variant="outline" asChild>
            <Link href="/projects">
              <span className="material-icons ml-2">format_list_bulleted</span>
              {t("project_list")}
            </Link>
          </Button>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <div className="text-red-500 mb-4">
              <span className="material-icons text-5xl">error_outline</span>
            </div>
            <h3 className="text-xl font-medium mb-2">{t("common.error_loading")}</h3>
            <p className="text-gray-500 mb-4">{t("dashboard_error")}</p>
            <Button onClick={() => window.location.reload()}>
              <span className="material-icons ml-2">refresh</span>
              {t("common.refresh")}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">{t("project_dashboard")}</h1>
          <p className="text-gray-600 text-sm">{t("dashboard_description")}</p>
        </div>
        <div className="flex space-x-2">
          <Select
            value={dateFilter}
            onValueChange={setDateFilter}
          >
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder={t("date_filter")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("all_time")}</SelectItem>
              <SelectItem value="month">{t("this_month")}</SelectItem>
              <SelectItem value="quarter">{t("this_quarter")}</SelectItem>
              <SelectItem value="year">{t("this_year")}</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" asChild>
            <Link href="/projects">
              <span className="material-icons ml-2">format_list_bulleted</span>
              {t("project_list")}
            </Link>
          </Button>
        </div>
      </div>
      
      {/* بطاقات الإحصائيات الرئيسية */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="flex justify-between">
                  <div>
                    <div className="h-3 w-24 bg-muted rounded mb-4"></div>
                    <div className="h-6 w-16 bg-muted rounded"></div>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-muted"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <StatCard 
            title={t("total_projects")}
            value={dashboardData?.totalProjects || 0}
            icon="business"
            iconColor="bg-blue-100 text-blue-600"
          />
          
          <StatCard 
            title={t("active_projects")}
            value={dashboardData?.activeProjects || 0}
            icon="play_circle"
            iconColor="bg-green-100 text-green-600"
            trend="15%"
            trendLabel={t("common.since_last_month")}
            trendPositive={true}
          />
          
          <StatCard 
            title={t("delayed_projects")}
            value={dashboardData?.delayedProjects || 0}
            icon="watch_later"
            iconColor="bg-amber-100 text-amber-600"
            trend="5%"
            trendLabel={t("common.since_last_month")}
            trendPositive={false}
          />
          
          <StatCard 
            title={t("total_budget")}
            value={formatCurrency(dashboardData?.totalBudget || 0)}
            icon="account_balance_wallet"
            iconColor="bg-indigo-100 text-indigo-600"
          />
        </div>
      )}
      
      {/* الرسوم البيانية والإحصائيات المتقدمة */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* رسم بياني للمشاريع حسب الحالة */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>{t("by_status")}</CardTitle>
            <CardDescription>{t("status_distribution")}</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center items-center pt-2">
            {isLoading ? (
              <div className="animate-pulse flex flex-col items-center">
                <div className="w-40 h-40 bg-muted rounded-full mb-4"></div>
                <div className="h-3 w-32 bg-muted rounded mb-2"></div>
                <div className="h-3 w-24 bg-muted rounded"></div>
              </div>
            ) : dashboardData?.projectsByStatus && dashboardData.projectsByStatus.length > 0 ? (
              <div className="w-full h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={dashboardData.projectsByStatus}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={3}
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      labelLine={false}
                    >
                      {dashboardData.projectsByStatus.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} ${t("projects")}`, ""]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">{t("no_status_data")}</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* رسم بياني للمشاريع حسب النوع */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>{t("by_type")}</CardTitle>
            <CardDescription>{t("type_distribution")}</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse">
                <div className="h-[250px] bg-muted rounded"></div>
              </div>
            ) : dashboardData?.projectsByType && dashboardData.projectsByType.length > 0 ? (
              <div className="w-full h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={dashboardData.projectsByType}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <XAxis type="number" hide />
                    <YAxis type="category" dataKey="name" width={100} />
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <Tooltip formatter={(value) => [`${value} ${t("projects")}`, ""]} />
                    <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                      {dashboardData.projectsByType.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">{t("no_type_data")}</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* متوسط التقدم في المشاريع */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>{t("performance_metrics")}</CardTitle>
            <CardDescription>
              {t("performance_description")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-4">
                <div className="h-4 w-full bg-muted rounded"></div>
                <div className="h-8 w-full bg-muted rounded"></div>
                <div className="h-4 w-3/4 bg-muted rounded"></div>
                <div className="h-8 w-full bg-muted rounded"></div>
              </div>
            ) : (
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">
                      {t("average_progress")}
                    </span>
                    <span className="text-sm font-medium">
                      {dashboardData?.averageProgress || 0}%
                    </span>
                  </div>
                  <ProgressWithText 
                    value={dashboardData?.averageProgress || 0} 
                    size="lg"
                  />
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">
                      {t("completion_rate")}
                    </span>
                    <span className="text-sm font-medium">
                      {dashboardData && dashboardData.totalProjects > 0 
                        ? Math.round((dashboardData.completedProjects / dashboardData.totalProjects) * 100) 
                        : 0}%
                    </span>
                  </div>
                  <ProgressWithText 
                    value={dashboardData && dashboardData.totalProjects > 0 
                      ? Math.round((dashboardData.completedProjects / dashboardData.totalProjects) * 100) 
                      : 0} 
                    size="lg"
                  />
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">
                      {t("delay_rate")}
                    </span>
                    <span className="text-sm font-medium">
                      {dashboardData && dashboardData.activeProjects > 0 
                        ? Math.round((dashboardData.delayedProjects / dashboardData.activeProjects) * 100) 
                        : 0}%
                    </span>
                  </div>
                  <ProgressWithText 
                    value={dashboardData && dashboardData.activeProjects > 0 
                      ? Math.round((dashboardData.delayedProjects / dashboardData.activeProjects) * 100) 
                      : 0} 
                    size="lg"
                    variant="danger"
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* مقارنات الأداء (الميزانية والجدول الزمني) */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>{t("performance_comparison")}</CardTitle>
              <CardDescription>{t("performance_comparison_description")}</CardDescription>
            </div>
            <Tabs 
              value={performanceChartType} 
              onValueChange={setPerformanceChartType} 
              className="w-[240px]"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="budget">
                  {t("budget_performance")}
                </TabsTrigger>
                <TabsTrigger value="schedule">
                  {t("schedule_performance")}
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse">
              <div className="h-[300px] w-full bg-muted rounded"></div>
            </div>
          ) : (
            <div className="w-full h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={[
                    { name: t("common.jan"), planned: 25, actual: 20 },
                    { name: t("common.feb"), planned: 45, actual: 40 },
                    { name: t("common.mar"), planned: 65, actual: 55 },
                    { name: t("common.apr"), planned: 85, actual: 75 },
                    { name: t("common.may"), planned: 105, actual: 90 },
                    { name: t("common.jun"), planned: 125, actual: 120 },
                  ]}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [
                      `${formatCurrency(value as number)}`, 
                      performanceChartType === "budget" ? t("amount") : t("progress")
                    ]} 
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="planned" 
                    stroke="#8884d8" 
                    activeDot={{ r: 8 }} 
                    name={t("planned")}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="actual" 
                    stroke="#82ca9d" 
                    name={t("actual")}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
        <CardFooter className="bg-muted/20 py-2 px-6">
          <div className="w-full flex items-center justify-between text-sm text-muted-foreground">
            <span>{performanceChartType === "budget" ? t("budget_chart_note") : t("schedule_chart_note")}</span>
            <Button variant="outline" size="sm">
              <span className="material-icons mr-1 text-sm">download</span>
              {t("common.export")}
            </Button>
          </div>
        </CardFooter>
      </Card>
      
      {/* أحدث المشاريع */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{t("recent_projects")}</CardTitle>
          <CardDescription>{t("recently_added")}</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3, 4, 5].map(i => (
                <div key={i} className="flex justify-between items-center p-3 border rounded-md">
                  <div className="space-y-2">
                    <div className="h-4 w-48 bg-muted rounded"></div>
                    <div className="h-3 w-32 bg-muted rounded"></div>
                  </div>
                  <div className="h-6 w-20 bg-muted rounded"></div>
                </div>
              ))}
            </div>
          ) : dashboardData?.recentProjects && dashboardData.recentProjects.length > 0 ? (
            <div className="space-y-4">
              {dashboardData.recentProjects.map(project => (
                <div 
                  key={project.id} 
                  className="flex justify-between items-center p-3 border rounded-md hover:bg-muted/20 transition-colors"
                >
                  <div>
                    <h4 className="font-medium">
                      <Link href={`/projects/${project.id}`} className="hover:text-primary hover:underline">
                        {project.name}
                      </Link>
                    </h4>
                    <div className="flex items-center mt-1 text-sm text-muted-foreground">
                      <ProjectTypeBadge type={project.type} size="sm" />
                      <span className="mx-2">•</span>
                      <span>{project.createdAt ? formatDate(project.createdAt) : ''}</span>
                    </div>
                  </div>
                  <StatusBadge status={project.status} size="sm" />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">{t("no_recent_projects")}</p>
              <Button variant="outline" size="sm" className="mt-4" asChild>
                <Link href="/projects/new">
                  <span className="material-icons mr-1 text-sm">add</span>
                  {t("create")}
                </Link>
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="bg-muted/20 py-2 px-6">
          <div className="w-full flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{t("showing")} {dashboardData?.recentProjects?.length || 0} {t("of")} {dashboardData?.totalProjects || 0} {t("projects")}</span>
            <Button variant="link" size="sm" asChild>
              <Link href="/projects" className="flex items-center">
                {t("view_all")}
                <span className="material-icons ml-1 text-sm">arrow_forward</span>
              </Link>
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}