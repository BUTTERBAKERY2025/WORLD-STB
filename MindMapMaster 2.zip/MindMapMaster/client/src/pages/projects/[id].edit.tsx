import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Link, useLocation, useRoute } from "wouter";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, differenceInDays } from "date-fns";
import { ar } from "date-fns/locale";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { insertProjectSchema, Project } from "@shared/schema";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

// مخطط التحقق للتعديل
const editProjectSchema = insertProjectSchema.extend({
  name: z.string().min(3, "يجب أن يكون الاسم 3 أحرف على الأقل"),
  description: z.string().min(10, "يجب أن يكون الوصف 10 أحرف على الأقل"),
  budget: z.coerce.number().min(1000, "يجب أن تكون الميزانية 1000 على الأقل"),
  startDate: z.date(),
  endDate: z.date(),
});

type EditProjectValues = z.infer<typeof editProjectSchema>;

export default function EditProject() {
  const { t } = useTranslation();
  const [_, navigate] = useLocation();
  const [match, params] = useRoute<{ id: string }>("/projects/:id/edit");
  const projectId = params ? parseInt(params.id) : 0;
  const { toast } = useToast();
  const [projectDuration, setProjectDuration] = useState(0);
  
  // Form definition with initial empty values
  const form = useForm<EditProjectValues>({
    resolver: zodResolver(editProjectSchema),
    defaultValues: {
      name: "",
      description: "",
      type: "road",
      status: "planning",
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 3)),
      budget: 0,
      progress: 0,
      location: { type: "Point", coordinates: [46.738586, 24.774265] } as any,
      createdBy: 1,
      managedBy: 1
    },
  });
  
  // استخدام useState بدلاً من useQuery لتحميل المشروع
  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  
  // تسجيل إضافي لتتبع حالة التحميل
  console.log("Edit page: projectId=", projectId, "isLoading=", isLoading, "project=", project);
  
  // طلب البيانات عند تحميل الصفحة
  useEffect(() => {
    const fetchProjectData = async () => {
      console.log("Fetching project with ID:", projectId);
      try {
        if (!projectId) {
          setIsLoading(false);
          return;
        }
        
        const response = await apiRequest("GET", `/api/projects/${projectId}`);
        if (!response.ok) {
          const errorText = await response.text();
          console.error("API Response Error:", response.status, errorText);
          throw new Error(`فشل في تحميل بيانات المشروع (${response.status}): ${errorText}`);
        }
        
        const data = await response.json();
        console.log("Project data received:", data);
        setProject(data);
        setIsLoading(false);
      } catch (err) {
        console.error("Fetch error:", err);
        setError(err instanceof Error ? err : new Error("حدث خطأ غير معروف"));
        setIsLoading(false);
      }
    };
    
    fetchProjectData();
  }, [projectId]);
  
  // تحديث النموذج ببيانات المشروع عند تحميلها
  useEffect(() => {
    if (project) {
      // تحضير التواريخ
      const startDate = project.startDate ? new Date(project.startDate) : new Date();
      const endDate = project.endDate ? new Date(project.endDate) : new Date();
      
      // تحضير تنسيق الموقع (تحويل من {lat, lng} إلى {type: "Point", coordinates: [lng, lat]})
      let locationData;
      if (project.location) {
        // تحقق من نوع الموقع ونسقه بالشكل المطلوب
        if ('lat' in project.location && 'lng' in project.location) {
          // تحويل من {lat, lng} إلى {type: "Point", coordinates: [lng, lat]}
          locationData = { 
            type: "Point", 
            coordinates: [project.location.lng, project.location.lat] 
          };
        } else if ('type' in project.location && 'coordinates' in project.location) {
          // الموقع بالفعل بالتنسيق المطلوب
          locationData = project.location;
        } else {
          // تنسيق افتراضي إذا لم يتمكن من التعرف على التنسيق
          locationData = { type: "Point", coordinates: [46.738586, 24.774265] };
        }
      } else {
        // إذا لم يكن هناك موقع، استخدم القيمة الافتراضية
        locationData = { type: "Point", coordinates: [46.738586, 24.774265] };
      }
      
      // تحديث قيم النموذج
      form.reset({
        ...project,
        startDate,
        endDate,
        location: locationData as any,
      });
    }
  }, [project, form]);
  
  // حساب مدة المشروع عند تغيير تاريخ البدء أو الانتهاء
  useEffect(() => {
    const startDate = form.watch('startDate');
    const endDate = form.watch('endDate');
    
    if (startDate instanceof Date && endDate instanceof Date) {
      // حساب الفرق بالأيام
      const days = differenceInDays(endDate, startDate);
      setProjectDuration(days > 0 ? days : 0);
    }
  }, [form.watch('startDate'), form.watch('endDate')]);
  
  // تحديث المشروع mutation
  const updateProjectMutation = useMutation({
    mutationFn: async (data: EditProjectValues) => {
      // تأكد من أن التواريخ المرسلة هي كائنات Date وليست سلاسل نصية
      if (typeof data.startDate === 'string') {
        data.startDate = new Date(data.startDate);
      }
      if (typeof data.endDate === 'string') {
        data.endDate = new Date(data.endDate);
      }
      
      // تحويل صيغة الموقع من {type: "Point", coordinates: [lng, lat]} إلى {lat, lng}
      let locationForAPI = data.location;
      if (data.location && 'type' in data.location && 'coordinates' in data.location) {
        const coords = data.location.coordinates as number[];
        if (coords && coords.length >= 2) {
          locationForAPI = {
            lat: coords[1],
            lng: coords[0]
          };
        }
      }
      
      // تجهيز البيانات للإرسال
      const dataToSend = {
        ...data,
        location: locationForAPI
      };
      
      const response = await apiRequest("PATCH", `/api/projects/${projectId}`, dataToSend);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
      toast({
        title: "تم تحديث المشروع بنجاح",
        description: "تم حفظ التغييرات بنجاح",
      });
      navigate(`/projects/${projectId}`);
    },
    onError: (error) => {
      toast({
        title: "خطأ في تحديث المشروع",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (data: EditProjectValues) => {
    updateProjectMutation.mutate(data);
  };
  
  // عرض رسالة خطأ إذا فشل تحميل بيانات المشروع
  if (error) {
    return (
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="sm" asChild className="ml-2">
            <Link href="/projects">
              <span className="material-icons ml-1">arrow_back</span>
              {t("common.back")}
            </Link>
          </Button>
          <h1 className="text-2xl font-bold text-gray-800">{t("project.edit")}</h1>
        </div>
        
        <Card>
          <CardContent className="p-6 flex flex-col items-center justify-center">
            <div className="text-red-500 text-6xl mb-4">
              <span className="material-icons text-6xl">error_outline</span>
            </div>
            <h2 className="text-xl font-medium mb-2">فشل في تحميل بيانات المشروع</h2>
            <p className="text-gray-500 mb-4">{error instanceof Error ? error.message : "حدث خطأ غير معروف"}</p>
            <Button asChild>
              <Link href="/projects">
                العودة إلى المشاريع
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // عرض شاشة التحميل
  if (isLoading || !project) {
    return (
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center mb-6">
          <Skeleton className="h-10 w-24 ml-2" />
          <Skeleton className="h-8 w-48" />
        </div>
        
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-6 w-full" />
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {Array(6).fill(null).map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ))}
            </div>
            <Skeleton className="h-20 w-full" />
          </CardContent>
          <CardFooter className="flex justify-between">
            <Skeleton className="h-10 w-24" />
            <Skeleton className="h-10 w-24" />
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto max-w-4xl">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="sm" asChild className="ml-2">
          <Link href={`/projects/${projectId}`}>
            <span className="material-icons ml-1">arrow_back</span>
            {t("common.back")}
          </Link>
        </Button>
        <h1 className="text-2xl font-bold text-gray-800">{t("project.edit")}</h1>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>{t("project.edit_details")}</CardTitle>
          <CardDescription>
            تعديل تفاصيل المشروع. جميع الحقول المميزة بـ * مطلوبة.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Project Name */}
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {t("project.name")} <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل اسم المشروع" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Project Type */}
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {t("project.type")} <span className="text-red-500">*</span>
                      </FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر نوع المشروع" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="road">{t("project.types.road")}</SelectItem>
                          <SelectItem value="water">{t("project.types.water")}</SelectItem>
                          <SelectItem value="electricity">{t("project.types.electricity")}</SelectItem>
                          <SelectItem value="telecom">{t("project.types.telecom")}</SelectItem>
                          <SelectItem value="building">{t("project.types.building")}</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Project Status */}
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {t("project.status")} <span className="text-red-500">*</span>
                      </FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر حالة المشروع" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="planning">تخطيط</SelectItem>
                          <SelectItem value="in_progress">قيد التنفيذ</SelectItem>
                          <SelectItem value="delayed">متأخر</SelectItem>
                          <SelectItem value="completed">مكتمل</SelectItem>
                          <SelectItem value="stopped">متوقف</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Project Budget */}
                <FormField
                  control={form.control}
                  name="budget"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {t("project.budget")} <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل ميزانية المشروع" 
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormDescription>
                        القيمة بالريال السعودي
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Project Progress */}
                <FormField
                  control={form.control}
                  name="progress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {t("project.progress")}
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل نسبة الإنجاز" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          value={field.value || ''}
                          min="0"
                          max="100"
                        />
                      </FormControl>
                      <FormDescription>
                        القيمة من 0 إلى 100
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Start Date */}
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>
                        {t("project.start_date")} <span className="text-red-500">*</span>
                      </FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className="w-full justify-start text-right"
                            >
                              {field.value ? (
                                format(new Date(field.value), "PPP", { locale: ar })
                              ) : (
                                <span>اختر تاريخ</span>
                              )}
                              <span className="material-icons mr-auto">calendar_today</span>
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={field.value instanceof Date ? field.value : undefined}
                            onSelect={(date) => field.onChange(date || new Date())}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* End Date */}
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>
                        {t("project.end_date")} <span className="text-red-500">*</span>
                      </FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className="w-full justify-start text-right"
                            >
                              {field.value ? (
                                format(new Date(field.value), "PPP", { locale: ar })
                              ) : (
                                <span>اختر تاريخ</span>
                              )}
                              <span className="material-icons mr-auto">calendar_today</span>
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={field.value instanceof Date ? field.value : undefined}
                            onSelect={(date) => field.onChange(date || new Date())}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* عرض مدة المشروع */}
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 flex items-center justify-between">
                <div className="flex items-center">
                  <span className="material-icons text-gray-500 ml-2">date_range</span>
                  <span className="text-gray-700 font-medium">مدة المشروع:</span>
                </div>
                <div className="flex items-center">
                  <span className="text-lg font-bold text-primary">{projectDuration}</span>
                  <span className="mr-1 text-gray-600">يوم</span>
                </div>
              </div>
              
              {/* Project Description */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {t("project.description")} <span className="text-red-500">*</span>
                    </FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="أدخل وصف المشروع" 
                        className="min-h-[120px]" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Hidden fields - location already set in form reset */}
              <div className="hidden">
                <input type="hidden" name="createdBy" id="createdBy" value={form.getValues('createdBy') || 1} />
                <input type="hidden" name="managedBy" id="managedBy" value={form.getValues('managedBy') || 1} />
              </div>
              
              <CardFooter className="px-0 pb-0 pt-6 flex justify-between">
                <Button variant="outline" asChild>
                  <Link href={`/projects/${projectId}`}>{t("common.cancel")}</Link>
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateProjectMutation.isPending}
                  className="flex items-center"
                >
                  {updateProjectMutation.isPending && (
                    <span className="material-icons animate-spin ml-2">autorenew</span>
                  )}
                  {t("common.save")}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}