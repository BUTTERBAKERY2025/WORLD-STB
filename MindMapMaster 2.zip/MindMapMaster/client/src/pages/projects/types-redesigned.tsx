import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// مكونات UI
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

// أيقونات
import { 
  PlusCircle, 
  Search, 
  FileEdit, 
  Trash2, 
  MoreHorizontal, 
  LayoutGrid, 
  List, 
  BarChart3, 
  Download, 
  Printer, 
  RefreshCcw, 
  MapPin, 
  Droplet, 
  Zap, 
  Phone, 
  Building2, 
  Check, 
  Filter, 
  LucideIcon
} from "lucide-react";

// واجهة بيانات نوع المشروع
interface ProjectType {
  id: number;
  name: string;
  description: string;
  createdAt: string;
}

// مكون أيقونة النوع
const TypeIcon = ({ type }: { type: string }) => {
  const getIcon = (): React.ReactNode => {
    switch (type) {
      case 'road':
        return <MapPin className="h-6 w-6 text-amber-500" />;
      case 'water':
        return <Droplet className="h-6 w-6 text-blue-500" />;
      case 'electricity':
        return <Zap className="h-6 w-6 text-yellow-500" />;
      case 'telecom':
        return <Phone className="h-6 w-6 text-purple-500" />;
      case 'building':
        return <Building2 className="h-6 w-6 text-emerald-500" />;
      default:
        return <Building2 className="h-6 w-6 text-gray-500" />;
    }
  };

  return (
    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-100">
      {getIcon()}
    </div>
  );
};

// مكون بطاقة النوع
const TypeCard = ({ 
  type, 
  onEdit, 
  onDelete 
}: { 
  type: ProjectType; 
  onEdit: (type: ProjectType) => void; 
  onDelete: (id: number) => void; 
}) => {
  const { t } = useTranslation();
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <TypeIcon type={type.name} />
            <div>
              <CardTitle className="text-lg">
                {t(`project.type.${type.name}`) || type.name}
              </CardTitle>
              <CardDescription className="text-xs mt-1">
                ID: {type.id}
              </CardDescription>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">{t("common.actions")}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit(type)}>
                <FileEdit className="h-4 w-4 ml-2" />
                <span>{t("common.edit")}</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="text-destructive focus:text-destructive" 
                onClick={() => onDelete(type.id)}
              >
                <Trash2 className="h-4 w-4 ml-2" />
                <span>{t("common.delete")}</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">
          {t(`type_descriptions.${type.name}`) || type.description}
        </p>
      </CardContent>
      <CardFooter className="pt-1 text-xs text-muted-foreground border-t">
        <div className="flex w-full justify-between">
          <div>{t("common.created_at")}</div>
          <div>{new Date(type.createdAt).toLocaleDateString()}</div>
        </div>
      </CardFooter>
    </Card>
  );
};

// المكون الرئيسي
export default function ProjectTypesRedesigned() {
  const { t } = useTranslation();
  const { toast } = useToast();
  
  // الحالة والإعدادات
  const [viewMode, setViewMode] = useState<'table' | 'cards' | 'chart'>('cards');
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentType, setCurrentType] = useState<ProjectType | null>(null);

  // استعلام للحصول على أنواع المشاريع
  const { 
    data: projectTypes = [], 
    isLoading, 
    isError, 
    refetch 
  } = useQuery<ProjectType[]>({
    queryKey: ["/api/project-types"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/project-types");
      return response.json();
    },
  });

  // إضافة نوع مشروع جديد
  const addMutation = useMutation({
    mutationFn: async (data: Omit<ProjectType, 'id' | 'createdAt'>) => {
      const res = await apiRequest("POST", "/api/project-types", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project-types"] });
      toast({
        description: t("project.type_added_successfully"),
      });
      setShowAddDialog(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: t("project.type_add_error"),
        description: error.message,
      });
    },
  });

  // تحديث نوع مشروع
  const updateMutation = useMutation({
    mutationFn: async (data: ProjectType) => {
      const res = await apiRequest("PATCH", `/api/project-types/${data.id}`, {
        name: data.name,
        description: data.description,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project-types"] });
      toast({
        description: t("project.type_updated_successfully"),
      });
      setShowAddDialog(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: t("project.type_update_error"),
        description: error.message,
      });
    },
  });

  // حذف نوع مشروع
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/project-types/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/project-types"] });
      toast({
        description: t("project.type_deleted_successfully"),
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: t("project.type_delete_error"),
        description: error.message,
      });
    },
  });

  // تصفية أنواع المشاريع حسب البحث
  const filteredTypes = projectTypes.filter(
    (type) =>
      type.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      type.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // إعادة تعيين النموذج
  const resetForm = () => {
    setCurrentType(null);
    setIsEditMode(false);
  };

  // بدء تحرير نوع
  const handleEdit = (type: ProjectType) => {
    setCurrentType(type);
    setIsEditMode(true);
    setShowAddDialog(true);
  };

  // حذف نوع
  const handleDelete = (id: number) => {
    if (window.confirm(t("project.confirm_delete_type"))) {
      deleteMutation.mutate(id);
    }
  };

  // إرسال نموذج الإضافة/التحرير
  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!currentType || !currentType.name || !currentType.description) {
      toast({
        variant: "destructive",
        title: t("validation.required_field"),
        description: t("project.type_fields_required"),
      });
      return;
    }

    if (isEditMode) {
      updateMutation.mutate(currentType);
    } else {
      const { name, description } = currentType;
      addMutation.mutate({ name, description });
    }
  };

  // عرض حالة التحميل
  if (isLoading) {
    return (
      <div className="flex h-[70vh] items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="h-12 w-12 animate-spin rounded-full border-b-2 border-primary"></div>
          <p className="text-lg font-medium">{t("loading")}</p>
        </div>
      </div>
    );
  }

  // عرض حالة الخطأ
  if (isError) {
    return (
      <div className="flex h-[70vh] flex-col items-center justify-center space-y-4">
        <div className="rounded-full bg-red-100 p-4 text-red-600">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-10 w-10"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
            />
          </svg>
        </div>
        <h3 className="text-xl font-bold">{t("common.error_loading")}</h3>
        <p className="text-muted-foreground">{t("project.error_loading_types")}</p>
        <Button onClick={() => refetch()}>{t("common.try_again")}</Button>
      </div>
    );
  }

  // المكون الرئيسي للصفحة
  return (
    <div className="container mx-auto p-6">
      {/* ترويسة الصفحة */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">{t("project.project_types")}</h1>
        <p className="text-muted-foreground">{t("project.manage_project_types_description")}</p>
      </div>

      {/* شريط الأدوات */}
      <div className="mb-6 flex flex-col md:flex-row space-y-4 md:space-y-0 md:items-center md:justify-between">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 md:items-center">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t("project.search_types")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-3 pr-10 w-full md:w-[300px]"
            />
          </div>
          
          <Select defaultValue="all">
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder={t("common.filter")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الأنواع</SelectItem>
              <SelectItem value="road">الطرق</SelectItem>
              <SelectItem value="water">المياه</SelectItem>
              <SelectItem value="electricity">الكهرباء</SelectItem>
              <SelectItem value="telecom">الاتصالات</SelectItem>
              <SelectItem value="building">المباني</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-wrap space-x-2 items-center">
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCcw className="h-4 w-4 ml-2" />
            <span>{t("common.refresh")}</span>
          </Button>
          
          <Button variant="outline" size="sm">
            <Printer className="h-4 w-4 ml-2" />
            <span>{t("print")}</span>
          </Button>
          
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            <span>{t("export.export_excel")}</span>
          </Button>
          
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  setIsEditMode(false);
                  setCurrentType({ id: 0, name: "", description: "", createdAt: "" });
                }}
              >
                <PlusCircle className="h-4 w-4 ml-2" />
                <span>{t("project.add_project_type")}</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {isEditMode
                    ? t("project.edit_project_type")
                    : t("project.add_project_type")}
                </DialogTitle>
                <DialogDescription>
                  {isEditMode
                    ? t("project.edit_project_type_description")
                    : t("project.add_project_type_description")}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-right">
                      {t("project.type_name")}
                    </Label>
                    <Input
                      id="name"
                      value={currentType?.name || ""}
                      onChange={(e) =>
                        setCurrentType({
                          ...currentType!,
                          name: e.target.value,
                        })
                      }
                      placeholder="مثال: road, water, building"
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description" className="text-right">
                      {t("project.type_description")}
                    </Label>
                    <Input
                      id="description"
                      value={currentType?.description || ""}
                      onChange={(e) =>
                        setCurrentType({
                          ...currentType!,
                          description: e.target.value,
                        })
                      }
                      placeholder="وصف نوع المشروع"
                      className="w-full"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      resetForm();
                      setShowAddDialog(false);
                    }}
                  >
                    {t("common.cancel")}
                  </Button>
                  <Button
                    type="submit"
                    disabled={addMutation.isPending || updateMutation.isPending}
                  >
                    {isEditMode ? t("common.save") : t("common.add")}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* أزرار تبديل طريقة العرض */}
      <div className="mb-6">
        <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as 'cards' | 'table' | 'chart')}>
          <TabsList className="mb-4">
            <TabsTrigger value="cards">
              <LayoutGrid className="h-4 w-4 ml-2" />
              <span>{t("view.cards")}</span>
            </TabsTrigger>
            <TabsTrigger value="table">
              <List className="h-4 w-4 ml-2" />
              <span>{t("view.table")}</span>
            </TabsTrigger>
            <TabsTrigger value="chart">
              <BarChart3 className="h-4 w-4 ml-2" />
              <span>مخطط</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* محتوى البيانات */}
      <div className="bg-white rounded-lg border shadow-sm">
        {filteredTypes.length === 0 ? (
          <div className="p-12 text-center">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-muted">
              <Search className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="mt-4 text-lg font-semibold">
              {t("project.no_types_found")}
            </h3>
            <p className="mb-4 mt-2 text-sm text-muted-foreground">
              {searchTerm
                ? "لم يتم العثور على أنواع مشاريع تطابق بحثك"
                : "لم يتم إضافة أنواع مشاريع بعد. يمكنك إضافة نوع جديد الآن."}
            </p>
            <Button
              onClick={() => {
                setIsEditMode(false);
                setCurrentType({ id: 0, name: "", description: "", createdAt: "" });
                setShowAddDialog(true);
              }}
            >
              <PlusCircle className="h-4 w-4 ml-2" />
              <span>{t("project.add_project_type")}</span>
            </Button>
          </div>
        ) : (
          <>
            {/* عرض البطاقات */}
            {viewMode === "cards" && (
              <div className="p-6">
                <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {filteredTypes.map((type) => (
                    <TypeCard
                      key={type.id}
                      type={type}
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* عرض الجدول */}
            {viewMode === "table" && (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead style={{ width: 48 }}>
                        <Checkbox />
                      </TableHead>
                      <TableHead style={{ width: 60 }}>{t("common.id")}</TableHead>
                      <TableHead>{t("project.type_name")}</TableHead>
                      <TableHead className="hidden md:table-cell">{t("project.type_description")}</TableHead>
                      <TableHead className="hidden md:table-cell">{t("common.created_at")}</TableHead>
                      <TableHead style={{ width: 80 }}>{t("common.actions")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTypes.map((type) => (
                      <TableRow key={type.id}>
                        <TableCell>
                          <Checkbox />
                        </TableCell>
                        <TableCell className="font-medium">{type.id}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <TypeIcon type={type.name} />
                            <div>
                              <div className="font-medium">
                                {t(`project.type.${type.name}`) || type.name}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {t(`type_descriptions.${type.name}`) || type.description}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {new Date(type.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">{t("common.actions")}</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleEdit(type)}>
                                <FileEdit className="h-4 w-4 ml-2" />
                                <span>{t("common.edit")}</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="text-destructive focus:text-destructive"
                                onClick={() => handleDelete(type.id)}
                              >
                                <Trash2 className="h-4 w-4 ml-2" />
                                <span>{t("common.delete")}</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            {/* عرض المخطط البياني */}
            {viewMode === "chart" && (
              <div className="p-6">
                <div className="flex flex-col space-y-8">
                  <div className="rounded-lg border p-6">
                    <h3 className="mb-4 text-lg font-semibold">توزيع أنواع المشاريع</h3>
                    <div className="flex flex-wrap gap-4">
                      {['road', 'water', 'electricity', 'telecom', 'building'].map(type => {
                        const count = filteredTypes.filter(t => t.name === type).length;
                        const percentage = (count / filteredTypes.length) * 100;
                        
                        return (
                          <div key={type} className="flex flex-col items-center">
                            <div className="relative mb-2 h-32 w-10 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className={`absolute bottom-0 w-full ${
                                  type === 'road' ? 'bg-amber-500' :
                                  type === 'water' ? 'bg-blue-500' :
                                  type === 'electricity' ? 'bg-yellow-500' :
                                  type === 'telecom' ? 'bg-purple-500' :
                                  'bg-emerald-500'
                                }`}
                                style={{ height: `${percentage}%` }}
                              ></div>
                            </div>
                            <TypeIcon type={type} />
                            <span className="mt-1 text-sm font-medium">
                              {t(`project.type.${type}`) || type}
                            </span>
                            <span className="text-xs text-muted-foreground">{count}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>إحصائيات أنواع المشاريع</CardTitle>
                        <CardDescription>توزيع المشاريع حسب النوع</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-4">
                          {['road', 'water', 'electricity', 'telecom', 'building'].map(type => {
                            const count = filteredTypes.filter(t => t.name === type).length;
                            const percentage = (count / filteredTypes.length) * 100;
                            
                            return (
                              <li key={type} className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <TypeIcon type={type} />
                                  <span className="font-medium">
                                    {t(`project.type.${type}`) || type}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${
                                        type === 'road' ? 'bg-amber-500' :
                                        type === 'water' ? 'bg-blue-500' :
                                        type === 'electricity' ? 'bg-yellow-500' :
                                        type === 'telecom' ? 'bg-purple-500' :
                                        'bg-emerald-500'
                                      }`}
                                      style={{ width: `${percentage}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-sm">
                                    {count} ({percentage.toFixed(1)}%)
                                  </span>
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>مشاريع حسب النوع</CardTitle>
                        <CardDescription>عدد المشاريع المرتبطة بكل نوع</CardDescription>
                      </CardHeader>
                      <CardContent className="flex flex-col justify-center h-full">
                        <div className="flex justify-center items-center h-full">
                          <p className="text-center text-muted-foreground">
                            سيتم عرض إحصائيات المشاريع المرتبطة بكل نوع هنا
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            )}
            
            {/* تذييل الصفحة */}
            <div className="border-t p-4 text-sm text-muted-foreground flex items-center justify-between">
              <span>
                {t("project.total_project_types", { count: filteredTypes.length })}
              </span>
              {searchTerm && (
                <Button variant="ghost" size="sm" onClick={() => setSearchTerm("")}>
                  <Check className="h-4 w-4 ml-2" />
                  <span>{t("common.clear_filter")}</span>
                </Button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}