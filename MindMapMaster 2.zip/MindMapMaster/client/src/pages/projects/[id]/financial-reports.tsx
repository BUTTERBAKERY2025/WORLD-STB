import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  ResponsiveContainer
} from 'recharts';
import { ChevronLeft, Building2, BarChart4, FileText, ArrowUpRight } from 'lucide-react';
import ProjectLayout from '@/components/layouts/ProjectLayout';

// بيانات تجريبية للرسوم البيانية
const budgetVsExpensesData = [
  { name: 'مواد البناء', budget: 350000, expenses: 320000 },
  { name: 'عمالة', budget: 250000, expenses: 230000 },
  { name: 'معدات', budget: 150000, expenses: 120000 },
  { name: 'مقاولي الباطن', budget: 200000, expenses: 210000 },
  { name: 'نقل', budget: 50000, expenses: 45000 },
  { name: 'إدارية', budget: 80000, expenses: 60000 },
];

const expensesByTypeData = [
  { name: 'مواد', value: 320000 },
  { name: 'عمالة', value: 230000 },
  { name: 'معدات', value: 120000 },
  { name: 'مقاولين', value: 210000 },
  { name: 'نقل', value: 45000 },
  { name: 'إدارية', value: 60000 },
];

const certificatesStatusData = [
  { name: 'مستخلصات مدفوعة', value: 750000 },
  { name: 'مستخلصات معتمدة', value: 250000 },
  { name: 'مستخلصات معلقة', value: 150000 },
];

const monthlyProfitData = [
  { month: 'يناير', إيرادات: 180000, مصروفات: 120000, ربح: 60000 },
  { month: 'فبراير', إيرادات: 210000, مصروفات: 150000, ربح: 60000 },
  { month: 'مارس', إيرادات: 240000, مصروفات: 180000, ربح: 60000 },
  { month: 'أبريل', إيرادات: 270000, مصروفات: 210000, ربح: 60000 },
  { month: 'مايو', إيرادات: 300000, مصروفات: 240000, ربح: 60000 },
  { month: 'يونيو', إيرادات: 330000, مصروفات: 270000, ربح: 60000 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function ProjectFinancialReports() {
  const { t } = useTranslation();
  const params = useParams();
  const projectId = params.id;
  const [activeTab, setActiveTab] = useState('budget');

  // استعلامات للحصول على بيانات المشروع (يمكن تنفيذها لاحقًا)
  const { data: project, isLoading } = useQuery({
    queryKey: ['/api/projects', projectId],
    enabled: !!projectId,
  });

  // تنسيق الأرقام بالعملة
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // تنسيق النسب المئوية
  const formatPercentage = (percentage: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'percent',
      maximumFractionDigits: 1,
    }).format(percentage / 100);
  };

  if (isLoading) {
    return (
      <ProjectLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </ProjectLayout>
    );
  }

  // حساب إجمالي الميزانية
  const totalBudget = budgetVsExpensesData.reduce((sum, item) => sum + item.budget, 0);
  
  // حساب إجمالي المصروفات
  const totalExpenses = budgetVsExpensesData.reduce((sum, item) => sum + item.expenses, 0);
  
  // حساب نسبة المصروفات
  const expensePercentage = Math.round((totalExpenses / totalBudget) * 100);
  
  // حساب المتبقي من الميزانية
  const remainingBudget = totalBudget - totalExpenses;

  // حساب إجمالي المستخلصات
  const totalCertificates = certificatesStatusData.reduce((sum, item) => sum + item.value, 0);
  
  // حساب نسبة استكمال المشروع مالياً
  const financialCompletion = Math.round((totalExpenses / totalBudget) * 100);

  return (
    <ProjectLayout>
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <div className="flex items-center">
              <Link href={`/projects/${projectId}`}>
                <Button variant="ghost" size="sm">
                  <ChevronLeft className="h-4 w-4 ml-2" />
                  {t('common.back_to_project') || "العودة للمشروع"}
                </Button>
              </Link>
              <h1 className="text-2xl font-bold">{t('financial.reports.title') || "التقارير المالية للمشروع"}</h1>
            </div>
            <p className="text-muted-foreground mt-1">{t('financial.reports.project_description') || "تحليل الأداء المالي والميزانية والمصروفات"}</p>
          </div>

          <div>
            <Button variant="outline">
              <FileText className="h-4 w-4 ml-2" />
              {t('financial.export_report') || "تصدير التقرير"}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.total_budget') || "إجمالي الميزانية"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalBudget)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.total_expenses') || "إجمالي المصروفات"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalExpenses)}</div>
              <div className="text-sm text-muted-foreground">{formatPercentage(expensePercentage)} {t('financial.from_budget') || "من الميزانية"}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.remaining_budget') || "المتبقي من الميزانية"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(remainingBudget)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.financial_completion') || "نسبة الإنجاز المالي"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatPercentage(financialCompletion)}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="budget">
              <BarChart4 className="h-4 w-4 ml-2" />
              {t('financial.budget_vs_expenses') || "الميزانية والمصروفات"}
            </TabsTrigger>
            <TabsTrigger value="certificates">
              <FileText className="h-4 w-4 ml-2" />
              {t('financial.certificates_status') || "حالة المستخلصات"}
            </TabsTrigger>
            <TabsTrigger value="profitability">
              <Building2 className="h-4 w-4 ml-2" />
              {t('financial.profitability') || "الربحية"}
            </TabsTrigger>
          </TabsList>

          {/* الميزانية والمصروفات */}
          <TabsContent value="budget" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('financial.budget_vs_expenses') || "الميزانية مقابل المصروفات"}</CardTitle>
                <CardDescription>
                  {t('financial.budget_vs_expenses_by_category') || "توزيع الميزانية والمصروفات حسب الفئة"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={budgetVsExpensesData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis tickFormatter={value => formatCurrency(value)} />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Bar dataKey="budget" name={t('financial.budget') || "الميزانية"} fill="#8884d8" />
                      <Bar dataKey="expenses" name={t('financial.expenses') || "المصروفات"} fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>{t('financial.expense_distribution') || "توزيع المصروفات"}</CardTitle>
                  <CardDescription>
                    {t('financial.expense_distribution_by_category') || "توزيع المصروفات حسب الفئة"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={expensesByTypeData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                          nameKey="name"
                          label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {expensesByTypeData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{t('financial.budget_items') || "بنود الميزانية"}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="max-h-[300px] overflow-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{t('financial.item_name') || "اسم البند"}</TableHead>
                          <TableHead>{t('financial.budget') || "الميزانية"}</TableHead>
                          <TableHead>{t('financial.expenses') || "المصروفات"}</TableHead>
                          <TableHead>{t('financial.remaining') || "المتبقي"}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {budgetVsExpensesData.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell>{formatCurrency(item.budget)}</TableCell>
                            <TableCell>{formatCurrency(item.expenses)}</TableCell>
                            <TableCell>{formatCurrency(item.budget - item.expenses)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* حالة المستخلصات */}
          <TabsContent value="certificates" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('financial.certificates_status') || "حالة المستخلصات"}</CardTitle>
                <CardDescription>
                  {t('financial.certificates_status_by_status') || "توزيع المستخلصات حسب الحالة"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={certificatesStatusData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={150}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({name, value, percent}) => `${name}: ${formatCurrency(value)} (${(percent * 100).toFixed(0)}%)`}
                      >
                        {certificatesStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t('financial.certificates_list') || "قائمة المستخلصات"}</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('financial.certificate_number') || "رقم المستخلص"}</TableHead>
                      <TableHead>{t('financial.issue_date') || "تاريخ الإصدار"}</TableHead>
                      <TableHead>{t('financial.amount') || "المبلغ"}</TableHead>
                      <TableHead>{t('common.status') || "الحالة"}</TableHead>
                      <TableHead>{t('financial.payment') || "الدفع"}</TableHead>
                      <TableHead className="text-right">{t('common.details') || "التفاصيل"}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">001</TableCell>
                      <TableCell>2025-01-15</TableCell>
                      <TableCell>{formatCurrency(250000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">مدفوع</span>
                      </TableCell>
                      <TableCell>{formatCurrency(250000)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <ArrowUpRight className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">002</TableCell>
                      <TableCell>2025-02-15</TableCell>
                      <TableCell>{formatCurrency(350000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">مدفوع</span>
                      </TableCell>
                      <TableCell>{formatCurrency(350000)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <ArrowUpRight className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">003</TableCell>
                      <TableCell>2025-03-15</TableCell>
                      <TableCell>{formatCurrency(250000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">معتمد</span>
                      </TableCell>
                      <TableCell>{formatCurrency(150000)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <ArrowUpRight className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">004</TableCell>
                      <TableCell>2025-04-15</TableCell>
                      <TableCell>{formatCurrency(150000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">معلق</span>
                      </TableCell>
                      <TableCell>{formatCurrency(0)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <ArrowUpRight className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* الربحية */}
          <TabsContent value="profitability" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>{t('financial.contract_value') || "قيمة العقد"}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(1500000)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>{t('financial.estimated_profit') || "الربح المتوقع"}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{formatCurrency(420000)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>{t('financial.profit_margin') || "هامش الربح"}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">28%</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>{t('financial.target_completion_date') || "تاريخ الإنجاز المستهدف"}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-medium">2025-08-30</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>{t('financial.monthly_profitability') || "الربحية الشهرية"}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={monthlyProfitData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis tickFormatter={value => formatCurrency(value)} />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Line type="monotone" dataKey="إيرادات" stroke="#8884d8" name={t('financial.income') || "الإيرادات"} />
                      <Line type="monotone" dataKey="مصروفات" stroke="#82ca9d" name={t('financial.expenses') || "المصروفات"} />
                      <Line type="monotone" dataKey="ربح" stroke="#ff7300" name={t('financial.profit') || "الربح"} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t('financial.profitability_analysis') || "تحليل الربحية"}</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('financial.indicator') || "المؤشر"}</TableHead>
                      <TableHead>{t('financial.target') || "المستهدف"}</TableHead>
                      <TableHead>{t('financial.actual') || "الفعلي"}</TableHead>
                      <TableHead>{t('financial.variance') || "الفرق"}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">{t('financial.profit_margin') || "هامش الربح"}</TableCell>
                      <TableCell>25%</TableCell>
                      <TableCell className="text-green-600">28%</TableCell>
                      <TableCell className="text-green-600">+3%</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">{t('financial.cost_performance_index') || "مؤشر أداء التكلفة"}</TableCell>
                      <TableCell>1.0</TableCell>
                      <TableCell className="text-green-600">1.1</TableCell>
                      <TableCell className="text-green-600">+0.1</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">{t('financial.schedule_performance_index') || "مؤشر أداء الجدول الزمني"}</TableCell>
                      <TableCell>1.0</TableCell>
                      <TableCell className="text-yellow-600">0.9</TableCell>
                      <TableCell className="text-yellow-600">-0.1</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">{t('financial.return_on_investment') || "العائد على الاستثمار"}</TableCell>
                      <TableCell>20%</TableCell>
                      <TableCell className="text-green-600">22%</TableCell>
                      <TableCell className="text-green-600">+2%</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ProjectLayout>
  );
}