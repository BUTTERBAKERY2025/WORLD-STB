import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import { Icon, LatLngExpression } from "leaflet";
import 'leaflet/dist/leaflet.css';
import { Project, projectTypeMap } from "@shared/schema";
import { fetchProjects } from "../projects/fetchProjects";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ProjectTypeBadge } from "@/components/ui/project-type-badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { formatCurrency } from "@/lib/utils";
import { Link } from "wouter";

// Default icon workaround for Leaflet in React
// Create custom icon
const customIcon = new Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Generate custom SVG icons for different project types
const createSVGIcon = (color: string) => {
  const svgTemplate = `
    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="40" viewBox="0 0 28 40">
      <path fill="${color}" stroke="#fff" stroke-width="1.5" d="M14 0C6.3 0 0 6.3 0 14c0 10.5 14 26 14 26s14-15.5 14-26C28 6.3 21.7 0 14 0z"/>
      <circle fill="white" cx="14" cy="14" r="7"/>
    </svg>
  `;
  
  return `data:image/svg+xml;base64,${btoa(svgTemplate)}`;
};

// Map type icons
const mapTypeIcons = {
  road: new Icon({
    iconUrl: createSVGIcon('#3b82f6'), // blue
    iconSize: [28, 40],
    iconAnchor: [14, 40],
    popupAnchor: [0, -35]
  }),
  water: new Icon({
    iconUrl: createSVGIcon('#06b6d4'), // cyan
    iconSize: [28, 40],
    iconAnchor: [14, 40],
    popupAnchor: [0, -35]
  }),
  electricity: new Icon({
    iconUrl: createSVGIcon('#eab308'), // yellow
    iconSize: [28, 40],
    iconAnchor: [14, 40],
    popupAnchor: [0, -35]
  }),
  telecom: new Icon({
    iconUrl: createSVGIcon('#a855f7'), // purple
    iconSize: [28, 40],
    iconAnchor: [14, 40],
    popupAnchor: [0, -35]
  }),
  building: new Icon({
    iconUrl: createSVGIcon('#84cc16'), // lime
    iconSize: [28, 40],
    iconAnchor: [14, 40],
    popupAnchor: [0, -35]
  })
};

// Default center for the map (Saudi Arabia)
const DEFAULT_CENTER: LatLngExpression = [24.7136, 46.6753];
const DEFAULT_ZOOM = 6;

// Helper to recenter map
function MapUpdater({ center, zoom }: { center: LatLngExpression, zoom: number }) {
  const map = useMap();
  
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  
  return null;
}

// Utility function to parse GeoJSON location
function parseLocation(location: any): LatLngExpression | null {
  if (!location) return null;
  
  try {
    // If it's a GeoJSON Point
    if (location.type === 'Point' && Array.isArray(location.coordinates)) {
      // GeoJSON uses [longitude, latitude] format, but Leaflet uses [latitude, longitude]
      return [location.coordinates[1], location.coordinates[0]];
    }
    
    // If it's already in the right format
    if (Array.isArray(location) && location.length === 2) {
      return location as LatLngExpression;
    }
    
    // If it's an object with lat and lng
    if (location.lat && location.lng) {
      return [location.lat, location.lng];
    }
  } catch (error) {
    console.error("Error parsing location:", error);
  }
  
  return null;
}

export default function ProjectsMap() {
  const { t } = useTranslation();
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [mapCenter, setMapCenter] = useState<LatLngExpression>(DEFAULT_CENTER);
  const [mapZoom, setMapZoom] = useState(DEFAULT_ZOOM);
  
  // Fetch projects data
  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    queryFn: fetchProjects,
    staleTime: 60000, // 1 minute
  });
  
  // Filter projects with valid locations
  const projectsWithLocation = projects.filter(project => {
    const location = parseLocation(project.location);
    return location !== null;
  });
  
  // Handle project selection
  const handleProjectSelect = (project: Project) => {
    setSelectedProject(project);
    
    const location = parseLocation(project.location);
    if (location) {
      setMapCenter(location);
      setMapZoom(12); // Zoom in when selecting a project
    }
  };
  
  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t("map.title")}</h1>
        <p className="text-muted-foreground">{t("map.project_locations")}</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-14rem)]">
        {/* Project List */}
        <div className="overflow-y-auto pb-4 lg:col-span-1">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>{t("project.title")}</CardTitle>
              <CardDescription>
                {t("map.filter_by_type")}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {isLoading ? (
                  <div className="p-4 text-center">
                    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                    <p className="mt-2 text-muted-foreground">{t("loading")}</p>
                  </div>
                ) : projectsWithLocation.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground">
                    {t("project.no_projects_found")}
                  </div>
                ) : (
                  projectsWithLocation.map((project) => (
                    <div 
                      key={project.id}
                      className={`p-4 cursor-pointer hover:bg-muted/20 transition-colors ${selectedProject?.id === project.id ? 'bg-muted/40' : ''}`}
                      onClick={() => handleProjectSelect(project)}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-medium">{project.name}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <ProjectTypeBadge type={project.type} size="sm" />
                            <StatusBadge status={project.status} size="sm" />
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-muted-foreground">{t("project.budget")}</div>
                          <div className="font-medium">{formatCurrency(project.budget || 0)}</div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Map */}
        <div className="h-full lg:col-span-2 rounded-lg overflow-hidden shadow-md">
          <MapContainer
            center={DEFAULT_CENTER}
            zoom={DEFAULT_ZOOM}
            style={{ height: "100%", width: "100%" }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            <MapUpdater center={mapCenter} zoom={mapZoom} />
            
            {projectsWithLocation.map(project => {
              const location = parseLocation(project.location);
              if (!location) return null;
              
              return (
                <Marker 
                  key={project.id} 
                  position={location}
                  icon={mapTypeIcons[project.type] || customIcon}
                  eventHandlers={{
                    click: () => handleProjectSelect(project)
                  }}
                >
                  <Popup>
                    <div className="text-sm">
                      <h3 className="font-bold mb-1">{project.name}</h3>
                      <p className="text-zinc-600 mb-2">{project.description}</p>
                      <div className="flex items-center justify-between mb-1">
                        <span>{t("project.type")}:</span>
                        <ProjectTypeBadge type={project.type} size="sm" />
                      </div>
                      <div className="flex items-center justify-between mb-1">
                        <span>{t("project.status")}:</span>
                        <StatusBadge status={project.status} size="sm" />
                      </div>
                      <div className="flex items-center justify-between mb-1">
                        <span>{t("project.budget")}:</span>
                        <span className="font-medium">{formatCurrency(project.budget || 0)}</span>
                      </div>
                      <div className="mt-2">
                        <Link href={`/projects/${project.id}`} className="text-primary hover:underline">
                          {t("project.details")}
                        </Link>
                      </div>
                    </div>
                  </Popup>
                </Marker>
              );
            })}
          </MapContainer>
        </div>
      </div>
    </div>
  );
}