import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, ArrowRight, BarChart, ChevronUp, CreditCard, DollarSign, LineChart, PieChart, Receipt, Wallet } from "lucide-react";
import { LineChart as ReLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart as ReBarChart, Bar, PieChart as RePieChart, Pie, Cell } from "recharts";
import { Progress } from "@/components/ui/progress";
import { format, subMonths } from "date-fns";

export default function FinancialDashboard() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState("overview");

  // Mock financial data for demonstration
  const financialOverview = {
    totalBudget: 25000000,
    totalIncome: 12500000,
    totalExpenses: 10000000,
    currentBalance: 2500000,
  };

  // Generate last 6 months data for the chart
  const generateMonthlyData = () => {
    const months = [];
    const currentDate = new Date();
    
    for (let i = 5; i >= 0; i--) {
      const date = subMonths(currentDate, i);
      const monthName = t(`months.${format(date, 'MMM').toLowerCase()}`);
      
      // Generate some mock data with a realistic pattern
      const income = Math.round(1500000 + Math.random() * 500000);
      const expenses = Math.round(1000000 + Math.random() * 700000);
      
      months.push({
        name: monthName,
        income: income,
        expenses: expenses,
        balance: income - expenses,
      });
    }
    
    return months;
  };

  const monthlyData = generateMonthlyData();

  // Mock project budget usage data
  const projectBudgetData = [
    { 
      name: "مشروع الطرق السريعة", 
      budget: 10000000, 
      spent: 8500000,
      percentage: 85
    },
    { 
      name: "مشروع شبكة المياه", 
      budget: 7000000, 
      spent: 4900000,
      percentage: 70
    },
    { 
      name: "مشروع البنية التحتية", 
      budget: 5000000, 
      spent: 2000000,
      percentage: 40
    },
    { 
      name: "مشروع تجديد المباني", 
      budget: 3000000, 
      spent: 2700000,
      percentage: 90
    },
  ];

  // Mock transactions by type data for pie chart
  const transactionsByTypeData = [
    { name: t("financial.transactions.income"), value: 12500000 },
    { name: t("financial.transactions.expense"), value: 10000000 },
    { name: t("financial.transactions.transfer"), value: 3000000 },
  ];

  // Mock recent transactions
  const recentTransactions = [
    {
      id: 1,
      type: "income",
      description: "دفعة من وزارة النقل لمشروع الطرق السريعة",
      amount: 500000,
      date: new Date(2024, 4, 15),
      project: "مشروع الطرق السريعة",
    },
    {
      id: 2,
      type: "expense",
      description: "شراء معدات لمشروع شبكة المياه",
      amount: 125000,
      date: new Date(2024, 4, 18),
      project: "مشروع شبكة المياه",
    },
    {
      id: 3,
      type: "expense",
      description: "تكاليف العمالة لمشروع الطرق السريعة",
      amount: 85000,
      date: new Date(2024, 4, 28),
      project: "مشروع الطرق السريعة",
    },
    {
      id: 4,
      type: "income",
      description: "دفعة من شركة الكهرباء لمشروع البنية التحتية",
      amount: 300000,
      date: new Date(2024, 5, 5),
      project: "مشروع البنية التحتية",
    },
  ];

  // Colors for charts
  const COLORS = ['#0088FE', '#00C49F', '#FF8042'];

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Get transaction icon and color based on type
  const getTransactionTypeDetails = (type: string) => {
    switch (type) {
      case "income":
        return { 
          icon: <ChevronUp className="h-4 w-4 text-green-500" />, 
          textColor: "text-green-500" 
        };
      case "expense":
        return { 
          icon: <ChevronUp className="h-4 w-4 text-red-500 transform rotate-180" />, 
          textColor: "text-red-500" 
        };
      case "transfer":
        return { 
          icon: <ArrowRight className="h-4 w-4 text-blue-500" />, 
          textColor: "text-blue-500" 
        };
      default:
        return { 
          icon: <DollarSign className="h-4 w-4 text-gray-500" />, 
          textColor: "text-gray-500" 
        };
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("financial.dashboard.title")}</h1>
          <p className="text-muted-foreground">{t("financial.dashboard.overview")}</p>
        </div>

        <Alert className="mb-2">
          <AlertCircle className="h-4 w-4 ml-2" />
          <AlertTitle>{t("financial.formUnderDevelopment")}</AlertTitle>
          <AlertDescription>
            هذه الواجهة تعرض بيانات تجريبية وليست متصلة بقاعدة البيانات.
          </AlertDescription>
        </Alert>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <div className="flex justify-between">
            <TabsList>
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Wallet className="h-4 w-4" />
                {t("financial.dashboard.overview")}
              </TabsTrigger>
              <TabsTrigger value="budget" className="flex items-center gap-2">
                <PieChart className="h-4 w-4" />
                {t("financial.dashboard.budgetAnalysis")}
              </TabsTrigger>
              <TabsTrigger value="transactions" className="flex items-center gap-2">
                <Receipt className="h-4 w-4" />
                {t("financial.dashboard.transactionAnalysis")}
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("financial.dashboard.totalBudget")}
                  </CardTitle>
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(financialOverview.totalBudget)}</div>
                  <p className="text-xs text-muted-foreground">
                    {t("financial.dashboard.acrossAllProjects")}
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("financial.dashboard.totalIncome")}
                  </CardTitle>
                  <ChevronUp className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(financialOverview.totalIncome)}</div>
                  <p className="text-xs text-muted-foreground">
                    {t("financial.dashboard.totalIncomeDesc")}
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("financial.dashboard.totalExpenses")}
                  </CardTitle>
                  <ChevronUp className="h-4 w-4 text-red-500 transform rotate-180" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(financialOverview.totalExpenses)}</div>
                  <p className="text-xs text-muted-foreground">
                    {t("financial.dashboard.totalExpensesDesc")}
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("financial.dashboard.currentBalance")}
                  </CardTitle>
                  <Wallet className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(financialOverview.currentBalance)}</div>
                  <p className="text-xs text-green-500">
                    {financialOverview.currentBalance >= 0 
                      ? t("financial.dashboard.positiveBalance") 
                      : t("financial.dashboard.negativeBalance")}
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>{t("financial.dashboard.financialTrends")}</CardTitle>
                  <CardDescription>
                    {t("financial.dashboard.financialTrendsDescription")}
                  </CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ReLineChart
                      data={monthlyData}
                      margin={{
                        top: 10,
                        right: 30,
                        left: 20,
                        bottom: 10,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                      <YAxis 
                        tickFormatter={(value) => 
                          new Intl.NumberFormat('ar-SA', { 
                            notation: 'compact', 
                            compactDisplay: 'short',
                            style: 'currency',
                            currency: 'SAR'
                          }).format(value)
                        } 
                      />
                      <Tooltip 
                        formatter={(value) => formatCurrency(value as number)} 
                        labelFormatter={(label) => `${label} - ${t("financial.dashboard.lastSixMonths")}`}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="income" 
                        name={t("financial.dashboard.income")} 
                        stroke="#0088FE" 
                        activeDot={{ r: 8 }} 
                      />
                      <Line 
                        type="monotone" 
                        dataKey="expenses" 
                        name={t("financial.dashboard.expenses")} 
                        stroke="#FF8042" 
                      />
                    </ReLineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>{t("financial.dashboard.budgetUsage")}</CardTitle>
                  <CardDescription>
                    {t("financial.dashboard.topProjectsByUsage")}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {projectBudgetData.map((project, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <div className="font-medium">{project.name}</div>
                        <div>{project.percentage}%</div>
                      </div>
                      <Progress value={project.percentage} className="h-2" />
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div>
                          <span className="font-medium">{formatCurrency(project.spent)}</span> / {formatCurrency(project.budget)}
                        </div>
                        <div>
                          {formatCurrency(project.budget - project.spent)} {t("financial.dashboard.remainingBudget")}
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>{t("financial.dashboard.transactionsByType")}</CardTitle>
                  <CardDescription>
                    {t("financial.dashboard.transactionsByTypeDescription")}
                  </CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={transactionsByTypeData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {transactionsByTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                    </RePieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card className="col-span-4">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>{t("financial.dashboard.recentTransactions")}</CardTitle>
                    <CardDescription>
                      {t("financial.dashboard.recentTransactionsDescription")}
                    </CardDescription>
                  </div>
                  <Link href="/financial/transactions">
                    <Button variant="outline" size="sm">
                      {t("financial.dashboard.viewAllTransactions")}
                      <ArrowRight className="h-4 w-4 mr-2" />
                    </Button>
                  </Link>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {recentTransactions.map((transaction) => {
                      const { icon, textColor } = getTransactionTypeDetails(transaction.type);
                      return (
                        <div key={transaction.id} className="flex items-center justify-between rounded-lg border p-3">
                          <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 items-center justify-center rounded-full border bg-background">
                              {icon}
                            </div>
                            <div>
                              <div className="font-medium">{transaction.description}</div>
                              <div className="text-xs text-muted-foreground">
                                {format(transaction.date, "yyyy/MM/dd")} • {transaction.project}
                              </div>
                            </div>
                          </div>
                          <div className={`font-medium ${textColor}`}>
                            {transaction.type === "expense" ? "- " : ""}
                            {formatCurrency(transaction.amount)}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="budget" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{t("financial.dashboard.budgetAnalysis")}</CardTitle>
                <CardDescription>{t("financial.dashboard.budgetVsSpentDescription")}</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <ReBarChart
                    data={projectBudgetData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis 
                      tickFormatter={(value) => 
                        new Intl.NumberFormat('ar-SA', { 
                          notation: 'compact', 
                          compactDisplay: 'short',
                          style: 'currency',
                          currency: 'SAR'
                        }).format(value)
                      } 
                    />
                    <Tooltip formatter={(value) => formatCurrency(value as number)} />
                    <Legend />
                    <Bar 
                      dataKey="budget" 
                      name={t("financial.budgets.planned")}
                      fill="#8884d8" 
                      stackId="a" 
                    />
                    <Bar 
                      dataKey="spent" 
                      name={t("financial.dashboard.spent")}
                      fill="#82ca9d" 
                      stackId="b" 
                    />
                  </ReBarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>{t("financial.dashboard.usagePercentage")}</CardTitle>
                  <CardDescription>{t("financial.dashboard.topProjectsByUsage")}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {projectBudgetData.map((project, index) => (
                      <div key={index}>
                        <div className="flex items-center justify-between mb-1">
                          <div className="text-sm font-medium">{project.name}</div>
                          <div className="text-sm font-medium">{project.percentage}%</div>
                        </div>
                        <div className="h-4 w-full rounded-full bg-muted overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              project.percentage > 90 
                                ? "bg-red-500"
                                : project.percentage > 75 
                                ? "bg-amber-500"
                                : "bg-green-500"
                            }`}
                            style={{ width: `${project.percentage}%` }}
                          />
                        </div>
                        <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                          <div>{formatCurrency(project.spent)}</div>
                          <div>{formatCurrency(project.budget)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>{t("financial.dashboard.remainingBudget")}</CardTitle>
                  <CardDescription>{t("financial.budgets.totalBudget")}: {formatCurrency(projectBudgetData.reduce((sum, p) => sum + p.budget, 0))}</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={projectBudgetData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={120}
                        fill="#8884d8"
                        dataKey="budget"
                        nameKey="name"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {projectBudgetData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                    </RePieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="transactions" className="space-y-4">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>{t("financial.dashboard.transactionsByType")}</CardTitle>
                  <CardDescription>{t("financial.dashboard.transactionsByTypeDescription")}</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={transactionsByTypeData}
                        cx="50%"
                        cy="50%"
                        innerRadius={70}
                        outerRadius={90}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        label
                      >
                        {transactionsByTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                    </RePieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>{t("financial.dashboard.financialTrends")}</CardTitle>
                  <CardDescription>{t("financial.dashboard.lastSixMonths")}</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ReBarChart
                      data={monthlyData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis 
                        tickFormatter={(value) => 
                          new Intl.NumberFormat('ar-SA', { 
                            notation: 'compact', 
                            compactDisplay: 'short',
                            style: 'currency',
                            currency: 'SAR'
                          }).format(value)
                        } 
                      />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Bar 
                        dataKey="income" 
                        name={t("financial.dashboard.income")}
                        fill="#0088FE" 
                      />
                      <Bar 
                        dataKey="expenses" 
                        name={t("financial.dashboard.expenses")}
                        fill="#FF8042" 
                      />
                      <Bar 
                        dataKey="balance" 
                        name={t("financial.dashboard.currentBalance")}
                        fill="#00C49F" 
                      />
                    </ReBarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>{t("financial.dashboard.recentTransactions")}</CardTitle>
                    <CardDescription>{t("financial.dashboard.recentTransactionsDescription")}</CardDescription>
                  </div>
                  <Link href="/financial/transactions">
                    <Button>
                      {t("financial.dashboard.viewAllTransactions")}
                      <ArrowRight className="h-4 w-4 mr-2" />
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="grid grid-cols-5 border-b px-4 py-3 font-medium text-sm">
                    <div>{t("financial.transactions.date")}</div>
                    <div>{t("financial.transactions.type")}</div>
                    <div>{t("financial.transactions.description")}</div>
                    <div>{t("financial.transactions.project")}</div>
                    <div className="text-right">{t("financial.transactions.amount")}</div>
                  </div>
                  
                  {recentTransactions.map((transaction) => {
                    const { icon, textColor } = getTransactionTypeDetails(transaction.type);
                    return (
                      <div key={transaction.id} className="grid grid-cols-5 border-b last:border-0 px-4 py-3 text-sm items-center">
                        <div className="text-muted-foreground">
                          {format(transaction.date, "yyyy/MM/dd")}
                        </div>
                        <div className="flex items-center gap-2">
                          {icon}
                          <span>
                            {transaction.type === "income" ? t("financial.transactions.income") :
                             transaction.type === "expense" ? t("financial.transactions.expense") :
                             t("financial.transactions.transfer")}
                          </span>
                        </div>
                        <div className="truncate max-w-[200px]">{transaction.description}</div>
                        <div>{transaction.project}</div>
                        <div className={`text-right font-medium ${textColor}`}>
                          {transaction.type === "expense" ? "- " : ""}
                          {formatCurrency(transaction.amount)}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <Link href="/financial/transactions">
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">{t("financial.transactions.title")}</CardTitle>
                <Receipt className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{t("financial.transactions.list")}</CardDescription>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/financial/accounts">
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">{t("financial.accounts.title")}</CardTitle>
                <BarChart className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{t("financial.accounts.structure")}</CardDescription>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/financial/budgets">
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">{t("financial.budgets.title")}</CardTitle>
                <LineChart className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{t("financial.budgets.budgetByProject")}</CardDescription>
              </CardContent>
            </Card>
          </Link>

          <Link href="/financial/certificates">
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">{t("financial.certificates.title") || "المستخلصات"}</CardTitle>
                <CreditCard className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{t("financial.certificates.description") || "إدارة المستخلصات والفواتير"}</CardDescription>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/financial/budgets-new">
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">{t("financial.budgets.title")} (تحديث)</CardTitle>
                <LineChart className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{t("financial.budgets.budgetByProject")} - نسخة محدثة</CardDescription>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/financial/journal-entries">
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">{t("journal_entries") || "قيود اليومية"}</CardTitle>
                <BarChart className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{t("journal_entries_description") || "إنشاء وإدارة قيود اليومية المحاسبية"}</CardDescription>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  );
}