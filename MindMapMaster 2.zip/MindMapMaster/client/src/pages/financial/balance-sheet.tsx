import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DatePicker } from "@/components/ui/date-picker";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Calculator, ChevronDown, ChevronRight, Download, FileDown, Filter, Printer, Search, Settings2 } from "lucide-react";
import { format } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ExportMenu } from "@/components/financial/ExportMenu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { printDocument } from "@/utils/printUtils";

export default function BalanceSheet() {
  const { t } = useTranslation();
  const { toast } = useToast();
  
  // مرجع للجدول لاستخدامه في التصدير
  const tableRef = useRef<HTMLTableElement>(null);
  const printSectionRef = useRef<HTMLDivElement>(null);
  
  // تاريخ الميزانية العمومية (افتراضيًا تاريخ اليوم)
  const [asOfDate, setAsOfDate] = useState<Date>(new Date());
  const [fiscalYear, setFiscalYear] = useState<string | undefined>();
  const [fiscalPeriod, setFiscalPeriod] = useState<string | undefined>();
  const [compareWithPrevPeriod, setCompareWithPrevPeriod] = useState(false);
  
  // استخراج بيانات ورؤوس الجدول للتصدير بصيغة Excel
  const getExportData = () => {
    if (!balanceSheetData) return { data: [], headers: [] };
    
    // تجميع كل البيانات من الأصول والخصوم وحقوق الملكية
    const combinedData = [
      ...balanceSheetData.assets.map(account => ({
        ...account,
        category: 'الأصول'
      })),
      ...balanceSheetData.liabilities.map(account => ({
        ...account,
        category: 'الخصوم'
      })),
      ...balanceSheetData.equity.map(account => ({
        ...account,
        category: 'حقوق الملكية'
      }))
    ];
    
    // تعريف عناوين الأعمدة للتصدير
    const headers = [
      { header: 'الفئة', dataKey: 'category' },
      { header: 'رمز الحساب', dataKey: 'accountCode' },
      { header: 'اسم الحساب', dataKey: 'accountName' },
    ];
    
    // إضافة أعمدة المقارنة إذا كانت مفعّلة
    if (compareWithPrevPeriod) {
      headers.push(
        { header: 'رصيد سابق', dataKey: 'previousBalance' },
        { header: 'التغيير', dataKey: 'change' },
        { header: 'نسبة التغيير', dataKey: 'changePercentage' }
      );
    }
    
    // إضافة عمود الرصيد الحالي
    headers.push({ header: 'الرصيد', dataKey: 'balance' });
    
    return { data: combinedData, headers };
  };
  
  // المستوى المفتوح لكل فئة من الحسابات
  const [expandedAssets, setExpandedAssets] = useState<Record<string, boolean>>({});
  const [expandedLiabilities, setExpandedLiabilities] = useState<Record<string, boolean>>({});
  const [expandedEquity, setExpandedEquity] = useState<Record<string, boolean>>({});
  
  // علامة تبويب نشطة
  const [activeTab, setActiveTab] = useState("statement");
  
  // استدعاء واجهة برمجة التطبيقات للحصول على الميزانية العمومية
  const { data: balanceSheetData, isLoading, refetch } = useQuery({
    queryKey: ['/api/financial/balance-sheet', asOfDate, fiscalYear, fiscalPeriod, compareWithPrevPeriod],
    queryFn: async () => {
      try {
        // بناء معلمات الاستعلام
        const params = new URLSearchParams();
        params.append('asOfDate', asOfDate.toISOString());
        if (fiscalYear) params.append('fiscalYear', fiscalYear);
        if (fiscalPeriod) params.append('fiscalPeriod', fiscalPeriod);
        params.append('compareWithPrevPeriod', String(compareWithPrevPeriod));
        
        const response = await apiRequest('GET', `/api/financial/balance-sheet?${params.toString()}`);
        return await response.json();
      } catch (error) {
        console.error('Error fetching balance sheet:', error);
        toast({
          variant: "destructive",
          title: t('financial.balance_sheet.fetch_error') || "خطأ في جلب الميزانية العمومية",
          description: String(error),
        });
        return null;
      }
    },
  });
  
  // تنسيق الأرقام بالعملة السعودية
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // الحصول على بيانات الرسم البياني للمقارنة بين الأصول والخصوم وحقوق الملكية
  const getChartData = () => {
    if (!balanceSheetData) return [];
    
    return [
      {
        name: t('financial.assets') || "الأصول",
        amount: balanceSheetData.totalAssets,
      },
      {
        name: t('financial.liabilities') || "الخصوم",
        amount: balanceSheetData.totalLiabilities,
      },
      {
        name: t('financial.equity') || "حقوق الملكية",
        amount: balanceSheetData.totalEquity,
      },
    ];
  };

  // استخراج حسابات المستوى 1 فقط (الرئيسية)
  const getLevel1Accounts = (accounts: any[]) => {
    return accounts?.filter(account => account.level === 1) || [];
  };
  
  // استخراج الحسابات الفرعية لحساب رئيسي
  const getChildAccounts = (accounts: any[], parentId: number) => {
    return accounts?.filter(account => account.parentId === parentId) || [];
  };
  
  // التبديل بين طي وفتح القسم
  const toggleSection = (section: string, id: number) => {
    if (section === 'assets') {
      setExpandedAssets({
        ...expandedAssets,
        [id]: !expandedAssets[id],
      });
    } else if (section === 'liabilities') {
      setExpandedLiabilities({
        ...expandedLiabilities,
        [id]: !expandedLiabilities[id],
      });
    } else if (section === 'equity') {
      setExpandedEquity({
        ...expandedEquity,
        [id]: !expandedEquity[id],
      });
    }
  };
  
  return (
    <PageLayout
      title={t('financial.balance_sheet.title') || "الميزانية العمومية"}
      sections={[
        {
          title: t('financial.reports.categories') || "فئات التقارير",
          items: [
            { title: t('financial.overview') || "نظرة عامة", href: "/financial/reports" },
            { title: t('financial.account_statement') || "كشف الحساب", href: "/financial/account-statement" },
            { title: t('financial.trial_balance') || "ميزان المراجعة", href: "/financial/trial-balance" },
            { title: t('financial.balance_sheet') || "الميزانية العمومية", href: "/financial/balance-sheet" },
            { title: t('financial.income_statement') || "قائمة الدخل", href: "/financial/income-statement" },
          ],
        },
      ]}
    >
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>{t('financial.balance_sheet.filter') || "تصفية الميزانية العمومية"}</CardTitle>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => printDocument(printSectionRef, t('financial.balance_sheet.title') || "الميزانية العمومية")}
                >
                  <Printer className="h-4 w-4 mr-2" />
                  {t('common.print') || "طباعة"}
                </Button>
                <ExportMenu
                  tableRef={tableRef}
                  data={getExportData().data}
                  headers={getExportData().headers}
                  fileName="balance_sheet"
                  reportTitle={t('financial.balance_sheet.title') || "الميزانية العمومية"}
                  subtitle={format(asOfDate, 'yyyy/MM/dd')}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/30 p-4 rounded-lg border mb-4">
              <h3 className="text-sm font-medium mb-3 flex items-center">
                <Filter className="h-4 w-4 mr-2 text-primary" />
                {t('financial.filter_options') || "خيارات التصفية"}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.as_of_date') || "كما في تاريخ"}
                  </label>
                  <DatePicker
                    date={asOfDate}
                    onSelect={setAsOfDate}
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.fiscal_year') || "السنة المالية"}
                  </label>
                  <Select value={fiscalYear} onValueChange={setFiscalYear}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('financial.select_fiscal_year') || "اختر السنة المالية"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2025">2025</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.fiscal_period') || "الفترة المالية"}
                  </label>
                  <Select value={fiscalPeriod} onValueChange={setFiscalPeriod}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('financial.select_fiscal_period') || "اختر الفترة المالية"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">{t('financial.period_1') || "الفترة 1"}</SelectItem>
                      <SelectItem value="2">{t('financial.period_2') || "الفترة 2"}</SelectItem>
                      <SelectItem value="3">{t('financial.period_3') || "الفترة 3"}</SelectItem>
                      <SelectItem value="4">{t('financial.period_4') || "الفترة 4"}</SelectItem>
                      <SelectItem value="5">{t('financial.period_5') || "الفترة 5"}</SelectItem>
                      <SelectItem value="6">{t('financial.period_6') || "الفترة 6"}</SelectItem>
                      <SelectItem value="7">{t('financial.period_7') || "الفترة 7"}</SelectItem>
                      <SelectItem value="8">{t('financial.period_8') || "الفترة 8"}</SelectItem>
                      <SelectItem value="9">{t('financial.period_9') || "الفترة 9"}</SelectItem>
                      <SelectItem value="10">{t('financial.period_10') || "الفترة 10"}</SelectItem>
                      <SelectItem value="11">{t('financial.period_11') || "الفترة 11"}</SelectItem>
                      <SelectItem value="12">{t('financial.period_12') || "الفترة 12"}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.compare_with_prev_period') || "المقارنة مع الفترة السابقة"}
                  </label>
                  <div className="flex items-center space-x-2 h-10 bg-background rounded-md px-3 border">
                    <Switch 
                      checked={compareWithPrevPeriod} 
                      onCheckedChange={setCompareWithPrevPeriod} 
                    />
                    <span className="text-sm">
                      {compareWithPrevPeriod 
                        ? t('financial.compare_enabled') || "المقارنة مفعلة" 
                        : t('financial.compare_disabled') || "المقارنة معطلة"}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="border-t pt-3 mt-2 flex justify-end">
                <Button className="px-6" onClick={() => refetch()}>
                  <Search className="h-4 w-4 mr-2" />
                  {t('common.search') || "بحث"}
                </Button>
              </div>
            </div>
            
            <div className="bg-muted/30 p-4 rounded-lg border">
              <h3 className="text-sm font-medium mb-3 flex items-center">
                <Settings2 className="h-4 w-4 mr-2 text-primary" />
                {t('financial.display_options') || "خيارات العرض"}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="col-span-1 md:col-span-3">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={activeTab === "statement" ? "bg-primary/10" : ""}
                        onClick={() => setActiveTab("statement")}
                      >
                        {t('financial.balance_sheet.statement') || "القائمة"}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={activeTab === "visual" ? "bg-primary/10" : ""}
                        onClick={() => setActiveTab("visual")}
                      >
                        {t('financial.balance_sheet.visual') || "عرض مرئي"}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={activeTab === "comparative" ? "bg-primary/10" : ""}
                        onClick={() => setActiveTab("comparative")}
                      >
                        {t('financial.balance_sheet.comparative') || "مقارن"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="statement" value={activeTab} onValueChange={setActiveTab}>
          
          <TabsContent value="statement">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>
                    {t('financial.balance_sheet.header', { date: format(asOfDate, 'yyyy/MM/dd') }) || 
                      `الميزانية العمومية كما في ${format(asOfDate, 'yyyy/MM/dd')}`}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-2">
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                ) : balanceSheetData ? (
                  <div className="space-y-6" ref={printSectionRef}>
                    {/* عنوان الطباعة - يظهر فقط عند الطباعة */}
                    <div className="print-header hidden print:block">
                      <h1>{t('financial.balance_sheet.title') || "الميزانية العمومية"}</h1>
                      <h3>{format(asOfDate, 'yyyy/MM/dd')}</h3>
                      <h4>{t('financial.generated_date') || "تاريخ الإنشاء"}: {format(new Date(), 'yyyy/MM/dd HH:mm')}</h4>
                    </div>
                    {/* الأصول - Assets */}
                    <div>
                      <h3 className="text-lg font-bold mb-2">{t('financial.assets') || "الأصول"}</h3>
                      <div className="rounded-md border">
                        <Table dir="rtl" ref={tableRef}>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-12"></TableHead>
                              <TableHead className="w-24">{t('financial.account_code') || "رمز الحساب"}</TableHead>
                              <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableHead className="text-left">{t('financial.prev_balance') || "رصيد سابق"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_amount') || "التغيير"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_percentage') || "نسبة التغيير"}</TableHead>
                                </>
                              )}
                              <TableHead className="text-left">{t('financial.balance') || "الرصيد"}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {getLevel1Accounts(balanceSheetData.assets).map((account: any) => (
                              <>
                                <TableRow 
                                  key={account.accountId}
                                  className="bg-muted/40"
                                >
                                  <TableCell>
                                    <button 
                                      onClick={() => toggleSection('assets', account.accountId)}
                                      className="p-1"
                                    >
                                      {expandedAssets[account.accountId] ? 
                                        <ChevronDown className="h-4 w-4" /> : 
                                        <ChevronRight className="h-4 w-4" />
                                      }
                                    </button>
                                  </TableCell>
                                  <TableCell>{account.accountCode}</TableCell>
                                  <TableCell>
                                    <div className="font-medium">
                                      {account.accountName}
                                    </div>
                                    {account.accountNameEn && (
                                      <div className="text-xs text-muted-foreground">
                                        {account.accountNameEn}
                                      </div>
                                    )}
                                  </TableCell>
                                  {compareWithPrevPeriod && (
                                    <>
                                      <TableCell>
                                        {formatCurrency(account.previousBalance)}
                                      </TableCell>
                                      <TableCell className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                        {account.change >= 0 ? "+" : ""}{formatCurrency(account.change)}
                                      </TableCell>
                                      <TableCell className={account.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                        {account.changePercentage >= 0 ? "+" : ""}
                                        {account.changePercentage.toFixed(2)}%
                                      </TableCell>
                                    </>
                                  )}
                                  <TableCell className="font-bold">
                                    {formatCurrency(account.balance)}
                                  </TableCell>
                                </TableRow>
                                
                                {/* الحسابات الفرعية */}
                                {expandedAssets[account.accountId] && 
                                  getChildAccounts(balanceSheetData.assets, account.accountId).map((childAccount: any) => (
                                    <TableRow key={childAccount.accountId}>
                                      <TableCell></TableCell>
                                      <TableCell>{childAccount.accountCode}</TableCell>
                                      <TableCell>
                                        <div className="font-medium pr-4">
                                          {childAccount.accountName}
                                        </div>
                                        {childAccount.accountNameEn && (
                                          <div className="text-xs text-muted-foreground">
                                            {childAccount.accountNameEn}
                                          </div>
                                        )}
                                      </TableCell>
                                      {compareWithPrevPeriod && (
                                        <>
                                          <TableCell>
                                            {formatCurrency(childAccount.previousBalance)}
                                          </TableCell>
                                          <TableCell className={childAccount.change >= 0 ? "text-green-600" : "text-red-600"}>
                                            {childAccount.change >= 0 ? "+" : ""}{formatCurrency(childAccount.change)}
                                          </TableCell>
                                          <TableCell className={childAccount.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                            {childAccount.changePercentage >= 0 ? "+" : ""}
                                            {childAccount.changePercentage.toFixed(2)}%
                                          </TableCell>
                                        </>
                                      )}
                                      <TableCell>
                                        {formatCurrency(childAccount.balance)}
                                      </TableCell>
                                    </TableRow>
                                  ))
                                }
                              </>
                            ))}
                            
                            {/* إجمالي الأصول */}
                            <TableRow className="bg-primary/10 font-bold">
                              <TableCell colSpan={2}></TableCell>
                              <TableCell>
                                {t('financial.total_assets') || "إجمالي الأصول"}
                              </TableCell>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                </>
                              )}
                              <TableCell className="font-bold">
                                {formatCurrency(balanceSheetData.totalAssets)}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* الخصوم - Liabilities */}
                    <div>
                      <h3 className="text-lg font-bold mb-2">{t('financial.liabilities') || "الخصوم"}</h3>
                      <div className="rounded-md border">
                        <Table dir="rtl" ref={tableRef}>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-12"></TableHead>
                              <TableHead className="w-24">{t('financial.account_code') || "رمز الحساب"}</TableHead>
                              <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableHead className="text-left">{t('financial.prev_balance') || "رصيد سابق"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_amount') || "التغيير"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_percentage') || "نسبة التغيير"}</TableHead>
                                </>
                              )}
                              <TableHead className="text-left">{t('financial.balance') || "الرصيد"}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {getLevel1Accounts(balanceSheetData.liabilities).map((account: any) => (
                              <>
                                <TableRow 
                                  key={account.accountId}
                                  className="bg-muted/40"
                                >
                                  <TableCell>
                                    <button 
                                      onClick={() => toggleSection('liabilities', account.accountId)}
                                      className="p-1"
                                    >
                                      {expandedLiabilities[account.accountId] ? 
                                        <ChevronDown className="h-4 w-4" /> : 
                                        <ChevronRight className="h-4 w-4" />
                                      }
                                    </button>
                                  </TableCell>
                                  <TableCell>{account.accountCode}</TableCell>
                                  <TableCell>
                                    <div className="font-medium">
                                      {account.accountName}
                                    </div>
                                    {account.accountNameEn && (
                                      <div className="text-xs text-muted-foreground">
                                        {account.accountNameEn}
                                      </div>
                                    )}
                                  </TableCell>
                                  {compareWithPrevPeriod && (
                                    <>
                                      <TableCell>
                                        {formatCurrency(account.previousBalance)}
                                      </TableCell>
                                      <TableCell className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                        {account.change >= 0 ? "+" : ""}{formatCurrency(account.change)}
                                      </TableCell>
                                      <TableCell className={account.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                        {account.changePercentage >= 0 ? "+" : ""}
                                        {account.changePercentage.toFixed(2)}%
                                      </TableCell>
                                    </>
                                  )}
                                  <TableCell className="font-bold">
                                    {formatCurrency(account.balance)}
                                  </TableCell>
                                </TableRow>
                                
                                {/* الحسابات الفرعية */}
                                {expandedLiabilities[account.accountId] && 
                                  getChildAccounts(balanceSheetData.liabilities, account.accountId).map((childAccount: any) => (
                                    <TableRow key={childAccount.accountId}>
                                      <TableCell></TableCell>
                                      <TableCell>{childAccount.accountCode}</TableCell>
                                      <TableCell>
                                        <div className="font-medium pr-4">
                                          {childAccount.accountName}
                                        </div>
                                        {childAccount.accountNameEn && (
                                          <div className="text-xs text-muted-foreground">
                                            {childAccount.accountNameEn}
                                          </div>
                                        )}
                                      </TableCell>
                                      {compareWithPrevPeriod && (
                                        <>
                                          <TableCell>
                                            {formatCurrency(childAccount.previousBalance)}
                                          </TableCell>
                                          <TableCell className={childAccount.change >= 0 ? "text-green-600" : "text-red-600"}>
                                            {childAccount.change >= 0 ? "+" : ""}{formatCurrency(childAccount.change)}
                                          </TableCell>
                                          <TableCell className={childAccount.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                            {childAccount.changePercentage >= 0 ? "+" : ""}
                                            {childAccount.changePercentage.toFixed(2)}%
                                          </TableCell>
                                        </>
                                      )}
                                      <TableCell>
                                        {formatCurrency(childAccount.balance)}
                                      </TableCell>
                                    </TableRow>
                                  ))
                                }
                              </>
                            ))}
                            
                            {/* إجمالي الخصوم */}
                            <TableRow className="bg-primary/10 font-bold">
                              <TableCell colSpan={2}></TableCell>
                              <TableCell>
                                {t('financial.total_liabilities') || "إجمالي الخصوم"}
                              </TableCell>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                </>
                              )}
                              <TableCell className="font-bold">
                                {formatCurrency(balanceSheetData.totalLiabilities)}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* حقوق الملكية - Equity */}
                    <div>
                      <h3 className="text-lg font-bold mb-2">{t('financial.equity') || "حقوق الملكية"}</h3>
                      <div className="rounded-md border">
                        <Table dir="rtl" ref={tableRef}>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-12"></TableHead>
                              <TableHead className="w-24">{t('financial.account_code') || "رمز الحساب"}</TableHead>
                              <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableHead className="text-left">{t('financial.prev_balance') || "رصيد سابق"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_amount') || "التغيير"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_percentage') || "نسبة التغيير"}</TableHead>
                                </>
                              )}
                              <TableHead className="text-left">{t('financial.balance') || "الرصيد"}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {getLevel1Accounts(balanceSheetData.equity).map((account: any) => (
                              <>
                                <TableRow 
                                  key={account.accountId}
                                  className="bg-muted/40"
                                >
                                  <TableCell>
                                    <button 
                                      onClick={() => toggleSection('equity', account.accountId)}
                                      className="p-1"
                                    >
                                      {expandedEquity[account.accountId] ? 
                                        <ChevronDown className="h-4 w-4" /> : 
                                        <ChevronRight className="h-4 w-4" />
                                      }
                                    </button>
                                  </TableCell>
                                  <TableCell>{account.accountCode}</TableCell>
                                  <TableCell>
                                    <div className="font-medium">
                                      {account.accountName}
                                    </div>
                                    {account.accountNameEn && (
                                      <div className="text-xs text-muted-foreground">
                                        {account.accountNameEn}
                                      </div>
                                    )}
                                  </TableCell>
                                  {compareWithPrevPeriod && (
                                    <>
                                      <TableCell>
                                        {formatCurrency(account.previousBalance)}
                                      </TableCell>
                                      <TableCell className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                        {account.change >= 0 ? "+" : ""}{formatCurrency(account.change)}
                                      </TableCell>
                                      <TableCell className={account.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                        {account.changePercentage >= 0 ? "+" : ""}
                                        {account.changePercentage.toFixed(2)}%
                                      </TableCell>
                                    </>
                                  )}
                                  <TableCell className="font-bold">
                                    {formatCurrency(account.balance)}
                                  </TableCell>
                                </TableRow>
                                
                                {/* الحسابات الفرعية */}
                                {expandedEquity[account.accountId] && 
                                  getChildAccounts(balanceSheetData.equity, account.accountId).map((childAccount: any) => (
                                    <TableRow key={childAccount.accountId}>
                                      <TableCell></TableCell>
                                      <TableCell>{childAccount.accountCode}</TableCell>
                                      <TableCell>
                                        <div className="font-medium pr-4">
                                          {childAccount.accountName}
                                        </div>
                                        {childAccount.accountNameEn && (
                                          <div className="text-xs text-muted-foreground">
                                            {childAccount.accountNameEn}
                                          </div>
                                        )}
                                      </TableCell>
                                      {compareWithPrevPeriod && (
                                        <>
                                          <TableCell>
                                            {formatCurrency(childAccount.previousBalance)}
                                          </TableCell>
                                          <TableCell className={childAccount.change >= 0 ? "text-green-600" : "text-red-600"}>
                                            {childAccount.change >= 0 ? "+" : ""}{formatCurrency(childAccount.change)}
                                          </TableCell>
                                          <TableCell className={childAccount.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                            {childAccount.changePercentage >= 0 ? "+" : ""}
                                            {childAccount.changePercentage.toFixed(2)}%
                                          </TableCell>
                                        </>
                                      )}
                                      <TableCell>
                                        {formatCurrency(childAccount.balance)}
                                      </TableCell>
                                    </TableRow>
                                  ))
                                }
                              </>
                            ))}
                            
                            {/* إجمالي حقوق الملكية */}
                            <TableRow className="bg-primary/10 font-bold">
                              <TableCell colSpan={2}></TableCell>
                              <TableCell>
                                {t('financial.total_equity') || "إجمالي حقوق الملكية"}
                              </TableCell>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                </>
                              )}
                              <TableCell className="font-bold">
                                {formatCurrency(balanceSheetData.totalEquity)}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* الملخص والمطابقة */}
                    <div className="mt-6">
                      <Card className="bg-primary/5">
                        <CardContent className="pt-6">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <div className="font-medium">{t('financial.total_assets') || "إجمالي الأصول"}</div>
                                <div className="font-bold">
                                  {formatCurrency(balanceSheetData.totalAssets)}
                                </div>
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <div className="font-medium">{t('financial.total_liabilities') || "إجمالي الخصوم"}</div>
                                <div className="font-bold">
                                  {formatCurrency(balanceSheetData.totalLiabilities)}
                                </div>
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <div className="font-medium">{t('financial.total_equity') || "إجمالي حقوق الملكية"}</div>
                                <div className="font-bold">
                                  {formatCurrency(balanceSheetData.totalEquity)}
                                </div>
                              </div>
                              <Separator />
                              <div className="flex justify-between">
                                <div className="font-medium">{t('financial.total_liabilities_and_equity') || "إجمالي الخصوم وحقوق الملكية"}</div>
                                <div className="font-bold">
                                  {formatCurrency(balanceSheetData.totalLiabilitiesAndEquity)}
                                </div>
                              </div>
                              <div className="flex justify-between pt-2">
                                <div className="font-medium">{t('financial.balance_status') || "حالة التوازن"}</div>
                                <div className={`font-bold ${balanceSheetData.isBalanced ? 'text-green-500' : 'text-red-500'}`}>
                                  {balanceSheetData.isBalanced 
                                    ? t('financial.balanced') || "متوازن" 
                                    : t('financial.not_balanced') || "غير متوازن"}
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    {/* تذييل الطباعة - يظهر فقط عند الطباعة */}
                    <div className="print-footer hidden print:block mt-8 pt-6 border-t text-center text-sm text-gray-500">
                      <p>
                        {t('financial.report_generated_by') || "تم إنشاء هذا التقرير بواسطة"} - 
                        {t('app.title') || "نظام إدارة المشاريع"} - 
                        {format(new Date(), 'yyyy/MM/dd HH:mm')}
                      </p>
                      <p>
                        {t('financial.footer_disclaimer') || "هذا تقرير آلي تم إنشاؤه بواسطة النظام. جميع الأرقام بالريال السعودي ما لم يذكر خلاف ذلك."}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    {t('financial.no_data_available') || "لا توجد بيانات متاحة"}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="visual">
            {!isLoading && balanceSheetData && (
              <Card>
                <CardHeader>
                  <CardTitle>
                    {t('financial.balance_sheet.visual_representation') || "التمثيل المرئي للميزانية العمومية"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={getChartData()}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip 
                          formatter={(value: number) => formatCurrency(value)}
                        />
                        <Legend />
                        <Bar 
                          dataKey="amount" 
                          name={t('financial.amount') || "المبلغ"} 
                          fill="#8884d8" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                    <Card className="bg-blue-50 dark:bg-blue-950">
                      <CardContent className="pt-6">
                        <div className="text-center space-y-2">
                          <div className="text-lg font-medium">{t('financial.assets') || "الأصول"}</div>
                          <div className="text-2xl font-bold">
                            {formatCurrency(balanceSheetData.totalAssets)}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {t('financial.assets_percentage') || "نسبة الأصول"}: 
                            {" "}{((balanceSheetData.totalAssets / 
                              (balanceSheetData.totalAssets || 1)) * 100).toFixed(2)}%
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-red-50 dark:bg-red-950">
                      <CardContent className="pt-6">
                        <div className="text-center space-y-2">
                          <div className="text-lg font-medium">{t('financial.liabilities') || "الخصوم"}</div>
                          <div className="text-2xl font-bold">
                            {formatCurrency(balanceSheetData.totalLiabilities)}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {t('financial.liabilities_percentage') || "نسبة الخصوم"}: 
                            {" "}{((balanceSheetData.totalLiabilities / 
                              (balanceSheetData.totalAssets || 1)) * 100).toFixed(2)}%
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-green-50 dark:bg-green-950">
                      <CardContent className="pt-6">
                        <div className="text-center space-y-2">
                          <div className="text-lg font-medium">{t('financial.equity') || "حقوق الملكية"}</div>
                          <div className="text-2xl font-bold">
                            {formatCurrency(balanceSheetData.totalEquity)}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {t('financial.equity_percentage') || "نسبة حقوق الملكية"}: 
                            {" "}{((balanceSheetData.totalEquity / 
                              (balanceSheetData.totalAssets || 1)) * 100).toFixed(2)}%
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="comparative">
            <Card>
              <CardHeader>
                <CardTitle>
                  {t('financial.balance_sheet.comparative_analysis') || "التحليل المقارن للميزانية العمومية"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {compareWithPrevPeriod ? (
                  isLoading ? (
                    <div className="space-y-2">
                      <Skeleton className="h-8 w-full" />
                      <Skeleton className="h-8 w-full" />
                      <Skeleton className="h-8 w-full" />
                    </div>
                  ) : balanceSheetData ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {/* الأصول */}
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">
                              {t('financial.assets_change') || "تغيير الأصول"}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="text-2xl font-bold">
                              {formatCurrency(balanceSheetData.totalAssets)}
                            </div>
                            
                            {getLevel1Accounts(balanceSheetData.assets).slice(0, 5).map((account: any) => (
                              <div key={account.accountId} className="flex justify-between mt-2 text-sm">
                                <div>{account.accountName}</div>
                                <div className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                  {account.change >= 0 ? "+" : ""}{account.changePercentage.toFixed(1)}%
                                </div>
                              </div>
                            ))}
                          </CardContent>
                        </Card>
                        
                        {/* الخصوم */}
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">
                              {t('financial.liabilities_change') || "تغيير الخصوم"}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="text-2xl font-bold">
                              {formatCurrency(balanceSheetData.totalLiabilities)}
                            </div>
                            
                            {getLevel1Accounts(balanceSheetData.liabilities).slice(0, 5).map((account: any) => (
                              <div key={account.accountId} className="flex justify-between mt-2 text-sm">
                                <div>{account.accountName}</div>
                                <div className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                  {account.change >= 0 ? "+" : ""}{account.changePercentage.toFixed(1)}%
                                </div>
                              </div>
                            ))}
                          </CardContent>
                        </Card>
                        
                        {/* حقوق الملكية */}
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">
                              {t('financial.equity_change') || "تغيير حقوق الملكية"}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="text-2xl font-bold">
                              {formatCurrency(balanceSheetData.totalEquity)}
                            </div>
                            
                            {getLevel1Accounts(balanceSheetData.equity).slice(0, 5).map((account: any) => (
                              <div key={account.accountId} className="flex justify-between mt-2 text-sm">
                                <div>{account.accountName}</div>
                                <div className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                  {account.change >= 0 ? "+" : ""}{account.changePercentage.toFixed(1)}%
                                </div>
                              </div>
                            ))}
                          </CardContent>
                        </Card>
                      </div>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">
                            {t('financial.significant_changes') || "التغييرات الملحوظة"}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="rounded-md border">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                                  <TableHead>{t('financial.prev_balance') || "الرصيد السابق"}</TableHead>
                                  <TableHead>{t('financial.current_balance') || "الرصيد الحالي"}</TableHead>
                                  <TableHead>{t('financial.change_amount') || "مقدار التغيير"}</TableHead>
                                  <TableHead>{t('financial.change_percentage') || "نسبة التغيير"}</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {/* عرض أكبر 5 تغييرات بالنسبة المئوية */}
                                {[
                                  ...balanceSheetData.assets, 
                                  ...balanceSheetData.liabilities, 
                                  ...balanceSheetData.equity
                                ]
                                  .sort((a, b) => Math.abs(b.changePercentage) - Math.abs(a.changePercentage))
                                  .slice(0, 5)
                                  .map((account: any) => (
                                    <TableRow key={account.accountId}>
                                      <TableCell>{account.accountName}</TableCell>
                                      <TableCell>{formatCurrency(account.previousBalance)}</TableCell>
                                      <TableCell>{formatCurrency(account.balance)}</TableCell>
                                      <TableCell 
                                        className={account.change >= 0 ? "text-green-600" : "text-red-600"}
                                      >
                                        {account.change >= 0 ? "+" : ""}{formatCurrency(account.change)}
                                      </TableCell>
                                      <TableCell
                                        className={account.changePercentage >= 0 ? "text-green-600" : "text-red-600"}
                                      >
                                        {account.changePercentage >= 0 ? "+" : ""}
                                        {account.changePercentage.toFixed(2)}%
                                      </TableCell>
                                    </TableRow>
                                  ))
                                }
                              </TableBody>
                            </Table>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      {t('financial.no_data_available') || "لا توجد بيانات متاحة"}
                    </div>
                  )
                ) : (
                  <div className="text-center py-10">
                    <Calculator className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-medium mb-2">
                      {t('financial.enable_comparison') || "تفعيل خاصية المقارنة"}
                    </h3>
                    <p className="text-muted-foreground max-w-md mx-auto mb-4">
                      {t('financial.enable_comparison_desc') || 
                        "لعرض التحليل المقارن، يرجى تفعيل خيار المقارنة مع الفترة السابقة في قسم التصفية أعلاه."}
                    </p>
                    <Button onClick={() => setCompareWithPrevPeriod(true)}>
                      {t('financial.enable_comparison_now') || "تفعيل المقارنة الآن"}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageLayout>
  );
}