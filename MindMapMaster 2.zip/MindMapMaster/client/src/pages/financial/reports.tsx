import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  ResponsiveContainer
} from 'recharts';
import { FileText, BarChart4, Building2, Calendar, ArrowUpRight } from 'lucide-react';
import PageLayout from '../../components/layouts/PageLayout';

// بيانات تجريبية للرسوم البيانية
const financialPeriodData = [
  { name: 'الفترة 1', إيرادات: 750000, مصروفات: 600000, ربح: 150000 },
  { name: 'الفترة 2', إيرادات: 900000, مصروفات: 700000, ربح: 200000 },
  { name: 'الفترة 3', إيرادات: 1050000, مصروفات: 850000, ربح: 200000 },
  { name: 'الفترة 4', إيرادات: 1200000, مصروفات: 950000, ربح: 250000 },
];

const projectExpensesData = [
  { name: 'تمديدات مواسير طريق المطار', value: 450000 },
  { name: 'توسعة طريق الملك فهد', value: 350000 },
  { name: 'بناء محطة معالجة مياه', value: 600000 },
  { name: 'توسعة شبكة الاتصالات', value: 250000 },
  { name: 'إنشاء مجمع سكني', value: 500000 },
];

const accountBalanceData = [
  { name: 'الأصول', value: 3500000 },
  { name: 'الخصوم', value: 1500000 },
  { name: 'حقوق الملكية', value: 2000000 },
];

const certificateStatusData = [
  { name: 'معتمد ومدفوع', value: 1200000 },
  { name: 'معتمد غير مدفوع', value: 500000 },
  { name: 'قيد المراجعة', value: 350000 },
  { name: 'مرفوض', value: 100000 },
];

const expensesByTypeData = [
  { name: 'مواد', value: 850000 },
  { name: 'عمالة', value: 650000 },
  { name: 'معدات', value: 450000 },
  { name: 'مقاولين', value: 550000 },
  { name: 'نقل', value: 150000 },
  { name: 'إدارية', value: 250000 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function FinancialReports() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('overview');

  // استعلامات للحصول على بيانات مالية (يمكن تنفيذها لاحقًا)
  const { data: financialOverview, isLoading: loadingOverview } = useQuery({
    queryKey: ['/api/financial/overview'],
    enabled: false,
  });

  // تنسيق الأرقام بالعملة
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // تنسيق النسب المئوية
  const formatPercentage = (percentage: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'percent',
      maximumFractionDigits: 1,
    }).format(percentage / 100);
  };

  // حساب إجمالي المصروفات
  const totalExpenses = expensesByTypeData.reduce((sum, item) => sum + item.value, 0);
  
  // حساب إجمالي المستخلصات
  const totalCertificates = certificateStatusData.reduce((sum, item) => sum + item.value, 0);
  
  // حساب مجموع الأصول والخصوم
  const totalAssets = accountBalanceData.find(item => item.name === 'الأصول')?.value || 0;
  const totalLiabilities = accountBalanceData.find(item => item.name === 'الخصوم')?.value || 0;
  
  // حساب إجمالي الإيرادات والمصروفات والربح
  const totalRevenue = financialPeriodData.reduce((sum, item) => sum + item.إيرادات, 0);
  const totalCosts = financialPeriodData.reduce((sum, item) => sum + item.مصروفات, 0);
  const totalProfit = financialPeriodData.reduce((sum, item) => sum + item.ربح, 0);
  
  // حساب نسبة الربح
  const profitMargin = Math.round((totalProfit / totalRevenue) * 100);

  return (
    <PageLayout
      title={t('financial.reports.main_title') || "التقارير المالية"}
      sections={[
        {
          title: t('financial.reports.categories') || "فئات التقارير",
          items: [
            { title: t('financial.overview') || "نظرة عامة", href: "/financial/reports" },
            { title: t('financial.account_statement') || "كشف الحساب", href: "/financial/account-statement" },
            { title: t('financial.trial_balance') || "ميزان المراجعة", href: "/financial/trial-balance" },
            { title: t('financial.balance_sheet') || "الميزانية العمومية", href: "/financial/balance-sheet" },
            { title: t('financial.income_statement') || "قائمة الدخل", href: "/financial/income-statement" },
          ],
        },
      ]}
    >
      <div className="py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <p className="text-muted-foreground mt-1">{t('financial.reports.main_description') || "نظرة شاملة على الأداء المالي للمؤسسة والمشاريع"}</p>
          </div>

          <div>
            <Button variant="outline">
              <FileText className="h-4 w-4 ml-2" />
              {t('financial.export_report') || "تصدير التقرير"}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.total_assets') || "إجمالي الأصول"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalAssets)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.total_revenue') || "إجمالي الإيرادات"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalRevenue)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.total_expenses') || "إجمالي المصروفات"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalCosts)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>{t('financial.profit_margin') || "هامش الربح"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{formatPercentage(profitMargin)}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="overview">
              <BarChart4 className="h-4 w-4 ml-2" />
              {t('financial.overview') || "نظرة عامة"}
            </TabsTrigger>
            <TabsTrigger value="projects">
              <Building2 className="h-4 w-4 ml-2" />
              {t('financial.projects_financial') || "مالية المشاريع"}
            </TabsTrigger>
            <TabsTrigger value="periods">
              <Calendar className="h-4 w-4 ml-2" />
              {t('financial.periods') || "الفترات المالية"}
            </TabsTrigger>
          </TabsList>

          {/* نظرة عامة */}
          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('financial.income_expenses_profit') || "الإيرادات والمصروفات والأرباح"}</CardTitle>
                <CardDescription>
                  {t('financial.income_expenses_by_period') || "توزيع الإيرادات والمصروفات والأرباح حسب الفترة المالية"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={financialPeriodData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis tickFormatter={value => formatCurrency(value)} />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Bar dataKey="إيرادات" name={t('financial.income') || "الإيرادات"} fill="#8884d8" />
                      <Bar dataKey="مصروفات" name={t('financial.expenses') || "المصروفات"} fill="#82ca9d" />
                      <Bar dataKey="ربح" name={t('financial.profit') || "الربح"} fill="#ffc658" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>{t('financial.account_balances') || "أرصدة الحسابات"}</CardTitle>
                  <CardDescription>
                    {t('financial.account_balances_description') || "توزيع أرصدة الحسابات الرئيسية"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={accountBalanceData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                          nameKey="name"
                          label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {accountBalanceData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{t('financial.expense_distribution') || "توزيع المصروفات"}</CardTitle>
                  <CardDescription>
                    {t('financial.expense_distribution_by_category') || "توزيع المصروفات حسب الفئة"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={expensesByTypeData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                          nameKey="name"
                          label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {expensesByTypeData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* الروابط للتقارير التفصيلية */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t('financial.account_statement') || "كشف الحساب"}</CardTitle>
                  <CardDescription>
                    {t('financial.account_statement_description') || "تفاصيل وحركات الحسابات حسب الفترة"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Link href="/financial/account-statement">
                    <Button>
                      {t('financial.view_report') || "عرض التقرير"}
                      <ArrowUpRight className="h-4 w-4 mr-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{t('financial.trial_balance') || "ميزان المراجعة"}</CardTitle>
                  <CardDescription>
                    {t('financial.trial_balance_description') || "أرصدة كافة الحسابات في لحظة معينة"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Link href="/financial/trial-balance">
                    <Button>
                      {t('financial.view_report') || "عرض التقرير"}
                      <ArrowUpRight className="h-4 w-4 mr-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{t('financial.balance_sheet') || "الميزانية العمومية"}</CardTitle>
                  <CardDescription>
                    {t('financial.balance_sheet_description') || "الأصول والخصوم وحقوق الملكية"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Link href="/financial/balance-sheet">
                    <Button>
                      {t('financial.view_report') || "عرض التقرير"}
                      <ArrowUpRight className="h-4 w-4 mr-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* مالية المشاريع */}
          <TabsContent value="projects" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('financial.project_expenses') || "مصروفات المشاريع"}</CardTitle>
                <CardDescription>
                  {t('financial.project_expenses_description') || "توزيع المصروفات حسب المشاريع"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={projectExpensesData}
                      layout="vertical"
                      margin={{ top: 20, right: 30, left: 120, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" tickFormatter={value => formatCurrency(value)} />
                      <YAxis type="category" dataKey="name" width={120} />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Bar dataKey="value" name={t('financial.expenses') || "المصروفات"} fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t('financial.certificates_status') || "حالة المستخلصات"}</CardTitle>
                <CardDescription>
                  {t('financial.certificates_status_by_status') || "توزيع المستخلصات حسب الحالة"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={certificateStatusData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({name, value, percent}) => `${name}: ${formatCurrency(value)} (${(percent * 100).toFixed(0)}%)`}
                      >
                        {certificateStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t('financial.projects_financial_reports') || "تقارير مالية للمشاريع"}</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('financial.project_name') || "اسم المشروع"}</TableHead>
                      <TableHead>{t('financial.budget') || "الميزانية"}</TableHead>
                      <TableHead>{t('financial.expenses') || "المصروفات"}</TableHead>
                      <TableHead>{t('financial.remaining') || "المتبقي"}</TableHead>
                      <TableHead>{t('financial.utilization') || "نسبة الاستغلال"}</TableHead>
                      <TableHead className="text-right">{t('common.details') || "التفاصيل"}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">تمديدات مواسير طريق المطار</TableCell>
                      <TableCell>{formatCurrency(550000)}</TableCell>
                      <TableCell>{formatCurrency(450000)}</TableCell>
                      <TableCell>{formatCurrency(100000)}</TableCell>
                      <TableCell>{formatPercentage(82)}</TableCell>
                      <TableCell className="text-right">
                        <Link href="/projects/1/financial-reports">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">توسعة طريق الملك فهد</TableCell>
                      <TableCell>{formatCurrency(450000)}</TableCell>
                      <TableCell>{formatCurrency(350000)}</TableCell>
                      <TableCell>{formatCurrency(100000)}</TableCell>
                      <TableCell>{formatPercentage(78)}</TableCell>
                      <TableCell className="text-right">
                        <Link href="/projects/2/financial-reports">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">بناء محطة معالجة مياه</TableCell>
                      <TableCell>{formatCurrency(750000)}</TableCell>
                      <TableCell>{formatCurrency(600000)}</TableCell>
                      <TableCell>{formatCurrency(150000)}</TableCell>
                      <TableCell>{formatPercentage(80)}</TableCell>
                      <TableCell className="text-right">
                        <Link href="/projects/3/financial-reports">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">توسعة شبكة الاتصالات</TableCell>
                      <TableCell>{formatCurrency(350000)}</TableCell>
                      <TableCell>{formatCurrency(250000)}</TableCell>
                      <TableCell>{formatCurrency(100000)}</TableCell>
                      <TableCell>{formatPercentage(71)}</TableCell>
                      <TableCell className="text-right">
                        <Link href="/projects/4/financial-reports">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">إنشاء مجمع سكني</TableCell>
                      <TableCell>{formatCurrency(650000)}</TableCell>
                      <TableCell>{formatCurrency(500000)}</TableCell>
                      <TableCell>{formatCurrency(150000)}</TableCell>
                      <TableCell>{formatPercentage(77)}</TableCell>
                      <TableCell className="text-right">
                        <Link href="/projects/5/financial-reports">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* الفترات المالية */}
          <TabsContent value="periods" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('financial.financial_periods_performance') || "أداء الفترات المالية"}</CardTitle>
                <CardDescription>
                  {t('financial.financial_periods_description') || "تحليل الأداء المالي للفترات"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={financialPeriodData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis tickFormatter={value => formatCurrency(value)} />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Line type="monotone" dataKey="إيرادات" stroke="#8884d8" name={t('financial.income') || "الإيرادات"} />
                      <Line type="monotone" dataKey="مصروفات" stroke="#82ca9d" name={t('financial.expenses') || "المصروفات"} />
                      <Line type="monotone" dataKey="ربح" stroke="#ff7300" name={t('financial.profit') || "الربح"} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t('financial.periods_list') || "قائمة الفترات المالية"}</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('financial.period_name') || "اسم الفترة"}</TableHead>
                      <TableHead>{t('financial.start_date') || "تاريخ البداية"}</TableHead>
                      <TableHead>{t('financial.end_date') || "تاريخ النهاية"}</TableHead>
                      <TableHead>{t('financial.income') || "الإيرادات"}</TableHead>
                      <TableHead>{t('financial.expenses') || "المصروفات"}</TableHead>
                      <TableHead>{t('financial.profit') || "الربح"}</TableHead>
                      <TableHead>{t('common.status') || "الحالة"}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">الربع الأول 2025</TableCell>
                      <TableCell>2025-01-01</TableCell>
                      <TableCell>2025-03-31</TableCell>
                      <TableCell>{formatCurrency(750000)}</TableCell>
                      <TableCell>{formatCurrency(600000)}</TableCell>
                      <TableCell className="text-green-600">{formatCurrency(150000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">مغلق</span>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">الربع الثاني 2025</TableCell>
                      <TableCell>2025-04-01</TableCell>
                      <TableCell>2025-06-30</TableCell>
                      <TableCell>{formatCurrency(900000)}</TableCell>
                      <TableCell>{formatCurrency(700000)}</TableCell>
                      <TableCell className="text-green-600">{formatCurrency(200000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">مغلق</span>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">الربع الثالث 2025</TableCell>
                      <TableCell>2025-07-01</TableCell>
                      <TableCell>2025-09-30</TableCell>
                      <TableCell>{formatCurrency(1050000)}</TableCell>
                      <TableCell>{formatCurrency(850000)}</TableCell>
                      <TableCell className="text-green-600">{formatCurrency(200000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">نشط</span>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">الربع الرابع 2025</TableCell>
                      <TableCell>2025-10-01</TableCell>
                      <TableCell>2025-12-31</TableCell>
                      <TableCell>{formatCurrency(1200000)}</TableCell>
                      <TableCell>{formatCurrency(950000)}</TableCell>
                      <TableCell className="text-green-600">{formatCurrency(250000)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">مجدول</span>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* بطاقات الوصول السريع للتقارير المالية الرئيسية */}
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">{t('financial.main_reports') || "التقارير المالية الرئيسية"}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* ميزان المراجعة */}
            <Card className="hover:shadow-md transition-shadow">
              <Link href="/financial/trial-balance">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{t('financial.trial_balance') || "ميزان المراجعة"}</CardTitle>
                  <CardDescription>
                    {t('financial.trial_balance_description') || "عرض أرصدة الحسابات للتحقق من توازن المدين والدائن"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <BarChart4 className="h-6 w-6 text-primary" />
                    </div>
                    <Button variant="ghost" size="sm">
                      {t('common.view_report') || "عرض التقرير"} <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Link>
            </Card>

            {/* الميزانية العمومية */}
            <Card className="hover:shadow-md transition-shadow">
              <Link href="/financial/balance-sheet">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{t('financial.balance_sheet') || "الميزانية العمومية"}</CardTitle>
                  <CardDescription>
                    {t('financial.balance_sheet_description') || "عرض الأصول والالتزامات وحقوق الملكية للمؤسسة"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Building2 className="h-6 w-6 text-primary" />
                    </div>
                    <Button variant="ghost" size="sm">
                      {t('common.view_report') || "عرض التقرير"} <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Link>
            </Card>

            {/* قائمة الدخل */}
            <Card className="hover:shadow-md transition-shadow">
              <Link href="/financial/income-statement">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{t('financial.income_statement') || "قائمة الدخل"}</CardTitle>
                  <CardDescription>
                    {t('financial.income_statement_description') || "عرض الإيرادات والمصروفات وصافي الربح أو الخسارة"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Calendar className="h-6 w-6 text-primary" />
                    </div>
                    <Button variant="ghost" size="sm">
                      {t('common.view_report') || "عرض التقرير"} <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Link>
            </Card>

          </div>
        </div>
      </div>
    </PageLayout>
  );
}