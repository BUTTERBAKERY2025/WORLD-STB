import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import { z } from 'zod';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  FileText, 
  ChevronLeft, 
  Plus, 
  Trash, 
  Calculator, 
  FileSpreadsheet, 
  ClipboardList,
  Receipt, 
  Info,
  ListFilter,
  BanknoteIcon,
  FileCheck,
  BarChart3,
  PlusCircle,
  RefreshCcw,
  Percent,
  CheckCircle
} from 'lucide-react';

export default function NewCertificatePage() {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [currentStep, setCurrentStep] = useState("generalInfo");
  const [workflowSteps, setWorkflowSteps] = useState<any[]>([]);
  const [certificateWorkflowSettings, setCertificateWorkflowSettings] = useState({
    enableWorkflow: true,
    workflowTemplate: 'standard',
    requiredApprovals: [],
  });
  const [certificateSettings, setCertificateSettings] = useState<any>(null);
  
  // مخطط Zod لنموذج المستخلص - مطوّر ومحسّن
  const formSchema = z.object({
    projectId: z.number().min(1, t('projectIsRequired')),
    type: z.enum(['subcontractor', 'main_contractor', 'consultant', 'internal', 'interim', 'final']),
    contractorName: z.string().optional().transform(val => val || ''),
    contractNumber: z.string().optional().transform(val => val || ''),
    fromDate: z.string().min(1, t('periodFromIsRequired')),
    toDate: z.string().min(1, t('periodToIsRequired')),
    grossAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    totalAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    previousAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    currentAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    finalAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    advancePaymentAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    advancePaymentDeduction: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    retentionAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    taxAmount: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    otherDeductions: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    materialsOnSite: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    otherAdditions: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('amountMustBePositive'))
    ),
    completionPercentage: z.preprocess(
      (val) => parseFloat(val as string) || 0,
      z.number().min(0, t('percentageMustBePositive')).max(100, t('percentageCannotExceed100'))
    ),
    notes: z.string().optional().transform(val => val || ''),
    items: z.array(z.object({
      description: z.string().min(1, t('descriptionIsRequired')),
      contractItemId: z.preprocess(
        (val) => val === '' || val === null ? null : Number(val),
        z.number().nullable().optional()
      ),
      unit: z.string().min(1, t('unitIsRequired')),
      currentQuantity: z.preprocess(
        (val) => parseFloat(val as string) || 0,
        z.number().min(0, t('quantityMustBePositive'))
      ),
      unitPrice: z.preprocess(
        (val) => parseFloat(val as string) || 0,
        z.number().min(0, t('unitPriceMustBePositive'))
      ),
      amount: z.preprocess(
        (val) => parseFloat(val as string) || 0,
        z.number().min(0, t('amountMustBePositive'))
      ),
      completionPercentage: z.preprocess(
        (val) => parseFloat(val as string) || 0,
        z.number().min(0, t('percentageMustBePositive')).max(100, t('percentageCannotExceed100'))
      )
    }))
  });

  type FormData = z.infer<typeof formSchema>;

  // إنشاء نموذج المستخلص
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectId: 0,
      type: 'interim',
      contractorName: '',
      contractNumber: '',
      fromDate: '',
      toDate: '',
      grossAmount: 0,
      totalAmount: 0,
      previousAmount: 0,
      currentAmount: 0,
      finalAmount: 0,
      advancePaymentAmount: 0,
      advancePaymentDeduction: 0,
      retentionAmount: 0,
      taxAmount: 0,
      otherDeductions: 0,
      materialsOnSite: 0,
      otherAdditions: 0,
      completionPercentage: 0,
      notes: '',
      items: [
        {
          description: '',
          contractItemId: null,
          unit: '',
          currentQuantity: 0,
          unitPrice: 0,
          amount: 0,
          completionPercentage: 0
        }
      ]
    }
  });

  // إنشاء مصفوفة لإدارة عناصر المستخلص
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items"
  });
  
  // تحميل المشاريع عند تهيئة الصفحة
  const [projects, setProjects] = useState<any[]>([]);
  const [contractItems, setContractItems] = useState<any[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  
  useEffect(() => {
    const loadProjects = async () => {
      try {
        const response = await apiRequest('GET', '/api/projects');
        const data = await response.json();
        setProjects(data);
      } catch (error) {
        console.error('Error loading projects:', error);
        toast({
          variant: "destructive",
          title: t('error'),
          description: t('failedToLoadProjects'),
        });
      }
    };
    
    loadProjects();
  }, [t, toast]);
  
  // تحميل بنود العقد وإعدادات المستخلص عند تغيير المشروع المحدد
  useEffect(() => {
    const loadProjectData = async () => {
      if (!selectedProjectId) return;
      
      try {
        // تحميل بنود العقد
        const contractItemsResponse = await apiRequest('GET', `/api/projects/${selectedProjectId}/contract-items`);
        const contractItemsData = await contractItemsResponse.json();
        setContractItems(contractItemsData);
        
        // تحميل إعدادات المستخلصات للمشروع
        const settingsResponse = await apiRequest('GET', `/api/projects/${selectedProjectId}/certificate-settings`);
        if (settingsResponse.ok) {
          const settingsData = await settingsResponse.json();
          setCertificateSettings(settingsData);
          
          // تطبيق الإعدادات الافتراضية على النموذج
          if (settingsData) {
            form.setValue('retentionAmount', form.getValues('grossAmount') * (settingsData.retentionPercentage || 5) / 100);
            form.setValue('taxAmount', form.getValues('grossAmount') * (settingsData.taxPercentage || 15) / 100);
            
            // إعدادات سير العمل
            if (settingsData.workflowTemplate) {
              setCertificateWorkflowSettings({
                ...certificateWorkflowSettings,
                workflowTemplate: settingsData.workflowTemplate
              });
            }
          }
        }
        
        // تحميل خطوات سير العمل للمشروع
        const workflowResponse = await apiRequest('GET', `/api/projects/${selectedProjectId}/certificate-workflow-steps`);
        if (workflowResponse.ok) {
          const workflowData = await workflowResponse.json();
          setWorkflowSteps(workflowData);
        }
      } catch (error) {
        console.error('Error loading project data:', error);
        toast({
          variant: "destructive",
          title: t('error'),
          description: t('failedToLoadProjectData'),
        });
      }
    };
    
    loadProjectData();
  }, [selectedProjectId, t, toast, form, certificateWorkflowSettings]);
  
  // تغيير المشروع المحدد
  const handleProjectChange = (projectId: string) => {
    setSelectedProjectId(Number(projectId));
    form.setValue('projectId', Number(projectId));
  };
  
  // حساب المبلغ لعنصر - نسخة محسنة مع التأكد من تحويل الأرقام
  const calculateItemAmount = (index: number) => {
    // استخدام parseFloat للتأكد من أن القيم دائمًا أرقام
    const quantity = parseFloat(form.getValues(`items.${index}.currentQuantity`).toString()) || 0;
    const unitPrice = parseFloat(form.getValues(`items.${index}.unitPrice`).toString()) || 0;
    
    // حساب المبلغ بدقة
    const amount = quantity * unitPrice;
    
    // تخزين القيمة المحسوبة
    form.setValue(`items.${index}.amount`, amount);
    
    // تحديث المبلغ الإجمالي للمستخلص
    const items = form.getValues('items');
    const totalAmount = items.reduce((sum: number, item: any) => {
      // التأكد من أن كل قيمة رقمية
      const itemAmount = parseFloat(item.amount?.toString() || '0') || 0;
      return sum + itemAmount;
    }, 0);
    
    // تحديث الحقول ذات الصلة
    form.setValue('totalAmount', totalAmount);
    form.setValue('grossAmount', totalAmount);
    form.setValue('currentAmount', totalAmount);
    
    // تسجيل معلومات للتصحيح
    console.log(`Item ${index} calculated: Q=${quantity} x P=${unitPrice} = A=${amount}, Total=${totalAmount}`);
    
    // إعادة حساب المبلغ النهائي بعد التحديث
    calculateFinalAmount();
  };
  
  // إضافة عنصر جديد
  const addItem = () => {
    append({
      description: '',
      contractItemId: null,
      unit: '',
      currentQuantity: 0,
      unitPrice: 0,
      amount: 0,
      completionPercentage: 0
    });
  };
  
  // حساب المبلغ النهائي بناءً على الخصومات والإضافات - نسخة محسنة
  const calculateFinalAmount = () => {
    // نحصل على القيم ونتأكد من تحويلها إلى أرقام
    const grossAmount = parseFloat(form.getValues('grossAmount')?.toString() || '0') || 0;
    const advancePaymentDeduction = parseFloat(form.getValues('advancePaymentDeduction')?.toString() || '0') || 0;
    const retentionAmount = parseFloat(form.getValues('retentionAmount')?.toString() || '0') || 0;
    const taxAmount = parseFloat(form.getValues('taxAmount')?.toString() || '0') || 0;
    const otherDeductions = parseFloat(form.getValues('otherDeductions')?.toString() || '0') || 0;
    const materialsOnSite = parseFloat(form.getValues('materialsOnSite')?.toString() || '0') || 0;
    const otherAdditions = parseFloat(form.getValues('otherAdditions')?.toString() || '0') || 0;
    
    // نحسب مجموع الخصومات
    const totalDeductions = advancePaymentDeduction + retentionAmount + taxAmount + otherDeductions;
    
    // نحسب مجموع الإضافات
    const totalAdditions = materialsOnSite + otherAdditions;
    
    // نحسب المبلغ النهائي
    const finalAmount = grossAmount - totalDeductions + totalAdditions;
    
    // نسجل المعلومات للتصحيح
    console.log(`Final amount calculation: Gross=${grossAmount}, Deductions=${totalDeductions}, Additions=${totalAdditions}, Final=${finalAmount}`);
    
    // نحدث قيمة المبلغ النهائي في النموذج
    form.setValue('finalAmount', finalAmount);
  };

  // إرسال النموذج
  const onSubmit = async (data: FormData) => {
    setSubmitting(true);
    
    try {
      console.log('Submitting certificate data:', data);
      
      // التحقق من صحة البيانات الأساسية قبل الإرسال
      if (data.projectId <= 0) {
        throw new Error('يجب تحديد المشروع');
      }
      
      if (!data.fromDate || !data.toDate) {
        throw new Error('يجب تحديد فترة المستخلص');
      }
      
      // التحقق من أن تاريخ الانتهاء بعد تاريخ البداية
      if (new Date(data.toDate) < new Date(data.fromDate)) {
        throw new Error(t('periodToMustBeAfterFrom'));
      }
      
      if (data.items.length === 0 || !data.items[0].description) {
        throw new Error('يجب إضافة بند واحد على الأقل للمستخلص');
      }
      
      // تحديث مبلغ المستخلص الإجمالي قبل الإرسال
      const totalAmount = data.items.reduce((sum, item) => sum + (item.amount || 0), 0);
      const formData = {
        ...data,
        grossAmount: totalAmount,
        totalAmount: totalAmount,
        currentAmount: totalAmount,
        finalAmount: totalAmount - 
                   (data.advancePaymentDeduction || 0) - 
                   (data.retentionAmount || 0) - 
                   (data.taxAmount || 0) - 
                   (data.otherDeductions || 0) + 
                   (data.materialsOnSite || 0) + 
                   (data.otherAdditions || 0),
        status: 'draft',
      };
      
      console.log('Final certificate data to submit:', formData);
      
      // إرسال بيانات المستخلص
      const certificateResponse = await apiRequest('POST', '/api/certificates', formData);
      
      if (!certificateResponse.ok) {
        const errorData = await certificateResponse.json().catch(() => ({}));
        console.error('Certificate creation failed:', errorData);
        throw new Error(errorData.message || 'فشل في إنشاء المستخلص');
      }
      
      const certificateData = await certificateResponse.json();
      console.log('Certificate created successfully:', certificateData);
      
      // التحقق من صحة بنود المستخلص وإرسالها
      const validItems = data.items.filter(item => item.description && item.unit);
      if (validItems.length === 0) {
        throw new Error(t('noValidItemsToSubmit'));
      }
      
      // حساب القيم المطلوبة لكل بند وإرسالها
      for (const item of validItems) {
        // التأكد من احتساب القيمة إذا لم تكن محسوبة مسبقاً
        const calculatedAmount = item.amount || (item.currentQuantity * item.unitPrice) || 0;
        
        const itemData = {
          certificateId: certificateData.id,
          description: item.description,
          contractItemId: item.contractItemId || null,
          unit: item.unit,
          currentQuantity: parseFloat(item.currentQuantity.toString()) || 0,
          unitPrice: parseFloat(item.unitPrice.toString()) || 0,
          amount: parseFloat(calculatedAmount.toString()) || 0,
          completionPercentage: parseFloat(item.completionPercentage?.toString() || '0') || 0
        };
        
        console.log('Submitting certificate item:', itemData);
        
        try {
          const itemResponse = await apiRequest('POST', '/api/certificate-items', itemData);
          
          if (!itemResponse.ok) {
            const errorData = await itemResponse.json().catch(() => ({}));
            console.error('Failed to create certificate item:', errorData);
            // نستمر بالمحاولة مع باقي البنود حتى لو فشل بند واحد
          } else {
            console.log('Certificate item created successfully');
          }
        } catch (error) {
          console.error('Error submitting certificate item:', error);
          // نستمر بالمحاولة مع باقي البنود حتى لو فشل بند واحد
        }
      }
      
      toast({
        title: t('success'),
        description: t('certificateCreated'),
      });
      
      navigate('/financial/certificates');
    } catch (error) {
      console.error('Error creating certificate:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: error instanceof Error ? error.message : t('certificateCreationFailed'),
      });
    } finally {
      setSubmitting(false);
    }
  };

  // التحقق من أن بند العقد غير مستخدم بالفعل
  const isContractItemAlreadySelected = (item: any) => (
    fields
      .filter((_, idx) => idx !== form.getValues('items').length - 1)
      .some(formItem => formItem.contractItemId === item.id)
  );
  
  return (
    <div className="container mx-auto p-4">
      <Breadcrumb className="mb-4">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">{t('home')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/financial">{t('financial')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/financial/certificates">{t('certificates')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink>{t('newCertificate')}</BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">{t('newCertificate')}</h1>
          <p className="text-muted-foreground">{t('createNewPaymentCertificate')}</p>
        </div>
        <Link href="/financial/certificates">
          <Button variant="outline">
            <ChevronLeft className="h-4 w-4 mr-2" />
            {t('back')}
          </Button>
        </Link>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Tabs defaultValue="generalInfo" className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="generalInfo">
                <Info className="h-4 w-4 mr-2" />
                {t('generalInfo')}
              </TabsTrigger>
              <TabsTrigger value="contractItems">
                <ClipboardList className="h-4 w-4 mr-2" />
                {t('contractItems')}
              </TabsTrigger>
              <TabsTrigger value="workItems">
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                {t('workItems')}
              </TabsTrigger>
              <TabsTrigger value="financialSummary">
                <BarChart3 className="h-4 w-4 mr-2" />
                {t('financialSummary')}
              </TabsTrigger>
              <TabsTrigger value="approvals">
                <FileCheck className="h-4 w-4 mr-2" />
                {t('approvalWorkflow')}
              </TabsTrigger>
              <TabsTrigger value="preview">
                <FileCheck className="h-4 w-4 mr-2" />
                {t('preview')}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="contractItems" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t('contractItems')}</CardTitle>
                  <CardDescription>{t('selectContractItems')}</CardDescription>
                </CardHeader>
                <CardContent>
                  {!selectedProjectId ? (
                    <div className="py-8 text-center">
                      <FileText className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                      <h3 className="mb-2 text-lg font-medium">{t('selectProjectFirst')}</h3>
                      <p className="text-muted-foreground text-sm mb-4">
                        {t('selectProjectToViewContractItems')}
                      </p>
                    </div>
                  ) : contractItems.length === 0 ? (
                    <div className="py-8 text-center">
                      <ClipboardList className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                      <h3 className="mb-2 text-lg font-medium">{t('noContractItems')}</h3>
                      <p className="text-muted-foreground text-sm">
                        {t('noContractItemsDescription')}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="text-lg font-medium">{t('availableContractItems')}</h3>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => {
                            // استيراد كل بنود العقد
                            const newItems = contractItems
                              .filter(item => !isContractItemAlreadySelected(item))
                              .map(item => ({
                                description: item.description,
                                contractItemId: item.id,
                                unit: item.unit,
                                currentQuantity: 0,
                                unitPrice: item.unitPrice,
                                amount: 0,
                                completionPercentage: 0
                              }));
                              
                            // إضافة البنود الجديدة
                            if (newItems.length > 0) {
                              // إذا كان هناك عنصر فارغ، نقوم بحذفه أولاً
                              const items = form.getValues('items');
                              if (items.length === 1 && !items[0].description) {
                                remove(0);
                              }
                              
                              // إضافة البنود الجديدة
                              newItems.forEach(item => append(item));
                              
                              toast({
                                title: t('itemsImported'),
                                description: t('allContractItemsImported'),
                              });
                            }
                          }}
                        >
                          <PlusCircle className="h-4 w-4 mr-2" />
                          {t('importAllItems')}
                        </Button>
                      </div>
                      
                      <div className="border rounded-md">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[50px]">#</TableHead>
                              <TableHead>{t('description')}</TableHead>
                              <TableHead>{t('unit')}</TableHead>
                              <TableHead>{t('quantity')}</TableHead>
                              <TableHead>{t('unitPrice')}</TableHead>
                              <TableHead>{t('totalPrice')}</TableHead>
                              <TableHead className="text-right">{t('actions')}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {contractItems.map((item, index) => (
                              <TableRow 
                                key={item.id}
                                className={isContractItemAlreadySelected(item) ? 'bg-muted/50' : ''}
                              >
                                <TableCell>{item.itemNumber || index + 1}</TableCell>
                                <TableCell>{item.description}</TableCell>
                                <TableCell>{item.unit}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>{item.unitPrice}</TableCell>
                                <TableCell>{item.totalPrice}</TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    disabled={isContractItemAlreadySelected(item)}
                                    onClick={() => {
                                      append({
                                        description: item.description,
                                        contractItemId: item.id,
                                        unit: item.unit,
                                        currentQuantity: 0,
                                        unitPrice: item.unitPrice,
                                        amount: 0,
                                        completionPercentage: 0
                                      });
                                      
                                      toast({
                                        title: t('itemAdded'),
                                        description: t('contractItemAddedToList'),
                                      });
                                    }}
                                  >
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="generalInfo" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t('projectInformation')}</CardTitle>
                  <CardDescription>{t('selectProjectAndType')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="projectId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('project')} <span className="text-destructive">*</span></FormLabel>
                          <Select 
                            onValueChange={(value) => handleProjectChange(value)} 
                            defaultValue={field.value ? String(field.value) : undefined}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('selectProject')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {projects.map((project) => (
                                <SelectItem key={project.id} value={String(project.id)}>
                                  {project.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormDescription>{t('projectDescription')}</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('certificateType')} <span className="text-destructive">*</span></FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('selectCertificateType')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="interim">{t('interim')}</SelectItem>
                              <SelectItem value="final">{t('final')}</SelectItem>
                              <SelectItem value="main_contractor">{t('mainContractor')}</SelectItem>
                              <SelectItem value="subcontractor">{t('subcontractor')}</SelectItem>
                              <SelectItem value="consultant">{t('consultant')}</SelectItem>
                              <SelectItem value="internal">{t('internal')}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>{t('certificateTypeDescription')}</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mt-4">
                <CardHeader>
                  <CardTitle>{t('contractDetails')}</CardTitle>
                  <CardDescription>{t('enterContractorAndContractDetails')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="contractorName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('contractorName')}</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormDescription>{t('contractorNameDescription')}</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="contractNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('contractNumber')}</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormDescription>{t('contractNumberDescription')}</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mt-4">
                <CardHeader>
                  <CardTitle>{t('periodDetails')}</CardTitle>
                  <CardDescription>{t('specifyWorkPeriod')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="fromDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('periodFrom')} <span className="text-destructive">*</span></FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormDescription>{t('periodFromDescription')}</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="toDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('periodTo')} <span className="text-destructive">*</span></FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormDescription>{t('periodToDescription')}</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mt-4">
                <CardHeader>
                  <CardTitle>{t('additionalInformation')}</CardTitle>
                  <CardDescription>{t('additionalDetailsDescription')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('notes')}</FormLabel>
                        <FormControl>
                          <Textarea {...field} rows={3} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="workItems" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t('certificateItems')}</CardTitle>
                  <CardDescription>{t('addCertificateItems')}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <h3 className="text-lg font-medium">{t('workItemsList')}</h3>
                      <p className="text-muted-foreground text-sm">{t('enterCompletedWorks')}</p>
                    </div>
                    <div>
                      <Button type="button" variant="outline" onClick={() => addItem()}>
                        <PlusCircle className="h-4 w-4 mr-2" />
                        {t('addNewItem')}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50px]">#</TableHead>
                          <TableHead>{t('description')}</TableHead>
                          <TableHead>{t('unit')}</TableHead>
                          <TableHead>{t('currentQuantity')}</TableHead>
                          <TableHead>{t('unitPrice')}</TableHead>
                          <TableHead>{t('amount')}</TableHead>
                          <TableHead className="text-right">{t('actions')}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {fields.map((field, index) => (
                          <TableRow key={field.id}>
                            <TableCell>{index + 1}</TableCell>
                            <TableCell>
                              <FormField
                                control={form.control}
                                name={`items.${index}.description`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </TableCell>
                            <TableCell>
                              <FormField
                                control={form.control}
                                name={`items.${index}.unit`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </TableCell>
                            <TableCell>
                              <FormField
                                control={form.control}
                                name={`items.${index}.currentQuantity`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input 
                                        type="number" 
                                        step="0.01" 
                                        min="0" 
                                        {...field} 
                                        onChange={(e) => {
                                          field.onChange(parseFloat(e.target.value) || 0);
                                          calculateItemAmount(index);
                                        }}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </TableCell>
                            <TableCell>
                              <FormField
                                control={form.control}
                                name={`items.${index}.unitPrice`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input 
                                        type="number" 
                                        step="0.01" 
                                        min="0" 
                                        {...field} 
                                        onChange={(e) => {
                                          field.onChange(parseFloat(e.target.value) || 0);
                                          calculateItemAmount(index);
                                        }}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </TableCell>
                            <TableCell>
                              <FormField
                                control={form.control}
                                name={`items.${index}.amount`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input type="number" step="0.01" min="0" {...field} readOnly />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </TableCell>
                            <TableCell className="text-right">
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm"
                                onClick={() => remove(index)}
                              >
                                <Trash className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {fields.length === 0 && (
                    <div className="text-center py-8 border rounded-md bg-muted/20">
                      <p className="text-muted-foreground">{t('noCertificateItems')}</p>
                      <Button 
                        variant="outline" 
                        className="mt-4" 
                        onClick={() => addItem()}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        {t('addItem')}
                      </Button>
                    </div>
                  )}
                  
                  <div className="mt-4 flex justify-end">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => fields.forEach((_, index) => calculateItemAmount(index))}
                      className="mr-2"
                    >
                      <Calculator className="h-4 w-4 mr-2" />
                      {t('recalculate')}
                    </Button>
                    
                    <Button 
                      type="button" 
                      variant="secondary" 
                      onClick={() => addItem()}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      {t('addItem')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="approvals" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t('approvalWorkflow')}</CardTitle>
                  <CardDescription>{t('configureApprovalWorkflow')}</CardDescription>
                </CardHeader>
                <CardContent>
                  {!selectedProjectId ? (
                    <div className="py-8 text-center">
                      <FileText className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                      <h3 className="mb-2 text-lg font-medium">{t('selectProjectFirst')}</h3>
                      <p className="text-muted-foreground text-sm mb-4">
                        {t('selectProjectToConfigureWorkflow')}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="flex justify-between items-center mb-4">
                        <div>
                          <h3 className="text-lg font-medium">{t('approvalSteps')}</h3>
                          <p className="text-muted-foreground text-sm">
                            {t('configureApprovalStepsForCertificate')}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <div className="flex items-center gap-2 space-y-0">
                            <span className="text-sm font-medium">{t('enableWorkflow')}</span>
                            <Switch
                              checked={certificateWorkflowSettings.enableWorkflow}
                              onCheckedChange={(checked: boolean) => 
                                setCertificateWorkflowSettings({
                                  ...certificateWorkflowSettings,
                                  enableWorkflow: checked
                                })
                              }
                            />
                          </div>
                        </div>
                      </div>
                      
                      {certificateWorkflowSettings.enableWorkflow ? (
                        <>
                          <div className="border rounded-md p-4 bg-muted/20">
                            <h4 className="font-medium mb-4">{t('workflowTemplate')}</h4>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div 
                                className={`border rounded-md p-4 cursor-pointer transition-all hover:border-primary ${certificateWorkflowSettings.workflowTemplate === 'standard' ? 'border-primary bg-primary/5' : ''}`}
                                onClick={() => setCertificateWorkflowSettings({
                                  ...certificateWorkflowSettings,
                                  workflowTemplate: 'standard'
                                })}
                              >
                                <div className="flex justify-between mb-2">
                                  <h5 className="font-medium">{t('standardWorkflow')}</h5>
                                  {certificateWorkflowSettings.workflowTemplate === 'standard' && (
                                    <CheckCircle className="h-5 w-5 text-primary" />
                                  )}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {t('standardWorkflowDescription')}
                                </p>
                                <div className="mt-2 text-xs text-muted-foreground">
                                  <p>{t('approvalLevels')}: 3</p>
                                </div>
                              </div>
                              
                              <div 
                                className={`border rounded-md p-4 cursor-pointer transition-all hover:border-primary ${certificateWorkflowSettings.workflowTemplate === 'simplified' ? 'border-primary bg-primary/5' : ''}`}
                                onClick={() => setCertificateWorkflowSettings({
                                  ...certificateWorkflowSettings,
                                  workflowTemplate: 'simplified'
                                })}
                              >
                                <div className="flex justify-between mb-2">
                                  <h5 className="font-medium">{t('simplifiedWorkflow')}</h5>
                                  {certificateWorkflowSettings.workflowTemplate === 'simplified' && (
                                    <CheckCircle className="h-5 w-5 text-primary" />
                                  )}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {t('simplifiedWorkflowDescription')}
                                </p>
                                <div className="mt-2 text-xs text-muted-foreground">
                                  <p>{t('approvalLevels')}: 2</p>
                                </div>
                              </div>
                              
                              <div 
                                className={`border rounded-md p-4 cursor-pointer transition-all hover:border-primary ${certificateWorkflowSettings.workflowTemplate === 'advanced' ? 'border-primary bg-primary/5' : ''}`}
                                onClick={() => setCertificateWorkflowSettings({
                                  ...certificateWorkflowSettings,
                                  workflowTemplate: 'advanced'
                                })}
                              >
                                <div className="flex justify-between mb-2">
                                  <h5 className="font-medium">{t('advancedWorkflow')}</h5>
                                  {certificateWorkflowSettings.workflowTemplate === 'advanced' && (
                                    <CheckCircle className="h-5 w-5 text-primary" />
                                  )}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {t('advancedWorkflowDescription')}
                                </p>
                                <div className="mt-2 text-xs text-muted-foreground">
                                  <p>{t('approvalLevels')}: 5</p>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="border rounded-md overflow-hidden">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-[50px]">#</TableHead>
                                  <TableHead>{t('approvalStep')}</TableHead>
                                  <TableHead>{t('approver')}</TableHead>
                                  <TableHead>{t('dueDays')}</TableHead>
                                  <TableHead>{t('required')}</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {workflowSteps.length === 0 ? (
                                  <TableRow>
                                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                                      {t('noWorkflowStepsConfigured')}
                                    </TableCell>
                                  </TableRow>
                                ) : (
                                  workflowSteps.map((step, index) => (
                                    <TableRow key={index}>
                                      <TableCell>{index + 1}</TableCell>
                                      <TableCell>{step.stepName}</TableCell>
                                      <TableCell>{step.approverRole}</TableCell>
                                      <TableCell>{step.dueDays}</TableCell>
                                      <TableCell>
                                        {step.isRequired ? (
                                          <Badge variant="default">{t('required')}</Badge>
                                        ) : (
                                          <Badge variant="outline">{t('optional')}</Badge>
                                        )}
                                      </TableCell>
                                    </TableRow>
                                  ))
                                )}
                              </TableBody>
                            </Table>
                          </div>
                          
                          <div className="bg-muted/20 p-4 rounded-md">
                            <p className="text-sm">
                              {t('workflowNote')}
                            </p>
                          </div>
                        </>
                      ) : (
                        <div className="border rounded-md p-6 text-center">
                          <FileCheck className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                          <h3 className="text-lg font-medium mb-2">{t('workflowDisabled')}</h3>
                          <p className="text-muted-foreground text-sm mb-4">
                            {t('workflowDisabledDescription')}
                          </p>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setCertificateWorkflowSettings({
                              ...certificateWorkflowSettings,
                              enableWorkflow: true
                            })}
                          >
                            {t('enableWorkflow')}
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>{t('approvalWorkflow')}</CardTitle>
                  <CardDescription>{t('certificateApprovalProcess')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">{t('approvalStages')}</h3>
                    <p className="text-muted-foreground">
                      {t('approvalWorkflowDescription')}
                    </p>
                    
                    <div className="relative mt-6 pb-6">
                      {/* Vertical line */}
                      <div className="absolute left-[19px] top-1 h-full w-[2px] bg-border" />
                      
                      {/* Approval process stages */}
                      <div className="space-y-8">
                        {/* Stage 1: Draft */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-white">
                            <span className="font-bold">1</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold">{t('draft')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('draftDescription')}
                            </p>
                          </div>
                        </div>
                        
                        {/* Stage 2: Submission */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-primary bg-background">
                            <span className="font-bold text-primary">2</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold">{t('submitted')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('submittedDescription')}
                            </p>
                          </div>
                        </div>
                        
                        {/* Stage 3: Engineer Review */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-muted bg-background">
                            <span className="font-bold text-muted-foreground">3</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold text-muted-foreground">{t('supervisorApproved')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('supervisorApprovedDescription')}
                            </p>
                          </div>
                        </div>
                        
                        {/* Stage 4: Project Manager Review */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-muted bg-background">
                            <span className="font-bold text-muted-foreground">4</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold text-muted-foreground">{t('pmApproved')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('pmApprovedDescription')}
                            </p>
                          </div>
                        </div>
                        
                        {/* Stage 5: Finance Review */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-muted bg-background">
                            <span className="font-bold text-muted-foreground">5</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold text-muted-foreground">{t('financeApproved')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('financeApprovedDescription')}
                            </p>
                          </div>
                        </div>
                        
                        {/* Stage 6: GM Approval */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-muted bg-background">
                            <span className="font-bold text-muted-foreground">6</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold text-muted-foreground">{t('gmApproved')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('gmApprovedDescription')}
                            </p>
                          </div>
                        </div>
                        
                        {/* Stage 7: Final Approval */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-muted bg-background">
                            <span className="font-bold text-muted-foreground">7</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold text-muted-foreground">{t('approved')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('approvedDescription')}
                            </p>
                          </div>
                        </div>
                        
                        {/* Stage 8: Payment */}
                        <div className="flex gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-muted bg-background">
                            <span className="font-bold text-muted-foreground">8</span>
                          </div>
                          <div className="space-y-1">
                            <h4 className="font-semibold text-muted-foreground">{t('paid')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {t('paidDescription')}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="text-lg font-medium mb-2">{t('projectFinancialRelations')}</h3>
                      <Accordion type="single" collapsible className="border rounded-md">
                        <AccordionItem value="project-accounts">
                          <AccordionTrigger className="px-4">
                            {t('projectAccounts')}
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            <p className="text-sm text-muted-foreground mb-2">
                              {t('projectAccountsDescription')}
                            </p>
                            <div className="bg-muted/30 p-3 rounded-md">
                              {t('certificateProjectAccountsIntegration')}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="payment-tracking">
                          <AccordionTrigger className="px-4">
                            {t('paymentTracking')}
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            <p className="text-sm text-muted-foreground mb-2">
                              {t('paymentTrackingDescription')}
                            </p>
                            <div className="bg-muted/30 p-3 rounded-md">
                              {t('certificatePaymentTrackingIntegration')}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="financial-reporting">
                          <AccordionTrigger className="px-4">
                            {t('financialReporting')}
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            <p className="text-sm text-muted-foreground mb-2">
                              {t('financialReportingDescription')}
                            </p>
                            <div className="bg-muted/30 p-3 rounded-md">
                              {t('certificateFinancialReportingIntegration')}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="financialSummary" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t('financialSummary')}</CardTitle>
                  <CardDescription>{t('amountSummary')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-4">{t('certificateMainAmounts')}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <FormField
                          control={form.control}
                          name="grossAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('grossAmount')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    form.setValue('currentAmount', parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }} 
                                />
                              </FormControl>
                              <FormDescription>{t('grossAmountDescription')}</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div>
                        <FormField
                          control={form.control}
                          name="previousAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('previousAmount')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field} 
                                  value={field.value || 0}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                  }}
                                />
                              </FormControl>
                              <FormDescription>{t('previousAmountDescription')}</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                      <div>
                        <FormField
                          control={form.control}
                          name="currentAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('currentAmount')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }}
                                />
                              </FormControl>
                              <FormDescription>{t('currentAmountDescription')}</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div>
                        <FormField
                          control={form.control}
                          name="completionPercentage"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('completionPercentage')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  max="100" 
                                  {...field} 
                                  value={field.value || 0}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                  }}
                                />
                              </FormControl>
                              <FormDescription>{t('completionPercentageDescription')}</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-4">{t('deductionsAndAdditions')}</h3>
                    <p className="text-muted-foreground mb-4">{t('deductionsAdditionsDescription')}</p>
                    
                    <div>
                      <h4 className="text-md font-medium mb-2">{t('deductions')}</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="advancePaymentDeduction"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('advancePaymentDeduction')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0"
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="retentionAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('retentionAmount')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="taxAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('taxAmount')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="otherDeductions"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('otherDeductions')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-md font-medium mb-2">{t('additions')}</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="materialsOnSite"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('materialsOnSite')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="otherAdditions"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('otherAdditions')}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  min="0" 
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateFinalAmount();
                                  }} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-4">{t('finalSummary')}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 border rounded-md bg-red-50/50">
                        <div className="flex justify-between mb-2">
                          <div className="font-medium">{t('totalDeductions')}</div>
                          <div className="font-bold">
                            {
                              (
                                (form.getValues('advancePaymentDeduction') || 0) +
                                (form.getValues('retentionAmount') || 0) +
                                (form.getValues('taxAmount') || 0) +
                                (form.getValues('otherDeductions') || 0)
                              ).toFixed(2)
                            } SAR
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-4 border rounded-md bg-green-50/50">
                        <div className="flex justify-between mb-2">
                          <div className="font-medium">{t('totalAdditions')}</div>
                          <div className="font-bold">
                            {
                              (
                                (form.getValues('materialsOnSite') || 0) +
                                (form.getValues('otherAdditions') || 0)
                              ).toFixed(2)
                            } SAR
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <FormField
                        control={form.control}
                        name="finalAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('finalAmount')}</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01" 
                                min="0" 
                                {...field} 
                                readOnly
                                className="bg-primary/5 font-bold"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex justify-end mt-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => calculateFinalAmount()}
                      >
                        <RefreshCcw className="h-4 w-4 mr-2" />
                        {t('recalculate')}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="preview" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t('certificatePreview')}</CardTitle>
                  <CardDescription>{t('reviewBeforeSubmit')}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-card p-6 border rounded-md">
                    <div className="text-center mb-6">
                      <h2 className="text-2xl font-bold">{t('paymentCertificate')}</h2>
                      <p>{t('certificateDate')}: {new Date().toLocaleDateString()}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">{t('projectDetails')}</h3>
                        <div className="space-y-2">
                          <div className="flex">
                            <span className="font-medium w-40">{t('project')}:</span>
                            <span>{
                              projects.find(p => p.id === form.getValues('projectId'))?.name || t('none')
                            }</span>
                          </div>
                          <div className="flex">
                            <span className="font-medium w-40">{t('contractorName')}:</span>
                            <span>{form.getValues('contractorName') || t('none')}</span>
                          </div>
                          <div className="flex">
                            <span className="font-medium w-40">{t('contractNumber')}:</span>
                            <span>{form.getValues('contractNumber') || t('none')}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-semibold mb-2">{t('certificateDetails')}</h3>
                        <div className="space-y-2">
                          <div className="flex">
                            <span className="font-medium w-40">{t('certificateType')}:</span>
                            <span>{t(form.getValues('type'))}</span>
                          </div>
                          <div className="flex">
                            <span className="font-medium w-40">{t('periodFrom')}:</span>
                            <span>{form.getValues('fromDate')}</span>
                          </div>
                          <div className="flex">
                            <span className="font-medium w-40">{t('periodTo')}:</span>
                            <span>{form.getValues('toDate')}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-2">{t('workItems')}</h3>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>#</TableHead>
                              <TableHead>{t('description')}</TableHead>
                              <TableHead>{t('unit')}</TableHead>
                              <TableHead>{t('currentQuantity')}</TableHead>
                              <TableHead>{t('unitPrice')}</TableHead>
                              <TableHead>{t('amount')}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {fields.map((field, index) => (
                              <TableRow key={field.id}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell>{form.getValues(`items.${index}.description`)}</TableCell>
                                <TableCell>{form.getValues(`items.${index}.unit`)}</TableCell>
                                <TableCell>{form.getValues(`items.${index}.currentQuantity`)}</TableCell>
                                <TableCell>{form.getValues(`items.${index}.unitPrice`)}</TableCell>
                                <TableCell>{form.getValues(`items.${index}.amount`)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                      
                      {fields.length === 0 && (
                        <div className="text-center py-4 border rounded-md">
                          <p className="text-muted-foreground">{t('noCertificateItems')}</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">{t('mainAmounts')}</h3>
                        <div className="space-y-2 p-4 border rounded-md">
                          <div className="flex justify-between">
                            <span className="font-medium">{t('grossAmount')}:</span>
                            <span>{form.getValues('grossAmount') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('previousAmount')}:</span>
                            <span>{form.getValues('previousAmount') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('currentAmount')}:</span>
                            <span>{form.getValues('currentAmount') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('completionPercentage')}:</span>
                            <span>{form.getValues('completionPercentage') || 0}%</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-semibold mb-2">{t('deductionsAndAdditions')}</h3>
                        <div className="space-y-2 p-4 border rounded-md">
                          <div className="flex justify-between">
                            <span className="font-medium">{t('advancePaymentDeduction')}:</span>
                            <span>{form.getValues('advancePaymentDeduction') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('retentionAmount')}:</span>
                            <span>{form.getValues('retentionAmount') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('taxAmount')}:</span>
                            <span>{form.getValues('taxAmount') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('otherDeductions')}:</span>
                            <span>{form.getValues('otherDeductions') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('materialsOnSite')}:</span>
                            <span>{form.getValues('materialsOnSite') || 0} SAR</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">{t('otherAdditions')}:</span>
                            <span>{form.getValues('otherAdditions') || 0} SAR</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6 p-4 border rounded-md bg-primary/5">
                      <div className="flex justify-between">
                        <span className="font-bold text-lg">{t('finalAmount')}:</span>
                        <span className="font-bold text-lg">{form.getValues('finalAmount') || 0} SAR</span>
                      </div>
                    </div>
                    
                    {form.getValues('notes') && (
                      <div className="mt-6">
                        <h3 className="text-lg font-semibold mb-2">{t('notes')}</h3>
                        <div className="p-4 border rounded-md">
                          {form.getValues('notes')}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          <div className="flex justify-between pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate('/financial/certificates')}
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              {t('cancel')}
            </Button>
            
            <div className="space-x-2">
              <Button 
                type="submit" 
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <span className="animate-spin mr-2">◌</span>
                    {t('saving')}
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    {t('saveCertificate')}
                  </>
                )}
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}