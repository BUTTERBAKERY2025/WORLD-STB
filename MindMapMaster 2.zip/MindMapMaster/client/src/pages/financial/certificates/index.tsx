import { useState, useEffect } from 'react';
import { Link, useRoute } from 'wouter';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  ChevronDownIcon, FileTextIcon, PlusIcon, CheckCircle2Icon, XCircleIcon, BanknoteIcon, 
  CalendarIcon, ClipboardIcon, TableIcon, LayoutGridIcon, FilterIcon, BarChart4Icon, SearchIcon
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { paymentCertificateStatusMap, paymentCertificateTypeMap } from '@shared/schema';
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";

const formatDate = (dateString: string) => {
  if (!dateString) return '-';
  return new Date(dateString).toLocaleDateString('ar-SA');
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'SAR',
    minimumFractionDigits: 2
  }).format(amount);
};

const CertificateStatus = ({ status }: { status: string }) => {
  let color = "bg-gray-200 text-gray-800";
  
  switch(status) {
    case 'draft':
      color = "bg-gray-200 text-gray-800";
      break;
    case 'submitted':
      color = "bg-blue-200 text-blue-800";
      break;
    case 'supervisor_approved':
    case 'pm_approved':
    case 'finance_approved':
    case 'gm_approved':
      color = "bg-amber-200 text-amber-800";
      break;
    case 'approved':
      color = "bg-green-200 text-green-800";
      break;
    case 'paid':
      color = "bg-emerald-200 text-emerald-800";
      break;
    case 'rejected':
      color = "bg-red-200 text-red-800";
      break;
  }
  
  // تأكد من وجود الحالة في خريطة الحالات وإلا استخدم الحالة كما هي
  const statusLabelObj = status && typeof status === 'string' && 
    paymentCertificateStatusMap[status as keyof typeof paymentCertificateStatusMap];
  
  const statusLabel = statusLabelObj ? statusLabelObj.ar : status;
  
  return (
    <Badge variant="outline" className={`${color} border-0`}>
      {statusLabel}
    </Badge>
  );
};

const CertificatesPage = () => {
  const [, params] = useRoute('/financial/certificates');
  const { t } = useTranslation();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [certificates, setCertificates] = useState<any[]>([]);
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [searchTerm, setSearchTerm] = useState('');
  const [stats, setStats] = useState<any>({
    totalCertificates: 0,
    totalPaid: 0,
    totalAmount: 0,
    paidAmount: 0,
    certificatesByType: {},
    certificatesByStatus: {}
  });
  const [filter, setFilter] = useState({
    type: '',
    status: ''
  });
  
  const loadCertificates = async () => {
    setLoading(true);
    try {
      // بناء استعلام API مع الفلاتر المحددة
      let url = '/api/certificates';
      const params = [];
      if (filter.type) params.push(`type=${filter.type}`);
      if (filter.status) params.push(`status=${filter.status}`);
      if (params.length > 0) {
        url += `?${params.join('&')}`;
      }
      
      const response = await apiRequest('GET', url);
      const data = await response.json();
      setCertificates(data);
      
      // تحميل الإحصائيات
      const statsResponse = await apiRequest('GET', '/api/certificates/stats');
      const statsData = await statsResponse.json();
      setStats(statsData);
    } catch (error) {
      console.error('Error loading certificates:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToLoadCertificates'),
      });
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    loadCertificates();
  }, [filter]);

  // تصفية المستخلصات بناءً على مصطلح البحث
  const filteredCertificates = certificates.filter(certificate => {
    if (!searchTerm) return true;
    
    const searchLower = searchTerm.toLowerCase();
    
    return (
      (certificate.certificateNumber && String(certificate.certificateNumber).toLowerCase().includes(searchLower)) ||
      (certificate.projectName && certificate.projectName.toLowerCase().includes(searchLower)) ||
      (certificate.contractorName && certificate.contractorName.toLowerCase().includes(searchLower)) ||
      (certificate.contractNumber && certificate.contractNumber.toLowerCase().includes(searchLower)) ||
      (certificate.type && paymentCertificateTypeMap[certificate.type as keyof typeof paymentCertificateTypeMap]?.ar.toLowerCase().includes(searchLower))
    );
  });
  
  const handleSubmitCertificate = async (id: number) => {
    try {
      const response = await apiRequest('POST', `/api/certificates/${id}/submit`);
      if (response.ok) {
        toast({
          title: t('success'),
          description: t('certificateSubmittedSuccessfully'),
        });
        loadCertificates();
      } else {
        throw new Error('Failed to submit certificate');
      }
    } catch (error) {
      console.error('Error submitting certificate:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToSubmitCertificate'),
      });
    }
  };
  
  const handleMarkAsPaid = async (id: number) => {
    try {
      const response = await apiRequest('POST', `/api/certificates/${id}/mark-paid`);
      if (response.ok) {
        toast({
          title: t('success'),
          description: t('certificateMarkedAsPaid'),
        });
        loadCertificates();
      } else {
        throw new Error('Failed to mark certificate as paid');
      }
    } catch (error) {
      console.error('Error marking certificate as paid:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToMarkCertificateAsPaid'),
      });
    }
  };
  
  const renderEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-12">
      <FileTextIcon className="h-12 w-12 text-muted-foreground mb-3" />
      <h3 className="text-lg font-medium">{t('noCertificatesFound')}</h3>
      <p className="text-sm text-muted-foreground mb-4">{t('noCertificatesDescription')}</p>
      <Link href="/financial/certificates/new">
        <Button>
          <PlusIcon className="h-4 w-4 mr-2" />
          {t('createYourFirstCertificate')}
        </Button>
      </Link>
    </div>
  );

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{t('paymentCertificates')}</h1>
        <Link href="/financial/certificates/new">
          <Button>
            <PlusIcon className="h-4 w-4 mr-2" />
            {t('newCertificate')}
          </Button>
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-sm font-medium">{t('totalCertificates')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalCertificates}</div>
            <p className="text-xs text-muted-foreground">{t('certificatesCount')}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-sm font-medium">{t('totalAmount')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalAmount)}</div>
            <p className="text-xs text-muted-foreground">{t('totalValue')}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-sm font-medium">{t('paidCertificates')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalPaid}</div>
            <p className="text-xs text-muted-foreground">{t('paidCount')}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-sm font-medium">{t('paidAmount')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.paidAmount)}</div>
            <p className="text-xs text-muted-foreground">{t('paidValue')}</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 mb-4">
        {/* أدوات البحث والفلترة والعرض */}
        <div className="flex flex-col sm:flex-row gap-4 w-full">
          {/* البحث */}
          <div className="flex-1">
            <div className="relative">
              <Input
                placeholder={t('searchCertificates')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10"
              />
              <SearchIcon className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          </div>
          
          {/* الفلترة حسب النوع */}
          <div className="w-full sm:w-1/3 md:w-1/4">
            <Select
              value={filter.type}
              onValueChange={(value) => setFilter({ ...filter, type: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder={t('filterByType')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allTypes')}</SelectItem>
                <SelectItem value="subcontractor">{t('subcontractor')}</SelectItem>
                <SelectItem value="main_contractor">{t('mainContractor')}</SelectItem>
                <SelectItem value="consultant">{t('consultant')}</SelectItem>
                <SelectItem value="internal">{t('internal')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* الفلترة حسب الحالة */}
          <div className="w-full sm:w-1/3 md:w-1/4">
            <Select
              value={filter.status}
              onValueChange={(value) => setFilter({ ...filter, status: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder={t('filterByStatus')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allStatuses')}</SelectItem>
                <SelectItem value="draft">{t('draft')}</SelectItem>
                <SelectItem value="submitted">{t('submitted')}</SelectItem>
                <SelectItem value="approved">{t('approved')}</SelectItem>
                <SelectItem value="paid">{t('paid')}</SelectItem>
                <SelectItem value="rejected">{t('rejected')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* أنماط العرض */}
          <div className="flex items-center">
            <Tabs 
              value={viewMode} 
              onValueChange={(value) => setViewMode(value as 'table' | 'cards')}
              className="w-[200px]"
            >
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="table">
                  <TableIcon className="h-4 w-4 mr-2" />
                  {t('view.table')}
                </TabsTrigger>
                <TabsTrigger value="cards">
                  <LayoutGridIcon className="h-4 w-4 mr-2" />
                  {t('view.cards')}
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      </div>
      
      {/* عرض المحتوى حسب النمط المحدد */}
      {viewMode === 'table' ? (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('id')}</TableHead>
                  <TableHead>{t('type')}</TableHead>
                  <TableHead>{t('project')}</TableHead>
                  <TableHead>{t('amount')}</TableHead>
                  <TableHead>{t('periodFrom')}</TableHead>
                  <TableHead>{t('periodTo')}</TableHead>
                  <TableHead>{t('status')}</TableHead>
                  <TableHead>{t('actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  // حالة التحميل - عرض صفوف وهمية
                  Array(5).fill(0).map((_, idx) => (
                    <TableRow key={idx}>
                      {Array(8).fill(0).map((_, cellIdx) => (
                        <TableCell key={cellIdx}>
                          <Skeleton className="h-6 w-full" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : filteredCertificates.length === 0 ? (
                  // لا توجد مستخلصات
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      {renderEmptyState()}
                    </TableCell>
                  </TableRow>
                ) : (
                  // عرض المستخلصات
                  filteredCertificates.map((certificate) => (
                    <TableRow key={certificate.id}>
                      <TableCell>
                        <Link href={`/financial/certificates/${certificate.id}`}>
                          <span className="font-medium hover:underline cursor-pointer">
                            {certificate.certificateNumber || certificate.id}
                          </span>
                        </Link>
                      </TableCell>
                      <TableCell>
                        {certificate.type && typeof certificate.type === 'string' && 
                          paymentCertificateTypeMap[certificate.type as keyof typeof paymentCertificateTypeMap] 
                          ? paymentCertificateTypeMap[certificate.type as keyof typeof paymentCertificateTypeMap].ar 
                          : certificate.type}
                      </TableCell>
                      <TableCell>
                        <Link href={`/projects/${certificate.projectId}`}>
                          <span className="hover:underline cursor-pointer">
                            {certificate.projectName || `مشروع #${certificate.projectId}`}
                          </span>
                        </Link>
                      </TableCell>
                      <TableCell>{formatCurrency(certificate.totalAmount)}</TableCell>
                      <TableCell>{formatDate(certificate.periodFrom)}</TableCell>
                      <TableCell>{formatDate(certificate.periodTo)}</TableCell>
                      <TableCell>
                        <CertificateStatus status={certificate.status} />
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <span className="sr-only">{t('openMenu')}</span>
                              <ChevronDownIcon className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>{t('actions')}</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            
                            <Link href={`/financial/certificates/${certificate.id}`}>
                              <DropdownMenuItem>
                                <FileTextIcon className="h-4 w-4 mr-2" />
                                {t('view')}
                              </DropdownMenuItem>
                            </Link>
                            
                            <Link href={`/financial/certificates/${certificate.id}/edit`}>
                              <DropdownMenuItem>
                                <FileTextIcon className="h-4 w-4 mr-2" />
                                {t('edit')}
                              </DropdownMenuItem>
                            </Link>
                            
                            {certificate.status === 'draft' && (
                              <DropdownMenuItem onClick={() => handleSubmitCertificate(certificate.id)}>
                                <CheckCircle2Icon className="h-4 w-4 mr-2" />
                                {t('submit')}
                              </DropdownMenuItem>
                            )}
                            
                            {certificate.status === 'approved' && (
                              <DropdownMenuItem onClick={() => handleMarkAsPaid(certificate.id)}>
                                <BanknoteIcon className="h-4 w-4 mr-2" />
                                {t('markAsPaid')}
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        /* عرض البطاقات */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            // حالة التحميل - عرض بطاقات وهمية
            Array(6).fill(0).map((_, idx) => (
              <Card key={idx} className="overflow-hidden">
                <CardHeader className="p-4 pb-2">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <Skeleton className="h-20 w-full mb-2" />
                  <div className="flex justify-between mb-2">
                    <Skeleton className="h-4 w-1/3" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                  <Skeleton className="h-8 w-1/2" />
                </CardContent>
              </Card>
            ))
          ) : filteredCertificates.length === 0 ? (
            // لا توجد مستخلصات
            <div className="col-span-full flex flex-col items-center justify-center p-12 bg-gray-50 rounded-md">
              {renderEmptyState()}
            </div>
          ) : (
            // عرض المستخلصات في بطاقات
            filteredCertificates.map((certificate) => (
              <Card key={certificate.id} className="overflow-hidden">
                <CardHeader className="p-4 pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">
                      <Link href={`/financial/certificates/${certificate.id}`}>
                        <span className="font-medium hover:underline cursor-pointer">
                          {certificate.certificateNumber || `مستخلص #${certificate.id}`}
                        </span>
                      </Link>
                    </CardTitle>
                    <CertificateStatus status={certificate.status} />
                  </div>
                  <CardDescription>
                    {certificate.type && typeof certificate.type === 'string' && 
                      paymentCertificateTypeMap[certificate.type as keyof typeof paymentCertificateTypeMap] 
                      ? paymentCertificateTypeMap[certificate.type as keyof typeof paymentCertificateTypeMap].ar 
                      : certificate.type}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <div className="mb-3">
                    <Link href={`/projects/${certificate.projectId}`}>
                      <span className="text-sm font-medium hover:underline cursor-pointer">
                        {certificate.projectName || `مشروع #${certificate.projectId}`}
                      </span>
                    </Link>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                    <div>
                      <span className="text-muted-foreground">{t('periodFrom')}:</span> 
                      <span className="block font-medium">{formatDate(certificate.periodFrom)}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">{t('periodTo')}:</span> 
                      <span className="block font-medium">{formatDate(certificate.periodTo)}</span>
                    </div>
                  </div>
                  <div className="text-lg font-bold mt-2">
                    {formatCurrency(certificate.totalAmount)}
                  </div>
                </CardContent>
                <CardFooter className="p-4 pt-0 flex justify-between">
                  <Link href={`/financial/certificates/${certificate.id}`}>
                    <Button variant="outline" size="sm">
                      <FileTextIcon className="h-4 w-4 mr-2" />
                      {t('view')}
                    </Button>
                  </Link>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <ChevronDownIcon className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <Link href={`/financial/certificates/${certificate.id}/edit`}>
                        <DropdownMenuItem>
                          <FileTextIcon className="h-4 w-4 mr-2" />
                          {t('edit')}
                        </DropdownMenuItem>
                      </Link>
                      
                      {certificate.status === 'draft' && (
                        <DropdownMenuItem onClick={() => handleSubmitCertificate(certificate.id)}>
                          <CheckCircle2Icon className="h-4 w-4 mr-2" />
                          {t('submit')}
                        </DropdownMenuItem>
                      )}
                      
                      {certificate.status === 'approved' && (
                        <DropdownMenuItem onClick={() => handleMarkAsPaid(certificate.id)}>
                          <BanknoteIcon className="h-4 w-4 mr-2" />
                          {t('markAsPaid')}
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardFooter>
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default CertificatesPage;