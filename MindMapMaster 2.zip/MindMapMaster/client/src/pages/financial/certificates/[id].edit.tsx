import { useState, useEffect } from 'react';
import { Link, useRoute, useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import { z } from 'zod';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ChevronLeft, Plus, Trash } from 'lucide-react';
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from '@/lib/queryClient';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from "@/hooks/use-toast";
import { insertPaymentCertificateSchema } from '@shared/schema';

const EditCertificatePage = () => {
  const [match, params] = useRoute('/financial/certificates/:id/edit');
  const [, setLocation] = useLocation();
  const { t } = useTranslation();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [certificate, setCertificate] = useState<any>(null);
  const [certificateItems, setCertificateItems] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [contractItems, setContractItems] = useState<any[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  
  const certificateId = params?.id ? parseInt(params.id) : 0;
  
  // مخطط Zod لنموذج المستخلص
  const formSchema = z.object({
    projectId: z.number().min(1, t('projectIsRequired')),
    title: z.string().min(1, t('titleIsRequired')),
    certificateNumber: z.string().optional(),
    type: z.enum(['subcontractor', 'main_contractor', 'consultant', 'internal']),
    description: z.string().optional(),
    periodFrom: z.string().min(1, t('periodFromIsRequired')),
    periodTo: z.string().min(1, t('periodToIsRequired')),
    totalAmount: z.number().min(0, t('amountMustBePositive')),
    items: z.array(z.object({
      id: z.number().optional(),
      description: z.string().min(1, t('descriptionIsRequired')),
      contractItemId: z.number().optional().nullable(),
      unit: z.string().min(1, t('unitIsRequired')),
      quantity: z.number().min(0, t('quantityMustBePositive')),
      unitPrice: z.number().min(0, t('unitPriceMustBePositive')),
      amount: z.number().min(0, t('amountMustBePositive')),
    }))
  });
  
  // تعريف نوع بيانات النموذج
  type FormData = z.infer<typeof formSchema>;
  
  // إعداد نموذج React Hook Form
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectId: 0,
      title: '',
      certificateNumber: '',
      type: 'main_contractor',
      description: '',
      periodFrom: new Date().toISOString().slice(0, 10),
      periodTo: new Date().toISOString().slice(0, 10),
      totalAmount: 0,
      items: [{
        description: '',
        contractItemId: null,
        unit: '',
        quantity: 0,
        unitPrice: 0,
        amount: 0
      }]
    }
  });
  
  // إعداد FieldArray للعناصر
  const { fields, append, remove, replace } = useFieldArray({
    control: form.control,
    name: "items"
  });
  
  // تحميل المستخلص والمشاريع
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // تحميل المشاريع
        const projectsResponse = await apiRequest('GET', '/api/projects');
        const projectsData = await projectsResponse.json();
        setProjects(projectsData);
        
        if (!certificateId) {
          setLoading(false);
          return;
        }
        
        // تحميل بيانات المستخلص
        const certificateResponse = await apiRequest('GET', `/api/certificates/${certificateId}`);
        if (!certificateResponse.ok) {
          throw new Error('Failed to load certificate');
        }
        
        const certificateData = await certificateResponse.json();
        setCertificate(certificateData);
        setSelectedProjectId(certificateData.projectId);
        
        // تحميل عناصر المستخلص
        const itemsResponse = await apiRequest('GET', `/api/certificates/${certificateId}/items`);
        if (!itemsResponse.ok) {
          throw new Error('Failed to load certificate items');
        }
        
        const itemsData = await itemsResponse.json();
        setCertificateItems(itemsData);
        
        // تحميل بنود العقد للمشروع
        if (certificateData.projectId) {
          const contractItemsResponse = await apiRequest('GET', `/api/projects/${certificateData.projectId}/contract-items`);
          const contractItemsData = await contractItemsResponse.json();
          setContractItems(contractItemsData);
        }
        
        // تعبئة النموذج بالبيانات الحالية
        form.reset({
          projectId: certificateData.projectId,
          title: certificateData.title || '',
          certificateNumber: certificateData.certificateNumber || '',
          type: certificateData.type,
          description: certificateData.description || '',
          periodFrom: certificateData.periodFrom ? new Date(certificateData.periodFrom).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
          periodTo: certificateData.periodTo ? new Date(certificateData.periodTo).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
          totalAmount: certificateData.totalAmount || 0,
          items: itemsData.length > 0 ? itemsData.map((item: any) => ({
            id: item.id,
            description: item.description || '',
            contractItemId: item.contractItemId,
            unit: item.unit || '',
            quantity: item.quantity || 0,
            unitPrice: item.unitPrice || 0,
            amount: item.amount || 0
          })) : [{
            description: '',
            contractItemId: null,
            unit: '',
            quantity: 0,
            unitPrice: 0,
            amount: 0
          }]
        });
      } catch (error) {
        console.error('Error loading certificate:', error);
        toast({
          variant: "destructive",
          title: t('error'),
          description: t('failedToLoadCertificate'),
        });
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, [certificateId]);
  
  // تحميل بنود العقد عند تغيير المشروع المحدد
  useEffect(() => {
    const loadContractItems = async () => {
      if (!selectedProjectId) return;
      
      try {
        const response = await apiRequest('GET', `/api/projects/${selectedProjectId}/contract-items`);
        const data = await response.json();
        setContractItems(data);
      } catch (error) {
        console.error('Error loading contract items:', error);
        toast({
          variant: "destructive",
          title: t('error'),
          description: t('failedToLoadContractItems'),
        });
      }
    };
    
    if (selectedProjectId && selectedProjectId !== certificate?.projectId) {
      loadContractItems();
    }
  }, [selectedProjectId]);
  
  // تغيير المشروع المحدد
  const handleProjectChange = (projectId: string) => {
    const newProjectId = Number(projectId);
    setSelectedProjectId(newProjectId);
    form.setValue('projectId', newProjectId);
    
    // إذا تم تغيير المشروع، يجب إعادة تعيين بنود العقد
    if (certificate && newProjectId !== certificate.projectId) {
      // إعادة تعيين عناصر المستخلص في حالة تغيير المشروع
      replace([{
        description: '',
        contractItemId: null,
        unit: '',
        quantity: 0,
        unitPrice: 0,
        amount: 0
      }]);
    }
  };
  
  // حساب المبلغ لعنصر
  const calculateItemAmount = (index: number) => {
    const quantity = form.getValues(`items.${index}.quantity`);
    const unitPrice = form.getValues(`items.${index}.unitPrice`);
    const amount = quantity * unitPrice;
    form.setValue(`items.${index}.amount`, amount);
    
    // تحديث المبلغ الإجمالي للمستخلص
    const totalAmount = form.getValues('items').reduce((sum, item) => sum + (item.amount || 0), 0);
    form.setValue('totalAmount', totalAmount);
  };
  
  // إضافة عنصر جديد
  const addItem = () => {
    append({
      description: '',
      contractItemId: null,
      unit: '',
      quantity: 0,
      unitPrice: 0,
      amount: 0
    });
  };
  
  // إرسال النموذج
  const onSubmit = async (data: FormData) => {
    setSubmitting(true);
    try {
      // تحديث بيانات المستخلص
      const certificateResponse = await apiRequest('PATCH', `/api/certificates/${certificateId}`, {
        projectId: data.projectId,
        title: data.title,
        certificateNumber: data.certificateNumber,
        type: data.type,
        description: data.description,
        periodFrom: data.periodFrom,
        periodTo: data.periodTo,
        totalAmount: data.totalAmount
      });
      
      if (!certificateResponse.ok) {
        throw new Error('Failed to update certificate');
      }
      
      // مسح العناصر الحالية واستبدالها بالعناصر الجديدة
      for (const item of certificateItems) {
        // تجاهل العناصر التي ما زالت موجودة في النموذج
        const stillExists = data.items.some(formItem => formItem.id === item.id);
        if (!stillExists) {
          const deleteResponse = await apiRequest('DELETE', `/api/certificate-items/${item.id}`);
          if (!deleteResponse.ok) {
            console.error(`Failed to delete item ${item.id}`);
          }
        }
      }
      
      // تحديث/إنشاء العناصر من النموذج
      for (const item of data.items) {
        if (item.id) {
          // تحديث عنصر موجود
          const updateResponse = await apiRequest('PATCH', `/api/certificate-items/${item.id}`, {
            description: item.description,
            contractItemId: item.contractItemId,
            unit: item.unit,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            amount: item.amount
          });
          
          if (!updateResponse.ok) {
            console.error(`Failed to update item ${item.id}`);
          }
        } else {
          // إنشاء عنصر جديد
          const createResponse = await apiRequest('POST', '/api/certificate-items', {
            certificateId,
            description: item.description,
            contractItemId: item.contractItemId,
            unit: item.unit,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            amount: item.amount
          });
          
          if (!createResponse.ok) {
            console.error('Failed to create new item');
          }
        }
      }
      
      toast({
        title: t('success'),
        description: t('certificateUpdatedSuccessfully'),
      });
      
      // الانتقال إلى صفحة تفاصيل المستخلص
      setLocation(`/financial/certificates/${certificateId}`);
    } catch (error) {
      console.error('Error updating certificate:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToUpdateCertificate'),
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  if (loading) {
    return (
      <div className="container mx-auto p-4">
        <div className="space-y-6">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-80 w-full" />
        </div>
      </div>
    );
  }
  
  // تحديد بنود العقد المتوفرة للاختيار
  const availableContractItems = (itemIndex: number) => {
    const currentItemId = form.getValues(`items.${itemIndex}.id`);
    
    return contractItems.filter(contractItem => {
      // تحقق ما إذا كان بند العقد مستخدم في عنصر آخر
      const isUsedInOtherItem = form.getValues('items').some((formItem, idx) => 
        idx !== itemIndex && 
        formItem.contractItemId === contractItem.id
      );
      
      // السماح باستخدام بند العقد إذا:
      // 1. لم يتم استخدامه في عنصر آخر، أو
      // 2. تم استخدامه في العنصر الحالي
      return !isUsedInOtherItem || form.getValues(`items.${itemIndex}.contractItemId`) === contractItem.id;
    });
  };
  
  return (
    <div className="container mx-auto p-4">
      <Breadcrumb className="mb-4">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">{t('home')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/financial">{t('financial')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/financial/certificates">{t('certificates')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href={`/financial/certificates/${certificateId}`}>
              {certificate?.title || `${t('certificate')} #${certificateId}`}
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink>{t('edit')}</BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
      
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{t('editCertificate')}</h1>
        <Link href={`/financial/certificates/${certificateId}`}>
          <Button variant="outline">
            <ChevronLeft className="h-4 w-4 mr-2" />
            {t('back')}
          </Button>
        </Link>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('certificateDetails')}</CardTitle>
              <CardDescription>{t('editCertificateDetails')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="projectId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('project')} <span className="text-destructive">*</span></FormLabel>
                      <Select 
                        onValueChange={handleProjectChange} 
                        value={String(field.value)}
                        disabled={certificate && certificate.status !== 'draft'}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t('selectProject')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {projects.map((project) => (
                            <SelectItem key={project.id} value={String(project.id)}>
                              {project.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('certificateType')} <span className="text-destructive">*</span></FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        value={field.value}
                        disabled={certificate && certificate.status !== 'draft'}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t('selectCertificateType')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="subcontractor">{t('subcontractor')}</SelectItem>
                          <SelectItem value="main_contractor">{t('mainContractor')}</SelectItem>
                          <SelectItem value="consultant">{t('consultant')}</SelectItem>
                          <SelectItem value="internal">{t('internal')}</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('title')} <span className="text-destructive">*</span></FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="certificateNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('certificateNumber')}</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>
                        {t('certificateNumberDescription')}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="periodFrom"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('periodFrom')} <span className="text-destructive">*</span></FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="periodTo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('periodTo')} <span className="text-destructive">*</span></FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('description')}</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={3} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>{t('certificateItems')}</CardTitle>
              <CardDescription>{t('editCertificateItems')}</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead style={{ width: '40%' }}>{t('description')} <span className="text-destructive">*</span></TableHead>
                    <TableHead style={{ width: '15%' }}>{t('contractItem')}</TableHead>
                    <TableHead style={{ width: '10%' }}>{t('unit')} <span className="text-destructive">*</span></TableHead>
                    <TableHead style={{ width: '10%' }}>{t('quantity')} <span className="text-destructive">*</span></TableHead>
                    <TableHead style={{ width: '10%' }}>{t('unitPrice')} <span className="text-destructive">*</span></TableHead>
                    <TableHead style={{ width: '10%' }}>{t('amount')}</TableHead>
                    <TableHead style={{ width: '5%' }}></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fields.map((field, index) => (
                    <TableRow key={field.id} className="align-top">
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.description`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.contractItemId`}
                          render={({ field }) => (
                            <FormItem>
                              <Select 
                                onValueChange={(value) => field.onChange(value ? Number(value) : null)} 
                                value={field.value ? String(field.value) : ""}
                                disabled={!selectedProjectId}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder={t('selectItem')} />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="null">{t('none')}</SelectItem>
                                  {availableContractItems(index).map((item) => (
                                    <SelectItem key={item.id} value={String(item.id)}>
                                      {item.description || `بند #${item.id}`}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.unit`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.quantity`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01"
                                  min="0"
                                  {...field} 
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateItemAmount(index);
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.unitPrice`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01"
                                  min="0"
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    calculateItemAmount(index);
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.amount`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01"
                                  readOnly 
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        {fields.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => remove(index)}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              <div className="mt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={addItem}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  {t('addItem')}
                </Button>
              </div>
              
              <div className="mt-6 flex justify-end">
                <div className="w-1/3">
                  <FormField
                    control={form.control}
                    name="totalAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('totalAmount')}</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.01"
                            readOnly 
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Link href={`/financial/certificates/${certificateId}`}>
                <Button variant="outline" type="button">
                  {t('cancel')}
                </Button>
              </Link>
              <Button type="submit" disabled={submitting}>
                {submitting ? t('saving') : t('updateCertificate')}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>
    </div>
  );
};

export default EditCertificatePage;