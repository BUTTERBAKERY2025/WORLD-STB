import { useState, useEffect } from 'react';
import { Link, useRoute, useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { 
  ChevronLeft, 
  FileTextIcon, 
  PencilIcon, 
  CheckCircle2Icon, 
  XCircleIcon, 
  TrashIcon, 
  Clock,
  CalendarIcon,
  BuildingIcon,
  User2Icon,
  ChevronsUpDownIcon,
  ArrowDownIcon,
  ArrowUpIcon,
  Eye as EyeIcon,
  CheckIcon,
  BanknoteIcon
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { 
  paymentCertificateStatusMap, 
  paymentCertificateTypeMap 
} from '@shared/schema';
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from "@/components/ui/textarea";

const formatDate = (dateString: string) => {
  if (!dateString) return '-';
  return new Date(dateString).toLocaleDateString('ar-SA');
};

const formatDateTime = (dateString: string) => {
  if (!dateString) return '-';
  return new Date(dateString).toLocaleString('ar-SA');
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'SAR',
    minimumFractionDigits: 2
  }).format(amount);
};

const formatPercentage = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'percent',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value / 100);
};

const CertificateStatus = ({ status }: { status: string }) => {
  let color = "bg-gray-200 text-gray-800";
  
  switch(status) {
    case 'draft':
      color = "bg-gray-200 text-gray-800";
      break;
    case 'submitted':
      color = "bg-blue-200 text-blue-800";
      break;
    case 'supervisor_approved':
    case 'pm_approved':
    case 'finance_approved':
    case 'gm_approved':
      color = "bg-amber-200 text-amber-800";
      break;
    case 'approved':
      color = "bg-green-200 text-green-800";
      break;
    case 'paid':
      color = "bg-emerald-200 text-emerald-800";
      break;
    case 'rejected':
      color = "bg-red-200 text-red-800";
      break;
  }
  
  const statusLabel = paymentCertificateStatusMap[status] || status;
  
  return (
    <Badge variant="outline" className={`${color} border-0`}>
      {statusLabel}
    </Badge>
  );
};

const CertificateDetailPage = () => {
  const [match, params] = useRoute('/financial/certificates/:id');
  const [location, setLocation] = useLocation();
  const { t } = useTranslation();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [certificate, setCertificate] = useState<any>(null);
  const [certificateItems, setCertificateItems] = useState<any[]>([]);
  const [approvals, setApprovals] = useState<any[]>([]);
  const [journalEntries, setJournalEntries] = useState<any[]>([]);
  const [project, setProject] = useState<any>(null);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [approvalComment, setApprovalComment] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [actionPending, setActionPending] = useState(false);
  
  const certificateId = params?.id ? parseInt(params.id) : 0;
  
  const loadCertificate = async () => {
    setLoading(true);
    try {
      // تحميل بيانات المستخلص
      const response = await apiRequest('GET', `/api/certificates/${certificateId}`);
      const data = await response.json();
      setCertificate(data);
      
      // تحميل بيانات المشروع
      if (data.projectId) {
        const projectResponse = await apiRequest('GET', `/api/projects/${data.projectId}`);
        const projectData = await projectResponse.json();
        setProject(projectData);
      }
      
      // تحميل عناصر المستخلص
      const itemsResponse = await apiRequest('GET', `/api/certificates/${certificateId}/items`);
      const itemsData = await itemsResponse.json();
      setCertificateItems(itemsData);
      
      // تحميل سجلات الموافقة
      const approvalsResponse = await apiRequest('GET', `/api/certificates/${certificateId}/approvals`);
      const approvalsData = await approvalsResponse.json();
      setApprovals(approvalsData);
      
      // تحميل القيود المحاسبية المرتبطة بالمستخلص
      const journalEntriesResponse = await apiRequest('GET', `/api/journal-entries?certificateId=${certificateId}`);
      const journalEntriesData = await journalEntriesResponse.json();
      setJournalEntries(journalEntriesData);
      
    } catch (error) {
      console.error('Error loading certificate:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToLoadCertificate'),
      });
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    if (certificateId) {
      loadCertificate();
    }
  }, [certificateId]);
  
  const handleSubmitCertificate = async () => {
    setActionPending(true);
    try {
      const response = await apiRequest('POST', `/api/certificates/${certificateId}/submit`);
      if (response.ok) {
        toast({
          title: t('success'),
          description: t('certificateSubmittedSuccessfully'),
        });
        loadCertificate();
      } else {
        throw new Error('Failed to submit certificate');
      }
    } catch (error) {
      console.error('Error submitting certificate:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToSubmitCertificate'),
      });
    } finally {
      setActionPending(false);
    }
  };
  
  const handleApproveCertificate = async () => {
    setActionPending(true);
    try {
      // في الواقع، نحتاج إلى تحديد المستوى المناسب للموافقة بناءً على حالة المستخلص الحالية
      // هذا مجرد مثال، وينبغي تعديله وفقًا لمنطق العمل الخاص بك
      let approvalLevel = 'supervisor';
      
      switch (certificate.status) {
        case 'submitted':
          approvalLevel = 'supervisor';
          break;
        case 'supervisor_approved':
          approvalLevel = 'project_manager';
          break;
        case 'pm_approved':
          approvalLevel = 'financial';
          break;
        case 'finance_approved':
          approvalLevel = 'general_manager';
          break;
        case 'gm_approved':
          approvalLevel = 'final';
          break;
      }
      
      const response = await apiRequest('POST', `/api/certificates/${certificateId}/approve`, {
        level: approvalLevel,
        approverId: 1, // يجب استبدال هذا بمعرف المستخدم الحالي
        comments: approvalComment
      });
      
      if (response.ok) {
        toast({
          title: t('success'),
          description: t('certificateApprovedSuccessfully'),
        });
        setShowApproveDialog(false);
        setApprovalComment('');
        loadCertificate();
      } else {
        throw new Error('Failed to approve certificate');
      }
    } catch (error) {
      console.error('Error approving certificate:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToApproveCertificate'),
      });
    } finally {
      setActionPending(false);
    }
  };
  
  const handleRejectCertificate = async () => {
    if (!rejectionReason) {
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('rejectionReasonRequired'),
      });
      return;
    }
    
    setActionPending(true);
    try {
      // يمكن استخدام نفس منطق تحديد المستوى كما في حالة الموافقة
      let approvalLevel = 'supervisor';
      
      switch (certificate.status) {
        case 'submitted':
          approvalLevel = 'supervisor';
          break;
        case 'supervisor_approved':
          approvalLevel = 'project_manager';
          break;
        case 'pm_approved':
          approvalLevel = 'financial';
          break;
        case 'finance_approved':
          approvalLevel = 'general_manager';
          break;
        case 'gm_approved':
          approvalLevel = 'final';
          break;
      }
      
      const response = await apiRequest('POST', `/api/certificates/${certificateId}/reject`, {
        level: approvalLevel,
        approverId: 1, // يجب استبدال هذا بمعرف المستخدم الحالي
        comments: rejectionReason
      });
      
      if (response.ok) {
        toast({
          title: t('success'),
          description: t('certificateRejectedSuccessfully'),
        });
        setShowRejectDialog(false);
        setRejectionReason('');
        loadCertificate();
      } else {
        throw new Error('Failed to reject certificate');
      }
    } catch (error) {
      console.error('Error rejecting certificate:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToRejectCertificate'),
      });
    } finally {
      setActionPending(false);
    }
  };
  
  const handleMarkAsPaid = async () => {
    setActionPending(true);
    try {
      const response = await apiRequest('POST', `/api/certificates/${certificateId}/mark-paid`);
      if (response.ok) {
        toast({
          title: t('success'),
          description: t('certificateMarkedAsPaid'),
        });
        loadCertificate();
      } else {
        throw new Error('Failed to mark certificate as paid');
      }
    } catch (error) {
      console.error('Error marking certificate as paid:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: t('failedToMarkCertificateAsPaid'),
      });
    } finally {
      setActionPending(false);
    }
  };
  
  if (loading) {
    return (
      <div className="container mx-auto p-4">
        <div className="space-y-6">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-80 w-full" />
        </div>
      </div>
    );
  }
  
  if (!certificate) {
    return (
      <div className="container mx-auto p-4">
        <div className="flex flex-col items-center justify-center py-12">
          <FileTextIcon className="h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-xl font-medium mb-2">{t('certificateNotFound')}</h2>
          <p className="text-muted-foreground mb-6">{t('certificateNotFoundDescription')}</p>
          <Link href="/financial/certificates">
            <Button variant="outline">
              <ChevronLeft className="h-4 w-4 mr-2" />
              {t('backToCertificates')}
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  // تحديد ما إذا كان المستخلص مؤهلاً للموافقة أو الرفض
  const canApprove = ['submitted', 'supervisor_approved', 'pm_approved', 'finance_approved', 'gm_approved'].includes(certificate.status);
  const canReject = canApprove; // نفس شروط الموافقة
  
  // تحديد ما إذا كان المستخلص مؤهلاً للتحديث إلى حالة "مدفوع"
  const canMarkAsPaid = certificate.status === 'approved';
  
  // تحديد ما إذا كان المستخلص قابلاً للتقديم
  const canSubmit = certificate.status === 'draft';
  
  // تحديد ما إذا كان المستخلص قابلاً للتعديل
  const canEdit = ['draft'].includes(certificate.status);
  
  // حساب المبالغ الإجمالية والأرقام
  const totalItemsQuantity = certificateItems.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const totalItemsAmount = certificateItems.reduce((sum, item) => sum + (item.amount || 0), 0);
  
  // جمع معلومات أحدث الموافقات
  const latestApproval = approvals.length > 0 ? approvals[approvals.length - 1] : null;
  
  return (
    <div className="container mx-auto p-4">
      <Breadcrumb className="mb-4">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">{t('home')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/financial">{t('financial')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/financial/certificates">{t('certificates')}</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink>{certificate.title || `${t('certificate')} #${certificate.id}`}</BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
      
      <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">{certificate.title || `${t('certificate')} #${certificate.id}`}</h1>
          <p className="text-muted-foreground mt-1">
            {t('certificateNumber')}: {certificate.certificateNumber || certificate.id}
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {canEdit && (
            <Link href={`/financial/certificates/${certificateId}/edit`}>
              <Button variant="outline">
                <PencilIcon className="h-4 w-4 mr-2" />
                {t('edit')}
              </Button>
            </Link>
          )}
          
          {canSubmit && (
            <Button 
              variant="default" 
              onClick={handleSubmitCertificate}
              disabled={actionPending}
            >
              <CheckCircle2Icon className="h-4 w-4 mr-2" />
              {t('submit')}
            </Button>
          )}
          
          {canApprove && (
            <Button 
              variant="default" 
              onClick={() => setShowApproveDialog(true)}
              disabled={actionPending}
            >
              <CheckIcon className="h-4 w-4 mr-2" />
              {t('approve')}
            </Button>
          )}
          
          {canReject && (
            <Button 
              variant="destructive" 
              onClick={() => setShowRejectDialog(true)}
              disabled={actionPending}
            >
              <XCircleIcon className="h-4 w-4 mr-2" />
              {t('reject')}
            </Button>
          )}
          
          {canMarkAsPaid && (
            <Button 
              variant="default" 
              onClick={handleMarkAsPaid}
              disabled={actionPending}
            >
              <BanknoteIcon className="h-4 w-4 mr-2" />
              {t('markAsPaid')}
            </Button>
          )}
          
          <Link href="/financial/certificates">
            <Button variant="outline">
              <ChevronLeft className="h-4 w-4 mr-2" />
              {t('back')}
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* بطاقة معلومات المستخلص */}
        <Card>
          <CardHeader>
            <CardTitle>{t('certificateDetails')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t('status')}</span>
                <CertificateStatus status={certificate.status} />
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t('type')}</span>
                <span className="font-medium">{paymentCertificateTypeMap[certificate.type] || certificate.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t('totalAmount')}</span>
                <span className="font-medium">{formatCurrency(certificate.totalAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t('periodFrom')}</span>
                <span>{formatDate(certificate.periodFrom)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t('periodTo')}</span>
                <span>{formatDate(certificate.periodTo)}</span>
              </div>
              {certificate.submittedAt && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('submittedAt')}</span>
                  <span>{formatDateTime(certificate.submittedAt)}</span>
                </div>
              )}
              {certificate.approvedAt && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('approvedAt')}</span>
                  <span>{formatDateTime(certificate.approvedAt)}</span>
                </div>
              )}
              {certificate.paidAt && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('paidAt')}</span>
                  <span>{formatDateTime(certificate.paidAt)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t('createdAt')}</span>
                <span>{formatDateTime(certificate.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t('updatedAt')}</span>
                <span>{formatDateTime(certificate.updatedAt)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* بطاقة معلومات المشروع */}
        <Card>
          <CardHeader>
            <CardTitle>{t('projectDetails')}</CardTitle>
          </CardHeader>
          <CardContent>
            {project ? (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('project')}</span>
                  <Link href={`/projects/${project.id}`}>
                    <span className="font-medium hover:underline cursor-pointer">
                      {project.name}
                    </span>
                  </Link>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('projectType')}</span>
                  <span>{project.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('projectStatus')}</span>
                  <Badge variant="outline">
                    {project.status}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('projectStart')}</span>
                  <span>{formatDate(project.startDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('projectEnd')}</span>
                  <span>{formatDate(project.endDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('projectBudget')}</span>
                  <span className="font-medium">{formatCurrency(project.budget)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('projectProgress')}</span>
                  <span>{formatPercentage(project.progress)}</span>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                {t('projectNotFound')}
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* بطاقة الموافقات */}
        <Card>
          <CardHeader>
            <CardTitle>{t('approvals')}</CardTitle>
          </CardHeader>
          <CardContent>
            {approvals.length > 0 ? (
              <div className="space-y-4">
                {approvals.map((approval, index) => (
                  <div key={approval.id || index} className="border rounded-md p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-medium">
                          {approval.approvalLevel === 'supervisor' && t('supervisor')}
                          {approval.approvalLevel === 'project_manager' && t('projectManager')}
                          {approval.approvalLevel === 'financial' && t('financial')}
                          {approval.approvalLevel === 'general_manager' && t('generalManager')}
                          {approval.approvalLevel === 'final' && t('finalApproval')}
                        </span>
                        <div className="text-xs text-muted-foreground mt-1">
                          {formatDateTime(approval.approvedAt)}
                        </div>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={approval.status === 'approved' ? 'bg-green-200 text-green-800 border-0' : 'bg-red-200 text-red-800 border-0'}
                      >
                        {approval.status === 'approved' ? t('approved') : t('rejected')}
                      </Badge>
                    </div>
                    {approval.comments && (
                      <div className="mt-2 text-sm border-t pt-2">
                        {approval.comments}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                {t('noApprovalsYet')}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="items" className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="items">{t('certificateItems')}</TabsTrigger>
          <TabsTrigger value="approvals">{t('approvals')}</TabsTrigger>
          <TabsTrigger value="journalEntries">{t('journalEntries')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value="items">
          <Card>
            <CardHeader>
              <CardTitle>{t('certificateItems')}</CardTitle>
              <CardDescription>{t('certificateItemsDescription')}</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>#</TableHead>
                    <TableHead>{t('description')}</TableHead>
                    <TableHead>{t('contractItem')}</TableHead>
                    <TableHead className="text-right">{t('unit')}</TableHead>
                    <TableHead className="text-right">{t('quantity')}</TableHead>
                    <TableHead className="text-right">{t('unitPrice')}</TableHead>
                    <TableHead className="text-right">{t('amount')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {certificateItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        {t('noCertificateItems')}
                      </TableCell>
                    </TableRow>
                  ) : (
                    <>
                      {certificateItems.map((item, index) => (
                        <TableRow key={item.id || index}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell>{item.description}</TableCell>
                          <TableCell>
                            {item.contractItemId && (
                              <span className="text-primary hover:underline cursor-pointer">
                                {item.contractItemNumber || `#${item.contractItemId}`}
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">{item.unit}</TableCell>
                          <TableCell className="text-right">{item.quantity?.toLocaleString('en-US')}</TableCell>
                          <TableCell className="text-right">{formatCurrency(item.unitPrice)}</TableCell>
                          <TableCell className="text-right font-medium">{formatCurrency(item.amount)}</TableCell>
                        </TableRow>
                      ))}
                      
                      {/* صف الإجمالي */}
                      <TableRow className="bg-muted/50">
                        <TableCell colSpan={4} className="font-medium">{t('total')}</TableCell>
                        <TableCell className="text-right font-medium">{totalItemsQuantity.toLocaleString('en-US')}</TableCell>
                        <TableCell className="text-right"></TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(totalItemsAmount)}</TableCell>
                      </TableRow>
                    </>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="approvals">
          <Card>
            <CardHeader>
              <CardTitle>{t('approvals')}</CardTitle>
              <CardDescription>{t('approvalsDescription')}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {approvals.length > 0 ? (
                  <div className="space-y-6">
                    {approvals.map((approval, index) => (
                      <div key={approval.id || index} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">{approval.level || t('approval')}</div>
                            <div className="text-sm text-muted-foreground">
                              {approval.approverName || `${t('user')} #${approval.approverId}`}
                            </div>
                          </div>
                          <div className="text-left">
                            <div className="text-sm text-muted-foreground">
                              {formatDateTime(approval.createdAt)}
                            </div>
                            <Badge variant={approval.approved ? 'default' : 'destructive'}>
                              {approval.approved ? t('approved') : t('rejected')}
                            </Badge>
                          </div>
                        </div>
                        {approval.comments && (
                          <div className="mt-2 text-sm border-t pt-2">
                            {approval.comments}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    {t('noApprovalsYet')}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="journalEntries">
          <Card>
            <CardHeader>
              <CardTitle>{t('journalEntries')}</CardTitle>
              <CardDescription>{t('certificateJournalEntriesDescription')}</CardDescription>
            </CardHeader>
            <CardContent>
              {journalEntries.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>#</TableHead>
                      <TableHead>{t('journalNumber')}</TableHead>
                      <TableHead>{t('date')}</TableHead>
                      <TableHead>{t('description')}</TableHead>
                      <TableHead className="text-right">{t('debitAmount')}</TableHead>
                      <TableHead className="text-right">{t('creditAmount')}</TableHead>
                      <TableHead className="text-center">{t('status')}</TableHead>
                      <TableHead className="text-right">{t('actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {journalEntries.map((entry, index) => (
                      <TableRow key={entry.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{entry.journalNumber || `${t('entry')} #${entry.id}`}</TableCell>
                        <TableCell>{formatDate(entry.journalDate)}</TableCell>
                        <TableCell className="max-w-[200px] truncate">{entry.description}</TableCell>
                        <TableCell className="text-right">{formatCurrency(entry.totalDebit)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(entry.totalCredit)}</TableCell>
                        <TableCell className="text-center">
                          <Badge 
                            variant={entry.isPosted ? 'default' : 'outline'}
                            className="capitalize"
                          >
                            {entry.isPosted ? t('posted') : t('draft')}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Link href={`/financial/journal-entries/${entry.id}`}>
                            <Button variant="outline" size="sm">
                              <EyeIcon className="h-4 w-4 mr-1" />
                              {t('view')}
                            </Button>
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 space-y-3">
                  <FileTextIcon className="h-12 w-12 mx-auto text-muted-foreground" />
                  <h3 className="font-medium">{t('noJournalEntriesForCertificate')}</h3>
                  <p className="text-muted-foreground text-sm max-w-md mx-auto">
                    {t('noJournalEntriesForCertificateDescription')}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* مربع حوار الموافقة */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('approveCertificate')}</DialogTitle>
            <DialogDescription>
              {t('approveCertificateDescription')}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <label htmlFor="approvalComment" className="text-sm font-medium">
                {t('comments')} ({t('optional')})
              </label>
              <Textarea
                id="approvalComment"
                value={approvalComment}
                onChange={(e) => setApprovalComment(e.target.value)}
                placeholder={t('approvalCommentsPlaceholder')}
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowApproveDialog(false)}
              disabled={actionPending}
            >
              {t('cancel')}
            </Button>
            <Button 
              onClick={handleApproveCertificate}
              disabled={actionPending}
            >
              {actionPending ? t('approving') : t('approve')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* مربع حوار الرفض */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('rejectCertificate')}</DialogTitle>
            <DialogDescription>
              {t('rejectCertificateDescription')}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <label htmlFor="rejectionReason" className="text-sm font-medium">
                {t('rejectionReason')} <span className="text-destructive">*</span>
              </label>
              <Textarea
                id="rejectionReason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder={t('rejectionReasonPlaceholder')}
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowRejectDialog(false)}
              disabled={actionPending}
            >
              {t('cancel')}
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleRejectCertificate}
              disabled={actionPending || !rejectionReason}
            >
              {actionPending ? t('rejecting') : t('reject')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CertificateDetailPage;