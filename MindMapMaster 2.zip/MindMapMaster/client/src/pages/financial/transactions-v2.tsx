import { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search as SearchIcon, 
  Plus, 
  Filter, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Repeat, 
  Download, 
  Share, 
  FileText, 
  Calendar, 
  Copy,
  ListFilter,
  X,
  CalendarRange,
  CalendarIcon,
  LayoutList,
  LayoutGrid,
  CircleAlert,
  MoreHorizontal,
  BookOpen,
  Printer,
  Sparkles,
  FileUp,
  Building2,
  FileText as FileTextIcon,
  File as FileIcon,
  Hash as HashIcon,
  BadgeInfo as InfoIcon,
  Coins as CoinsIcon,
  Activity as ActivityIcon,
  FolderTree as FolderIcon,
  ArrowUp as ArrowUpIcon,
  ArrowDown as ArrowDownIcon,
  ArrowRight as ArrowRightIcon,
  Briefcase as BriefcaseIcon,
  Tags as TagsIcon,
  FileUp as FileDigit
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, subDays, startOfMonth, endOfMonth, isSameMonth } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { printTransaction, exportTransactionToExcel } from "./transaction-exporters";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { AccountTreeSelector } from "@/components/financial/account-tree-selector";
import { TransactionViewModes } from "@/components/financial/transaction-view-modes";
import TransactionSteps from "@/components/financial/transaction-steps";
import { ExportDataDialog } from "@/components/financial/export-data-dialog";
import { AccountBalanceImpact } from "@/components/financial/account-balance-impact";
import { ProjectBudgetImpact } from "@/components/financial/project-budget-impact";
import { CertificatePaymentTracker } from "@/components/financial/certificate-payment-tracker";
import { TransactionApprovalSystem } from "@/components/financial/transaction-approval-system";

// Interface for API transaction data
interface Transaction {
  id: number;
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: string | Date;
  description: string | null;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number;
  creditAccountId: number;
  referenceNumber: string;
  status: string;
  createdAt: string | Date;
  updatedAt: string | Date;
  debitAccount: { id?: number; name: string; code: string; type?: string };
  creditAccount: { id?: number; name: string; code: string; type?: string };
  project: { id?: number; name: string } | null;
  journalEntry?: {
    id: number;
    journalNumber: string;
    journalDate: string | Date;
    totalDebit: number;
    totalCredit: number;
    isBalanced: boolean;
    lines: {
      id: number;
      accountId: number;
      accountName: string;
      accountCode: string;
      debitAmount: number;
      creditAmount: number;
      description: string;
    }[];
  };
}

interface Account {
  id: number;
  code: string;
  name: string;
  type: string;
  level: number;
  hasChildren: boolean;
  parentId?: number;
}

interface Project {
  id: number;
  name: string;
}

interface CostCategory {
  id: string;
  name: string;
}

interface TransactionFormData {
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: Date;
  description: string;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number | null;
  creditAccountId: number | null;
  referenceNumber: string;
  createJournalEntry: boolean;
  paymentMethod?: string;
  notes?: string;
  tags?: string[];
  relatedCertificateId?: number | null;
  relatedBudgetItemId?: number | null;
  status?: string;
  currencyCode?: string;
  exchangeRate?: number;
  invoiceDate?: Date | null;
  dueDate?: Date | null;
}

export default function FinancialTransactions() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // UI State
  const [viewMode, setViewMode] = useState<"table" | "cards" | "timeline">("table");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
  const [selectedTransactionId, setSelectedTransactionId] = useState<number | null>(null);
  const [isFilterExpanded, setIsFilterExpanded] = useState(false);
  const [groupBy, setGroupBy] = useState<"none" | "date" | "account" | "project">("none");
  const [datePreset, setDatePreset] = useState<string>("all");
  
  // Query and Filter State
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [projectFilter, setProjectFilter] = useState<number | "all">("all");
  const [accountFilter, setAccountFilter] = useState<number | "all">("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [amountRange, setAmountRange] = useState<{ min?: number; max?: number }>({});
  
  // Batch operations state
  const [selectedTransactions, setSelectedTransactions] = useState<number[]>([]);
  
  // Pagination state
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  
  // Create a ref for transaction details content for printing/exporting
  const transactionDetailsPrintRef = useRef<HTMLDivElement>(null);
  
  // Query parameters for transactions
  const [queryParams, setQueryParams] = useState({
    page,
    limit: pageSize,
    type: typeFilter !== "all" ? typeFilter : undefined,
    projectId: projectFilter !== "all" ? projectFilter : undefined,
    accountId: accountFilter !== "all" ? accountFilter : undefined,
    status: statusFilter !== "all" ? statusFilter : undefined,
    search: searchQuery || undefined,
    startDate: startDate ? format(startDate, "yyyy-MM-dd") : undefined,
    endDate: endDate ? format(endDate, "yyyy-MM-dd") : undefined,
    minAmount: amountRange.min,
    maxAmount: amountRange.max
  });
  
  // Apply date preset when changed
  useEffect(() => {
    const today = new Date();
    
    switch (datePreset) {
      case "today":
        setStartDate(today);
        setEndDate(today);
        break;
      case "yesterday":
        const yesterday = subDays(today, 1);
        setStartDate(yesterday);
        setEndDate(yesterday);
        break;
      case "last7days":
        setStartDate(subDays(today, 6));
        setEndDate(today);
        break;
      case "last30days":
        setStartDate(subDays(today, 29));
        setEndDate(today);
        break;
      case "thisMonth":
        setStartDate(startOfMonth(today));
        setEndDate(endOfMonth(today));
        break;
      case "lastMonth":
        const lastMonth = subDays(startOfMonth(today), 1);
        setStartDate(startOfMonth(lastMonth));
        setEndDate(endOfMonth(lastMonth));
        break;
      case "all":
        setStartDate(undefined);
        setEndDate(undefined);
        break;
    }
  }, [datePreset]);
  
  // Update query params when filters change
  useEffect(() => {
    setQueryParams({
      page,
      limit: pageSize,
      type: typeFilter !== "all" ? typeFilter : undefined,
      projectId: projectFilter !== "all" ? projectFilter : undefined,
      accountId: accountFilter !== "all" ? accountFilter : undefined,
      status: statusFilter !== "all" ? statusFilter : undefined,
      search: searchQuery || undefined,
      startDate: startDate ? format(startDate, "yyyy-MM-dd") : undefined,
      endDate: endDate ? format(endDate, "yyyy-MM-dd") : undefined,
      minAmount: amountRange.min,
      maxAmount: amountRange.max
    });
  }, [
    page, 
    pageSize, 
    typeFilter, 
    projectFilter, 
    accountFilter, 
    statusFilter, 
    searchQuery, 
    startDate, 
    endDate, 
    amountRange
  ]);
  
  // Reset to page 1 when filters change
  useEffect(() => {
    setPage(1);
  }, [typeFilter, projectFilter, accountFilter, statusFilter, searchQuery, startDate, endDate, amountRange]);
  
  // Fetch transactions
  const { 
    data: transactionsData = { data: [] }, 
    isLoading: isLoadingTransactions,
    isError: isTransactionsError,
    error: transactionsError
  } = useQuery({
    queryKey: ['/api/financial/transactions', queryParams],
    refetchOnWindowFocus: false
  });
  
  // Fetch accounts for dropdown
  const { 
    data: accounts = [],
    isLoading: isLoadingAccounts
  } = useQuery({
    queryKey: ['/api/accounts'],
    refetchOnWindowFocus: false
  });
  
  // Fetch projects for dropdown
  const { 
    data: projects = [],
    isLoading: isLoadingProjects
  } = useQuery({
    queryKey: ['/api/financial/projects'],
    refetchOnWindowFocus: false
  });
  
  // Fetch cost categories for dropdown
  const { 
    data: costCategories = [],
    isLoading: isLoadingCategories
  } = useQuery({
    queryKey: ['/api/financial/cost-categories'],
    refetchOnWindowFocus: false
  });
  
  // Fetch certificates
  const {
    data: certificates = [],
    isLoading: isLoadingCertificates
  } = useQuery({
    queryKey: ['/api/financial/certificates'],
    refetchOnWindowFocus: false
  });
  
  // Fetch budget items
  const {
    data: budgetItems = [],
    isLoading: isLoadingBudgetItems
  } = useQuery({
    queryKey: ['/api/financial/budget-items'],
    refetchOnWindowFocus: false
  });
  
  // Fetch transaction details when viewing a specific transaction
  const { 
    data: transactionDetails,
    isLoading: isLoadingDetails,
    refetch: refetchTransactionDetails
  } = useQuery<any>({
    queryKey: ['/api/financial/transactions', selectedTransactionId],
    enabled: selectedTransactionId !== null && isViewDetailsOpen,
    refetchOnWindowFocus: false
  });
  
  // Create new transaction mutation
  const createTransactionMutation = useMutation({
    mutationFn: (data: TransactionFormData) => {
      return apiRequest("POST", "/api/financial/transactions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.successTitle"),
        description: t("financial.transactions.createSuccess"),
      });
      setIsCreateDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.errorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Delete transaction mutation
  const deleteTransactionMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/financial/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.successTitle"),
        description: t("financial.transactions.deleteSuccess"),
      });
      setIsViewDetailsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.errorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Batch delete mutation
  const batchDeleteMutation = useMutation({
    mutationFn: (ids: number[]) => {
      return apiRequest("POST", "/api/financial/transactions/batch-delete", { ids });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.successTitle"),
        description: t("financial.transactions.batchDeleteSuccess"),
      });
      setSelectedTransactions([]);
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.errorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Duplicate transaction mutation
  const duplicateTransactionMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/financial/transactions/${id}/duplicate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.successTitle"),
        description: t("financial.transactions.duplicateSuccess"),
      });
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.errorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Handle view transaction details
  const handleViewDetails = (id: number) => {
    setSelectedTransactionId(id);
    setIsViewDetailsOpen(true);
  };
  
  // Handle transaction creation submission
  const handleCreateTransaction = (data: TransactionFormData) => {
    createTransactionMutation.mutate(data);
  };
  
  // Handle transaction deletion
  const handleDeleteTransaction = (id: number) => {
    if (window.confirm(t("financial.transactions.confirmDelete"))) {
      deleteTransactionMutation.mutate(id);
    }
  };
  
  // Handle transaction duplication
  const handleDuplicateTransaction = (id: number) => {
    duplicateTransactionMutation.mutate(id);
  };
  
  // Print transaction details
  const handlePrintTransaction = async () => {
    if (!transactionDetails) return;
    
    await printTransaction(
      transactionDetailsPrintRef.current, 
      transactionDetails as any, 
      { 
        t, 
        formatAmount, 
        formatDate 
      },
      (title, description) => {
        toast({ title, description });
      },
      (title, description) => {
        toast({ title, description, variant: "destructive" });
      }
    );
  };
  
  // Export transaction details to Excel
  const handleExportTransaction = () => {
    if (!transactionDetails) return;
    
    exportTransactionToExcel(
      transactionDetails as any,
      { 
        t, 
        formatAmount, 
        formatDate 
      },
      (title, description) => {
        toast({ title, description });
      },
      (title, description) => {
        toast({ title, description, variant: "destructive" });
      }
    );
  };
  
  // Handle batch operation
  const handleBatchDelete = () => {
    if (selectedTransactions.length === 0) return;
    
    if (window.confirm(t("financial.transactions.confirmBatchDelete", { count: selectedTransactions.length }))) {
      batchDeleteMutation.mutate(selectedTransactions);
    }
  };
  
  // Clear all filters
  const clearAllFilters = () => {
    setTypeFilter("all");
    setProjectFilter("all");
    setAccountFilter("all");
    setStatusFilter("all");
    setSearchQuery("");
    setDatePreset("all");
    setStartDate(undefined);
    setEndDate(undefined);
    setAmountRange({});
  };
  
  // Format date for display
  const formatDate = (date: string | Date | null | undefined) => {
    if (!date) return "-";
    try {
      return format(new Date(date), "yyyy/MM/dd");
    } catch (error) {
      console.error("Invalid date format:", date);
      return "-";
    }
  };
  
  // Format currency amount
  const formatAmount = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined) {
      return '٠ ر.س.';
    }
    try {
      return new Intl.NumberFormat('ar-SA', { 
        style: 'currency', 
        currency: 'SAR',
        maximumFractionDigits: 0
      }).format(amount);
    } catch (error) {
      console.error('Error formatting amount:', amount, error);
      return '٠ ر.س.';
    }
  };

  // Get columns for export
  const exportColumns = [
    { field: 'id', title: t("financial.transactions.id") },
    { field: 'referenceNumber', title: t("financial.transactions.reference") },
    { field: 'transactionDate', title: t("financial.transactions.date") },
    { field: 'type', title: t("financial.transactions.type") },
    { field: 'amount', title: t("financial.transactions.amount") },
    { field: 'description', title: t("financial.transactions.description") },
    { field: 'debitAccount.name', title: t("financial.transactions.debitAccount") },
    { field: 'debitAccount.code', title: t("financial.transactions.debitAccountCode") },
    { field: 'creditAccount.name', title: t("financial.transactions.creditAccount") },
    { field: 'creditAccount.code', title: t("financial.transactions.creditAccountCode") },
    { field: 'project.name', title: t("financial.transactions.project") },
    { field: 'costCategory', title: t("financial.transactions.category") },
    { field: 'status', title: t("financial.transactions.status") },
    { field: 'createdAt', title: t("financial.transactions.createdAt") },
    { field: 'updatedAt', title: t("financial.transactions.updatedAt") }
  ];

  // Define the date range display
  const dateRangeValue = () => {
    if (!startDate && !endDate) return t("financial.transactions.allDates");
    
    if (startDate && !endDate) {
      return `${format(startDate, "yyyy/MM/dd")} ${t("common.toNow")}`;
    }
    
    if (!startDate && endDate) {
      return `${t("common.untilDate")} ${format(endDate, "yyyy/MM/dd")}`;
    }
    
    if (startDate && endDate) {
      // Check if same day
      if (format(startDate, "yyyy/MM/dd") === format(endDate, "yyyy/MM/dd")) {
        return format(startDate, "yyyy/MM/dd");
      }
      
      // Check if same month
      if (isSameMonth(startDate, endDate)) {
        return `${format(startDate, "d")} - ${format(endDate, "d")} ${format(startDate, "MMM yyyy")}`;
      }
      
      return `${format(startDate, "yyyy/MM/dd")} - ${format(endDate, "yyyy/MM/dd")}`;
    }
    
    return "";
  };
  
  // Loading state when any dependencies are loading
  const isLoading = 
    isLoadingTransactions || 
    isLoadingAccounts || 
    isLoadingProjects || 
    isLoadingCategories ||
    isLoadingCertificates ||
    isLoadingBudgetItems;
  
  // Get filtered count
  const getFilteredCount = () => {
    if (!transactionsData?.data) return 0;
    return transactionsData.data.length;
  };
  
  // Check if any filters are active
  const hasActiveFilters = () => {
    return (
      typeFilter !== "all" || 
      projectFilter !== "all" || 
      accountFilter !== "all" || 
      statusFilter !== "all" || 
      !!searchQuery || 
      !!startDate || 
      !!endDate || 
      !!amountRange.min || 
      !!amountRange.max
    );
  };
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col gap-6">
        {/* Page Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{t("financial.transactions.title")}</h1>
            <p className="text-muted-foreground">{t("financial.transactions.description")}</p>
          </div>
          
          {/* Action buttons */}
          <div className="flex gap-2">
            {/* Batch Actions (conditional) */}
            {selectedTransactions.length > 0 && (
              <div className="bg-secondary/20 border rounded-lg p-2 flex items-center gap-2 mr-2">
                <span className="text-sm font-medium">{selectedTransactions.length} {t("common.selected")}</span>
                
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedTransactions([])}
                >
                  {t("common.clearSelection")}
                </Button>
                
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={handleBatchDelete}
                >
                  {t("common.delete")}
                </Button>
              </div>
            )}
            
            {/* Export button */}
            <ExportDataDialog
              data={transactionsData?.data || []}
              columns={exportColumns}
              filename="financial_transactions"
              title={t("financial.transactions.exportTitle")}
              description={t("financial.transactions.exportDescription")}
            />
            
            {/* Create Transaction button */}
            <Dialog 
              open={isCreateDialogOpen} 
              onOpenChange={setIsCreateDialogOpen}
            >
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  {t("financial.transactions.add")}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>{t("financial.transactions.addNew")}</DialogTitle>
                  <DialogDescription>
                    {t("financial.transactions.addNewDescription")}
                  </DialogDescription>
                </DialogHeader>
                
                {/* Transaction Steps Wizard */}
                <div className="py-4">
                  <TransactionSteps
                    accounts={accounts || []}
                    projects={projects || []}
                    costCategories={costCategories || []}
                    certificates={certificates || []}
                    budgetItems={budgetItems || []}
                    onSubmit={handleCreateTransaction}
                    onCancel={() => setIsCreateDialogOpen(false)}
                    isSubmitting={createTransactionMutation.isPending}
                  />
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {/* Filters */}
        <div className="bg-muted/30 rounded-lg border p-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
            {/* Search bar */}
            <div className="relative w-full md:w-1/3">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t("financial.transactions.search")}
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            {/* Quick filters */}
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={typeFilter}
                onValueChange={setTypeFilter}
              >
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder={t("financial.transactions.type")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("financial.transactions.allTypes")}</SelectItem>
                  <SelectItem value="income">{t("financial.transactions.income")}</SelectItem>
                  <SelectItem value="expense">{t("financial.transactions.expense")}</SelectItem>
                  <SelectItem value="transfer">{t("financial.transactions.transfer")}</SelectItem>
                </SelectContent>
              </Select>
              
              <Select
                value={datePreset}
                onValueChange={setDatePreset}
              >
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder={t("financial.transactions.datePeriod")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("financial.transactions.allDates")}</SelectItem>
                  <SelectItem value="today">{t("financial.transactions.today")}</SelectItem>
                  <SelectItem value="yesterday">{t("financial.transactions.yesterday")}</SelectItem>
                  <SelectItem value="last7days">{t("financial.transactions.last7days")}</SelectItem>
                  <SelectItem value="last30days">{t("financial.transactions.last30days")}</SelectItem>
                  <SelectItem value="thisMonth">{t("financial.transactions.thisMonth")}</SelectItem>
                  <SelectItem value="lastMonth">{t("financial.transactions.lastMonth")}</SelectItem>
                </SelectContent>
              </Select>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button 
                    variant="outline" 
                    className={cn(
                      "gap-2", 
                      startDate || endDate ? "bg-primary/10 border-primary/30" : ""
                    )}
                  >
                    <CalendarRange className="h-4 w-4" />
                    <span className="hidden md:inline">{dateRangeValue()}</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <div className="p-2 flex flex-col gap-2">
                    <div className="flex gap-2">
                      <div>
                        <div className="mb-2">
                          <label className="text-sm font-medium">
                            {t("financial.transactions.startDate")}
                          </label>
                        </div>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !startDate && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {startDate ? (
                                format(startDate, "PP")
                              ) : (
                                <span>{t("financial.transactions.pickDate")}</span>
                              )}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <CalendarComponent
                              mode="single"
                              selected={startDate}
                              onSelect={setStartDate}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                      
                      <div>
                        <div className="mb-2">
                          <label className="text-sm font-medium">
                            {t("financial.transactions.endDate")}
                          </label>
                        </div>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !endDate && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {endDate ? (
                                format(endDate, "PP")
                              ) : (
                                <span>{t("financial.transactions.pickDate")}</span>
                              )}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <CalendarComponent
                              mode="single"
                              selected={endDate}
                              onSelect={setEndDate}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>
                    
                    <div className="flex justify-between">
                      <Button 
                        variant="ghost" 
                        onClick={() => {
                          setStartDate(undefined);
                          setEndDate(undefined);
                          setDatePreset("all");
                        }}
                      >
                        {t("common.reset")}
                      </Button>
                      <Button onClick={() => {}}>{t("common.apply")}</Button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
              
              <Button
                variant="outline"
                className={cn(
                  "gap-2",
                  (isFilterExpanded || hasActiveFilters()) && "bg-primary/10 border-primary/30"
                )}
                onClick={() => setIsFilterExpanded(!isFilterExpanded)}
              >
                <Filter className="h-4 w-4" />
                <span className="hidden md:inline">{t("common.moreFilters")}</span>
                {hasActiveFilters() && (
                  <Badge 
                    variant="default" 
                    className="ml-1 h-5 w-5 rounded-full p-0 flex items-center justify-center"
                  >
                    {Object.values(queryParams).filter(v => v !== undefined && v !== "all").length}
                  </Badge>
                )}
              </Button>
              
              {hasActiveFilters() && (
                <Button
                  variant="ghost"
                  className="gap-2 text-muted-foreground"
                  onClick={clearAllFilters}
                >
                  <X className="h-4 w-4" />
                  <span>{t("common.clearAll")}</span>
                </Button>
              )}
            </div>
          </div>
          
          {/* Advanced filters */}
          {isFilterExpanded && (
            <div className="mt-4 pt-4 border-t grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t("financial.transactions.project")}
                </label>
                <Select
                  value={projectFilter === "all" ? "all" : projectFilter.toString()}
                  onValueChange={(value) => setProjectFilter(value === "all" ? "all" : parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("financial.transactions.filterByProject")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("financial.transactions.allProjects")}</SelectItem>
                    {!isLoadingProjects && projects?.map((project) => (
                      <SelectItem key={project.id} value={project.id.toString()}>{project.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t("financial.transactions.account")}
                </label>
                {!isLoadingAccounts && (
                  <AccountTreeSelector
                    accounts={accounts || []}
                    value={accountFilter === "all" ? null : accountFilter}
                    onChange={(id) => setAccountFilter(id)}
                    placeholder={t("financial.transactions.allAccounts")}
                  />
                )}
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t("financial.transactions.status")}
                </label>
                <Select
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("financial.transactions.filterByStatus")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("financial.transactions.allStatuses")}</SelectItem>
                    <SelectItem value="completed">{t("financial.transactions.completed")}</SelectItem>
                    <SelectItem value="pending">{t("financial.transactions.pending")}</SelectItem>
                    <SelectItem value="draft">{t("financial.transactions.draft")}</SelectItem>
                    <SelectItem value="cancelled">{t("financial.transactions.cancelled")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t("financial.transactions.minAmount")}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2">SAR</span>
                  <Input
                    type="number"
                    placeholder="0"
                    className="pl-12"
                    value={amountRange.min || ""}
                    onChange={(e) => setAmountRange({ ...amountRange, min: e.target.value ? Number(e.target.value) : undefined })}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t("financial.transactions.maxAmount")}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2">SAR</span>
                  <Input
                    type="number"
                    placeholder="∞"
                    className="pl-12"
                    value={amountRange.max || ""}
                    onChange={(e) => setAmountRange({ ...amountRange, max: e.target.value ? Number(e.target.value) : undefined })}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t("financial.transactions.groupBy")}
                </label>
                <Select
                  value={groupBy}
                  onValueChange={(value: "none" | "date" | "account" | "project") => setGroupBy(value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("financial.transactions.selectGrouping")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("financial.transactions.noGrouping")}</SelectItem>
                    <SelectItem value="date">{t("financial.transactions.groupByDate")}</SelectItem>
                    <SelectItem value="account">{t("financial.transactions.groupByAccount")}</SelectItem>
                    <SelectItem value="project">{t("financial.transactions.groupByProject")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </div>
        
        {/* Results stats and view controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-lg font-semibold">{t("financial.transactions.results")}</h2>
            <p className="text-sm text-muted-foreground">
              {getFilteredCount()} {t("financial.transactions.transactionsFound")}
              {hasActiveFilters() && ` (${t("common.filtered")})`}
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant={viewMode === "table" ? "default" : "outline"} 
              size="sm" 
              className="gap-2"
              onClick={() => setViewMode("table")}
            >
              <LayoutList className="h-4 w-4" />
              <span className="hidden md:inline">{t("view.table")}</span>
            </Button>
            <Button 
              variant={viewMode === "cards" ? "default" : "outline"} 
              size="sm" 
              className="gap-2"
              onClick={() => setViewMode("cards")}
            >
              <LayoutGrid className="h-4 w-4" />
              <span className="hidden md:inline">{t("view.cards")}</span>
            </Button>
            <Button 
              variant={viewMode === "timeline" ? "default" : "outline"} 
              size="sm" 
              className="gap-2"
              onClick={() => setViewMode("timeline")}
            >
              <Calendar className="h-4 w-4" />
              <span className="hidden md:inline">{t("view.timeline")}</span>
            </Button>
          </div>
        </div>
        
        {/* Main content */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>{t("financial.transactions.transactionsList")}</CardTitle>
            <CardDescription>{t("financial.transactions.selectTransactionToView")}</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingTransactions ? (
              <div className="flex items-center justify-center p-12">
                <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full" />
              </div>
            ) : isTransactionsError ? (
              <div className="bg-destructive/10 text-destructive p-4 rounded-lg border border-destructive/30 flex items-start gap-3">
                <CircleAlert className="h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-medium mb-1">{t("common.error")}</h3>
                  <p className="text-sm">{(transactionsError as Error)?.message || t("financial.transactions.errorLoading")}</p>
                </div>
              </div>
            ) : !transactionsData?.data || transactionsData.data.length === 0 ? (
              <div className="text-center p-10">
                <FileText className="h-10 w-10 text-muted-foreground/40 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">{t("financial.transactions.noTransactions")}</h3>
                <p className="text-muted-foreground mb-4">{t("financial.transactions.noTransactionsDescription")}</p>
                <Button 
                  onClick={() => setIsCreateDialogOpen(true)}
                  className="gap-2"
                >
                  <Plus className="h-4 w-4" />
                  {t("financial.transactions.createFirstTransaction")}
                </Button>
              </div>
            ) : (
              <TransactionViewModes
                transactions={transactionsData.data}
                viewMode={viewMode}
                onViewModeChange={setViewMode}
                onViewDetails={handleViewDetails}
                groupBy={groupBy}
              />
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* View Transaction Details Dialog */}
      <Dialog open={isViewDetailsOpen} onOpenChange={setIsViewDetailsOpen}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          <DialogHeader className="bg-gradient-to-l from-primary/10 to-transparent p-6 border-b">
            <div className="flex items-center gap-3 mb-1">
              <div className="bg-primary/20 rounded-full p-1.5">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <DialogTitle className="text-xl font-bold text-primary">
                {t("financial.transactions.transactionDetails")}
              </DialogTitle>
            </div>
            <DialogDescription className="text-[15px]">
              {isLoadingDetails 
                ? t("common.loading")
                : t("financial.transactions.transactionDetailsDesc", { id: transactionDetails?.id, ref: transactionDetails?.referenceNumber })}
            </DialogDescription>
          </DialogHeader>
          
          {isLoadingDetails ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mr-4" />
              <p>{t("common.loading")}</p>
            </div>
          ) : transactionDetails ? (
            <div className="p-6 max-h-[70vh] overflow-y-auto">
              <div ref={transactionDetailsPrintRef} className="flex flex-col">
                {/* رأس المستند / Document Header */}
                <div className="border-b-2 border-primary/20 mb-6 pb-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="bg-primary/10 rounded-full p-2 border border-primary/20">
                        <Building2 className="h-8 w-8 text-primary" />
                      </div>
                      <div>
                        <h2 className="text-xl font-bold text-primary">{t("app.companyName", "شركة تطوير المشاريع")}</h2>
                        <p className="text-sm text-muted-foreground">{t("app.companySlogan", "للمقاولات والبنية التحتية")}</p>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="inline-block border-2 border-primary/30 rounded-lg px-4 py-2 bg-primary/5 relative">
                        <h3 className="text-lg font-bold">{t("financial.transactions.documentTitle", "مستند معاملة مالية")}</h3>
                        <div className="absolute -top-3 -right-3 bg-white border-2 border-primary text-primary rounded-full h-6 w-6 flex items-center justify-center text-xs font-bold">
                          {transactionDetails.type === "income" ? "د" : transactionDetails.type === "expense" ? "م" : "ت"}
                        </div>
                      </div>
                    </div>
                    <div className="text-start">
                      <div className="flex flex-col items-end">
                        <div className="text-sm text-muted-foreground">{t("financial.transactions.documentNumber", "رقم المستند")}</div>
                        <div className="font-bold font-mono text-lg">{transactionDetails?.referenceNumber || `FT-${transactionDetails?.id || '0000'}`}</div>
                        <div className="text-xs text-muted-foreground">{format(new Date(), "yyyy/MM/dd HH:mm:ss")}</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* معلومات المعاملة الرئيسية / Transaction Main Info */}
                <div className="flex justify-between items-start mb-6 bg-muted/10 p-4 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "rounded-full p-3 border",
                    transactionDetails.type === "income" && "bg-green-100 border-green-300",
                    transactionDetails.type === "expense" && "bg-red-100 border-red-300",
                    transactionDetails.type === "transfer" && "bg-blue-100 border-blue-300"
                  )}>
                    {transactionDetails.type === "income" && <ArrowUpRight className="h-6 w-6 text-green-600" />}
                    {transactionDetails.type === "expense" && <ArrowDownLeft className="h-6 w-6 text-red-600" />}
                    {transactionDetails.type === "transfer" && <Repeat className="h-6 w-6 text-blue-600" />}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">
                      {t(`financial.transactions.type_${transactionDetails.type || 'unknown'}`, t(`financial.transactions.${transactionDetails.type || 'unknown'}`, "معاملة"))}
                    </div>
                    <h2 className="text-2xl font-bold">
                      {formatAmount(transactionDetails?.amount || 0)}
                    </h2>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDate(transactionDetails?.transactionDate || new Date())}
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleDuplicateTransaction(transactionDetails.id)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{t("common.duplicate")}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={handlePrintTransaction}
                        >
                          <Printer className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{t("common.print")}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>{t("common.actions")}</DropdownMenuLabel>
                      <DropdownMenuItem
                        className="flex items-center gap-2"
                        onClick={() => refetchTransactionDetails()}
                      >
                        <BookOpen className="h-4 w-4" />
                        {t("common.refresh")}
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="flex items-center gap-2"
                        onClick={handleExportTransaction}
                      >
                        <FileUp className="h-4 w-4" />
                        {t("common.export")}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="flex items-center gap-2 text-destructive focus:text-destructive"
                        onClick={() => handleDeleteTransaction(transactionDetails.id)}
                      >
                        <X className="h-4 w-4" />
                        {t("common.delete")}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {/* رقم المعاملة والتفاصيل الأساسية / Transaction ID and Basic Details */}
                <Card className="relative overflow-hidden border-primary/20">
                  <div className="absolute -top-16 -right-16 w-32 h-32 bg-primary/5 rounded-full"></div>
                  <div className="absolute top-0 right-0 w-full h-1 bg-primary"></div>
                  <CardHeader className="pb-2 pt-5 border-b">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <FileIcon className="h-5 w-5 text-primary" />
                        {t("financial.transactions.basicInfo", "معلومات المعاملة الأساسية")}
                      </CardTitle>
                      <Badge variant="outline" className="font-medium text-xs border-2">
                        {t("financial.transactions.officialDocument", "مستند رسمي")}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="grid grid-cols-1 gap-4 mb-4">
                      {transactionDetails?.type === 'transfer' ? null : (
                        <div className="border border-dashed border-primary/20 rounded-lg p-3 bg-primary/5">
                          <div className="text-sm text-muted-foreground mb-1">{t("financial.transactions.reference", "الرقم المرجعي")}</div>
                          <div className="text-xl font-bold font-mono tracking-wider flex items-center gap-2">
                            <FileDigit className="h-4 w-4 text-primary" />
                            {transactionDetails?.referenceNumber || `FT-${transactionDetails?.id || '0000'}`}
                          </div>
                        </div>
                      )}
                    </div>

                    <dl className="grid grid-cols-3 gap-3 text-sm">
                      <dt className="text-muted-foreground flex items-center gap-1">
                        <HashIcon className="h-3 w-3" />
                        {t("financial.transactions.id", "المعرف")}
                      </dt>
                      <dd className="col-span-2 font-medium bg-muted/20 p-1.5 rounded">
                        {transactionDetails?.id || '-'}
                      </dd>
                      
                      <dt className="text-muted-foreground flex items-center gap-1">
                        <InfoIcon className="h-3 w-3" />
                        {t("financial.transactions.type", "النوع")}
                      </dt>
                      <dd className="col-span-2">
                        <Badge variant={
                          transactionDetails?.type === "income" ? "success" : 
                          transactionDetails?.type === "expense" ? "destructive" : 
                          "default"
                        } className="font-medium">
                          {t(`financial.transactions.type_${transactionDetails?.type || 'unknown'}`, t(`financial.transactions.${transactionDetails?.type || 'unknown'}`, "معاملة"))}
                        </Badge>
                      </dd>
                      
                      <dt className="text-muted-foreground flex items-center gap-1">
                        <CoinsIcon className="h-3 w-3" />
                        {t("financial.transactions.amount", "المبلغ")}
                      </dt>
                      <dd className="col-span-2 font-bold text-lg">
                        {transactionDetails?.amount ? formatAmount(transactionDetails.amount) : '٠ ر.س.'}
                      </dd>
                      
                      <dt className="text-muted-foreground flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {t("financial.transactions.date", "التاريخ")}
                      </dt>
                      <dd className="col-span-2 bg-muted/20 p-1.5 rounded">
                        {formatDate(transactionDetails?.transactionDate || new Date())}
                      </dd>
                      
                      <dt className="text-muted-foreground flex items-center gap-1">
                        <ActivityIcon className="h-3 w-3" />
                        {t("financial.transactions.status", "الحالة")}
                      </dt>
                      <dd className="col-span-2">
                        <Badge variant={
                          transactionDetails?.status === "completed" ? "success" :
                          transactionDetails?.status === "pending" ? "warning" :
                          transactionDetails?.status === "cancelled" ? "destructive" :
                          "outline"
                        } className="font-medium">
                          {t(`financial.transactions.status_${transactionDetails?.status || 'pending'}`, "قيد الانتظار")}
                        </Badge>
                      </dd>
                    </dl>

                    <div className="mt-5 pt-4 border-t border-dashed flex justify-between text-xs text-muted-foreground">
                      <div>
                        <div>{t("financial.transactions.createdAt", "تاريخ الإنشاء")}</div>
                        <div className="font-medium">{formatDate(transactionDetails?.createdAt || new Date())}</div>
                      </div>
                      <div className="text-end">
                        <div>{t("financial.transactions.lastUpdated", "آخر تحديث")}</div>
                        <div className="font-medium">{formatDate(transactionDetails?.updatedAt || new Date())}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* معلومات الحسابات / Accounts Information */}
                <Card className="relative overflow-hidden border-primary/20">
                  <div className="absolute -top-16 -left-16 w-32 h-32 bg-primary/5 rounded-full"></div>
                  <div className="absolute top-0 left-0 w-full h-1 bg-primary"></div>
                  <CardHeader className="pb-2 pt-5 border-b">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <FolderIcon className="h-5 w-5 text-primary" />
                        {t("financial.transactions.accountsInfo", "معلومات الحسابات")}
                      </CardTitle>
                      <div className="text-sm font-semibold text-primary">
                        {t("financial.transactions.doubleEntrySystem", "نظام القيد المزدوج")}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="grid grid-cols-1 gap-4 mb-4">
                      <div className="flex flex-col sm:flex-row gap-3">
                        <div className="flex-1 border rounded-lg p-3 bg-red-50 dark:bg-red-950/20">
                          <div className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                            <ArrowUpIcon className="h-3 w-3" />
                            {t("financial.transactions.from", "من")}
                          </div>
                          {transactionDetails?.debitAccount ? (
                            <>
                              <div className="font-bold">{transactionDetails.debitAccount.name}</div>
                              <div className="text-xs font-mono text-muted-foreground border-t pt-1 mt-1">{transactionDetails.debitAccount.code}</div>
                            </>
                          ) : (
                            <div className="p-1.5 text-muted-foreground italic">{t("common.not_available", "غير متوفر")}</div>
                          )}
                        </div>
                        
                        <div className="flex items-center justify-center text-muted-foreground">
                          <ArrowRightIcon className="h-4 w-4 rotate-180" />
                        </div>
                        
                        <div className="flex-1 border rounded-lg p-3 bg-green-50 dark:bg-green-950/20">
                          <div className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                            <ArrowDownIcon className="h-3 w-3" />
                            {t("financial.transactions.to", "إلى")}
                          </div>
                          {transactionDetails?.creditAccount ? (
                            <>
                              <div className="font-bold">{transactionDetails.creditAccount.name}</div>
                              <div className="text-xs font-mono text-muted-foreground border-t pt-1 mt-1">{transactionDetails.creditAccount.code}</div>
                            </>
                          ) : (
                            <div className="p-1.5 text-muted-foreground italic">{t("common.not_available", "غير متوفر")}</div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="grid gap-3 mt-5">
                      {transactionDetails?.project && (
                        <div className="border rounded-lg p-3">
                          <div className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                            <Building2 className="h-3 w-3" />
                            {t("financial.transactions.project", "المشروع")}
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="font-semibold">
                              {transactionDetails.project.name}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              ID: {transactionDetails.project.id || '-'}
                            </span>
                          </div>
                        </div>
                      )}
                      
                      {transactionDetails?.costCategory && (
                        <div className="border rounded-lg p-3">
                          <div className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                            <TagsIcon className="h-3 w-3" />
                            {t("financial.transactions.category", "الفئة")}
                          </div>
                          <Badge variant="secondary" className="font-normal">
                            {transactionDetails.costCategory}
                          </Badge>
                        </div>
                      )}
                    </div>

                    <div className="mt-4 p-3 bg-muted/10 rounded-lg border border-dashed text-xs text-center text-muted-foreground">
                      {t("financial.transactions.accountingNote", "تعكس هذه المعاملة حركة القيد المحاسبي وفقًا لمبادئ المحاسبة المتعارف عليها")}
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {transactionDetails.description && (
                <Card className="mb-6">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{t("financial.transactions.description")}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-line">{transactionDetails.description}</p>
                  </CardContent>
                </Card>
              )}
              
              {transactionDetails.journalEntry && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-muted-foreground" />
                      {t("financial.transactions.journalEntry")}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <dl className="grid grid-cols-3 gap-2 text-sm mb-4">
                      <dt className="text-muted-foreground">{t("financial.transactions.journalNumber")}</dt>
                      <dd className="col-span-2 font-medium">{transactionDetails.journalEntry.journalNumber}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.journalDate")}</dt>
                      <dd className="col-span-2">{formatDate(transactionDetails.journalEntry.journalDate)}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.totalDebit")}</dt>
                      <dd className="col-span-2 text-green-600 font-medium">
                        {formatAmount(transactionDetails.journalEntry.totalDebit)}
                      </dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.totalCredit")}</dt>
                      <dd className="col-span-2 text-red-600 font-medium">
                        {formatAmount(transactionDetails.journalEntry.totalCredit)}
                      </dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.balanced")}</dt>
                      <dd className="col-span-2">
                        <Badge variant={transactionDetails.journalEntry.isBalanced ? "success" : "destructive"}>
                          {transactionDetails.journalEntry.isBalanced
                            ? t("common.yes")
                            : t("common.no")}
                        </Badge>
                      </dd>
                    </dl>
                    
                    <div className="border rounded-md overflow-hidden">
                      <div className="bg-muted/50 p-2 text-sm font-medium border-b">
                        {t("financial.transactions.journalLines")}
                      </div>
                      <table className="w-full text-sm">
                        <thead className="bg-muted/30 border-b">
                          <tr>
                            <th className="py-2 px-4 text-right font-medium text-muted-foreground">
                              {t("financial.transactions.accountCode")}
                            </th>
                            <th className="py-2 px-4 text-right font-medium text-muted-foreground">
                              {t("financial.transactions.account")}
                            </th>
                            <th className="py-2 px-4 text-right font-medium text-muted-foreground">
                              {t("financial.transactions.debit")}
                            </th>
                            <th className="py-2 px-4 text-right font-medium text-muted-foreground">
                              {t("financial.transactions.credit")}
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {transactionDetails.journalEntry.lines.map((line) => (
                            <tr key={line.id}>
                              <td className="py-2 px-4 text-right font-mono">
                                {line.accountCode}
                              </td>
                              <td className="py-2 px-4 text-right">
                                {line.accountName}
                              </td>
                              <td className="py-2 px-4 text-right font-medium text-green-600">
                                {line.debitAmount > 0 ? 
                                  formatAmount(line.debitAmount)
                                  : "—"}
                              </td>
                              <td className="py-2 px-4 text-right font-medium text-red-600">
                                {line.creditAmount > 0 ? 
                                  formatAmount(line.creditAmount)
                                  : "—"}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot className="bg-muted/20 border-t font-medium">
                          <tr>
                            <th className="py-2 px-4 text-right" colSpan={2}>
                              {t("financial.transactions.total")}
                            </th>
                            <th className="py-2 px-4 text-right text-green-600">
                              {formatAmount(transactionDetails.journalEntry.totalDebit)}
                            </th>
                            <th className="py-2 px-4 text-right text-red-600">
                              {formatAmount(transactionDetails.journalEntry.totalCredit)}
                            </th>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Phase 3 Integration Components */}
              {transactionDetails && (
                <>
                  {/* Transaction Approval System */}
                  <TransactionApprovalSystem
                    transactionId={transactionDetails.id}
                    status={transactionDetails.status}
                    amount={transactionDetails.amount}
                    type={transactionDetails.type}
                    onStatusChange={(newStatus) => {
                      // Update the transaction details locally with the new status
                      transactionDetails.status = newStatus;
                      // Trigger a refetch to get updated transaction details
                      refetchTransactionDetails();
                    }}
                  />
                  
                  {/* Account Balance Impact */}
                  <AccountBalanceImpact
                    debitAccountId={transactionDetails.debitAccountId}
                    creditAccountId={transactionDetails.creditAccountId}
                    amount={transactionDetails.amount}
                    transactionType={transactionDetails.type}
                    className="mt-4"
                  />
                  
                  {/* Project Budget Impact - only if project is selected */}
                  {transactionDetails.projectId && (
                    <ProjectBudgetImpact
                      projectId={transactionDetails.projectId}
                      amount={transactionDetails.amount}
                      transactionType={transactionDetails.type}
                      className="mt-4"
                    />
                  )}
                  
                  {/* Certificate Payment Tracker - only for income transactions that might be linked to certificates */}
                  {transactionDetails.type === "income" && (
                    <CertificatePaymentTracker
                      certificateId={transactionDetails.relatedCertificateId || null}
                      amount={transactionDetails.amount}
                      transactionType={transactionDetails.type}
                      className="mt-4"
                    />
                  )}
                </>
              )}
              </div>
            </div>
          ) : (
            <div className="text-center p-8">
              <CircleAlert className="h-8 w-8 text-red-500 mx-auto mb-4" />
              <p className="text-muted-foreground">{t("financial.transactions.transactionNotFound")}</p>
            </div>
          )}
          
          <DialogFooter className="bg-muted/20 px-6 py-4">
            <Button variant="outline" onClick={() => setIsViewDetailsOpen(false)}>
              {t("common.close")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}