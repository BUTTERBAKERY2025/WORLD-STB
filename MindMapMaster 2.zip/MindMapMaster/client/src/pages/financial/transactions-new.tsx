import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { SearchIcon, Plus, Filter, ArrowUpRight, ArrowDownLeft, Repeat, Eye, CalendarIcon, Loader2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AccountTreeSelector } from "@/components/financial/account-tree-selector";
import { format } from "date-fns";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// Interface for API transaction data
interface Transaction {
  id: number;
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: string | Date;
  description: string | null;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number;
  creditAccountId: number;
  referenceNumber: string;
  status: string;
  createdAt: string | Date;
  updatedAt: string | Date;
  debitAccount: { id?: number; name: string; code: string; type?: string };
  creditAccount: { id?: number; name: string; code: string; type?: string };
  project: { id?: number; name: string } | null;
}

interface Account {
  id: number;
  code: string;
  name: string;
  type: string;
  level: number;
  hasChildren: boolean;
  parentId?: number;
}

interface Project {
  id: number;
  name: string;
}

interface CostCategory {
  id: string;
  name: string;
}

interface TransactionFormData {
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: Date;
  description: string;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number | null;
  creditAccountId: number | null;
  referenceNumber: string;
  createJournalEntry: boolean;
}

export default function FinancialTransactions() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State for filters
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [projectFilter, setProjectFilter] = useState<number | "all">("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
  const [selectedTransactionId, setSelectedTransactionId] = useState<number | null>(null);
  
  // Form state for new transaction
  const [newTransaction, setNewTransaction] = useState<TransactionFormData>({
    type: "income",
    amount: 0,
    transactionDate: new Date(),
    description: "",
    costCategory: null,
    projectId: null,
    debitAccountId: null,
    creditAccountId: null,
    referenceNumber: "",
    createJournalEntry: true
  });
  
  // Query parameters for transactions
  const [queryParams, setQueryParams] = useState({
    page: 1,
    limit: 10,
    type: typeFilter !== "all" ? typeFilter : undefined,
    projectId: projectFilter !== "all" ? projectFilter : undefined,
    search: searchQuery || undefined
  });
  
  // Fetch transactions
  const { 
    data: transactionsData, 
    isLoading: isLoadingTransactions,
    isError: isTransactionsError,
    error: transactionsError
  } = useQuery({
    queryKey: ['/api/financial/transactions', queryParams],
    refetchOnWindowFocus: false
  });
  
  // Fetch accounts for dropdown
  const { 
    data: accounts,
    isLoading: isLoadingAccounts
  } = useQuery({
    queryKey: ['/api/accounts'],
    refetchOnWindowFocus: false
  });
  
  // Fetch projects for dropdown
  const { 
    data: projects,
    isLoading: isLoadingProjects
  } = useQuery({
    queryKey: ['/api/financial/projects'],
    refetchOnWindowFocus: false
  });
  
  // Fetch cost categories for dropdown
  const { 
    data: costCategories,
    isLoading: isLoadingCategories
  } = useQuery({
    queryKey: ['/api/financial/cost-categories'],
    refetchOnWindowFocus: false
  });
  
  // Fetch transaction details when viewing a specific transaction
  const { 
    data: transactionDetails,
    isLoading: isLoadingDetails
  } = useQuery({
    queryKey: ['/api/financial/transactions', selectedTransactionId],
    enabled: selectedTransactionId !== null && isViewDetailsOpen,
    refetchOnWindowFocus: false
  });
  
  // Create new transaction mutation
  const createTransactionMutation = useMutation({
    mutationFn: (data: TransactionFormData) => {
      // تأكد من أن التاريخ هو كائن Date صالح وتحويله لنص
      const processedData = {
        ...data,
        // إذا كان التاريخ موجوداً، قم بتحويله إلى نص بصيغة ISO
        transactionDate: data.transactionDate ? new Date(data.transactionDate).toISOString() : null
      };
      return apiRequest("POST", "/api/financial/transactions", processedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.successTitle"),
        description: t("financial.transactions.createSuccess"),
      });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.errorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Reset form after submission
  const resetForm = () => {
    setNewTransaction({
      type: "income",
      amount: 0,
      transactionDate: new Date(),
      description: "",
      costCategory: null,
      projectId: null,
      debitAccountId: null,
      creditAccountId: null,
      referenceNumber: "",
      createJournalEntry: true
    });
  };
  
  // Update query params when filters change
  useEffect(() => {
    setQueryParams({
      page: 1,
      limit: 10,
      type: typeFilter !== "all" ? typeFilter : undefined,
      projectId: projectFilter !== "all" ? projectFilter : undefined,
      search: searchQuery || undefined
    });
  }, [typeFilter, projectFilter, searchQuery]);
  
  // Handle view transaction details
  const handleViewDetails = (id: number) => {
    setSelectedTransactionId(id);
    setIsViewDetailsOpen(true);
  };
  
  // Handle form input changes
  const handleInputChange = (field: keyof TransactionFormData, value: any) => {
    setNewTransaction(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle transaction submission
  const handleAddTransaction = () => {
    // Validation
    if (!newTransaction.amount || newTransaction.amount <= 0) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.amountRequired"),
        variant: "destructive"
      });
      return;
    }
    
    if (!newTransaction.transactionDate) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.dateRequired"),
        variant: "destructive"
      });
      return;
    }
    
    if (!newTransaction.debitAccountId) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.debitAccountRequired"),
        variant: "destructive"
      });
      return;
    }
    
    if (!newTransaction.creditAccountId) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.creditAccountRequired"),
        variant: "destructive"
      });
      return;
    }
    
    // Submit the form data
    createTransactionMutation.mutate(newTransaction);
  };
  
  // Helper function to get icon for transaction type
  const getTypeIcon = (type: Transaction["type"]) => {
    switch (type) {
      case "income":
        return <ArrowUpRight className="h-4 w-4 text-green-500" />;
      case "expense":
        return <ArrowDownLeft className="h-4 w-4 text-red-500" />;
      case "transfer":
        return <Repeat className="h-4 w-4 text-blue-500" />;
    }
  };

  // Helper function to get badge for transaction type
  const getTypeBadge = (type: Transaction["type"]) => {
    switch (type) {
      case "income":
        return <Badge variant="success">{t("financial.transactions.income")}</Badge>;
      case "expense":
        return <Badge variant="destructive">{t("financial.transactions.expense")}</Badge>;
      case "transfer":
        return <Badge variant="default">{t("financial.transactions.transfer")}</Badge>;
    }
  };

  // Format currency amount
  const formatAmount = (amount: number, type: Transaction["type"]) => {
    const formatted = new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
    
    if (type === "expense") {
      return <span className="text-red-500">- {formatted}</span>;
    } else if (type === "income") {
      return <span className="text-green-500">{formatted}</span>;
    } else {
      return <span className="text-blue-500">{formatted}</span>;
    }
  };
  
  // Format date to display
  const formatDate = (date: string | Date | null | undefined) => {
    if (!date) return "-";
    try {
      return format(new Date(date), "yyyy/MM/dd");
    } catch (error) {
      console.error("Invalid date format:", date);
      return "-";
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{t("financial.transactions.title")}</h1>
            <p className="text-muted-foreground">{t("financial.transactions.list")}</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                {t("financial.transactions.add")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[700px] p-0 overflow-hidden">
              <DialogHeader className="bg-gradient-to-l from-primary/10 to-transparent p-6 border-b">
                <div className="flex items-center gap-3 mb-1">
                  <div className="bg-primary/20 rounded-full p-1.5">
                    <Plus className="h-5 w-5 text-primary" />
                  </div>
                  <DialogTitle className="text-xl font-bold text-primary">{t("financial.transactions.addNew")}</DialogTitle>
                </div>
                <DialogDescription className="text-[15px]">
                  {t("financial.transactions.addNewDescription")}
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-6 p-6 max-h-[70vh] overflow-y-auto">
                {/* نوع المعاملة - تعديل التصميم مع أيقونات وألوان لكل نوع */}
                <div className="space-y-3">
                  <Label htmlFor="transaction-type" className="text-[15px] font-medium">
                    {t("financial.transactions.type")}
                  </Label>
                  <div className="grid grid-cols-3 gap-3">
                    <div 
                      className={cn(
                        "flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-all",
                        newTransaction.type === "income" 
                          ? "bg-green-50 border-green-300 shadow-sm" 
                          : "hover:bg-gray-50 border-gray-200"
                      )}
                      onClick={() => handleInputChange("type", "income")}
                    >
                      <div className={cn(
                        "rounded-full p-2 transition-colors",
                        newTransaction.type === "income" ? "bg-green-100" : "bg-gray-100"
                      )}>
                        <ArrowUpRight className={cn(
                          "h-5 w-5",
                          newTransaction.type === "income" ? "text-green-600" : "text-gray-500"  
                        )} />
                      </div>
                      <div>
                        <div className={cn(
                          "font-medium text-[15px]",
                          newTransaction.type === "income" ? "text-green-700" : "text-gray-700"
                        )}>
                          {t("financial.transactions.income")}
                        </div>
                        <div className="text-xs text-gray-500">
                          {t("financial.transactions.incomeDescription")}
                        </div>
                      </div>
                    </div>
                    
                    <div 
                      className={cn(
                        "flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-all",
                        newTransaction.type === "expense" 
                          ? "bg-red-50 border-red-300 shadow-sm" 
                          : "hover:bg-gray-50 border-gray-200"
                      )}
                      onClick={() => handleInputChange("type", "expense")}
                    >
                      <div className={cn(
                        "rounded-full p-2 transition-colors",
                        newTransaction.type === "expense" ? "bg-red-100" : "bg-gray-100"
                      )}>
                        <ArrowDownLeft className={cn(
                          "h-5 w-5",
                          newTransaction.type === "expense" ? "text-red-600" : "text-gray-500"  
                        )} />
                      </div>
                      <div>
                        <div className={cn(
                          "font-medium text-[15px]",
                          newTransaction.type === "expense" ? "text-red-700" : "text-gray-700"
                        )}>
                          {t("financial.transactions.expense")}
                        </div>
                        <div className="text-xs text-gray-500">
                          {t("financial.transactions.expenseDescription")}
                        </div>
                      </div>
                    </div>
                    
                    <div 
                      className={cn(
                        "flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-all",
                        newTransaction.type === "transfer" 
                          ? "bg-blue-50 border-blue-300 shadow-sm" 
                          : "hover:bg-gray-50 border-gray-200"
                      )}
                      onClick={() => handleInputChange("type", "transfer")}
                    >
                      <div className={cn(
                        "rounded-full p-2 transition-colors",
                        newTransaction.type === "transfer" ? "bg-blue-100" : "bg-gray-100"
                      )}>
                        <Repeat className={cn(
                          "h-5 w-5",
                          newTransaction.type === "transfer" ? "text-blue-600" : "text-gray-500"  
                        )} />
                      </div>
                      <div>
                        <div className={cn(
                          "font-medium text-[15px]",
                          newTransaction.type === "transfer" ? "text-blue-700" : "text-gray-700"
                        )}>
                          {t("financial.transactions.transfer")}
                        </div>
                        <div className="text-xs text-gray-500">
                          {t("financial.transactions.transferDescription")}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* القيمة المالية */}
                  <div className="space-y-3">
                    <Label htmlFor="amount" className="text-[15px] font-medium">
                      {t("financial.transactions.amount")}
                    </Label>
                    <div className="relative">
                      <span className="absolute right-3 top-3 text-gray-500 font-medium">ر.س</span>
                      <Input 
                        id="amount" 
                        type="number" 
                        value={newTransaction.amount || ''} 
                        onChange={(e) => handleInputChange("amount", Number(e.target.value))}
                        className="pr-12 py-6 text-lg font-medium"
                        placeholder="0"
                      />
                    </div>
                  </div>
                  
                  {/* التاريخ */}
                  <div className="space-y-3">
                    <Label className="text-[15px] font-medium">
                      {t("financial.transactions.date")}
                    </Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-right py-6 text-[15px]"
                        >
                          {newTransaction.transactionDate ? (
                            format(newTransaction.transactionDate, "yyyy/MM/dd")
                          ) : (
                            <span className="text-muted-foreground">{t("financial.transactions.selectDate")}</span>
                          )}
                          <CalendarIcon className="ml-auto h-5 w-5 opacity-70" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={newTransaction.transactionDate}
                          onSelect={(date) => handleInputChange("transactionDate", date as Date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* الحساب المدين */}
                  <div className="space-y-3">
                    <Label htmlFor="debit-account" className="text-[15px] font-medium">
                      {t("financial.transactions.debitAccount")}
                    </Label>
                    <AccountTreeSelector
                      accounts={accounts || []}
                      value={newTransaction.debitAccountId}
                      onChange={(accountId) => handleInputChange("debitAccountId", accountId)}
                      placeholder={t("financial.transactions.selectAccount")}
                      isLoading={isLoadingAccounts}
                    />
                  </div>
                  
                  {/* الحساب الدائن */}
                  <div className="space-y-3">
                    <Label htmlFor="credit-account" className="text-[15px] font-medium">
                      {t("financial.transactions.creditAccount")}
                    </Label>
                    <AccountTreeSelector
                      accounts={accounts || []}
                      value={newTransaction.creditAccountId}
                      onChange={(accountId) => handleInputChange("creditAccountId", accountId)}
                      placeholder={t("financial.transactions.selectAccount")}
                      isLoading={isLoadingAccounts}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* المشروع */}
                  {newTransaction.type !== "transfer" && (
                    <div className="space-y-3">
                      <Label htmlFor="project" className="text-[15px] font-medium">
                        {t("financial.transactions.project")}
                      </Label>
                      <Select
                        value={newTransaction.projectId?.toString() || ""}
                        onValueChange={(value) => handleInputChange("projectId", value ? parseInt(value) : null)}
                      >
                        <SelectTrigger id="project" className="py-6">
                          <SelectValue placeholder={t("financial.transactions.selectProject")} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="null">
                            {t("financial.transactions.noProject")}
                          </SelectItem>
                          {isLoadingProjects ? (
                            <div className="flex items-center justify-center p-4">
                              <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              {t("common.loading")}
                            </div>
                          ) : projects?.map((project) => (
                            <SelectItem key={project.id} value={project.id.toString()}>
                              {project.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  {/* فئة التكلفة (فقط للنفقات) */}
                  {newTransaction.type === "expense" && (
                    <div className="space-y-3">
                      <Label htmlFor="costCategory" className="text-[15px] font-medium">
                        {t("financial.transactions.category")}
                      </Label>
                      <Select
                        value={newTransaction.costCategory || ""}
                        onValueChange={(value) => handleInputChange("costCategory", value)}
                      >
                        <SelectTrigger id="costCategory" className="py-6">
                          <SelectValue placeholder={t("financial.transactions.selectCategory")} />
                        </SelectTrigger>
                        <SelectContent>
                          {isLoadingCategories ? (
                            <div className="flex items-center justify-center p-4">
                              <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              {t("common.loading")}
                            </div>
                          ) : costCategories?.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  {/* رقم المرجع */}
                  <div className="space-y-3">
                    <Label htmlFor="reference" className="text-[15px] font-medium">
                      {t("financial.transactions.reference")}
                    </Label>
                    <Input
                      id="reference"
                      value={newTransaction.referenceNumber || ""}
                      onChange={(e) => handleInputChange("referenceNumber", e.target.value)}
                      className="py-6"
                      placeholder={t("financial.transactions.referencePlaceholder")}
                    />
                  </div>
                </div>
                
                {/* الوصف */}
                <div className="space-y-3">
                  <Label htmlFor="description" className="text-[15px] font-medium">
                    {t("financial.transactions.description")}
                  </Label>
                  <Textarea
                    id="description"
                    value={newTransaction.description || ""}
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    rows={3}
                    className="resize-none"
                  />
                </div>
              </div>
              
              <DialogFooter className="bg-gray-50 px-6 py-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  {t("common.cancel")}
                </Button>
                <Button 
                  onClick={handleAddTransaction}
                  disabled={createTransactionMutation.isPending}
                >
                  {createTransactionMutation.isPending && (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  )}
                  {t("financial.transactions.save")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      
        <div className="flex flex-col gap-4">
          {/* قسم الفلترة والبحث */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative w-full md:w-1/3">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder={t("financial.transactions.search")}
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2 items-center">
              <Select
                value={typeFilter}
                onValueChange={setTypeFilter}
              >
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder={t("financial.transactions.filterByType")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("financial.transactions.allTypes")}</SelectItem>
                  <SelectItem value="income">{t("financial.transactions.income")}</SelectItem>
                  <SelectItem value="expense">{t("financial.transactions.expense")}</SelectItem>
                  <SelectItem value="transfer">{t("financial.transactions.transfer")}</SelectItem>
                </SelectContent>
              </Select>
              
              <Select
                value={projectFilter === "all" ? "all" : projectFilter.toString()}
                onValueChange={(value) => setProjectFilter(value === "all" ? "all" : parseInt(value))}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder={t("financial.transactions.filterByProject")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("financial.transactions.allProjects")}</SelectItem>
                  {!isLoadingProjects && projects?.map((project) => (
                    <SelectItem key={project.id} value={project.id.toString()}>{project.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="icon" title={t("financial.transactions.moreFilters")}>
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* جدول المعاملات المالية */}
          <Card>
            <CardHeader className="py-4">
              <CardTitle>{t("financial.transactions.recentTransactions")}</CardTitle>
              <CardDescription>
                {isLoadingTransactions 
                  ? t("common.loading") 
                  : t("financial.transactions.showing", { count: transactionsData?.data?.length || 0 })}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Tabs defaultValue="all" className="p-0">
                <div className="border-b px-6">
                  <TabsList className="mb-0">
                    <TabsTrigger value="all">{t("financial.transactions.allTransactions")}</TabsTrigger>
                    <TabsTrigger value="income">{t("financial.transactions.incomeOnly")}</TabsTrigger>
                    <TabsTrigger value="expense">{t("financial.transactions.expensesOnly")}</TabsTrigger>
                    <TabsTrigger value="transfer">{t("financial.transactions.transfersOnly")}</TabsTrigger>
                  </TabsList>
                </div>
                
                {isLoadingTransactions ? (
                  <div className="flex items-center justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary mr-4" />
                    <p>{t("common.loading")}</p>
                  </div>
                ) : isTransactionsError ? (
                  <Alert variant="destructive" className="m-6">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>{t("common.error")}</AlertTitle>
                    <AlertDescription>
                      {(transactionsError as Error)?.message || t("financial.transactions.errorLoading")}
                    </AlertDescription>
                  </Alert>
                ) : !transactionsData?.data || transactionsData.data.length === 0 ? (
                  <div className="text-center p-8">
                    <p className="text-muted-foreground">{t("financial.transactions.noTransactionsFound")}</p>
                  </div>
                ) : (
                  <TabsContent value="all" className="p-0 m-0">
                    <table className="w-full">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground w-16">
                            {t("financial.transactions.id")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                            {t("financial.transactions.reference")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                            {t("financial.transactions.date")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                            {t("financial.transactions.type")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                            {t("financial.transactions.description")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                            {t("financial.transactions.amount")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                            {t("financial.transactions.account")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                            {t("financial.transactions.project")}
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground w-20">
                            {t("common.actions")}
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {transactionsData.data.map((transaction) => (
                          <tr key={transaction.id} className="hover:bg-muted/30">
                            <td className="text-right py-3 px-4 text-sm">
                              {transaction.id}
                            </td>
                            <td className="text-right py-3 px-4 text-sm font-medium">
                              {transaction.referenceNumber}
                            </td>
                            <td className="text-right py-3 px-4 text-sm text-muted-foreground">
                              {formatDate(transaction.transactionDate)}
                            </td>
                            <td className="text-right py-3 px-4 text-sm">
                              <div className="flex justify-end items-center gap-1">
                                {getTypeIcon(transaction.type)}
                                {getTypeBadge(transaction.type)}
                              </div>
                            </td>
                            <td className="text-right py-3 px-4 text-sm text-muted-foreground">
                              {transaction.description}
                            </td>
                            <td className="text-right py-3 px-4 text-sm font-medium">
                              {formatAmount(transaction.amount, transaction.type)}
                            </td>
                            <td className="text-right py-3 px-4 text-sm text-muted-foreground">
                              {transaction.debitAccount.name}
                            </td>
                            <td className="text-right py-3 px-4 text-sm text-muted-foreground">
                              {transaction.project?.name || "—"}
                            </td>
                            <td className="text-right py-3 px-4 text-sm">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title={t("common.viewDetails")}
                                onClick={() => handleViewDetails(transaction.id)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    
                    {/* الترقيم الصفحي */}
                    {transactionsData.pagination && transactionsData.pagination.totalPages > 1 && (
                      <div className="flex justify-between items-center p-4 border-t bg-muted/20">
                        <div className="text-sm text-muted-foreground">
                          {t("pagination.showing", { 
                            from: (transactionsData.pagination.page - 1) * transactionsData.pagination.limit + 1,
                            to: Math.min(
                              transactionsData.pagination.page * transactionsData.pagination.limit,
                              transactionsData.pagination.totalItems
                            ),
                            total: transactionsData.pagination.totalItems
                          })}
                        </div>
                        <div className="flex gap-1">
                          <Button 
                            variant="outline" 
                            size="sm"
                            disabled={queryParams.page === 1}
                            onClick={() => setQueryParams(prev => ({ ...prev, page: prev.page - 1 }))}
                          >
                            {t("pagination.previous")}
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            disabled={queryParams.page >= transactionsData.pagination.totalPages}
                            onClick={() => setQueryParams(prev => ({ ...prev, page: prev.page + 1 }))}
                          >
                            {t("pagination.next")}
                          </Button>
                        </div>
                      </div>
                    )}
                  </TabsContent>
                )}
                
                {/* Similar TabsContent for other tabs (income, expense, transfer) would be here */}
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* نافذة عرض تفاصيل المعاملة */}
      <Dialog open={isViewDetailsOpen} onOpenChange={setIsViewDetailsOpen}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          <DialogHeader className="bg-gradient-to-l from-primary/10 to-transparent p-6 border-b">
            <div className="flex items-center gap-3 mb-1">
              <div className="bg-primary/20 rounded-full p-1.5">
                <Eye className="h-5 w-5 text-primary" />
              </div>
              <DialogTitle className="text-xl font-bold text-primary">
                {t("financial.transactions.transactionDetails")}
              </DialogTitle>
            </div>
            <DialogDescription className="text-[15px]">
              {isLoadingDetails 
                ? t("common.loading")
                : t("financial.transactions.transactionDetailsDesc", { id: transactionDetails?.id })}
            </DialogDescription>
          </DialogHeader>
          
          {isLoadingDetails ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary mr-4" />
              <p>{t("common.loading")}</p>
            </div>
          ) : transactionDetails ? (
            <div className="p-6 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{t("financial.transactions.basicInfo")}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <dl className="grid grid-cols-3 gap-2 text-sm">
                      <dt className="text-muted-foreground">{t("financial.transactions.id")}</dt>
                      <dd className="col-span-2 font-medium">{transactionDetails.id}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.type")}</dt>
                      <dd className="col-span-2">
                        <div className="flex items-center gap-1">
                          {getTypeIcon(transactionDetails.type)}
                          {getTypeBadge(transactionDetails.type)}
                        </div>
                      </dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.amount")}</dt>
                      <dd className="col-span-2 font-medium">
                        {formatAmount(transactionDetails.amount, transactionDetails.type)}
                      </dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.date")}</dt>
                      <dd className="col-span-2">{formatDate(transactionDetails.transactionDate)}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.reference")}</dt>
                      <dd className="col-span-2">{transactionDetails.referenceNumber}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.status")}</dt>
                      <dd className="col-span-2">
                        <Badge variant={transactionDetails.status === "completed" ? "success" : "default"}>
                          {transactionDetails.status}
                        </Badge>
                      </dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.createdAt")}</dt>
                      <dd className="col-span-2">{formatDate(transactionDetails.createdAt)}</dd>
                    </dl>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{t("financial.transactions.accountsInfo")}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <dl className="grid grid-cols-3 gap-2 text-sm">
                      <dt className="text-muted-foreground">{t("financial.transactions.debitAccount")}</dt>
                      <dd className="col-span-2 font-medium">
                        {transactionDetails.debitAccount.code} - {transactionDetails.debitAccount.name}
                      </dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.debitAccountType")}</dt>
                      <dd className="col-span-2">{transactionDetails.debitAccount.type}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.creditAccount")}</dt>
                      <dd className="col-span-2 font-medium">
                        {transactionDetails.creditAccount.code} - {transactionDetails.creditAccount.name}
                      </dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.creditAccountType")}</dt>
                      <dd className="col-span-2">{transactionDetails.creditAccount.type}</dd>
                      
                      {transactionDetails.project && (
                        <>
                          <dt className="text-muted-foreground">{t("financial.transactions.project")}</dt>
                          <dd className="col-span-2">{transactionDetails.project.name}</dd>
                        </>
                      )}
                      
                      {transactionDetails.costCategory && (
                        <>
                          <dt className="text-muted-foreground">{t("financial.transactions.category")}</dt>
                          <dd className="col-span-2">{transactionDetails.costCategory}</dd>
                        </>
                      )}
                    </dl>
                  </CardContent>
                </Card>
              </div>
              
              {transactionDetails.description && (
                <Card className="mb-6">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{t("financial.transactions.description")}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-line">{transactionDetails.description}</p>
                  </CardContent>
                </Card>
              )}
              
              {transactionDetails.journalEntry && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{t("financial.transactions.journalEntry")}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <dl className="grid grid-cols-3 gap-2 text-sm mb-4">
                      <dt className="text-muted-foreground">{t("financial.transactions.journalNumber")}</dt>
                      <dd className="col-span-2 font-medium">{transactionDetails.journalEntry.journalNumber}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.journalDate")}</dt>
                      <dd className="col-span-2">{formatDate(transactionDetails.journalEntry.journalDate)}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.totalDebit")}</dt>
                      <dd className="col-span-2">{formatAmount(transactionDetails.journalEntry.totalDebit, "income")}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.totalCredit")}</dt>
                      <dd className="col-span-2">{formatAmount(transactionDetails.journalEntry.totalCredit, "expense")}</dd>
                      
                      <dt className="text-muted-foreground">{t("financial.transactions.balanced")}</dt>
                      <dd className="col-span-2">
                        <Badge variant={transactionDetails.journalEntry.isBalanced ? "success" : "destructive"}>
                          {transactionDetails.journalEntry.isBalanced
                            ? t("financial.transactions.yes")
                            : t("financial.transactions.no")}
                        </Badge>
                      </dd>
                    </dl>
                    
                    <div className="border rounded-md overflow-hidden">
                      <div className="bg-muted/50 p-2 text-sm font-medium border-b">
                        {t("financial.transactions.journalLines")}
                      </div>
                      <table className="w-full text-sm">
                        <thead className="bg-muted/30 border-b">
                          <tr>
                            <th className="py-2 px-4 text-right font-medium text-muted-foreground">
                              {t("financial.transactions.account")}
                            </th>
                            <th className="py-2 px-4 text-right font-medium text-muted-foreground">
                              {t("financial.transactions.debit")}
                            </th>
                            <th className="py-2 px-4 text-right font-medium text-muted-foreground">
                              {t("financial.transactions.credit")}
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {transactionDetails.journalEntry.lines.map((line) => (
                            <tr key={line.id}>
                              <td className="py-2 px-4 text-right">
                                {line.accountName}
                              </td>
                              <td className="py-2 px-4 text-right font-medium text-green-600">
                                {line.debitAmount > 0 ? 
                                  new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(line.debitAmount)
                                  : "—"}
                              </td>
                              <td className="py-2 px-4 text-right font-medium text-red-600">
                                {line.creditAmount > 0 ? 
                                  new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(line.creditAmount)
                                  : "—"}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot className="bg-muted/20 border-t">
                          <tr>
                            <th className="py-2 px-4 text-right font-medium">
                              {t("financial.transactions.total")}
                            </th>
                            <th className="py-2 px-4 text-right font-medium text-green-600">
                              {new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(transactionDetails.journalEntry.totalDebit)}
                            </th>
                            <th className="py-2 px-4 text-right font-medium text-red-600">
                              {new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(transactionDetails.journalEntry.totalCredit)}
                            </th>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <div className="text-center p-8">
              <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-4" />
              <p className="text-muted-foreground">{t("financial.transactions.transactionNotFound")}</p>
            </div>
          )}
          
          <DialogFooter className="bg-gray-50 px-6 py-4">
            <Button variant="outline" onClick={() => setIsViewDetailsOpen(false)}>
              {t("common.close")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}