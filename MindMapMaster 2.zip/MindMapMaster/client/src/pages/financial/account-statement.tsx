import React, { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import PageLayout from "../../components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePicker } from "../../components/ui/date-picker";
import { 
  Filter, 
  FileDown, 
  FileText, 
  Printer, 
  Mail,
  Search,
  Settings2,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Settings,
  ListFilter,
  Eye,
  EyeOff,
  Calendar
} from "lucide-react";
import { printDocument } from "@/utils/printUtils";
import { format, subMonths, parseISO } from "date-fns";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { ar } from 'date-fns/locale';
import { ExportMenu } from "../../components/financial/ExportMenu";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// تعريف نموذج نموذج البحث
const formSchema = z.object({
  accountId: z.string().min(1, "يجب اختيار حساب"),
  startDate: z.date(),
  endDate: z.date(),
  transactionType: z.string().default("all"),
});

type FormValues = z.infer<typeof formSchema>;

export default function AccountStatementPage() {
  const { t } = useTranslation();
  const [formattedStatement, setFormattedStatement] = useState<any>(null);
  const tableRef = useRef<HTMLTableElement>(null);
  
  // حالة توسيع/طي التفاصيل
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});
  const [expandAll, setExpandAll] = useState<boolean>(false);
  
  // خيارات العرض للجدول
  const [showOptions, setShowOptions] = useState({
    showDate: true,
    showReference: true,
    showDescription: true,
    showDebit: true,
    showCredit: true,
    showBalance: true,
  });

  // إعداد النموذج مع قيم افتراضية
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      accountId: "",
      startDate: subMonths(new Date(), 1), // تاريخ البداية قبل شهر من اليوم
      endDate: new Date(), // تاريخ النهاية اليوم
      transactionType: "all",
    },
  });

  // الحصول على قائمة الحسابات
  const { data: accounts, isLoading: isLoadingAccounts } = useQuery({
    queryKey: ['/api/financial/accounts'],
    enabled: true,
  });

  // الحصول على كشف الحساب بناءً على المعايير المحددة
  const { data: statement, isLoading: isLoadingStatement, refetch } = useQuery({
    queryKey: ['/api/financial/account-statement'],
    queryFn: async () => {
      const values = form.getValues();
      if (!values.accountId) return null;
      
      const params = new URLSearchParams({
        accountId: values.accountId,
        startDate: values.startDate.toISOString(),
        endDate: values.endDate.toISOString(),
        transactionType: values.transactionType,
      });
      
      const response = await apiRequest("GET", `/api/financial/account-statement?${params.toString()}`);
      return response.json();
    },
    enabled: false, // لا تبدأ الاستعلام تلقائيًا عند تحميل الصفحة
  });

  useEffect(() => {
    if (statement) {
      setFormattedStatement(statement);
    }
  }, [statement]);

  // إعادة تعيين حالة توسيع الصفوف عند تغيير البيانات
  useEffect(() => {
    if (statement) {
      setExpandedRows({});
      setExpandAll(false);
    }
  }, [statement]);
  
  // معالجة توسيع/طي صف معين
  const toggleRowExpansion = (journalId: string) => {
    setExpandedRows(prev => ({
      ...prev,
      [journalId]: !prev[journalId]
    }));
  };
  
  // معالجة توسيع/طي كل الصفوف
  const toggleExpandAll = () => {
    const newExpandAll = !expandAll;
    setExpandAll(newExpandAll);
    
    if (newExpandAll && formattedStatement?.transactions) {
      const allExpanded: Record<string, boolean> = {};
      formattedStatement.transactions.forEach((transaction: any) => {
        if (transaction.journalId) {
          allExpanded[transaction.journalId] = true;
        }
      });
      setExpandedRows(allExpanded);
    } else {
      setExpandedRows({});
    }
  };
  
  // معالجة تغيير خيارات العرض
  const toggleShowOption = (option: keyof typeof showOptions) => {
    setShowOptions(prev => ({
      ...prev,
      [option]: !prev[option]
    }));
  };

  // معالجة تقديم النموذج وبدء البحث
  const handleSubmit = (data: FormValues) => {
    refetch();
  };

  // معالجة تصدير البيانات إلى ملف
  const handleExport = (type: 'pdf' | 'excel') => {
    // سيتم تنفيذ تصدير البيانات هنا
    console.log(`Exporting statement as ${type}`, formattedStatement);
    alert(`سيتم تنفيذ التصدير بتنسيق ${type === 'pdf' ? 'PDF' : 'Excel'} قريبًا`);
  };

  // معالجة طباعة كشف الحساب
  // مرجع قسم الطباعة
  const printSectionRef = useRef<HTMLDivElement>(null);
  
  // معالجة طباعة كشف الحساب باستخدام وظيفة printDocument
  const handlePrint = () => {
    printDocument(printSectionRef, t("financial.account_statement.title"));
  };

  // معالجة إرسال كشف الحساب بالبريد الإلكتروني
  const handleSendEmail = () => {
    alert("سيتم تنفيذ ميزة إرسال كشف الحساب بالبريد الإلكتروني قريبًا");
  };

  // البحث عن الحساب المحدد في قائمة الحسابات
  const selectedAccount = formattedStatement?.account || 
    (form.watch("accountId") && accounts?.find(acc => acc.id === parseInt(form.watch("accountId"))));

  return (
    <PageLayout
      title={t("financial.account_statement.title")}
      sections={[
        {
          title: t("financial.reports"),
          items: [
            { title: t("financial.account_statement.title"), href: "/financial/account-statement" },
            { title: t("financial.trialBalance"), href: "/financial/trial-balance" },
            { title: t("financial.balanceSheet"), href: "/financial/balance-sheet" },
            { title: t("financial.incomeStatement"), href: "/financial/income-statement" },
          ],
        },
      ]}
    >
      <div className="space-y-6">
        {/* نموذج البحث والتصفية */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>{t("financial.searchCriteria")}</CardTitle>
              {formattedStatement && (
                <div className="flex space-x-2 gap-2 print:hidden">
                  <Button variant="outline" onClick={handlePrint} size="sm">
                    <Printer className="h-4 w-4 mr-2" />
                    {t("actions.print")}
                  </Button>
                  <ExportMenu 
                    tableRef={tableRef}
                    data={formattedStatement.transactions || []}
                    headers={[
                      { header: t("financial.date"), dataKey: "date" },
                      { header: t("financial.reference"), dataKey: "journalNumber" },
                      { header: t("financial.description"), dataKey: "description" },
                      { header: t("financial.debit"), dataKey: "debitAmount" },
                      { header: t("financial.credit"), dataKey: "creditAmount" },
                      { header: t("financial.balance"), dataKey: "runningBalance" },
                    ]}
                    fileName={`account-statement-${selectedAccount?.code || 'report'}`}
                    reportTitle={t("financial.account_statement.title")}
                    subtitle={`${selectedAccount?.nameAr || selectedAccount?.name} - ${format(
                      form.watch("startDate"),
                      'yyyy/MM/dd'
                    )} - ${format(
                      form.watch("endDate"),
                      'yyyy/MM/dd'
                    )}`}
                  />
                </div>
              )}
            </div>
            <CardDescription>{t("financial.searchDescription")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/30 p-4 rounded-lg border mb-4">
              <h3 className="text-sm font-medium mb-3 flex items-center">
                <Filter className="h-4 w-4 mr-2 text-primary" />
                {t("financial.filterOptions")}
              </h3>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmit)} className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
                  <FormField
                    control={form.control}
                    name="accountId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("financial.account")}</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                          disabled={isLoadingAccounts}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={t("financial.selectAccount")} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {accounts?.map((account: any) => (
                              <SelectItem key={account.id} value={account.id.toString()}>
                                {account.code} - {account.nameAr || account.nameEn || account.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("financial.startDate")}</FormLabel>
                        <FormControl>
                          <DatePicker
                            date={field.value}
                            onSelect={field.onChange}
                            locale={ar}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("financial.endDate")}</FormLabel>
                        <FormControl>
                          <DatePicker
                            date={field.value}
                            onSelect={field.onChange}
                            locale={ar}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="transactionType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("financial.transactionType")}</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={t("financial.allTransactions")} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="all">{t("financial.allTransactions")}</SelectItem>
                            <SelectItem value="debit">{t("financial.debitTransactions")}</SelectItem>
                            <SelectItem value="credit">{t("financial.creditTransactions")}</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  <div className="flex items-end col-span-1 md:col-span-2 lg:col-span-4 gap-2">
                    <Button type="submit" className="gap-1">
                      <Search className="h-4 w-4" />
                      {t("financial.search")}
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
          </CardContent>
        </Card>

        {/* عرض نتائج كشف الحساب */}
        {isLoadingStatement ? (
          <div className="h-[400px] flex flex-col items-center justify-center">
            <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
            <p className="mt-4 text-muted-foreground">{t("financial.account_statement.loading")}</p>
          </div>
        ) : formattedStatement ? (
          <div className="space-y-6 print:space-y-2" ref={printSectionRef}>
            {/* عنوان التقرير - يظهر فقط عند الطباعة */}
            <div className="hidden print:block print:mb-6 print:text-center">
              <h1 className="text-2xl font-bold">{t("financial.account_statement.title")}</h1>
              <h2 className="text-xl">
                {selectedAccount?.nameAr || selectedAccount?.name}
              </h2>
              <p className="text-muted-foreground mt-1">
                {format(form.watch("startDate"), 'yyyy/MM/dd')} - {format(form.watch("endDate"), 'yyyy/MM/dd')}
              </p>
            </div>
            
            {/* تذييل التقرير - يظهر فقط عند الطباعة */}
            <div className="hidden print:block print:mt-8 print:pt-4 print:border-t print:text-center print:text-sm print:text-muted-foreground">
              <p>{t("financial.printedOn")}: {format(new Date(), 'yyyy/MM/dd HH:mm')}</p>
              <p>{t("financial.poweredBy")}</p>
            </div>
            {/* معلومات الحساب وملخص كشف الحساب */}
            <div className="flex flex-col md:flex-row gap-4 md:gap-6">
              <Card className="flex-1">
                <CardHeader>
                  <CardTitle>{t("financial.accountInfo")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <dl className="grid grid-cols-1 gap-3 text-sm">
                    <div className="flex justify-between py-1 border-b">
                      <dt className="font-medium">{t("financial.accountNumber")}</dt>
                      <dd className="text-muted-foreground">{formattedStatement.account?.code}</dd>
                    </div>
                    <div className="flex justify-between py-1 border-b">
                      <dt className="font-medium">{t("financial.accountName")}</dt>
                      <dd className="text-muted-foreground">{formattedStatement.account?.nameAr || formattedStatement.account?.name}</dd>
                    </div>
                    <div className="flex justify-between py-1 border-b">
                      <dt className="font-medium">{t("financial.accountType")}</dt>
                      <dd className="text-muted-foreground">{t(`financial.accountTypes.${formattedStatement.account?.type}`)}</dd>
                    </div>
                    <div className="flex justify-between py-1">
                      <dt className="font-medium">{t("financial.currentBalance")}</dt>
                      <dd className="text-primary font-bold">{formattedStatement.closingBalance?.toLocaleString('ar-SA')} ريال</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>

              <Card className="flex-1">
                <CardHeader>
                  <CardTitle>{t("financial.statementSummary")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <dl className="grid grid-cols-1 gap-3 text-sm">
                    <div className="flex justify-between py-1 border-b">
                      <dt className="font-medium">{t("financial.period")}</dt>
                      <dd className="text-muted-foreground">
                        {format(
                          formattedStatement.period?.startDate
                            ? parseISO(formattedStatement.period.startDate)
                            : new Date(),
                          'yyyy/MM/dd'
                        )} - {format(
                          formattedStatement.period?.endDate
                            ? parseISO(formattedStatement.period.endDate)
                            : new Date(),
                          'yyyy/MM/dd'
                        )}
                      </dd>
                    </div>
                    <div className="flex justify-between py-1 border-b">
                      <dt className="font-medium">{t("financial.openingBalance")}</dt>
                      <dd className="text-muted-foreground">{formattedStatement.openingBalance?.toLocaleString('ar-SA')} ريال</dd>
                    </div>
                    <div className="flex justify-between py-1">
                      <dt className="font-medium">{t("financial.closingBalance")}</dt>
                      <dd className="text-primary font-bold">{formattedStatement.closingBalance?.toLocaleString('ar-SA')} ريال</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
            </div>

            {/* أزرار الأكشن (تصدير، طباعة) */}
            <div className="flex gap-2 print:hidden">
              <ExportMenu 
                tableRef={tableRef}
                data={formattedStatement.transactions || []}
                headers={[
                  { header: t("financial.date"), dataKey: "date" },
                  { header: t("financial.reference"), dataKey: "journalNumber" },
                  { header: t("financial.description"), dataKey: "description" },
                  { header: t("financial.debit"), dataKey: "debitAmount" },
                  { header: t("financial.credit"), dataKey: "creditAmount" },
                  { header: t("financial.balance"), dataKey: "runningBalance" },
                ]}
                fileName={`account-statement-${selectedAccount?.code || 'report'}`}
                reportTitle={t("financial.account_statement.title")}
                subtitle={`${selectedAccount?.nameAr || selectedAccount?.name} - ${format(
                  form.watch("startDate"),
                  'yyyy/MM/dd'
                )} - ${format(
                  form.watch("endDate"),
                  'yyyy/MM/dd'
                )}`}
              />
              
              <Button variant="outline" onClick={handlePrint} size="sm">
                <Printer size={16} className="ml-2" />
                {t("actions.print")}
              </Button>
            </div>

            {/* جدول المعاملات */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>{t("financial.transactions")}</CardTitle>
                      <CardDescription className="mt-1">
                        {t("financial.totalTransactions")}: {formattedStatement.summary?.totalTransactions || 0}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {/* زر التوسيع/الطي لكل الصفوف */}
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={toggleExpandAll}
                              className="h-8 w-8 p-0"
                            >
                              {expandAll ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{expandAll ? t("hideDetails") : t("showDetails")}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      {/* زر خيارات العرض */}
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => {
                                const dialog = document.getElementById("display-options-dialog");
                                if (dialog instanceof HTMLDialogElement) {
                                  dialog.showModal();
                                }
                              }}
                            >
                              <Settings className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{t("customizeView")}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>
                  
                  {/* مفتاح الألوان */}
                  <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span className="ml-2">{t("financial.accountingRecords")}</span>
                    </div>
                    
                    <div className="flex items-center">
                      <div className="h-2 w-2 rounded-full bg-muted-foreground"></div>
                      <span className="ml-2">{t("financial.summaryRecords")}</span>
                    </div>
                  </div>
                </div>
                
                {/* نافذة حوار خيارات العرض */}
                <dialog id="display-options-dialog" className="modal bg-transparent">
                  <div className="bg-background rounded-lg p-6 shadow-lg max-w-sm w-full border">
                    <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
                      <Settings2 className="h-4 w-4" />
                      {t("viewOptions")}
                    </h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {t("financial.date")}
                        </span>
                        <Button
                          variant={showOptions.showDate ? "default" : "outline"}
                          size="sm"
                          className="h-8"
                          onClick={() => toggleShowOption('showDate')}
                        >
                          {showOptions.showDate ? <Eye className="h-4 w-4 mr-2" /> : <EyeOff className="h-4 w-4 mr-2" />}
                          {showOptions.showDate ? t("show") : t("hide")}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          {t("financial.reference")}
                        </span>
                        <Button
                          variant={showOptions.showReference ? "default" : "outline"}
                          size="sm"
                          className="h-8"
                          onClick={() => toggleShowOption('showReference')}
                        >
                          {showOptions.showReference ? <Eye className="h-4 w-4 mr-2" /> : <EyeOff className="h-4 w-4 mr-2" />}
                          {showOptions.showReference ? t("show") : t("hide")}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          {t("financial.description")}
                        </span>
                        <Button
                          variant={showOptions.showDescription ? "default" : "outline"}
                          size="sm"
                          className="h-8"
                          onClick={() => toggleShowOption('showDescription')}
                        >
                          {showOptions.showDescription ? <Eye className="h-4 w-4 mr-2" /> : <EyeOff className="h-4 w-4 mr-2" />}
                          {showOptions.showDescription ? t("show") : t("hide")}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <FileDown className="h-4 w-4 text-muted-foreground" />
                          {t("financial.debit")}
                        </span>
                        <Button
                          variant={showOptions.showDebit ? "default" : "outline"}
                          size="sm"
                          className="h-8"
                          onClick={() => toggleShowOption('showDebit')}
                        >
                          {showOptions.showDebit ? <Eye className="h-4 w-4 mr-2" /> : <EyeOff className="h-4 w-4 mr-2" />}
                          {showOptions.showDebit ? t("show") : t("hide")}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <FileDown className="h-4 w-4 text-muted-foreground rotate-180" />
                          {t("financial.credit")}
                        </span>
                        <Button
                          variant={showOptions.showCredit ? "default" : "outline"}
                          size="sm"
                          className="h-8"
                          onClick={() => toggleShowOption('showCredit')}
                        >
                          {showOptions.showCredit ? <Eye className="h-4 w-4 mr-2" /> : <EyeOff className="h-4 w-4 mr-2" />}
                          {showOptions.showCredit ? t("show") : t("hide")}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <ListFilter className="h-4 w-4 text-muted-foreground" />
                          {t("financial.balance")}
                        </span>
                        <Button
                          variant={showOptions.showBalance ? "default" : "outline"}
                          size="sm"
                          className="h-8"
                          onClick={() => toggleShowOption('showBalance')}
                        >
                          {showOptions.showBalance ? <Eye className="h-4 w-4 mr-2" /> : <EyeOff className="h-4 w-4 mr-2" />}
                          {showOptions.showBalance ? t("show") : t("hide")}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mt-6 flex justify-end">
                      <Button variant="outline" onClick={() => {
                        const dialog = document.getElementById("display-options-dialog");
                        if (dialog instanceof HTMLDialogElement) {
                          dialog.close();
                        }
                      }}>
                        {t("close")}
                      </Button>
                    </div>
                  </div>
                </dialog>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-hidden">
                  <Table ref={tableRef}>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead className="w-8"></TableHead>
                        {showOptions.showDate && <TableHead className="w-[100px]">{t("financial.date")}</TableHead>}
                        {showOptions.showReference && <TableHead>{t("financial.reference")}</TableHead>}
                        {showOptions.showDescription && <TableHead>{t("financial.description")}</TableHead>}
                        {showOptions.showDebit && <TableHead className="text-left">{t("financial.debit")}</TableHead>}
                        {showOptions.showCredit && <TableHead className="text-left">{t("financial.credit")}</TableHead>}
                        {showOptions.showBalance && <TableHead className="text-left">{t("financial.balance")}</TableHead>}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {/* رصيد افتتاحي */}
                      <TableRow className="bg-muted/20">
                        <TableCell></TableCell>
                        <TableCell colSpan={Object.values(showOptions).filter(Boolean).length - 1} className="font-medium">
                          {t("financial.openingBalance")}
                        </TableCell>
                        {showOptions.showBalance && (
                          <TableCell className="text-left font-medium">
                            {formattedStatement.openingBalance?.toLocaleString('ar-SA')} ريال
                          </TableCell>
                        )}
                      </TableRow>

                      {/* بيانات المعاملات */}
                      {formattedStatement.transactions && formattedStatement.transactions.length > 0 ? (
                        formattedStatement.transactions.map((transaction: any, index: number) => (
                          <React.Fragment key={index}>
                            <TableRow 
                              className={`hover:bg-muted/10 group ${transaction.journalId ? 'cursor-pointer' : ''}`}
                              onClick={() => transaction.journalId && toggleRowExpansion(transaction.journalId)}
                            >
                              <TableCell className="p-2 align-middle">
                                {transaction.journalId ? (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 p-0 opacity-70 group-hover:opacity-100"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      toggleRowExpansion(transaction.journalId);
                                    }}
                                  >
                                    {expandedRows[transaction.journalId] ? (
                                      <ChevronDown className="h-4 w-4" />
                                    ) : (
                                      <ChevronRight className="h-4 w-4" />
                                    )}
                                  </Button>
                                ) : null}
                              </TableCell>
                              
                              {showOptions.showDate && (
                                <TableCell>
                                  {format(
                                    parseISO(transaction.date),
                                    'yyyy/MM/dd'
                                  )}
                                </TableCell>
                              )}
                              
                              {showOptions.showReference && (
                                <TableCell>
                                  <span className="font-medium text-primary">{transaction.journalNumber}</span>
                                </TableCell>
                              )}
                              
                              {showOptions.showDescription && (
                                <TableCell>{transaction.description}</TableCell>
                              )}
                              
                              {showOptions.showDebit && (
                                <TableCell className="text-left">
                                  {transaction.debitAmount > 0 ? 
                                    `${transaction.debitAmount.toLocaleString('ar-SA')} ريال` : '-'}
                                </TableCell>
                              )}
                              
                              {showOptions.showCredit && (
                                <TableCell className="text-left">
                                  {transaction.creditAmount > 0 ? 
                                    `${transaction.creditAmount.toLocaleString('ar-SA')} ريال` : '-'}
                                </TableCell>
                              )}
                              
                              {showOptions.showBalance && (
                                <TableCell className="text-left font-medium">
                                  {transaction.balance?.toLocaleString('ar-SA')} ريال
                                </TableCell>
                              )}
                            </TableRow>
                            
                            {/* تفاصيل القيد المحاسبي */}
                            {transaction.journalId && expandedRows[transaction.journalId] && transaction.details && (
                              <TableRow className="bg-muted/5 border-t border-dashed">
                                <TableCell colSpan={Object.values(showOptions).filter(Boolean).length + 1} className="py-0">
                                  <div className="pr-6 pt-2 pb-3 text-sm">
                                    <div className="mb-2 font-medium text-primary/80 flex items-center">
                                      <span className="ml-2">{t("financial.journalEntryDetails")}</span>
                                    </div>
                                    <table className="w-full">
                                      <thead>
                                        <tr className="text-xs text-muted-foreground border-b">
                                          <th className="text-right pb-2 pr-6">{t("financial.account")}</th>
                                          <th className="text-left pb-2 pr-4">{t("financial.debit")}</th>
                                          <th className="text-left pb-2">{t("financial.credit")}</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {transaction.details.map((detail: any, detailIndex: number) => (
                                          <tr key={detailIndex} className="border-b border-dashed border-muted">
                                            <td className="py-2 pl-6 pr-6 text-right">
                                              <span className="font-mono text-xs text-muted-foreground">{detail.accountCode}</span>
                                              <span className="px-2">-</span>
                                              <span>{detail.accountName}</span>
                                            </td>
                                            <td className="py-2 text-left pr-4">
                                              {detail.debitAmount > 0 ? 
                                                `${detail.debitAmount.toLocaleString('ar-SA')} ريال` : '-'}
                                            </td>
                                            <td className="py-2 text-left">
                                              {detail.creditAmount > 0 ? 
                                                `${detail.creditAmount.toLocaleString('ar-SA')} ريال` : '-'}
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>
                                      <tfoot>
                                        <tr className="font-medium text-muted-foreground">
                                          <td className="pt-2 text-right pr-6">{t("financial.totals")}</td>
                                          <td className="pt-2 text-left pr-4">
                                            {transaction.totalDebit?.toLocaleString('ar-SA')} ريال
                                          </td>
                                          <td className="pt-2 text-left">
                                            {transaction.totalCredit?.toLocaleString('ar-SA')} ريال
                                          </td>
                                        </tr>
                                      </tfoot>
                                    </table>
                                    {transaction.notes && (
                                      <div className="mt-3 pr-6 text-muted-foreground text-xs">
                                        <span className="font-medium">{t("financial.notes")}:</span> {transaction.notes}
                                      </div>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            )}
                          </React.Fragment>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={Object.values(showOptions).filter(Boolean).length + 1} className="text-center py-4">
                            {t("financial.noTransactions")}
                          </TableCell>
                        </TableRow>
                      )}

                      {/* الإجماليات */}
                      <TableRow className="bg-muted/50 font-medium border-t-2">
                        <TableCell></TableCell>
                        <TableCell colSpan={
                          (showOptions.showDate ? 1 : 0) +
                          (showOptions.showReference ? 1 : 0) +
                          (showOptions.showDescription ? 1 : 0)
                        } className="font-medium">
                          {t("financial.totals")}
                        </TableCell>
                        {showOptions.showDebit && (
                          <TableCell className="text-left font-medium">
                            {formattedStatement.summary?.totalPeriodDebits?.toLocaleString('ar-SA')} ريال
                          </TableCell>
                        )}
                        {showOptions.showCredit && (
                          <TableCell className="text-left font-medium">
                            {formattedStatement.summary?.totalPeriodCredits?.toLocaleString('ar-SA')} ريال
                          </TableCell>
                        )}
                        {showOptions.showBalance && (
                          <TableCell className="text-left font-medium">
                            {formattedStatement.closingBalance?.toLocaleString('ar-SA')} ريال
                          </TableCell>
                        )}
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : selectedAccount ? (
          <Card>
            <CardContent className="py-10 text-center">
              <p className="text-muted-foreground">
                {t("financial.useSearchCriteria")}
              </p>
            </CardContent>
          </Card>
        ) : null}
      </div>
    </PageLayout>
  );
}