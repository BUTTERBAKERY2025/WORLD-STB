import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DatePicker } from "@/components/ui/date-picker";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { 
  Calculator, 
  ChevronDown, 
  ChevronRight, 
  Download, 
  FileDown, 
  Filter,
  Printer, 
  Search, 
  Settings2,
  TrendingDown, 
  TrendingUp 
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";
import { format, subMonths } from "date-fns";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ExportMenu } from "@/components/financial/ExportMenu";
import { printDocument } from "@/utils/printUtils";

// ألوان للرسوم البيانية
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function IncomeStatement() {
  const { t } = useTranslation();
  const { toast } = useToast();
  
  // تواريخ قائمة الدخل
  const [startDate, setStartDate] = useState<Date>(subMonths(new Date(), 1)); // شهر واحد سابق
  const [endDate, setEndDate] = useState<Date>(new Date()); // تاريخ اليوم
  const [fiscalYear, setFiscalYear] = useState<string | undefined>();
  const [fiscalPeriod, setFiscalPeriod] = useState<string | undefined>();
  const [compareWithPrevPeriod, setCompareWithPrevPeriod] = useState(false);
  
  // علامة تبويب نشطة
  const [activeTab, setActiveTab] = useState("statement");
  
  // استدعاء واجهة برمجة التطبيقات للحصول على قائمة الدخل
  const { data: incomeStatementData, isLoading, refetch } = useQuery({
    queryKey: ['/api/financial/income-statement', startDate, endDate, fiscalYear, fiscalPeriod, compareWithPrevPeriod],
    queryFn: async () => {
      try {
        // بناء معلمات الاستعلام
        const params = new URLSearchParams();
        params.append('startDate', startDate.toISOString());
        params.append('endDate', endDate.toISOString());
        if (fiscalYear) params.append('fiscalYear', fiscalYear);
        if (fiscalPeriod) params.append('fiscalPeriod', fiscalPeriod);
        params.append('compareWithPrevPeriod', String(compareWithPrevPeriod));
        
        const response = await apiRequest('GET', `/api/financial/income-statement?${params.toString()}`);
        return await response.json();
      } catch (error) {
        console.error('Error fetching income statement:', error);
        toast({
          variant: "destructive",
          title: t('financial.income_statement.fetch_error') || "خطأ في جلب قائمة الدخل",
          description: String(error),
        });
        return null;
      }
    },
  });
  
  // تنسيق الأرقام بالعملة السعودية
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // التنسيق المختصر للمبالغ الكبيرة (مليون، مليار)
  const formatShortCurrency = (amount: number) => {
    if (Math.abs(amount) >= 1000000000) {
      return `${(amount / 1000000000).toFixed(1)} مليار ر.س`;
    } else if (Math.abs(amount) >= 1000000) {
      return `${(amount / 1000000).toFixed(1)} مليون ر.س`;
    } else if (Math.abs(amount) >= 1000) {
      return `${(amount / 1000).toFixed(1)} ألف ر.س`;
    } else {
      return `${amount.toFixed(1)} ر.س`;
    }
  };
  
  // الحصول على بيانات الرسم البياني للمقارنة بين الإيرادات والمصروفات
  const getChartData = () => {
    if (!incomeStatementData) return [];
    
    return [
      {
        name: t('financial.revenues') || "الإيرادات",
        amount: incomeStatementData.totalRevenue,
      },
      {
        name: t('financial.cost_of_sales') || "تكلفة المبيعات",
        amount: incomeStatementData.totalCostOfSales,
      },
      {
        name: t('financial.expenses') || "المصروفات",
        amount: incomeStatementData.totalExpenses,
      },
      {
        name: t('financial.gross_profit') || "مجمل الربح",
        amount: incomeStatementData.grossProfit,
      },
      {
        name: t('financial.net_income') || "صافي الدخل",
        amount: incomeStatementData.netIncome,
      },
    ];
  };
  
  // بيانات الرسم البياني للإيرادات
  const getRevenuesPieData = () => {
    if (!incomeStatementData?.revenues) return [];
    
    return incomeStatementData.revenues.map((revenue: any) => ({
      name: revenue.accountName,
      value: revenue.balance,
    }));
  };
  
  // بيانات الرسم البياني للمصروفات
  const getExpensesPieData = () => {
    if (!incomeStatementData?.expenses) return [];
    
    return incomeStatementData.expenses.map((expense: any) => ({
      name: expense.accountName,
      value: expense.balance,
    }));
  };
  
  // حساب هامش الربح الإجمالي والصافي
  const getGrossProfitMargin = () => {
    if (!incomeStatementData?.totalRevenue || incomeStatementData.totalRevenue === 0) {
      return 0;
    }
    return (incomeStatementData.grossProfit / incomeStatementData.totalRevenue) * 100;
  };
  
  const getNetProfitMargin = () => {
    if (!incomeStatementData?.totalRevenue || incomeStatementData.totalRevenue === 0) {
      return 0;
    }
    return (incomeStatementData.netIncome / incomeStatementData.totalRevenue) * 100;
  };
  
  // مرجع للجدول لاستخدامه في التصدير
  const tableRef = useRef<HTMLTableElement>(null);
  const printSectionRef = useRef<HTMLDivElement>(null);
  
  // استخراج البيانات للتصدير إلى Excel أو PDF
  const getExportData = () => {
    if (!incomeStatementData) return { headers: [], data: [] };
    
    // تعريف العناوين
    const baseHeaders = [
      { header: t('financial.account_code') || 'رمز الحساب', dataKey: 'accountCode' },
      { header: t('financial.account_name') || 'اسم الحساب', dataKey: 'accountName' },
    ];
    
    // إضافة أعمدة المقارنة إذا كانت مفعّلة
    const compareHeaders = compareWithPrevPeriod ? [
      { header: t('financial.prev_balance') || 'رصيد سابق', dataKey: 'previousBalance' },
      { header: t('financial.change_amount') || 'التغيير', dataKey: 'change' },
      { header: t('financial.change_percentage') || 'نسبة التغيير', dataKey: 'changePercentage' }
    ] : [];
    
    // إضافة عمود الرصيد
    const finalHeaders = [
      ...baseHeaders,
      ...compareHeaders,
      { header: t('financial.balance') || 'الرصيد', dataKey: 'balance' }
    ];
    
    // تجميع البيانات
    let allData = [];
    
    // إضافة بيانات الإيرادات مع علامة التصنيف
    const revenueData = incomeStatementData.revenues.map((account: any) => ({
      ...account,
      category: t('financial.revenues') || 'الإيرادات'
    }));
    
    // إضافة بيانات تكلفة المبيعات مع علامة التصنيف
    const cosData = incomeStatementData.costOfSales.map((account: any) => ({
      ...account,
      category: t('financial.cost_of_sales') || 'تكلفة المبيعات'
    }));
    
    // إضافة بيانات المصروفات مع علامة التصنيف
    const expenseData = incomeStatementData.expenses.map((account: any) => ({
      ...account,
      category: t('financial.expenses') || 'المصروفات'
    }));
    
    // دمج جميع البيانات
    allData = [...revenueData, ...cosData, ...expenseData];
    
    // إضافة الإجماليات
    allData.push({
      accountCode: '',
      accountName: t('financial.total_revenues') || 'إجمالي الإيرادات',
      balance: incomeStatementData.totalRevenue,
      category: t('financial.summary') || 'ملخص'
    });
    
    allData.push({
      accountCode: '',
      accountName: t('financial.total_cost_of_sales') || 'إجمالي تكلفة المبيعات',
      balance: incomeStatementData.totalCostOfSales,
      category: t('financial.summary') || 'ملخص'
    });
    
    allData.push({
      accountCode: '',
      accountName: t('financial.gross_profit') || 'مجمل الربح',
      balance: incomeStatementData.grossProfit,
      category: t('financial.summary') || 'ملخص'
    });
    
    allData.push({
      accountCode: '',
      accountName: t('financial.total_expenses') || 'إجمالي المصروفات',
      balance: incomeStatementData.totalExpenses,
      category: t('financial.summary') || 'ملخص'
    });
    
    allData.push({
      accountCode: '',
      accountName: t('financial.net_income') || 'صافي الدخل',
      balance: incomeStatementData.netIncome,
      category: t('financial.summary') || 'ملخص'
    });
    
    return { headers: finalHeaders, data: allData };
  };
  
  return (
    <PageLayout
      title={t('financial.income_statement.title') || "قائمة الدخل"}
      sections={[
        {
          title: t('financial.reports.categories') || "فئات التقارير",
          items: [
            { title: t('financial.overview') || "نظرة عامة", href: "/financial/reports" },
            { title: t('financial.account_statement') || "كشف الحساب", href: "/financial/account-statement" },
            { title: t('financial.trial_balance') || "ميزان المراجعة", href: "/financial/trial-balance" },
            { title: t('financial.balance_sheet') || "الميزانية العمومية", href: "/financial/balance-sheet" },
            { title: t('financial.income_statement') || "قائمة الدخل", href: "/financial/income-statement" },
          ],
        },
      ]}
    >
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>{t('financial.income_statement.filter') || "تصفية قائمة الدخل"}</CardTitle>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => printDocument(printSectionRef, t('financial.income_statement.title') || "قائمة الدخل")}
                >
                  <Printer className="h-4 w-4 mr-2" />
                  {t('common.print') || "طباعة"}
                </Button>
                <ExportMenu
                  tableRef={tableRef}
                  data={getExportData().data}
                  headers={getExportData().headers}
                  fileName="income_statement"
                  reportTitle={t('financial.income_statement.title') || "قائمة الدخل"}
                  subtitle={`${format(startDate, 'yyyy/MM/dd')} - ${format(endDate, 'yyyy/MM/dd')}`}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/30 p-4 rounded-lg border mb-4">
              <h3 className="text-sm font-medium mb-3 flex items-center">
                <Filter className="h-4 w-4 mr-2 text-primary" />
                {t('financial.filter_options') || "خيارات التصفية"}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.start_date') || "تاريخ البداية"}
                  </label>
                  <DatePicker
                    date={startDate}
                    onSelect={setStartDate}
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.end_date') || "تاريخ النهاية"}
                  </label>
                  <DatePicker
                    date={endDate}
                    onSelect={setEndDate}
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.fiscal_year') || "السنة المالية"}
                  </label>
                  <Select value={fiscalYear} onValueChange={setFiscalYear}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('financial.select_fiscal_year') || "اختر السنة المالية"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2025">2025</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.fiscal_period') || "الفترة المالية"}
                  </label>
                  <Select value={fiscalPeriod} onValueChange={setFiscalPeriod}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('financial.select_fiscal_period') || "اختر الفترة المالية"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">{t('financial.period_1') || "الفترة 1"}</SelectItem>
                      <SelectItem value="2">{t('financial.period_2') || "الفترة 2"}</SelectItem>
                      <SelectItem value="3">{t('financial.period_3') || "الفترة 3"}</SelectItem>
                      <SelectItem value="4">{t('financial.period_4') || "الفترة 4"}</SelectItem>
                      <SelectItem value="5">{t('financial.period_5') || "الفترة 5"}</SelectItem>
                      <SelectItem value="6">{t('financial.period_6') || "الفترة 6"}</SelectItem>
                      <SelectItem value="7">{t('financial.period_7') || "الفترة 7"}</SelectItem>
                      <SelectItem value="8">{t('financial.period_8') || "الفترة 8"}</SelectItem>
                      <SelectItem value="9">{t('financial.period_9') || "الفترة 9"}</SelectItem>
                      <SelectItem value="10">{t('financial.period_10') || "الفترة 10"}</SelectItem>
                      <SelectItem value="11">{t('financial.period_11') || "الفترة 11"}</SelectItem>
                      <SelectItem value="12">{t('financial.period_12') || "الفترة 12"}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">
                    {t('financial.compare_with_prev_period') || "المقارنة مع الفترة السابقة"}
                  </label>
                  <div className="flex items-center space-x-2 h-10 bg-background rounded-md px-3 border">
                    <Switch 
                      checked={compareWithPrevPeriod} 
                      onCheckedChange={setCompareWithPrevPeriod} 
                    />
                    <span className="text-sm">
                      {compareWithPrevPeriod 
                        ? t('financial.compare_enabled') || "المقارنة مفعلة" 
                        : t('financial.compare_disabled') || "المقارنة معطلة"}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="border-t pt-3 mt-2 flex justify-end">
                <Button className="px-6" onClick={() => refetch()}>
                  <Search className="h-4 w-4 mr-2" />
                  {t('common.search') || "بحث"}
                </Button>
              </div>
            </div>
            
            <div className="bg-muted/30 p-4 rounded-lg border">
              <h3 className="text-sm font-medium mb-3 flex items-center">
                <Settings2 className="h-4 w-4 mr-2 text-primary" />
                {t('financial.display_options') || "خيارات العرض"}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="col-span-1 md:col-span-3">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={activeTab === "statement" ? "bg-primary/10" : ""}
                        onClick={() => setActiveTab("statement")}
                      >
                        {t('financial.income_statement.statement') || "القائمة"}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={activeTab === "visual" ? "bg-primary/10" : ""}
                        onClick={() => setActiveTab("visual")}
                      >
                        {t('financial.income_statement.visual') || "عرض مرئي"}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={activeTab === "analysis" ? "bg-primary/10" : ""}
                        onClick={() => setActiveTab("analysis")}
                      >
                        {t('financial.income_statement.analysis') || "تحليل"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="statement" value={activeTab} onValueChange={setActiveTab}>
          
          <TabsContent value="statement">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>
                    {t('financial.income_statement.header', { 
                      startDate: format(startDate, 'yyyy/MM/dd'), 
                      endDate: format(endDate, 'yyyy/MM/dd') 
                    }) || 
                      `قائمة الدخل للفترة من ${format(startDate, 'yyyy/MM/dd')} إلى ${format(endDate, 'yyyy/MM/dd')}`}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-2">
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                ) : incomeStatementData ? (
                  <div className="space-y-6" ref={printSectionRef}>
                    {/* عنوان الطباعة - يظهر فقط عند الطباعة */}
                    <div className="print-header hidden print:block">
                      <h1>{t('financial.income_statement.title') || "قائمة الدخل"}</h1>
                      <h3>{format(startDate, 'yyyy/MM/dd')} - {format(endDate, 'yyyy/MM/dd')}</h3>
                      <p>{t('financial.generated_date') || "تم إنشاؤه في"}: {format(new Date(), 'yyyy/MM/dd HH:mm')}</p>
                    </div>
                    
                    {/* الإيرادات - Revenues */}
                    <div>
                      <h3 className="text-lg font-bold mb-2">{t('financial.revenues') || "الإيرادات"}</h3>
                      <div className="rounded-md border">
                        <Table dir="rtl" ref={tableRef}>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-24">{t('financial.account_code') || "رمز الحساب"}</TableHead>
                              <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableHead className="text-left">{t('financial.prev_balance') || "رصيد سابق"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_amount') || "التغيير"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_percentage') || "نسبة التغيير"}</TableHead>
                                </>
                              )}
                              <TableHead className="text-left">{t('financial.balance') || "الرصيد"}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {incomeStatementData.revenues.map((account: any) => (
                              <TableRow key={account.accountId}>
                                <TableCell>{account.accountCode}</TableCell>
                                <TableCell>
                                  <div className="font-medium">
                                    {account.accountName}
                                  </div>
                                  {account.accountNameEn && (
                                    <div className="text-xs text-muted-foreground">
                                      {account.accountNameEn}
                                    </div>
                                  )}
                                </TableCell>
                                {compareWithPrevPeriod && (
                                  <>
                                    <TableCell>
                                      {formatCurrency(account.previousBalance)}
                                    </TableCell>
                                    <TableCell className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                      {account.change >= 0 ? "+" : ""}{formatCurrency(account.change)}
                                    </TableCell>
                                    <TableCell className={account.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                      {account.changePercentage >= 0 ? "+" : ""}
                                      {account.changePercentage.toFixed(2)}%
                                    </TableCell>
                                  </>
                                )}
                                <TableCell className="font-bold">
                                  {formatCurrency(account.balance)}
                                </TableCell>
                              </TableRow>
                            ))}
                            
                            {/* إجمالي الإيرادات */}
                            <TableRow className="bg-primary/10 font-bold">
                              <TableCell colSpan={1}></TableCell>
                              <TableCell>
                                {t('financial.total_revenue') || "إجمالي الإيرادات"}
                              </TableCell>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                </>
                              )}
                              <TableCell className="font-bold">
                                {formatCurrency(incomeStatementData.totalRevenue)}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* تكلفة المبيعات - Cost of Sales */}
                    <div>
                      <h3 className="text-lg font-bold mb-2">{t('financial.cost_of_sales') || "تكلفة المبيعات"}</h3>
                      <div className="rounded-md border">
                        <Table dir="rtl">
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-24">{t('financial.account_code') || "رمز الحساب"}</TableHead>
                              <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableHead className="text-left">{t('financial.prev_balance') || "رصيد سابق"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_amount') || "التغيير"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_percentage') || "نسبة التغيير"}</TableHead>
                                </>
                              )}
                              <TableHead className="text-left">{t('financial.balance') || "الرصيد"}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {incomeStatementData.costOfSales.map((account: any) => (
                              <TableRow key={account.accountId}>
                                <TableCell>{account.accountCode}</TableCell>
                                <TableCell>
                                  <div className="font-medium">
                                    {account.accountName}
                                  </div>
                                  {account.accountNameEn && (
                                    <div className="text-xs text-muted-foreground">
                                      {account.accountNameEn}
                                    </div>
                                  )}
                                </TableCell>
                                {compareWithPrevPeriod && (
                                  <>
                                    <TableCell>
                                      {formatCurrency(account.previousBalance)}
                                    </TableCell>
                                    <TableCell className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                      {account.change >= 0 ? "+" : ""}{formatCurrency(account.change)}
                                    </TableCell>
                                    <TableCell className={account.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                      {account.changePercentage >= 0 ? "+" : ""}
                                      {account.changePercentage.toFixed(2)}%
                                    </TableCell>
                                  </>
                                )}
                                <TableCell className="font-bold">
                                  {formatCurrency(account.balance)}
                                </TableCell>
                              </TableRow>
                            ))}
                            
                            {/* إجمالي تكلفة المبيعات */}
                            <TableRow className="bg-primary/10 font-bold">
                              <TableCell colSpan={1}></TableCell>
                              <TableCell>
                                {t('financial.total_cost_of_sales') || "إجمالي تكلفة المبيعات"}
                              </TableCell>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                </>
                              )}
                              <TableCell className="font-bold">
                                {formatCurrency(incomeStatementData.totalCostOfSales)}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* مجمل الربح - Gross Profit */}
                    <div className="bg-green-50 dark:bg-green-950 p-4 rounded-md">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-bold">
                          {t('financial.gross_profit') || "مجمل الربح"}
                        </h3>
                        <div className="font-bold text-xl">
                          {formatCurrency(incomeStatementData.grossProfit)}
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground mt-2">
                        <div>
                          {t('financial.gross_profit_margin') || "هامش مجمل الربح"}: {getGrossProfitMargin().toFixed(2)}%
                        </div>
                      </div>
                    </div>
                    
                    {/* المصروفات - Expenses */}
                    <div>
                      <h3 className="text-lg font-bold mb-2">{t('financial.expenses') || "المصروفات"}</h3>
                      <div className="rounded-md border">
                        <Table dir="rtl">
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-24">{t('financial.account_code') || "رمز الحساب"}</TableHead>
                              <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableHead className="text-left">{t('financial.prev_balance') || "رصيد سابق"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_amount') || "التغيير"}</TableHead>
                                  <TableHead className="text-left">{t('financial.change_percentage') || "نسبة التغيير"}</TableHead>
                                </>
                              )}
                              <TableHead className="text-left">{t('financial.balance') || "الرصيد"}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {incomeStatementData.expenses.map((account: any) => (
                              <TableRow key={account.accountId}>
                                <TableCell>{account.accountCode}</TableCell>
                                <TableCell>
                                  <div className="font-medium">
                                    {account.accountName}
                                  </div>
                                  {account.accountNameEn && (
                                    <div className="text-xs text-muted-foreground">
                                      {account.accountNameEn}
                                    </div>
                                  )}
                                </TableCell>
                                {compareWithPrevPeriod && (
                                  <>
                                    <TableCell>
                                      {formatCurrency(account.previousBalance)}
                                    </TableCell>
                                    <TableCell className={account.change >= 0 ? "text-green-600" : "text-red-600"}>
                                      {account.change >= 0 ? "+" : ""}{formatCurrency(account.change)}
                                    </TableCell>
                                    <TableCell className={account.changePercentage >= 0 ? "text-green-600" : "text-red-600"}>
                                      {account.changePercentage >= 0 ? "+" : ""}
                                      {account.changePercentage.toFixed(2)}%
                                    </TableCell>
                                  </>
                                )}
                                <TableCell className="font-bold">
                                  {formatCurrency(account.balance)}
                                </TableCell>
                              </TableRow>
                            ))}
                            
                            {/* إجمالي المصروفات */}
                            <TableRow className="bg-primary/10 font-bold">
                              <TableCell colSpan={1}></TableCell>
                              <TableCell>
                                {t('financial.total_expenses') || "إجمالي المصروفات"}
                              </TableCell>
                              {compareWithPrevPeriod && (
                                <>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                  <TableCell></TableCell>
                                </>
                              )}
                              <TableCell className="font-bold">
                                {formatCurrency(incomeStatementData.totalExpenses)}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* صافي الدخل - Net Income */}
                    <div className={`p-4 rounded-md ${incomeStatementData.netIncome >= 0 ? 'bg-green-50 dark:bg-green-950' : 'bg-red-50 dark:bg-red-950'}`}>
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-bold">
                          {t('financial.net_income') || "صافي الدخل"}
                        </h3>
                        <div className="font-bold text-xl">
                          {formatCurrency(incomeStatementData.netIncome)}
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground mt-2">
                        <div>
                          {t('financial.net_profit_margin') || "هامش صافي الربح"}: {getNetProfitMargin().toFixed(2)}%
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    {t('financial.no_data_available') || "لا توجد بيانات متاحة"}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="visual">
            {!isLoading && incomeStatementData && (
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {t('financial.income_statement.summary') || "ملخص قائمة الدخل"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[400px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={getChartData()}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip 
                            formatter={(value: number) => formatCurrency(value)}
                          />
                          <Legend />
                          <Bar 
                            dataKey="amount" 
                            name={t('financial.amount') || "المبلغ"} 
                            fill="#8884d8" 
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* توزيع الإيرادات */}
                  <Card>
                    <CardHeader>
                      <CardTitle>
                        {t('financial.revenue_distribution') || "توزيع الإيرادات"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={getRevenuesPieData()}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={100}
                              fill="#8884d8"
                              paddingAngle={5}
                              dataKey="value"
                              label={(entry) => entry.name}
                            >
                              {getRevenuesPieData().map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip 
                              formatter={(value: number) => formatCurrency(value)}
                            />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="mt-4">
                        <div className="text-sm font-medium mb-2">{t('financial.total_revenue') || "إجمالي الإيرادات"}</div>
                        <div className="text-2xl font-bold">{formatCurrency(incomeStatementData.totalRevenue)}</div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* توزيع المصروفات */}
                  <Card>
                    <CardHeader>
                      <CardTitle>
                        {t('financial.expense_distribution') || "توزيع المصروفات"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={getExpensesPieData()}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={100}
                              fill="#8884d8"
                              paddingAngle={5}
                              dataKey="value"
                              label={(entry) => entry.name}
                            >
                              {getExpensesPieData().map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip 
                              formatter={(value: number) => formatCurrency(value)}
                            />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="mt-4">
                        <div className="text-sm font-medium mb-2">{t('financial.total_expenses') || "إجمالي المصروفات"}</div>
                        <div className="text-2xl font-bold">{formatCurrency(incomeStatementData.totalExpenses)}</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* بطاقات ملخصة */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-center mb-4">
                        <div className="text-lg font-semibold">
                          {t('financial.total_revenue') || "إجمالي الإيرادات"}
                        </div>
                        <TrendingUp className="h-6 w-6 text-green-500" />
                      </div>
                      <div className="text-2xl font-bold">
                        {formatShortCurrency(incomeStatementData.totalRevenue)}
                      </div>
                      {compareWithPrevPeriod && (
                        <div className="text-sm mt-2 text-green-600">
                          {/* يمكن حساب نسبة التغيير هنا عندما تكون البيانات متاحة */}
                          +8.5% منذ الفترة السابقة
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-center mb-4">
                        <div className="text-lg font-semibold">
                          {t('financial.total_expenses') || "إجمالي المصروفات"}
                        </div>
                        <TrendingDown className="h-6 w-6 text-red-500" />
                      </div>
                      <div className="text-2xl font-bold">
                        {formatShortCurrency(incomeStatementData.totalExpenses)}
                      </div>
                      {compareWithPrevPeriod && (
                        <div className="text-sm mt-2 text-red-600">
                          {/* يمكن حساب نسبة التغيير هنا عندما تكون البيانات متاحة */}
                          +12.3% منذ الفترة السابقة
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-center mb-4">
                        <div className="text-lg font-semibold">
                          {t('financial.gross_profit') || "مجمل الربح"}
                        </div>
                        <TrendingUp className="h-6 w-6 text-blue-500" />
                      </div>
                      <div className="text-2xl font-bold">
                        {formatShortCurrency(incomeStatementData.grossProfit)}
                      </div>
                      <div className="text-sm mt-2 text-muted-foreground">
                        {t('financial.gross_profit_margin') || "هامش مجمل الربح"}: {getGrossProfitMargin().toFixed(2)}%
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-center mb-4">
                        <div className="text-lg font-semibold">
                          {t('financial.net_income') || "صافي الدخل"}
                        </div>
                        <TrendingUp className={`h-6 w-6 ${incomeStatementData.netIncome >= 0 ? 'text-green-500' : 'text-red-500'}`} />
                      </div>
                      <div className="text-2xl font-bold">
                        {formatShortCurrency(incomeStatementData.netIncome)}
                      </div>
                      <div className="text-sm mt-2 text-muted-foreground">
                        {t('financial.net_profit_margin') || "هامش صافي الربح"}: {getNetProfitMargin().toFixed(2)}%
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="analysis">
            {!isLoading && incomeStatementData && (
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {t('financial.income_statement.trend_analysis') || "تحليل الاتجاهات"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {compareWithPrevPeriod ? (
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {/* أكبر الزيادات */}
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">
                                {t('financial.largest_increases') || "أكبر الزيادات"}
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                              <div className="space-y-4">
                                {/* عرض أكبر 5 زيادات في الحسابات */}
                                {[
                                  ...incomeStatementData.revenues,
                                  ...incomeStatementData.expenses,
                                  ...incomeStatementData.costOfSales
                                ]
                                  .filter(account => account.changePercentage > 0)
                                  .sort((a, b) => b.changePercentage - a.changePercentage)
                                  .slice(0, 5)
                                  .map((account: any) => (
                                    <div key={account.accountId} className="flex justify-between items-center">
                                      <div>
                                        <div className="font-medium">{account.accountName}</div>
                                        <div className="text-xs text-muted-foreground">
                                          {formatCurrency(account.previousBalance)} → {formatCurrency(account.balance)}
                                        </div>
                                      </div>
                                      <div className="text-green-600 font-bold">
                                        +{account.changePercentage.toFixed(2)}%
                                      </div>
                                    </div>
                                  ))}
                                
                                {/* إذا لم تكن هناك زيادات */}
                                {[
                                  ...incomeStatementData.revenues,
                                  ...incomeStatementData.expenses,
                                  ...incomeStatementData.costOfSales
                                ].filter(account => account.changePercentage > 0).length === 0 && (
                                  <div className="text-center py-4 text-muted-foreground">
                                    {t('financial.no_increases_found') || "لم يتم العثور على زيادات"}
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                          
                          {/* أكبر الانخفاضات */}
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">
                                {t('financial.largest_decreases') || "أكبر الانخفاضات"}
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                              <div className="space-y-4">
                                {/* عرض أكبر 5 انخفاضات في الحسابات */}
                                {[
                                  ...incomeStatementData.revenues,
                                  ...incomeStatementData.expenses,
                                  ...incomeStatementData.costOfSales
                                ]
                                  .filter(account => account.changePercentage < 0)
                                  .sort((a, b) => a.changePercentage - b.changePercentage)
                                  .slice(0, 5)
                                  .map((account: any) => (
                                    <div key={account.accountId} className="flex justify-between items-center">
                                      <div>
                                        <div className="font-medium">{account.accountName}</div>
                                        <div className="text-xs text-muted-foreground">
                                          {formatCurrency(account.previousBalance)} → {formatCurrency(account.balance)}
                                        </div>
                                      </div>
                                      <div className="text-red-600 font-bold">
                                        {account.changePercentage.toFixed(2)}%
                                      </div>
                                    </div>
                                  ))}
                                
                                {/* إذا لم تكن هناك انخفاضات */}
                                {[
                                  ...incomeStatementData.revenues,
                                  ...incomeStatementData.expenses,
                                  ...incomeStatementData.costOfSales
                                ].filter(account => account.changePercentage < 0).length === 0 && (
                                  <div className="text-center py-4 text-muted-foreground">
                                    {t('financial.no_decreases_found') || "لم يتم العثور على انخفاضات"}
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                        
                        {/* تحليل هوامش الربح */}
                        <Card>
                          <CardHeader>
                            <CardTitle>
                              {t('financial.profit_margin_analysis') || "تحليل هوامش الربح"}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-6">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {/* هامش الربح الإجمالي */}
                                <div>
                                  <div className="text-lg font-medium mb-2">
                                    {t('financial.gross_profit_margin') || "هامش مجمل الربح"}
                                  </div>
                                  <div className="flex justify-between mb-2">
                                    <div>الحالي:</div>
                                    <div className="font-bold">{getGrossProfitMargin().toFixed(2)}%</div>
                                  </div>
                                  <div className="flex justify-between mb-4">
                                    <div>السابق:</div>
                                    <div>
                                      {/* يمكن حساب الهامش السابق عندما تكون البيانات متاحة */}
                                      31.5%
                                    </div>
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {getGrossProfitMargin() > 30 
                                      ? "هامش ربح إجمالي قوي يشير إلى كفاءة في التكاليف المباشرة." 
                                      : "هامش ربح إجمالي متوسط، يمكن تحسينه بخفض تكاليف المبيعات المباشرة أو زيادة الأسعار."}
                                  </div>
                                </div>
                                
                                {/* هامش صافي الربح */}
                                <div>
                                  <div className="text-lg font-medium mb-2">
                                    {t('financial.net_profit_margin') || "هامش صافي الربح"}
                                  </div>
                                  <div className="flex justify-between mb-2">
                                    <div>الحالي:</div>
                                    <div className="font-bold">{getNetProfitMargin().toFixed(2)}%</div>
                                  </div>
                                  <div className="flex justify-between mb-4">
                                    <div>السابق:</div>
                                    <div>
                                      {/* يمكن حساب الهامش السابق عندما تكون البيانات متاحة */}
                                      18.2%
                                    </div>
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {getNetProfitMargin() > 15 
                                      ? "هامش صافي ربح ممتاز يشير إلى كفاءة عالية في الإدارة المالية." 
                                      : "هامش صافي ربح معقول، يمكن تحسينه بمراجعة النفقات الإدارية والعامة."}
                                  </div>
                                </div>
                              </div>
                              
                              {/* تنبيهات وملاحظات */}
                              <div className="bg-yellow-50 dark:bg-yellow-950 p-4 rounded-md">
                                <h4 className="font-bold mb-2">ملاحظات وتوصيات</h4>
                                <div className="space-y-2">
                                  {getNetProfitMargin() < 10 && (
                                    <div className="flex items-start gap-2">
                                      <div className="flex-shrink-0">⚠️</div>
                                      <div>هامش صافي الربح منخفض، يجب مراجعة المصروفات والتكاليف غير المباشرة.</div>
                                    </div>
                                  )}
                                  
                                  {getGrossProfitMargin() - getNetProfitMargin() > 20 && (
                                    <div className="flex items-start gap-2">
                                      <div className="flex-shrink-0">⚠️</div>
                                      <div>فجوة كبيرة بين مجمل الربح وصافي الربح، مما يشير إلى ارتفاع المصروفات الإدارية والعامة.</div>
                                    </div>
                                  )}
                                  
                                  {/* نصائح وتوصيات إضافية */}
                                  <div className="flex items-start gap-2 pt-2">
                                    <div className="flex-shrink-0">💡</div>
                                    <div>تحليل تفصيلي للمصروفات قد يساعد في تحديد فرص خفض التكاليف.</div>
                                  </div>
                                  
                                  <div className="flex items-start gap-2">
                                    <div className="flex-shrink-0">💡</div>
                                    <div>مراجعة تسعير المنتجات/الخدمات للتأكد من تحقيق أقصى قيمة.</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <Calculator className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                        <h3 className="text-lg font-medium mb-2">
                          {t('financial.enable_comparison') || "تفعيل خاصية المقارنة"}
                        </h3>
                        <p className="text-muted-foreground max-w-md mx-auto mb-4">
                          {t('financial.enable_comparison_desc') || 
                            "لعرض التحليل المقارن، يرجى تفعيل خيار المقارنة مع الفترة السابقة في قسم التصفية أعلاه."}
                        </p>
                        <Button onClick={() => setCompareWithPrevPeriod(true)}>
                          {t('financial.enable_comparison_now') || "تفعيل المقارنة الآن"}
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </PageLayout>
  );
}