import { useState, useEffect, useRef, useMemo } from 'react';
import type { KeyboardEvent } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useLocation } from 'wouter';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { 
  FileTextIcon, 
  PlusCircleIcon, 
  SaveIcon,
  TrashIcon,
  ChevronLeftIcon,
  XCircleIcon,
  PlusIcon,
  MinusIcon,
  InfoIcon,
  CopyIcon,
  DownloadIcon,
  ArrowLeftRightIcon,
  ClipboardIcon,
  ArrowUpRightIcon,
  BookmarkIcon,
  Repeat2Icon,
  KeyboardIcon,
  LightbulbIcon,
  HistoryIcon
} from 'lucide-react';

import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Command, CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator, CommandShortcut } from "@/components/ui/command";

// Schema for the form
const formSchema = z.object({
  journalDate: z.string().min(1, "التاريخ مطلوب"),
  description: z.string().min(3, "الوصف مطلوب ويجب أن يحتوي على 3 أحرف على الأقل"),
  fiscalYear: z.string().min(1, "السنة المالية مطلوبة"),
  fiscalPeriod: z.string().min(1, "الفترة المالية مطلوبة"),
  reference: z.string().optional(),
  isAutoBalanced: z.boolean().default(true),
  lines: z.array(z.object({
    accountId: z.string().min(1, "الحساب مطلوب"),
    description: z.string().optional(),
    debit: z.string().optional(), // Using string for better input handling
    credit: z.string().optional(), // Using string for better input handling
    projectId: z.string().optional(),
  })).min(2, "يجب إضافة سطرين على الأقل (مدين ودائن)")
});

// تم الانتقال للتعريف أدناه

// Common account templates for quick selection
const commonAccountTemplates = [
  {
    name: "مصروفات على مشروع",
    lines: [
      { accountType: 'expense', isDebit: true, description: 'مصروفات على المشروع' },
      { accountType: 'asset', isDebit: false, description: 'النقد في الصندوق' }
    ]
  },
  {
    name: "تحصيل من عميل",
    lines: [
      { accountType: 'asset', isDebit: true, description: 'النقد في الصندوق' },
      { accountType: 'income', isDebit: false, description: 'إيرادات من العميل' }
    ]
  },
  {
    name: "دفع لمورد",
    lines: [
      { accountType: 'liability', isDebit: true, description: 'ذمم الموردين' },
      { accountType: 'asset', isDebit: false, description: 'النقد في الصندوق' }
    ]
  },
  {
    name: "مصروفات رواتب",
    lines: [
      { accountType: 'expense', isDebit: true, description: 'مصروفات رواتب الموظفين' },
      { accountType: 'asset', isDebit: false, description: 'حساب البنك' }
    ]
  },
  {
    name: "قيد تسوية",
    lines: [
      { accountType: 'expense', isDebit: true, description: 'تسوية حساب' },
      { accountType: 'expense', isDebit: false, description: 'تسوية حساب' }
    ]
  }
];

// Keyboard shortcuts map for help display
const keyboardShortcuts = [
  { key: 'Alt + A', description: 'إضافة سطر جديد' },
  { key: 'Alt + B', description: 'موازنة القيد تلقائياً' },
  { key: 'Alt + S', description: 'حفظ القيد' },
  { key: 'Alt + F', description: 'البحث عن حساب' },
  { key: 'Alt + T', description: 'استخدام قالب جاهز' },
  { key: 'Ctrl + Space', description: 'فتح البحث السريع' },
  { key: 'Ctrl + Enter', description: 'حفظ القيد' },
  { key: 'Ctrl + B', description: 'موازنة القيد' },
  { key: 'Enter', description: 'الانتقال للحقل التالي' },
  { key: 'Tab', description: 'الانتقال للحقل التالي' },
  { key: 'Shift + Tab', description: 'الانتقال للحقل السابق' },
];

// Frequently used accounts history
const getRecentlyUsedAccounts = () => {
  try {
    const stored = localStorage.getItem('recentlyUsedAccounts');
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error('خطأ في قراءة الحسابات المستخدمة مؤخراً:', e);
    return [];
  }
};

// Save to recently used accounts
const saveToRecentlyUsedAccounts = (accountId: string, accountData: any) => {
  try {
    const recentAccounts = getRecentlyUsedAccounts();
    // Check if account already exists
    const existingIndex = recentAccounts.findIndex((a: any) => a.id === accountId);
    
    if (existingIndex >= 0) {
      // Move to top if exists
      const account = recentAccounts[existingIndex];
      account.useCount = (account.useCount || 0) + 1;
      account.lastUsed = new Date().toISOString();
      recentAccounts.splice(existingIndex, 1);
      recentAccounts.unshift(account);
    } else {
      // Add new
      recentAccounts.unshift({
        id: accountId,
        name: accountData.name,
        code: accountData.code,
        useCount: 1,
        lastUsed: new Date().toISOString()
      });
    }
    
    // Keep only top 10
    const trimmed = recentAccounts.slice(0, 10);
    localStorage.setItem('recentlyUsedAccounts', JSON.stringify(trimmed));
    return trimmed;
  } catch (e) {
    console.error('خطأ في حفظ الحسابات المستخدمة مؤخراً:', e);
    return [];
  }
};

export default function NewJournalEntryPage() {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [tab, setTab] = useState('general');
  const queryClient = useQueryClient();
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [filteredAccounts, setFilteredAccounts] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const lineRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Reference to the last focused input field
  const lastFocusedInput = useRef<{ index: number, field: 'debit' | 'credit' | 'accountId' | 'description' | 'projectId' | null }>({
    index: 0,
    field: null
  });

  // Keyboard shortcuts
  useEffect(() => {
    function handleKeyDown(this: Window, ev: globalThis.KeyboardEvent) {
      // Alt+A to add new line
      if (ev.altKey && ev.key === 'a') {
        ev.preventDefault();
        addLine();
      }
      // Alt+B to auto-balance
      else if (ev.altKey && ev.key === 'b') {
        ev.preventDefault();
        autoBalance();
      }
      // Alt+S to save/submit
      else if (ev.altKey && ev.key === 's') {
        ev.preventDefault();
        form.handleSubmit(onSubmit)();
      }
      // Alt+F to find account (open command dialog)
      else if (ev.altKey && ev.key === 'f') {
        ev.preventDefault();
        setIsCommandOpen(true);
      }
      // Alt+T to open templates
      else if (ev.altKey && ev.key === 't') {
        ev.preventDefault();
        setIsTemplateDialogOpen(true);
      }
      // Ctrl+Space to open command dialog (command palette style)
      else if (ev.ctrlKey && ev.code === 'Space') {
        ev.preventDefault();
        setIsCommandOpen(true);
      }
      // Ctrl+Enter to save/submit
      else if (ev.ctrlKey && ev.key === 'Enter') {
        ev.preventDefault();
        form.handleSubmit(onSubmit)();
      }
      // Ctrl+B to balance
      else if (ev.ctrlKey && ev.key === 'b') {
        ev.preventDefault();
        autoBalance();
      }
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Fetch projects
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery({
    queryKey: ['projects'],
    queryFn: async () => {
      const response = await fetch('/api/projects');
      if (!response.ok) {
        throw new Error('حدث خطأ أثناء جلب المشاريع');
      }
      return await response.json();
    }
  });

  // Fetch chart of accounts
  const { data: accounts = [], isLoading: isLoadingAccounts } = useQuery({
    queryKey: ['chartOfAccounts'],
    queryFn: async () => {
      const response = await fetch('/api/chart-of-accounts');
      if (!response.ok) {
        throw new Error('حدث خطأ أثناء جلب شجرة الحسابات');
      }
      return await response.json();
    }
  });

  // Group accounts by type
  const accountsByType = accounts.reduce((acc: Record<string, any[]>, account: any) => {
    const type = account.type || 'other';
    if (!acc[type]) acc[type] = [];
    acc[type].push(account);
    return acc;
  }, {});

  // Fetch fiscal periods
  const { data: fiscalPeriods = [], isLoading: isLoadingPeriods } = useQuery({
    queryKey: ['fiscalPeriods'],
    queryFn: async () => {
      const response = await fetch('/api/financial-periods');
      if (!response.ok) {
        throw new Error('حدث خطأ أثناء جلب الفترات المالية');
      }
      return await response.json();
    }
  });

  // Create the form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      journalDate: format(new Date(), 'yyyy-MM-dd'),
      description: '',
      fiscalYear: new Date().getFullYear().toString(),
      fiscalPeriod: '1', // استخدام الفترة 1 كقيمة افتراضية
      reference: '',
      isAutoBalanced: true,
      lines: [
        { accountId: '', description: '', debit: '', credit: '', projectId: '' },
        { accountId: '', description: '', debit: '', credit: '', projectId: '' }
      ]
    },
  });

  // Field array for journal entry lines
  const { fields, append, remove, update } = useFieldArray({
    control: form.control,
    name: "lines"
  });

  // Calculate totals
  const totalDebits = form.watch("lines").reduce((sum, line) => {
    const debitValue = parseFloat(line.debit || '0');
    return sum + (isNaN(debitValue) ? 0 : debitValue);
  }, 0);

  const totalCredits = form.watch("lines").reduce((sum, line) => {
    const creditValue = parseFloat(line.credit || '0');
    return sum + (isNaN(creditValue) ? 0 : creditValue);
  }, 0);

  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01; // Allow for floating point imprecision

  // Filter accounts by search term
  useEffect(() => {
    if (!searchTerm) {
      setFilteredAccounts([]);
      return;
    }

    const filtered = accounts.filter((account: any) => 
      (account.name && account.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (account.code && account.code.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    
    setFilteredAccounts(filtered);
  }, [searchTerm, accounts]);

  // Mutation for creating a journal entry
  const createJournalEntry = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      // حساب مجاميع المدين والدائن
      const totalDebitAmount = parseFloat(data.lines.reduce(
        (sum, line) => sum + (parseFloat(line.debit) || 0), 0
      ).toFixed(2));
      
      const totalCreditAmount = parseFloat(data.lines.reduce(
        (sum, line) => sum + (parseFloat(line.credit) || 0), 0
      ).toFixed(2));
      
      // تحويل البيانات إلى الصيغة التي يتوقعها الخادم
      const entryData = {
        journal_number: data.reference || Date.now().toString(), // رقم القيد
        journal_date: data.journalDate ? new Date(data.journalDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        fiscal_year: parseInt(data.fiscalYear || new Date().getFullYear().toString()),
        period_number: parseInt(data.fiscalPeriod || "1"),
        description: data.description || '',
        status: 'draft', // دائما ننشئ كمسودة أولاً
        debit_amount: totalDebitAmount,
        credit_amount: totalCreditAmount,
        source_reference: data.reference || '',
        lines: data.lines.map((line, index) => ({
          account_id: parseInt(line.accountId),
          description: line.description || '',
          debit_amount: parseFloat(line.debit) || 0,
          credit_amount: parseFloat(line.credit) || 0,
          line_number: index + 1,
          project_id: line.projectId && line.projectId !== 'none' ? parseInt(line.projectId) : null
        }))
      };

      // تسجيل تفاصيل البيانات المرسلة للخادم بشكل واضح
      console.log("إرسال البيانات إلى الخادم:", JSON.stringify(entryData, null, 2));

      try {
        const response = await apiRequest('POST', '/api/journal-entries', entryData);
        
        console.log("استجابة الخادم:", response);
        return response;
      } catch (error) {
        console.error("خطأ في استجابة الخادم:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['journalEntries'] });
      toast({
        title: t('success'),
        description: "تم إنشاء قيد اليومية بنجاح",
      });
      setLocation('/financial/journal-entries');
    },
    onError: (error) => {
      toast({
        title: t('error'),
        description: "حدث خطأ أثناء إنشاء قيد اليومية",
        variant: "destructive",
      });
      console.error(error);
    }
  });

  // Submit handler
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    if (!isBalanced) {
      if (data.isAutoBalanced) {
        // Auto balance before submitting
        autoBalance();
        if (!isBalanced) {
          showBalanceError();
          return;
        }
      } else {
        showBalanceError();
        return;
      }
    }
    
    // Remove empty lines
    const nonEmptyLines = data.lines.filter(
      line => line.accountId && (parseFloat(line.debit || '0') > 0 || parseFloat(line.credit || '0') > 0)
    );
    
    if (nonEmptyLines.length < 2) {
      toast({
        title: "خطأ في القيد",
        description: "يجب أن يحتوي القيد على سطرين على الأقل (مدين ودائن)",
        variant: "destructive",
      });
      return;
    }
    
    // Update form with non-empty lines
    data.lines = nonEmptyLines;
    createJournalEntry.mutate(data);
  };

  const showBalanceError = () => {
    toast({
      title: "خطأ في القيد",
      description: "يجب أن يكون مجموع المدين يساوي مجموع الدائن",
      variant: "destructive",
    });
  };

  // Handle adding a new journal line
  const addLine = () => {
    append({ accountId: '', description: '', debit: '', credit: '', projectId: '' });
    
    // Focus on the new line after it's added
    setTimeout(() => {
      const newIndex = fields.length;
      if (lineRefs.current[newIndex]) {
        const firstInput = lineRefs.current[newIndex]?.querySelector('input, select');
        if (firstInput) {
          (firstInput as HTMLElement).focus();
        }
      }
    }, 10);
  };

  // Add multiple lines at once (useful for templates)
  const addMultipleLines = (newLines: { accountId: string, description: string, debit: string, credit: string, projectId: string }[]) => {
    newLines.forEach(line => append(line));
  };

  // Remove line
  const removeLine = (index: number) => {
    if (fields.length > 2) {
      remove(index);
    } else {
      toast({
        title: "لا يمكن الحذف",
        description: "يجب أن يحتوي القيد على سطرين على الأقل",
      });
    }
  };

  // Handle tab key navigation within a line
  const handleTabKeyNavigation = (e: React.KeyboardEvent, index: number, field: 'accountId' | 'description' | 'debit' | 'credit' | 'projectId') => {
    if (e.key === 'Tab') {
      // Don't need to do anything special, normal tab behavior works,
      // but we update our reference to the last focused field
      lastFocusedInput.current = { index, field };
    } else if (e.key === 'Enter') {
      e.preventDefault();
      
      // If this is the last field of the last line, add a new line
      if (field === 'projectId' && index === fields.length - 1) {
        addLine();
      } else {
        // Move to the next field or next line
        const nextField = getNextField(field);
        const nextIndex = nextField === 'accountId' ? index + 1 : index;
        
        if (nextIndex < fields.length) {
          const targetRef = lineRefs.current[nextIndex];
          if (targetRef) {
            const inputToFocus = targetRef.querySelector(`[name="lines.${nextIndex}.${nextField}"]`);
            if (inputToFocus) {
              (inputToFocus as HTMLElement).focus();
            }
          }
        }
      }
    }
  };

  // Get the next field in tab order
  const getNextField = (currentField: 'accountId' | 'description' | 'debit' | 'credit' | 'projectId'): 'accountId' | 'description' | 'debit' | 'credit' | 'projectId' => {
    const fieldOrder: ('accountId' | 'description' | 'debit' | 'credit' | 'projectId')[] = ['accountId', 'description', 'debit', 'credit', 'projectId'];
    const currentIndex = fieldOrder.indexOf(currentField);
    return fieldOrder[(currentIndex + 1) % fieldOrder.length];
  };

  // Auto-balance the entries (improved version)
  const autoBalance = () => {
    if (totalDebits === 0 && totalCredits === 0) {
      return; // Nothing to balance
    }

    const values = form.getValues();
    const lines = [...values.lines];

    if (Math.abs(totalDebits - totalCredits) < 0.01) {
      // Already balanced (accounting for floating point imprecision)
      return;
    }

    if (totalDebits > totalCredits) {
      // Need to add more credits
      const diff = +(totalDebits - totalCredits).toFixed(2); // Fix to 2 decimal places
      
      // Try to find the most suitable line to adjust
      // Priority: 1. Last line with no debit, 2. Last line with credit, 3. Last line with accountId
      let creditLineIndex = -1;
      
      // First check for a line that already has a credit but no debit
      creditLineIndex = lines.findIndex(line => line.credit && !line.debit);
      
      // If not found, look for any line with an account selected but no debit
      if (creditLineIndex < 0) {
        creditLineIndex = lines.findIndex(line => line.accountId && !line.debit);
      }
      
      // If still not found, use the last line that has an account selected
      if (creditLineIndex < 0) {
        for (let i = lines.length - 1; i >= 0; i--) {
          if (lines[i].accountId) {
            creditLineIndex = i;
            break;
          }
        }
      }
      
      // If no suitable line was found, add a new line
      if (creditLineIndex < 0) {
        // Get the first asset account (assuming it's cash or bank)
        const cashAccount = accounts.find((acc: any) => acc.type === 'asset' || acc.code?.startsWith('1'));
        
        append({ 
          accountId: cashAccount ? cashAccount.id.toString() : '', 
          description: 'موازنة القيد - تلقائي', 
          debit: '', 
          credit: diff.toString(), 
          projectId: '' 
        });
        
        toast({
          title: "تم الموازنة تلقائيًا",
          description: "تمت إضافة سطر ائتمان (دائن) جديد لموازنة القيد",
        });
      } else {
        // Update the existing line
        const existingCredit = parseFloat(lines[creditLineIndex].credit || '0');
        lines[creditLineIndex].credit = (existingCredit + diff).toString();
        form.setValue('lines', lines);
        
        toast({
          title: "تم الموازنة تلقائيًا",
          description: "تم تعديل سطر الائتمان (الدائن) لموازنة القيد",
        });
      }
    } else if (totalCredits > totalDebits) {
      // Need to add more debits
      const diff = +(totalCredits - totalDebits).toFixed(2); // Fix to 2 decimal places
      
      // Try to find the most suitable line to adjust
      // Priority: 1. First line with no credit, 2. First line with debit, 3. First line with accountId
      let debitLineIndex = -1;
      
      // First check for a line that already has a debit but no credit
      debitLineIndex = lines.findIndex(line => line.debit && !line.credit);
      
      // If not found, look for any line with an account selected but no credit
      if (debitLineIndex < 0) {
        debitLineIndex = lines.findIndex(line => line.accountId && !line.credit);
      }
      
      // If still not found, use the first line that has an account selected
      if (debitLineIndex < 0) {
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].accountId) {
            debitLineIndex = i;
            break;
          }
        }
      }
      
      // If no suitable line was found, add a new line
      if (debitLineIndex < 0) {
        // Get the first expense account
        const expenseAccount = accounts.find((acc: any) => acc.type === 'expense' || acc.code?.startsWith('5'));
        
        append({ 
          accountId: expenseAccount ? expenseAccount.id.toString() : '', 
          description: 'موازنة القيد - تلقائي', 
          debit: diff.toString(), 
          credit: '', 
          projectId: '' 
        });
        
        toast({
          title: "تم الموازنة تلقائيًا",
          description: "تمت إضافة سطر مدين جديد لموازنة القيد",
        });
      } else {
        // Update the existing line
        const existingDebit = parseFloat(lines[debitLineIndex].debit || '0');
        lines[debitLineIndex].debit = (existingDebit + diff).toString();
        form.setValue('lines', lines);
        
        toast({
          title: "تم الموازنة تلقائيًا",
          description: "تم تعديل سطر المدين لموازنة القيد",
        });
      }
    }
  };
  
  // Apply a template
  const applyTemplate = (template: typeof commonAccountTemplates[0]) => {
    console.log("applyTemplate called with template:", template.name);
    
    try {
      const currentLines = form.getValues().lines;
      
      // Clear existing lines if they don't have entries
      if (currentLines.every(line => !line.accountId && !line.debit && !line.credit)) {
        console.log("Clearing existing empty lines");
        while (fields.length) {
          remove(0);
        }
      }
      
      // Check if accounts data is available
      if (!accounts) {
        console.error("Accounts is undefined or null");
        toast({
          title: "خطأ في تطبيق القالب",
          description: "لم يتم العثور على بيانات الحسابات.",
          variant: "destructive"
        });
        setIsTemplateDialogOpen(false);
        return;
      }
      
      if (!Array.isArray(accounts)) {
        console.error("Accounts is not an array:", accounts);
        toast({
          title: "خطأ في تطبيق القالب",
          description: "خطأ في هيكل بيانات الحسابات.",
          variant: "destructive"
        });
        setIsTemplateDialogOpen(false);
        return;
      }
      
      if (accounts.length === 0) {
        console.error("Accounts array is empty");
        toast({
          title: "خطأ في تطبيق القالب",
          description: "قائمة الحسابات فارغة. يرجى إضافة حسابات أولاً.",
          variant: "destructive"
        });
        setIsTemplateDialogOpen(false);
        return;
      }
      
      // Debug: log accounts data
      console.log("Template selected:", template.name);
      console.log("Available accounts count:", accounts.length);
      
      // Map of account types to use for matching
      const accountTypeMap = {
        'asset': ['asset', 'أصول', 'أصل', '1'],
        'liability': ['liability', 'التزامات', 'خصوم', '2'],
        'equity': ['equity', 'حقوق ملكية', 'حقوق', '3'],
        'income': ['income', 'revenue', 'إيرادات', 'دخل', '4'],
        'revenue': ['revenue', 'income', 'إيرادات', 'دخل', '4'],
        'expense': ['expense', 'expenses', 'مصروفات', 'نفقات', '5']
      };
      
      // Add template lines
      const newLines = [];
      for (const templateLine of template.lines) {
        // Convert account type to correct format (lowercase) if needed
        const accountTypeKey = (templateLine.accountType || '').toLowerCase();
        
        // Get possible type matches
        const possibleTypes = accountTypeMap[accountTypeKey as keyof typeof accountTypeMap] || [accountTypeKey];
        
        console.log(`Looking for account of type: ${accountTypeKey}, possible matches:`, possibleTypes);
        console.log(`IsDebit: ${templateLine.isDebit}`);
        
        // Find accounts by type or code pattern
        const accountsOfType = accounts.filter((acc: any) => {
          if (!acc) return false;
          
          // Make sure acc.type exists and convert to lowercase for comparison
          const accType = (acc.type || '').toLowerCase();
          const accCode = (acc.code || '').toLowerCase();
          
          // Check if account type matches any of the possible types
          const typeMatch = possibleTypes.some(type => {
            return accType === type || accCode.startsWith(type);
          });
          
          return typeMatch;
        });
        
        console.log(`Found ${accountsOfType.length} accounts matching type ${accountTypeKey}:`, accountsOfType);
        
        // Get the first matching account
        const account = accountsOfType.length > 0 ? accountsOfType[0] : null;
        
        if (account) {
          // Prepare a new line with the appropriate debit/credit values
          const newLine = {
            accountId: account.id.toString(),
            description: templateLine.description || '',
            debit: templateLine.isDebit ? '1000' : '', // تعيين مبلغ افتراضي للمدين
            credit: !templateLine.isDebit ? '1000' : '', // تعيين مبلغ افتراضي للدائن
            projectId: ''
          };
          
          newLines.push(newLine);
          console.log(`Prepared line for ${account.name} (${templateLine.isDebit ? 'debit' : 'credit'}):`, newLine);
        } else {
          console.warn(`No account found for type: ${templateLine.accountType}`);
        }
      }
      
      // Add all new lines at once if there are any
      if (newLines.length > 0) {
        console.log(`Adding ${newLines.length} new lines to the form`);
        newLines.forEach(line => {
          append(line);
        });
      }
      
      // Close the dialog and show the lines tab
      setIsTemplateDialogOpen(false);
      setTab('lines');
    } catch (error) {
      console.error("Error applying template:", error);
      toast({
        title: "خطأ في تطبيق القالب",
        description: "حدث خطأ أثناء تطبيق القالب. يرجى التحقق من وحدة التحكم للاطلاع على التفاصيل.",
        variant: "destructive"
      });
      setIsTemplateDialogOpen(false);
      return;
    }
    
    // متغير newLines تم تعريفه داخل الكتلة try، لا يمكن الوصول إليه هنا
    // لذلك نستخدم فحص form.getValues().lines 
    const lines = form.getValues().lines;
    // تحقق من وجود سطور غير فارغة
    const hasValidLines = lines.some(line => line.accountId && (line.debit || line.credit));
    
    if (hasValidLines) {
      toast({
        title: "تم تطبيق القالب",
        description: `تم تطبيق قالب "${template.name}" بنجاح`,
      });
    } else {
      toast({
        title: "تنبيه",
        description: "لم يتم العثور على حسابات مناسبة للقالب. يرجى إضافة الحسابات المطلوبة أولاً.",
        variant: "destructive"
      });
    }
  };
  
  // Duplicate a line
  const duplicateLine = (index: number) => {
    const lineToDuplicate = form.getValues().lines[index];
    append({ ...lineToDuplicate });
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Button variant="ghost" onClick={() => setLocation('/financial/journal-entries')} className="ml-2">
            <ChevronLeftIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
            {t('back')}
          </Button>
          <h1 className="text-2xl font-bold">{t('new_journal_entry')}</h1>
          
          {/* Keyboard shortcuts tooltip */}
          <TooltipProvider>
            <Tooltip delayDuration={300}>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="mr-2">
                  <KeyboardIcon size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="w-80 p-0" align="start">
                <Card className="border-0 shadow-none">
                  <CardHeader className="py-2">
                    <CardTitle className="text-md">اختصارات لوحة المفاتيح</CardTitle>
                    <CardDescription>استخدم هذه الاختصارات لتسريع إدخال البيانات</CardDescription>
                  </CardHeader>
                  <CardContent className="grid gap-1 py-2">
                    {keyboardShortcuts.map((shortcut, i) => (
                      <div key={i} className="flex justify-between">
                        <span className="font-medium">{shortcut.key}</span>
                        <span className="text-muted-foreground">{shortcut.description}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsTemplateDialogOpen(true)}
                >
                  <BookmarkIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                  استخدام قالب
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>استخدام قالب القيود المحفوظة (Alt+T)</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsCommandOpen(true)}
                >
                  <ArrowUpRightIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                  البحث السريع
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>البحث السريع عن الحسابات والقيود (Alt+F أو Ctrl+Space)</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Keyboard Shortcuts Help */}
      <Alert className="mb-4 bg-muted/50">
        <InfoIcon className="h-4 w-4" />
        <AlertTitle>اختصارات لوحة المفاتيح</AlertTitle>
        <AlertDescription className="text-sm">
          <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1">
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Alt+A</kbd> إضافة سطر جديد</span>
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Alt+B</kbd> موازنة القيد تلقائياً</span>
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Alt+S</kbd> حفظ القيد</span>
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Alt+F</kbd> البحث عن حساب</span>
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Alt+T</kbd> استخدام قالب</span>
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Ctrl+Space</kbd> البحث السريع</span>
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Ctrl+Enter</kbd> حفظ القيد</span>
            <span><kbd className="px-1 py-0.5 bg-muted rounded border">Enter</kbd> الانتقال للحقل التالي</span>
          </div>
        </AlertDescription>
      </Alert>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('new_journal_entry')}</CardTitle>
              <CardDescription className="flex justify-between">
                <span>{t('journal_entries_description')}</span>
                {isBalanced ? (
                  <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                    {t('balanced')}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">
                    {t('not_balanced')} ({Math.abs(totalDebits - totalCredits).toFixed(2)})
                  </Badge>
                )}
              </CardDescription>
            </CardHeader>

            <Tabs value={tab} onValueChange={setTab} className="w-full">
              <div className="px-6">
                <TabsList className="mb-2">
                  <TabsTrigger value="general">
                    <FileTextIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                    {t('general_info')}
                  </TabsTrigger>
                  <TabsTrigger value="lines">
                    <ArrowLeftRightIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                    {t('journal_lines')}
                  </TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="general" className="m-0">
                <CardContent className="space-y-4 pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="journalDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('date')}</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="reference"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('reference')}</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder={t('reference_placeholder')} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="fiscalYear"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('fiscal_year')}</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('select_fiscal_year')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="2025">2025</SelectItem>
                              <SelectItem value="2024">2024</SelectItem>
                              <SelectItem value="2023">2023</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="fiscalPeriod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('fiscal_period')}</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('select_fiscal_period')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {isLoadingPeriods ? (
                                <div className="p-2">
                                  <Skeleton className="h-5 w-full mb-2" />
                                  <Skeleton className="h-5 w-full mb-2" />
                                  <Skeleton className="h-5 w-full" />
                                </div>
                              ) : fiscalPeriods.length === 0 ? (
                                <div className="p-2 text-center text-muted-foreground">
                                  {t('no_fiscal_periods')}
                                </div>
                              ) : (
                                fiscalPeriods.map((period: any) => (
                                  <SelectItem key={period.id} value={period.periodNumber.toString()}>
                                    {period.name || `${period.startDate} - ${period.endDate}`}
                                  </SelectItem>
                                ))
                              )}
                              {/* قيم افتراضية في حالة عدم وجود فترات في قاعدة البيانات، يتم عرضها فقط إذا كانت قائمة الفترات فارغة */}
                              {!fiscalPeriods || fiscalPeriods.length === 0 && (
                                <>
                                  <SelectItem value="1">الربع الأول</SelectItem>
                                  <SelectItem value="2">الربع الثاني</SelectItem>
                                  <SelectItem value="3">الربع الثالث</SelectItem>
                                  <SelectItem value="4">الربع الرابع</SelectItem>
                                </>
                              )}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('description')}</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder={t('description_placeholder')}
                            rows={3}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="isAutoBalanced"
                    render={({ field }) => (
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <input
                          type="checkbox"
                          id="isAutoBalanced"
                          checked={field.value}
                          onChange={field.onChange}
                          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <label htmlFor="isAutoBalanced" className="text-sm text-gray-600">
                          {t('auto_balance')}
                        </label>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-6 w-6">
                                <InfoIcon className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="max-w-xs">{t('auto_balance_description')}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    )}
                  />
                </CardContent>
              </TabsContent>

              <TabsContent value="lines" className="m-0">
                <CardContent className="pt-4">
                  <div className="mb-4 flex items-center justify-between">
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <div className="font-medium">{t('journal_lines')}</div>
                      <Badge>{fields.length}</Badge>
                    </div>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                          >
                            <PlusIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                            {t('add_line')}
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={addLine}>
                            <PlusIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                            إضافة سطر فارغ
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setIsTemplateDialogOpen(true)}>
                            <BookmarkIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                            إضافة من قالب
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => {
                            append({ accountId: '', description: '', debit: '', credit: '', projectId: '' });
                            append({ accountId: '', description: '', debit: '', credit: '', projectId: '' });
                          }}>
                            <PlusCircleIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                            إضافة سطرين
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={autoBalance}
                              disabled={totalDebits === 0 && totalCredits === 0}
                            >
                              <Repeat2Icon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                              {t('auto_balance_lines')}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>موازنة القيد تلقائياً (Alt+B أو Ctrl+B)</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>

                  <ScrollArea className="h-[400px] rounded-md border">
                    <div className="p-4">
                      {fields.map((field, index) => (
                        <div 
                          key={field.id} 
                          className="mb-6 p-4 border rounded-md bg-muted/10 relative hover:bg-muted/20 transition-colors"
                          ref={el => lineRefs.current[index] = el}
                        >
                          <div className="absolute top-2 right-2 flex items-center space-x-1 rtl:space-x-reverse">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => duplicateLine(index)}
                                    className="h-8 w-8"
                                  >
                                    <CopyIcon className="h-4 w-4 text-muted-foreground" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>نسخ السطر</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => removeLine(index)}
                                    className="h-8 w-8"
                                  >
                                    <TrashIcon className="h-4 w-4 text-muted-foreground" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>حذف السطر</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-4">
                            <div className="md:col-span-5">
                              <FormField
                                control={form.control}
                                name={`lines.${index}.accountId`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>{t('account')}</FormLabel>
                                    <Select
                                      onValueChange={field.onChange}
                                      value={field.value}
                                    >
                                      <FormControl>
                                        <SelectTrigger onKeyDown={(e) => handleTabKeyNavigation(e, index, 'accountId')}>
                                          <SelectValue placeholder={t('select_account')} />
                                        </SelectTrigger>
                                      </FormControl>
                                      <SelectContent>
                                        <SelectGroup>
                                          <SelectLabel>الأصول</SelectLabel>
                                          {accountsByType['asset']?.map((account: any) => (
                                            <SelectItem key={account.id} value={account.id.toString()}>
                                              {account.name} ({account.code})
                                            </SelectItem>
                                          ))}
                                        </SelectGroup>
                                        <SelectGroup>
                                          <SelectLabel>الخصوم</SelectLabel>
                                          {accountsByType['liability']?.map((account: any) => (
                                            <SelectItem key={account.id} value={account.id.toString()}>
                                              {account.name} ({account.code})
                                            </SelectItem>
                                          ))}
                                        </SelectGroup>
                                        <SelectGroup>
                                          <SelectLabel>الإيرادات</SelectLabel>
                                          {accountsByType['income']?.map((account: any) => (
                                            <SelectItem key={account.id} value={account.id.toString()}>
                                              {account.name} ({account.code})
                                            </SelectItem>
                                          ))}
                                        </SelectGroup>
                                        <SelectGroup>
                                          <SelectLabel>المصروفات</SelectLabel>
                                          {accountsByType['expense']?.map((account: any) => (
                                            <SelectItem key={account.id} value={account.id.toString()}>
                                              {account.name} ({account.code})
                                            </SelectItem>
                                          ))}
                                        </SelectGroup>
                                        <SelectGroup>
                                          <SelectLabel>حقوق الملكية</SelectLabel>
                                          {accountsByType['equity']?.map((account: any) => (
                                            <SelectItem key={account.id} value={account.id.toString()}>
                                              {account.name} ({account.code})
                                            </SelectItem>
                                          ))}
                                        </SelectGroup>
                                        <SelectGroup>
                                          <SelectLabel>أخرى</SelectLabel>
                                          {accountsByType['other']?.map((account: any) => (
                                            <SelectItem key={account.id} value={account.id.toString()}>
                                              {account.name} ({account.code})
                                            </SelectItem>
                                          ))}
                                        </SelectGroup>
                                        {/* Fallback options */}
                                        {!accounts || accounts.length === 0 && (
                                          <SelectGroup>
                                            <SelectLabel>حسابات افتراضية</SelectLabel>
                                            <SelectItem value="1001">النقد في الصندوق (1001)</SelectItem>
                                            <SelectItem value="1002">البنك - الحساب الجاري (1002)</SelectItem>
                                            <SelectItem value="1100">الذمم المدينة (1100)</SelectItem>
                                            <SelectItem value="2001">الذمم الدائنة (2001)</SelectItem>
                                            <SelectItem value="3001">رأس المال (3001)</SelectItem>
                                            <SelectItem value="4001">إيرادات المشاريع (4001)</SelectItem>
                                            <SelectItem value="5001">مصاريف المشاريع (5001)</SelectItem>
                                          </SelectGroup>
                                        )}
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>

                            <div className="md:col-span-3">
                              <FormField
                                control={form.control}
                                name={`lines.${index}.description`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>{t('line_description')}</FormLabel>
                                    <FormControl>
                                      <Input 
                                        {...field} 
                                        placeholder={t('line_description_placeholder')} 
                                        onKeyDown={(e) => handleTabKeyNavigation(e, index, 'description')}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>

                            <div className="md:col-span-2">
                              <FormField
                                control={form.control}
                                name={`lines.${index}.debit`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>{t('debit')}</FormLabel>
                                    <FormControl>
                                      <Input
                                        {...field}
                                        type="number"
                                        step="0.01"
                                        min="0"
                                        placeholder="0.00"
                                        className={field.value ? "bg-blue-50" : ""}
                                        onChange={(e) => {
                                          field.onChange(e);
                                          if (e.target.value) {
                                            // Clear the credit if a debit is entered
                                            form.setValue(`lines.${index}.credit`, '');
                                          }
                                        }}
                                        onKeyDown={(e) => handleTabKeyNavigation(e, index, 'debit')}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>

                            <div className="md:col-span-2">
                              <FormField
                                control={form.control}
                                name={`lines.${index}.credit`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>{t('credit')}</FormLabel>
                                    <FormControl>
                                      <Input
                                        {...field}
                                        type="number"
                                        step="0.01"
                                        min="0"
                                        placeholder="0.00"
                                        className={field.value ? "bg-green-50" : ""}
                                        onChange={(e) => {
                                          field.onChange(e);
                                          if (e.target.value) {
                                            // Clear the debit if a credit is entered
                                            form.setValue(`lines.${index}.debit`, '');
                                          }
                                        }}
                                        onKeyDown={(e) => handleTabKeyNavigation(e, index, 'credit')}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>

                          <div className="mt-2">
                            <FormField
                              control={form.control}
                              name={`lines.${index}.projectId`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>{t('project')}</FormLabel>
                                  <Select
                                    onValueChange={field.onChange}
                                    value={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger onKeyDown={(e) => handleTabKeyNavigation(e, index, 'projectId')}>
                                        <SelectValue placeholder={t('select_project')} />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="none">{t('none')}</SelectItem>
                                      {projects.map((project: any) => (
                                        <SelectItem key={project.id} value={project.id.toString()}>
                                          {project.name}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>

                  <div className="mt-4 border-t pt-4">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[200px]">الإجمالي</TableHead>
                          <TableHead className="text-center">المدين</TableHead>
                          <TableHead className="text-center">الدائن</TableHead>
                          <TableHead className="text-center">الفرق</TableHead>
                          <TableHead className="text-center">الحالة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">القيم</TableCell>
                          <TableCell className="text-center font-semibold text-blue-600">{totalDebits.toFixed(2)}</TableCell>
                          <TableCell className="text-center font-semibold text-green-600">{totalCredits.toFixed(2)}</TableCell>
                          <TableCell className="text-center font-semibold">
                            {Math.abs(totalDebits - totalCredits).toFixed(2)}
                          </TableCell>
                          <TableCell className="text-center">
                            {isBalanced ? (
                              <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                                {t('balanced')}
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">
                                {t('not_balanced')}
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </TabsContent>
            </Tabs>

            <CardFooter className="flex justify-between">
              <Button
                variant="outline" 
                onClick={() => setLocation('/financial/journal-entries')}
              >
                {t('cancel')}
              </Button>
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={autoBalance}
                  disabled={isBalanced || (totalDebits === 0 && totalCredits === 0)}
                >
                  <Repeat2Icon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                  {t('auto_balance')}
                </Button>
                <Button 
                  type="submit" 
                  disabled={createJournalEntry.isPending}
                  className="gap-1"
                >
                  {createJournalEntry.isPending && (
                    <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full" />
                  )}
                  <SaveIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                  {t('save')}
                </Button>
              </div>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {/* Command Dialog for quick search */}
      <CommandDialog open={isCommandOpen} onOpenChange={setIsCommandOpen}>
        <CommandInput placeholder="ابحث عن الحسابات..." onValueChange={setSearchTerm} />
        <CommandList>
          <CommandEmpty>لا توجد نتائج مطابقة</CommandEmpty>
          {/* Recently used accounts */}
          {getRecentlyUsedAccounts().length > 0 && (
            <CommandGroup heading="الحسابات المستخدمة مؤخراً">
              {getRecentlyUsedAccounts().slice(0, 5).map((account: any) => (
                <CommandItem
                  key={account.id}
                  onSelect={() => {
                    if (lastFocusedInput.current.index !== null && lastFocusedInput.current.index < fields.length) {
                      form.setValue(`lines.${lastFocusedInput.current.index}.accountId`, account.id.toString());
                      
                      // Update recently used account
                      saveToRecentlyUsedAccounts(account.id.toString(), account);
                    } else {
                      append({
                        accountId: account.id.toString(),
                        description: account.name,
                        debit: '',
                        credit: '',
                        projectId: ''
                      });
                    }
                    setIsCommandOpen(false);
                  }}
                >
                  <div className="flex flex-col">
                    <div>
                      <span className="font-medium">{account.code}</span> - {account.name}
                    </div>
                    <div className="text-xs text-muted-foreground flex justify-between w-full">
                      <span>استخدم {account.useCount} مرة</span>
                      <span>{new Date(account.lastUsed).toLocaleDateString()}</span>
                    </div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}
          
          <CommandSeparator />
          
          <CommandGroup heading="الحسابات">
            {filteredAccounts.slice(0, 10).map((account: any) => (
              <CommandItem
                key={account.id}
                onSelect={() => {
                  // If there's a last focused item, update its account
                  if (lastFocusedInput.current.index !== null && lastFocusedInput.current.index < fields.length) {
                    form.setValue(`lines.${lastFocusedInput.current.index}.accountId`, account.id.toString());
                    
                    // Save to recently used accounts
                    saveToRecentlyUsedAccounts(account.id.toString(), account);
                  } else {
                    // Otherwise, add a new line with this account
                    append({
                      accountId: account.id.toString(),
                      description: account.name,
                      debit: '',
                      credit: '',
                      projectId: ''
                    });
                  }
                  setIsCommandOpen(false);
                }}
              >
                <div className="flex flex-col">
                  <div>
                    <span className="font-medium">{account.code}</span> - {account.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {account.type && account.type}
                  </div>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="خيارات">
            <CommandItem onSelect={() => { addLine(); setIsCommandOpen(false); }}>
              <PlusIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
              إضافة سطر جديد
            </CommandItem>
            <CommandItem onSelect={() => { autoBalance(); setIsCommandOpen(false); }}>
              <Repeat2Icon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
              موازنة القيد
            </CommandItem>
            <CommandItem onSelect={() => { form.handleSubmit(onSubmit)(); setIsCommandOpen(false); }}>
              <SaveIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
              حفظ القيد
            </CommandItem>
            <CommandItem onSelect={() => { setIsTemplateDialogOpen(true); setIsCommandOpen(false); }}>
              <BookmarkIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
              استخدام قالب
            </CommandItem>
            <CommandItem onSelect={() => { setTab('general'); setIsCommandOpen(false); }}>
              <FileTextIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
              التبديل إلى تبويب البيانات العامة
            </CommandItem>
            <CommandItem onSelect={() => { setTab('lines'); setIsCommandOpen(false); }}>
              <ArrowLeftRightIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
              التبديل إلى تبويب سطور القيد
            </CommandItem>
          </CommandGroup>
          
          <CommandSeparator />
          
          <CommandGroup heading="اختصارات لوحة المفاتيح">
            {keyboardShortcuts.map((shortcut, i) => (
              <CommandItem key={i} onSelect={() => setIsCommandOpen(false)}>
                <div className="flex justify-between w-full">
                  <span>{shortcut.description}</span>
                  <kbd className="px-1 py-0.5 bg-muted rounded border">{shortcut.key}</kbd>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>

      {/* Templates Dialog */}
      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>اختر قالب القيد</DialogTitle>
            <DialogDescription>
              قوالب القيود الجاهزة تساعدك على إنشاء قيود شائعة بسرعة
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-4">
            {commonAccountTemplates.map((template, index) => (
              <Button
                key={index}
                variant="outline"
                className="w-full justify-start text-right"
                onClick={() => {
                  console.log("Button clicked for template:", template.name);
                  
                  // تسجيل معلومات عن الحسابات المتاحة
                  console.log("Available accounts:", accounts);
                  
                  // نهج جديد: إضافة سطور القيد مباشرة مع الأخذ بعين الاعتبار معرفات الحسابات الفعلية
                  try {
                    const cashAccount = accounts.find((acc: any) => acc.name === "النقدية" || acc.code === "1101" || acc.id === 4);
                    const expenseAccount = accounts.find((acc: any) => acc.name === "المصروفات" || acc.type === "expense" || acc.code.startsWith("5"));
                    const revenueAccount = accounts.find((acc: any) => acc.name === "الإيرادات" || acc.type === "revenue" || acc.code.startsWith("4"));
                    const liabilityAccount = accounts.find((acc: any) => acc.name === "الخصوم" || acc.type === "liability" || acc.code.startsWith("2"));
                    
                    console.log("Template mapping results:", { 
                      cashAccount, 
                      expenseAccount, 
                      revenueAccount, 
                      liabilityAccount 
                    });
                    
                    if (template.name === "مصروفات على مشروع") {
                      if (!expenseAccount) {
                        toast({
                          title: "خطأ في تطبيق القالب",
                          description: "لم يتم العثور على حساب المصروفات",
                          variant: "destructive"
                        });
                        return;
                      }
                      
                      if (!cashAccount) {
                        toast({
                          title: "خطأ في تطبيق القالب",
                          description: "لم يتم العثور على حساب النقدية",
                          variant: "destructive"
                        });
                        return;
                      }
                      
                      // إضافة سطر مدين (مصروفات)
                      append({
                        accountId: expenseAccount.id.toString(),
                        description: "مصروفات على المشروع",
                        debit: "1000",
                        credit: "",
                        projectId: ""
                      });
                      // إضافة سطر دائن (نقدية)
                      append({
                        accountId: cashAccount.id.toString(),
                        description: "النقد في الصندوق",
                        debit: "",
                        credit: "1000",
                        projectId: ""
                      });
                      toast({
                        title: "تم تطبيق القالب",
                        description: `تم تطبيق قالب "${template.name}" بنجاح`,
                      });
                    } 
                    else if (template.name === "تحصيل من عميل") {
                      if (!revenueAccount) {
                        toast({
                          title: "خطأ في تطبيق القالب",
                          description: "لم يتم العثور على حساب الإيرادات",
                          variant: "destructive"
                        });
                        return;
                      }
                      
                      if (!cashAccount) {
                        toast({
                          title: "خطأ في تطبيق القالب",
                          description: "لم يتم العثور على حساب النقدية",
                          variant: "destructive"
                        });
                        return;
                      }
                      
                      // إضافة سطر مدين (نقدية)
                      append({
                        accountId: cashAccount.id.toString(),
                        description: "النقد في الصندوق",
                        debit: "1000",
                        credit: "",
                        projectId: ""
                      });
                      // إضافة سطر دائن (إيرادات)
                      append({
                        accountId: revenueAccount.id.toString(),
                        description: "إيرادات من العميل",
                        debit: "",
                        credit: "1000",
                        projectId: ""
                      });
                      toast({
                        title: "تم تطبيق القالب",
                        description: `تم تطبيق قالب "${template.name}" بنجاح`,
                      });
                    }
                    else if (template.name === "دفع لمورد") {
                      if (!liabilityAccount) {
                        toast({
                          title: "خطأ في تطبيق القالب",
                          description: "لم يتم العثور على حساب الخصوم/الذمم الدائنة",
                          variant: "destructive"
                        });
                        return;
                      }
                      
                      if (!cashAccount) {
                        toast({
                          title: "خطأ في تطبيق القالب",
                          description: "لم يتم العثور على حساب النقدية",
                          variant: "destructive"
                        });
                        return;
                      }
                      
                      // إضافة سطر مدين (ذمم دائنة)
                      append({
                        accountId: liabilityAccount.id.toString(),
                        description: "ذمم الموردين",
                        debit: "1000",
                        credit: "",
                        projectId: ""
                      });
                      // إضافة سطر دائن (نقدية)
                      append({
                        accountId: cashAccount.id.toString(),
                        description: "النقد في الصندوق",
                        debit: "",
                        credit: "1000",
                        projectId: ""
                      });
                      toast({
                        title: "تم تطبيق القالب",
                        description: `تم تطبيق قالب "${template.name}" بنجاح`,
                      });
                    }
                    
                    // إغلاق الحوار وعرض سطور القيد
                    setIsTemplateDialogOpen(false);
                    setTab('lines');
                  } catch (error) {
                    console.error("Error applying template:", error);
                    toast({
                      title: "خطأ في تطبيق القالب",
                      description: "حدث خطأ أثناء تطبيق القالب",
                      variant: "destructive"
                    });
                  }
                }}
              >
                <BookmarkIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                {template.name}
              </Button>
            ))}
          </div>
          <DialogFooter className="sm:justify-end">
            <Button variant="secondary" onClick={() => setIsTemplateDialogOpen(false)}>
              إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}