import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';
import React, { useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  PlusCircleIcon, 
  FileTextIcon, 
  XCircleIcon, 
  DownloadIcon, 
  FilterIcon, 
  CalendarIcon, 
  SearchIcon,
  DatabaseIcon,
  BarChart3Icon,
  ArrowUpCircleIcon, 
  ArrowDownCircleIcon,
  FileSpreadsheetIcon,
  FileIcon,
  RefreshCwIcon,
  PrinterIcon,
  UploadIcon,
  CalendarClockIcon
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';
import { useLanguage } from '@/contexts/language-context';

const JournalEntriesPage = () => {
  const { t } = useTranslation();
  const { language } = useLanguage();
  const [tab, setTab] = useState('all');
  
  // متغيرات الفلترة المتقدمة
  const [fiscalYear, setFiscalYear] = useState<string | undefined>(undefined);
  const [fiscalPeriod, setFiscalPeriod] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [minAmount, setMinAmount] = useState<string>('');
  const [maxAmount, setMaxAmount] = useState<string>('');
  const [accountId, setAccountId] = useState<string | undefined>(undefined);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  
  // متغيرات للتحميل والتصدير
  const [isExporting, setIsExporting] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // دالة لتنسيق التاريخ
  const formatDate = (date: Date) => {
    return format(date, 'yyyy-MM-dd', { locale: language === 'ar' ? ar : enUS });
  };
  
  // دالة لبناء رابط API استناداً إلى المرشحات المطبقة
  const getApiUrl = () => {
    let url = '/api/journal-entries';
    const queryParams = [];
    
    if (tab === 'draft') {
      queryParams.push('isPosted=false');
    } else if (tab === 'posted') {
      queryParams.push('isPosted=true');
    }
    
    if (fiscalYear) {
      queryParams.push(`fiscalYear=${fiscalYear}`);
    }
    
    if (fiscalPeriod) {
      queryParams.push(`fiscalPeriod=${fiscalPeriod}`);
    }
    
    if (startDate) {
      queryParams.push(`startDate=${formatDate(startDate)}`);
    }
    
    if (endDate) {
      queryParams.push(`endDate=${formatDate(endDate)}`);
    }
    
    if (minAmount && !isNaN(parseFloat(minAmount))) {
      queryParams.push(`minAmount=${parseFloat(minAmount)}`);
    }
    
    if (maxAmount && !isNaN(parseFloat(maxAmount))) {
      queryParams.push(`maxAmount=${parseFloat(maxAmount)}`);
    }
    
    if (accountId) {
      queryParams.push(`accountId=${accountId}`);
    }
    
    if (queryParams.length > 0) {
      url += `?${queryParams.join('&')}`;
    }
    
    return url;
  };
  
  // استعلام للحصول على القيود المحاسبية
  const { data: journalEntries = [], isLoading, error, refetch } = useQuery({
    queryKey: ['journalEntries', tab, fiscalYear, fiscalPeriod, startDate, endDate, minAmount, maxAmount, accountId],
    queryFn: async () => {
      const response = await fetch(getApiUrl());
      if (!response.ok) {
        throw new Error('حدث خطأ أثناء جلب القيود المحاسبية');
      }
      return await response.json();
    }
  });
  
  // استعلام للحصول على الحسابات المالية (للفلتر)
  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: async () => {
      const response = await fetch('/api/accounts');
      if (!response.ok) {
        return [];
      }
      return await response.json();
    }
  });
  
  // إعادة تعيين الفلاتر المتقدمة
  const resetFilters = () => {
    setFiscalYear(undefined);
    setFiscalPeriod(undefined);
    setStartDate(undefined);
    setEndDate(undefined);
    setMinAmount('');
    setMaxAmount('');
    setAccountId(undefined);
    setSearchQuery('');
  };
  
  // إحصائيات القيود
  const journalStats = {
    totalEntries: journalEntries.length,
    totalDebit: journalEntries.reduce((sum: number, entry: any) => sum + (entry.totalDebit || 0), 0),
    totalCredit: journalEntries.reduce((sum: number, entry: any) => sum + (entry.totalCredit || 0), 0),
    draftCount: journalEntries.filter((entry: any) => !entry.isPosted).length,
    postedCount: journalEntries.filter((entry: any) => entry.isPosted).length,
  };
  
  // تنسيق المبالغ المالية
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat(language === 'ar' ? 'ar-SA' : 'en-US', { 
      style: 'currency', 
      currency: 'SAR' 
    }).format(amount);
  };
  
  // وظائف التصدير والاستيراد والطباعة
  const handlePrint = () => {
    setIsPrinting(true);
    // نستخدم window.print() للطباعة بعد تأخير صغير لإتاحة الوقت لتحديث حالة الطباعة
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
    }, 100);
  };
  
  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      const response = await fetch(`/api/journal-entries/export?format=excel&${new URLSearchParams(getApiUrl().split('?')[1] || '')}`);
      if (!response.ok) throw new Error('فشل تصدير البيانات');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `journal_entries_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExporting(false);
    }
  };
  
  const handleExportPdf = async () => {
    setIsExporting(true);
    try {
      const response = await fetch(`/api/journal-entries/export?format=pdf&${new URLSearchParams(getApiUrl().split('?')[1] || '')}`);
      if (!response.ok) throw new Error('فشل تصدير البيانات');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `journal_entries_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExporting(false);
    }
  };
  
  const handleImport = () => {
    // نقوم بنقر على عنصر إدخال الملف المخفي
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      const response = await fetch('/api/journal-entries/import', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('فشل استيراد البيانات');
      }
      
      // إعادة تحميل القيود بعد الاستيراد
      refetch();
    } catch (err) {
      console.error(err);
    }
  };
  
  // تصفية القيود استناداً إلى استعلام البحث
  const filteredEntries = searchQuery.trim() 
    ? journalEntries.filter((entry: any) => 
        entry.journalNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.description?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : journalEntries;

  const columns = [
    {
      accessorKey: 'journalNumber',
      header: t('journal_number'),
    },
    {
      accessorKey: 'journalDate',
      header: t('date'),
      cell: ({ row }: any) => {
        const date = row.original.journalDate;
        return date ? new Date(date).toLocaleDateString() : '-';
      },
    },
    {
      accessorKey: 'description',
      header: t('description'),
    },
    {
      accessorKey: 'fiscalYear',
      header: t('fiscal_year'),
    },
    {
      accessorKey: 'fiscalPeriod',
      header: t('fiscal_period'),
    },
    {
      accessorKey: 'totalDebit',
      header: t('total_debit'),
      cell: ({ row }: any) => {
        return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(row.original.totalDebit || 0);
      },
    },
    {
      accessorKey: 'isPosted',
      header: t('status'),
      cell: ({ row }: any) => {
        return row.original.isPosted ? (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            {t('posted')}
          </Badge>
        ) : (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            {t('draft')}
          </Badge>
        );
      },
    },
    {
      id: 'actions',
      cell: ({ row }: any) => {
        return (
          <div className="flex space-x-2">
            <Link href={`/financial/journal-entries/${row.original.id}`}>
              <Button variant="ghost" size="icon">
                <FileTextIcon className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        );
      },
    }
  ];

  return (
    <>
      <div className="container mx-auto py-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">{t('journal_entries')}</h1>
          
          <div className="flex space-x-2 rtl:space-x-reverse">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            >
              <FilterIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
              {t('advanced_filters')}
            </Button>
            <Link href="/financial/journal-entries/new">
              <Button>
                <PlusCircleIcon className="h-4 w-4 ml-0 mr-2 rtl:ml-2 rtl:mr-0" />
                {t('new_journal_entry')}
              </Button>
            </Link>
          </div>
        </div>

        {/* بطاقات الإحصائيات */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {/* إجمالي القيود */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t('total_entries')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <DatabaseIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                <div className="text-2xl font-bold">{journalStats.totalEntries}</div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {t('entries_count_description')}
              </p>
            </CardContent>
          </Card>

          {/* إجمالي المدين */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t('total_debit')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <ArrowUpCircleIcon className="mr-2 h-4 w-4 text-green-500" />
                <div className="text-2xl font-bold">{formatCurrency(journalStats.totalDebit)}</div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {t('total_debit_description')}
              </p>
            </CardContent>
          </Card>

          {/* إجمالي الدائن */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t('total_credit')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <ArrowDownCircleIcon className="mr-2 h-4 w-4 text-red-500" />
                <div className="text-2xl font-bold">{formatCurrency(journalStats.totalCredit)}</div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {t('total_credit_description')}
              </p>
            </CardContent>
          </Card>

          {/* حالة القيود */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t('entry_status')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <div className="text-2xl font-bold">
                  {journalStats.draftCount}
                  <span className="text-xs text-muted-foreground mr-2"> {t('draft')}</span>
                </div>
                <div className="text-2xl font-bold">
                  {journalStats.postedCount}
                  <span className="text-xs text-muted-foreground"> {t('posted')}</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {t('entry_status_description')}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* لوحة الاستعلام والتصفية */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>{t('journal_entries')}</CardTitle>
            <CardDescription>
              {t('journal_entries_description')}
            </CardDescription>
          </CardHeader>
          
          <div className="px-6 py-2 flex items-center space-x-4 rtl:space-x-reverse border-b">
            <Tabs value={tab} onValueChange={setTab} className="w-full">
              <TabsList>
                <TabsTrigger value="all">{t('all_entries')}</TabsTrigger>
                <TabsTrigger value="draft">{t('draft')}</TabsTrigger>
                <TabsTrigger value="posted">{t('posted')}</TabsTrigger>
              </TabsList>
            </Tabs>
            
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Select
                value={fiscalYear || "all"}
                onValueChange={(value) => setFiscalYear(value === "all" ? undefined : value)}
              >
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder={t('fiscal_year')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    {t('all_years')}
                  </SelectItem>
                  <SelectItem value="2025">2025</SelectItem>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2023">2023</SelectItem>
                </SelectContent>
              </Select>
              
              <Input 
                placeholder={t('search')} 
                className="w-[180px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          {/* مرشحات متقدمة */}
          {showAdvancedFilters && (
            <div className="px-6 py-4 border-b bg-muted/20">
              <h3 className="text-sm font-medium mb-3">{t('advanced_filters')}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {/* الفترة المالية */}
                <div>
                  <Select
                    value={fiscalPeriod || "all"}
                    onValueChange={(value) => setFiscalPeriod(value === "all" ? undefined : value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('fiscal_period')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('all_periods')}</SelectItem>
                      <SelectItem value="1">{t('period_1')}</SelectItem>
                      <SelectItem value="2">{t('period_2')}</SelectItem>
                      <SelectItem value="3">{t('period_3')}</SelectItem>
                      <SelectItem value="4">{t('period_4')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* اختيار الحساب */}
                <div>
                  <Select
                    value={accountId || "all"}
                    onValueChange={(value) => setAccountId(value === "all" ? undefined : value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('account')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('all_accounts')}</SelectItem>
                      {accounts.map((account: any) => (
                        <SelectItem key={account.id} value={account.id.toString()}>
                          {account.code} - {account.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* تاريخ البداية */}
                <div>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {startDate ? formatDate(startDate) : t('start_date')}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={startDate}
                        onSelect={setStartDate}
                        locale={language === 'ar' ? ar : enUS}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* تاريخ النهاية */}
                <div>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {endDate ? formatDate(endDate) : t('end_date')}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        locale={language === 'ar' ? ar : enUS}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* الحد الأدنى للمبلغ */}
                <div>
                  <Input
                    type="number"
                    placeholder={t('min_amount')}
                    value={minAmount}
                    onChange={(e) => setMinAmount(e.target.value)}
                  />
                </div>

                {/* الحد الأقصى للمبلغ */}
                <div>
                  <Input
                    type="number"
                    placeholder={t('max_amount')}
                    value={maxAmount}
                    onChange={(e) => setMaxAmount(e.target.value)}
                  />
                </div>

                {/* أزرار إعادة تعيين وتطبيق المرشحات */}
                <div className="md:col-span-2 flex space-x-2 rtl:space-x-reverse">
                  <Button variant="outline" onClick={resetFilters}>
                    {t('reset_filters')}
                  </Button>
                  <Button onClick={() => refetch()}>
                    {t('apply_filters')}
                  </Button>
                </div>
              </div>
            </div>
          )}
        
          
          <CardContent>
            {isLoading ? (
              <div className="space-y-3 py-6">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : error ? (
              <div className="py-10 text-center">
                <XCircleIcon className="h-10 w-10 text-red-500 mx-auto mb-2" />
                <p className="text-muted-foreground">{t('error_loading_journal_entries')}</p>
                <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
                  {t('try_again')}
                </Button>
              </div>
            ) : journalEntries?.length === 0 ? (
              <div className="py-10 text-center">
                <FileTextIcon className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">{t('no_journal_entries')}</p>
                <p className="text-sm text-muted-foreground mt-1">{t('no_journal_entries_description')}</p>
                <Link href="/financial/journal-entries/new">
                  <Button className="mt-4">
                    <PlusCircleIcon className="h-4 w-4 mr-2" />
                    {t('create_first_journal_entry')}
                  </Button>
                </Link>
              </div>
            ) : filteredEntries.length === 0 && searchQuery ? (
              <div className="py-10 text-center">
                <XCircleIcon className="h-10 w-10 text-amber-500 mx-auto mb-2" />
                <p className="text-muted-foreground">{t('no_search_results')}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  {t('no_search_results_description', { query: searchQuery })}
                </p>
                <Button variant="outline" className="mt-4" onClick={() => setSearchQuery('')}>
                  {t('clear_search')}
                </Button>
              </div>
            ) : (
              <div className="relative overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {columns.map((column) => (
                        <TableHead key={column.accessorKey || column.id}>
                          {column.header}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(filteredEntries || []).map((row: any, rowIndex: number) => (
                      <TableRow key={rowIndex}>
                        {columns.map((column, colIndex) => (
                          <TableCell key={`${rowIndex}-${colIndex}`}>
                            {column.cell ? 
                              column.cell({ row: { original: row } }) : 
                              row[column.accessorKey]
                            }
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
          
          {/* وظائف إضافية للقيود المحاسبية */}
          {journalEntries?.length > 0 && (
            <CardFooter className="flex flex-wrap justify-between gap-2 border-t pt-4">
              <div className="flex flex-wrap gap-2">
                {/* طباعة القيود */}
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handlePrint}
                  disabled={isPrinting || isExporting}
                >
                  <PrinterIcon className={`h-4 w-4 mr-2 ${isPrinting ? 'animate-spin' : ''}`} />
                  {t('print')}
                </Button>
                
                {/* تصدير القيود */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm"
                      disabled={isPrinting || isExporting}
                    >
                      <DownloadIcon className={`h-4 w-4 mr-2 ${isExporting ? 'animate-spin' : ''}`} />
                      {t('export')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-2">
                    <div className="flex flex-col gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="justify-start"
                        onClick={handleExportExcel}
                        disabled={isPrinting || isExporting}
                      >
                        <FileSpreadsheetIcon className="h-4 w-4 mr-2" />
                        {t('export_excel')}
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="justify-start"
                        onClick={handleExportPdf}
                        disabled={isPrinting || isExporting}
                      >
                        <FileIcon className="h-4 w-4 mr-2" />
                        {t('export_pdf')}
                      </Button>
                    </div>
                  </PopoverContent>
                </Popover>
                
                {/* استيراد القيود */}
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleImport}
                  disabled={isPrinting || isExporting}
                >
                  <UploadIcon className="h-4 w-4 mr-2" />
                  {t('import')}
                </Button>
                
                {/* حقل إدخال الملف المخفي */}
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".xlsx,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
              
              <div className="flex flex-wrap gap-2">
                {/* القيود المتكررة */}
                <Link href="/financial/journal-entries/recurring">
                  <Button variant="outline" size="sm">
                    <CalendarClockIcon className="h-4 w-4 mr-2" />
                    {t('recurring_entries')}
                  </Button>
                </Link>
                
                {/* إنشاء قيد جديد */}
                <Link href="/financial/journal-entries/new">
                  <Button size="sm">
                    <PlusCircleIcon className="h-4 w-4 mr-2" />
                    {t('new_entry')}
                  </Button>
                </Link>
              </div>
            </CardFooter>
          )}
          
        </Card>
      </div>
    </>
  );
};

export default JournalEntriesPage;