import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  PlusCircleIcon, 
  ArrowLeftIcon,
  Calendar,
  CalendarClockIcon,
  Clock,
  Edit,
  Trash2,
  PauseCircle,
  PlayCircle
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from '@/components/ui/input';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';

export default function RecurringJournalEntriesPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);

  // استعلام للحصول على القيود المتكررة
  const { data: recurringEntries = [], isLoading, error, refetch } = useQuery({
    queryKey: ['recurringEntries', statusFilter],
    queryFn: async () => {
      const response = await fetch('/api/recurring-journal-entries');
      if (!response.ok) {
        throw new Error('فشل تحميل القيود المتكررة');
      }
      
      const data = await response.json();
      
      // تحويل البيانات الواردة من API إلى الشكل المطلوب في الواجهة
      const formattedData = data.map((entry: any) => ({
        id: entry.id,
        title: entry.title,
        description: entry.description,
        frequency: entry.frequency,
        nextRunDate: entry.nextRunDate,
        lastRunDate: entry.lastRunDate,
        amount: entry.amount,
        status: entry.isActive ? 'active' : 'paused',
        dayOfMonth: entry.dayOfMonth
      }));
      
      // تطبيق التصفية حسب الحالة إذا تم تحديدها
      if (statusFilter) {
        return formattedData.filter((entry: any) => entry.status === statusFilter);
      }
      
      return formattedData;
    }
  });

  // تنسيق العملة
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(amount);
  };

  // تصفية القيود استناداً إلى استعلام البحث
  const filteredEntries = searchQuery.trim() 
    ? recurringEntries.filter((entry: any) => 
        entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : recurringEntries;

  // تنسيق التكرار بالعربية
  const formatFrequency = (frequency: string) => {
    switch (frequency) {
      case 'daily': return 'يومي';
      case 'weekly': return 'أسبوعي';
      case 'monthly': return 'شهري';
      case 'quarterly': return 'ربع سنوي';
      case 'yearly': return 'سنوي';
      default: return frequency;
    }
  };

  // تنسيق حالة القيد المتكرر
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="outline" className="bg-green-100 text-green-800">نشط</Badge>;
      case 'paused':
        return <Badge variant="outline" className="bg-amber-100 text-amber-800">متوقف مؤقتاً</Badge>;
      case 'completed':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">مكتمل</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // وظائف لتغيير حالة القيد المتكرر
  const toggleEntryStatus = async (id: number, currentStatus: string) => {
    const isActive = currentStatus === 'paused'; // العكس لأننا نريد تغيير الحالة
    
    try {
      const response = await fetch(`/api/recurring-journal-entries/${id}/toggle-status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive }),
      });
      
      if (!response.ok) {
        throw new Error('فشل تحديث حالة القيد المتكرر');
      }
      
      toast({
        title: 'تم تغيير حالة القيد',
        description: `تم تغيير حالة القيد إلى ${isActive ? 'نشط' : 'متوقف مؤقتاً'}`,
      });
      
      // إعادة تحميل البيانات
      refetch();
    } catch (error) {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء تحديث حالة القيد المتكرر',
        variant: 'destructive',
      });
    }
  };

  // حذف قيد متكرر
  const deleteRecurringEntry = async (id: number) => {
    try {
      const response = await fetch(`/api/recurring-journal-entries/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('فشل حذف القيد المتكرر');
      }
      
      toast({
        title: 'تم حذف القيد المتكرر',
        description: 'تم حذف القيد المتكرر بنجاح',
      });
      
      // إعادة تحميل البيانات
      refetch();
    } catch (error) {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء حذف القيد المتكرر',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link href="/financial/journal-entries">
            <Button variant="ghost" size="sm">
              <ArrowLeftIcon className="h-4 w-4 mr-2" />
              {t('back_to_journal_entries')}
            </Button>
          </Link>
          <h1 className="text-3xl font-bold tracking-tight">{t('recurring_entries')}</h1>
          <p className="text-muted-foreground">{t('recurring_entries_description')}</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>{t('recurring_entries')}</CardTitle>
              <CardDescription>
                قيود اليومية المتكررة والمجدولة التي تنفذ تلقائياً
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Select
                value={statusFilter || "all"}
                onValueChange={(value) => setStatusFilter(value === "all" ? undefined : value)}
              >
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  <SelectItem value="active">نشط</SelectItem>
                  <SelectItem value="paused">متوقف مؤقتاً</SelectItem>
                </SelectContent>
              </Select>
              
              <Input
                placeholder="بحث..."
                className="w-[200px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          ) : error ? (
            <div className="text-center py-8">
              <p className="text-red-500">حدث خطأ أثناء تحميل البيانات</p>
              <Button variant="outline" onClick={() => refetch()} className="mt-4">
                إعادة المحاولة
              </Button>
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-16">
              <CalendarClockIcon className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">لا توجد قيود متكررة</h3>
              <p className="text-muted-foreground mt-2">
                لم يتم العثور على أي قيود متكررة تطابق معايير البحث.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>العنوان</TableHead>
                  <TableHead>التكرار</TableHead>
                  <TableHead>التنفيذ التالي</TableHead>
                  <TableHead>آخر تنفيذ</TableHead>
                  <TableHead>المبلغ</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEntries.map((entry: any) => (
                  <TableRow key={entry.id}>
                    <TableCell>
                      <div className="font-medium">{entry.title}</div>
                      <div className="text-sm text-muted-foreground">{entry.description}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <CalendarClockIcon className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>{formatFrequency(entry.frequency)}</span>
                        {entry.frequency === 'monthly' && (
                          <span className="text-xs text-muted-foreground ml-1">
                            (يوم {entry.dayOfMonth})
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{new Date(entry.nextRunDate).toLocaleDateString('ar-SA')}</TableCell>
                    <TableCell>{new Date(entry.lastRunDate).toLocaleDateString('ar-SA')}</TableCell>
                    <TableCell>{formatCurrency(entry.amount)}</TableCell>
                    <TableCell>{getStatusBadge(entry.status)}</TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleEntryStatus(entry.id, entry.status)}
                        >
                          {entry.status === 'active' ? (
                            <PauseCircle className="h-4 w-4" />
                          ) : (
                            <PlayCircle className="h-4 w-4" />
                          )}
                        </Button>
                        <Link href={`/financial/journal-entries/recurring/edit/${entry.id}`}>
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>حذف القيد المتكرر</AlertDialogTitle>
                              <AlertDialogDescription>
                                هل أنت متأكد من رغبتك في حذف هذا القيد المتكرر؟ لن يتم إنشاء أي قيود جديدة في المستقبل.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>إلغاء</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteRecurringEntry(entry.id)}
                                className="bg-red-500 hover:bg-red-600"
                              >
                                حذف
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <div>
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              تحديث
            </Button>
          </div>
          <Link href="/financial/journal-entries/recurring/new">
            <Button size="sm">
              <PlusCircleIcon className="h-4 w-4 mr-2" />
              إنشاء قيد متكرر جديد
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}