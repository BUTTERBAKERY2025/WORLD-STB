import { useTranslation } from 'react-i18next';
import { Link, useLocation } from 'wouter';
import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { apiRequest } from '@/lib/queryClient';
import { 
  ArrowLeftIcon,
  CalendarClockIcon,
  CalendarIcon,
  InfoIcon
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { ar, enUS } from 'date-fns/locale';
import { useLanguage } from '@/contexts/language-context';

// نموذج البيانات
const formSchema = z.object({
  title: z.string().min(3, { message: 'العنوان قصير جداً' }),
  description: z.string().optional(),
  frequency: z.enum(['daily', 'weekly', 'monthly', 'quarterly', 'yearly']),
  startDate: z.date(),
  endDate: z.date().optional(),
  dayOfMonth: z.string().optional(),
  dayOfWeek: z.string().optional(),
  amount: z.string().min(1, { message: 'يرجى إدخال المبلغ' }),
  accountDebit: z.string().min(1, { message: 'يرجى اختيار حساب المدين' }),
  accountCredit: z.string().min(1, { message: 'يرجى اختيار حساب الدائن' }),
  projectId: z.string().optional(),
  autoPost: z.boolean().default(false),
  autoBalance: z.boolean().default(true),
});

export default function NewRecurringEntryPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { language } = useLanguage();

  // استعلام للحصول على الحسابات
  const { data: accounts = [], isLoading: isLoadingAccounts } = useQuery({
    queryKey: ['chartOfAccounts'],
    queryFn: async () => {
      const response = await fetch('/api/chart-of-accounts');
      if (!response.ok) {
        throw new Error('حدث خطأ أثناء جلب شجرة الحسابات');
      }
      return await response.json();
    }
  });

  // استعلام للحصول على المشاريع
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery({
    queryKey: ['projects'],
    queryFn: async () => {
      const response = await fetch('/api/projects');
      if (!response.ok) {
        throw new Error('حدث خطأ أثناء جلب المشاريع');
      }
      return await response.json();
    }
  });

  // إنشاء نموذج
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      description: '',
      frequency: 'monthly',
      startDate: new Date(),
      amount: '',
      accountDebit: '',
      accountCredit: '',
      projectId: 'none', // استخدام القيمة 'none' كقيمة افتراضية
      autoPost: true,
      autoBalance: true,
      dayOfMonth: '1',
    },
  });

  // الاستماع لتغيير التكرار لتحديث الحقول ذات الصلة
  const watchFrequency = form.watch('frequency');

  // تقديم النموذج
  const createRecurringEntry = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      // تحويل البيانات إلى الصيغة المطلوبة للواجهة البرمجية
      const apiData = {
        title: data.title,
        description: data.description || '',
        amount: parseFloat(data.amount),
        accountDebit: data.accountDebit,
        accountCredit: data.accountCredit,
        frequency: data.frequency,
        startDate: format(data.startDate, 'yyyy-MM-dd'),
        projectId: data.projectId === 'none' ? null : parseInt(data.projectId),
        autoPost: data.autoPost,
        autoBalance: data.autoBalance,
        dayOfMonth: data.frequency === 'monthly' ? parseInt(data.dayOfMonth || '1') : 1
      };

      // استدعاء واجهة برمجة التطبيق لإنشاء قيد متكرر
      const response = await fetch('/api/recurring-journal-entries', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(apiData),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.message || 'فشل إنشاء القيد المتكرر');
      }

      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurringEntries'] });
      toast({
        title: 'تم إنشاء القيد المتكرر',
        description: 'تم إنشاء القيد المتكرر بنجاح وجدولته للتنفيذ',
      });
      setLocation('/financial/journal-entries/recurring');
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ',
        description: error.message || 'حدث خطأ أثناء إنشاء القيد المتكرر',
        variant: 'destructive',
      });
      console.error(error);
    },
  });

  // معالج تقديم النموذج
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // معالجة القيم قبل الإرسال
    const submitData = {
      ...values,
      // إذا كان المشروع "none" نجعله فارغاً
      projectId: values.projectId === "none" ? "" : values.projectId
    };
    createRecurringEntry.mutate(submitData);
  };

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link href="/financial/journal-entries/recurring">
            <Button variant="ghost" size="sm">
              <ArrowLeftIcon className="h-4 w-4 mr-2" />
              {t('back_to_recurring_entries')}
            </Button>
          </Link>
          <h1 className="text-3xl font-bold tracking-tight">إنشاء قيد متكرر جديد</h1>
          <p className="text-muted-foreground">إنشاء قيد محاسبي يتكرر تلقائياً وفق جدول زمني محدد</p>
        </div>
      </div>

      <Alert className="mb-6 bg-blue-50/50 border-blue-200 text-blue-800">
        <InfoIcon className="h-4 w-4" />
        <AlertTitle>معلومات هامة</AlertTitle>
        <AlertDescription className="text-blue-700">
          القيود المتكررة تُنشئ قيود محاسبية تلقائية في تواريخ محددة. تأكد من تحديد الحسابات والمبالغ بدقة.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>إنشاء قيد متكرر</CardTitle>
          <CardDescription>
            أدخل معلومات القيد المتكرر والجدول الزمني للتنفيذ
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
                {/* العنوان */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>عنوان القيد المتكرر</FormLabel>
                      <FormControl>
                        <Input placeholder="مثال: رواتب الموظفين الشهرية" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* المبلغ */}
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المبلغ</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="أدخل المبلغ" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* الوصف */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الوصف</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="وصف تفصيلي للقيد المتكرر"
                        rows={3}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
                {/* الحساب المدين */}
                <FormField
                  control={form.control}
                  name="accountDebit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الحساب المدين</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر الحساب المدين" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {isLoadingAccounts ? (
                            <div className="p-2">
                              <Skeleton className="h-5 w-full mb-2" />
                              <Skeleton className="h-5 w-full" />
                            </div>
                          ) : (
                            accounts.map((account: any) => (
                              <SelectItem key={account.id} value={account.id.toString()}>
                                {account.name} ({account.code})
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* الحساب الدائن */}
                <FormField
                  control={form.control}
                  name="accountCredit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الحساب الدائن</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر الحساب الدائن" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {isLoadingAccounts ? (
                            <div className="p-2">
                              <Skeleton className="h-5 w-full mb-2" />
                              <Skeleton className="h-5 w-full" />
                            </div>
                          ) : (
                            accounts.map((account: any) => (
                              <SelectItem key={account.id} value={account.id.toString()}>
                                {account.name} ({account.code})
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* المشروع */}
              <FormField
                control={form.control}
                name="projectId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>المشروع (اختياري)</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر المشروع (اختياري)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">بدون مشروع</SelectItem>
                        {isLoadingProjects ? (
                          <div className="p-2">
                            <Skeleton className="h-5 w-full mb-2" />
                            <Skeleton className="h-5 w-full" />
                          </div>
                        ) : (
                          projects.map((project: any) => (
                            <SelectItem key={project.id} value={project.id.toString()}>
                              {project.name}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      ربط القيد المتكرر بمشروع معين (اختياري)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="border-t pt-6 mt-6">
                <h3 className="text-lg font-medium mb-4">إعدادات الجدول الزمني</h3>
                
                <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
                  {/* التكرار */}
                  <FormField
                    control={form.control}
                    name="frequency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تكرار القيد</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر التكرار" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="daily">يومي</SelectItem>
                            <SelectItem value="weekly">أسبوعي</SelectItem>
                            <SelectItem value="monthly">شهري</SelectItem>
                            <SelectItem value="quarterly">ربع سنوي</SelectItem>
                            <SelectItem value="yearly">سنوي</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* تاريخ البدء */}
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>تاريخ البدء</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant="outline"
                                className="w-full pl-3 text-left font-normal"
                              >
                                {field.value ? (
                                  format(field.value, "yyyy-MM-dd")
                                ) : (
                                  <span>اختر التاريخ</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) => date < new Date()}
                              locale={language === 'ar' ? ar : enUS}
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* اليوم من الشهر (في حالة شهري أو ربع سنوي أو سنوي) */}
                {['monthly', 'quarterly', 'yearly'].includes(watchFrequency) && (
                  <FormField
                    control={form.control}
                    name="dayOfMonth"
                    render={({ field }) => (
                      <FormItem className="mt-4">
                        <FormLabel>اليوم من الشهر</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                          defaultValue="1"
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر اليوم من الشهر" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
                              <SelectItem key={day} value={day.toString()}>
                                {day}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          اليوم من الشهر الذي سيتم فيه إنشاء القيد
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {/* يوم الأسبوع (في حالة أسبوعي) */}
                {watchFrequency === 'weekly' && (
                  <FormField
                    control={form.control}
                    name="dayOfWeek"
                    render={({ field }) => (
                      <FormItem className="mt-4">
                        <FormLabel>يوم الأسبوع</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                          defaultValue="1"
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر يوم الأسبوع" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="0">الأحد</SelectItem>
                            <SelectItem value="1">الإثنين</SelectItem>
                            <SelectItem value="2">الثلاثاء</SelectItem>
                            <SelectItem value="3">الأربعاء</SelectItem>
                            <SelectItem value="4">الخميس</SelectItem>
                            <SelectItem value="5">الجمعة</SelectItem>
                            <SelectItem value="6">السبت</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          يوم الأسبوع الذي سيتم فيه إنشاء القيد
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {/* تاريخ الانتهاء (اختياري) */}
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="mt-4 flex flex-col">
                      <FormLabel>تاريخ الانتهاء (اختياري)</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className="w-full pl-3 text-left font-normal"
                            >
                              {field.value ? (
                                format(field.value, "yyyy-MM-dd")
                              ) : (
                                <span>اختر التاريخ (اختياري)</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => 
                              date < new Date() || 
                              (form.getValues().startDate && date <= form.getValues().startDate)
                            }
                            locale={language === 'ar' ? ar : enUS}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        تاريخ التوقف عن إنشاء القيود المتكررة (اختياري)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="border-t pt-6 mt-6">
                <h3 className="text-lg font-medium mb-4">إعدادات متقدمة</h3>
                
                <div className="space-y-4">
                  {/* الترحيل التلقائي */}
                  <FormField
                    control={form.control}
                    name="autoPost"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rtl:space-x-reverse">
                        <FormControl>
                          <RadioGroup
                            onValueChange={(value) => field.onChange(value === 'true')}
                            value={field.value ? 'true' : 'false'}
                            className="flex flex-row space-x-2 rtl:space-x-reverse"
                          >
                            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                              <RadioGroupItem value="true" id="autoPost-yes" />
                              <label htmlFor="autoPost-yes">ترحيل تلقائي</label>
                            </div>
                            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                              <RadioGroupItem value="false" id="autoPost-no" />
                              <label htmlFor="autoPost-no">مسودة</label>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <div className="space-y-1 flex-1">
                          <FormDescription>
                            ترحيل القيود تلقائياً بعد إنشائها أم حفظها كمسودة
                          </FormDescription>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />

                  {/* الموازنة التلقائية */}
                  <FormField
                    control={form.control}
                    name="autoBalance"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rtl:space-x-reverse">
                        <FormControl>
                          <RadioGroup
                            onValueChange={(value) => field.onChange(value === 'true')}
                            value={field.value ? 'true' : 'false'}
                            className="flex flex-row space-x-2 rtl:space-x-reverse"
                          >
                            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                              <RadioGroupItem value="true" id="autoBalance-yes" />
                              <label htmlFor="autoBalance-yes">موازنة تلقائية</label>
                            </div>
                            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                              <RadioGroupItem value="false" id="autoBalance-no" />
                              <label htmlFor="autoBalance-no">بدون موازنة</label>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <div className="space-y-1 flex-1">
                          <FormDescription>
                            موازنة القيود تلقائياً للتأكد من تساوي المدين والدائن
                          </FormDescription>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 rtl:space-x-reverse pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation('/financial/journal-entries/recurring')}
                >
                  إلغاء
                </Button>
                <Button
                  type="submit"
                  disabled={createRecurringEntry.isPending}
                >
                  {createRecurringEntry.isPending ? 'جاري الحفظ...' : 'إنشاء القيد المتكرر'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}