import { useTranslation } from 'react-i18next';
import { Link, useParams, useLocation } from 'wouter';
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { 
  ArrowLeftIcon,
  CalendarIcon,
  SaveIcon,
  Trash2 
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

export default function EditRecurringJournalEntry() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { id } = useParams();
  
  // أنماط التكرار
  const frequencies = [
    { value: 'daily', label: 'يومي' },
    { value: 'weekly', label: 'أسبوعي' },
    { value: 'monthly', label: 'شهري' },
    { value: 'quarterly', label: 'ربع سنوي' },
    { value: 'yearly', label: 'سنوي' }
  ];
  
  // أيام الشهر للتكرار الشهري
  const daysOfMonth = Array.from({ length: 31 }, (_, i) => i + 1);

  // استعلام للحصول على بيانات القيد المتكرر
  const { 
    data: entry, 
    isLoading, 
    error 
  } = useQuery({
    queryKey: ['recurringEntry', id],
    queryFn: async () => {
      const response = await fetch(`/api/recurring-journal-entries/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch recurring entry');
      }
      return response.json();
    }
  });

  // استعلام للحصول على قائمة الحسابات
  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: async () => {
      const response = await fetch('/api/financial/accounts');
      if (!response.ok) {
        throw new Error('Failed to fetch accounts');
      }
      return response.json();
    }
  });

  // استعلام للحصول على قائمة المشاريع
  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: async () => {
      const response = await fetch('/api/projects');
      if (!response.ok) {
        throw new Error('Failed to fetch projects');
      }
      return response.json();
    }
  });

  // حالة النموذج
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    amount: 0,
    accountDebit: '',
    accountCredit: '',
    frequency: 'monthly',
    startDate: new Date().toISOString().split('T')[0],
    projectId: 'none',
    autoPost: true,
    autoBalance: true,
    dayOfMonth: 1,
  });

  // تعيين بيانات النموذج عند تحميل بيانات القيد
  useEffect(() => {
    if (entry) {
      setFormData({
        title: entry.title || '',
        description: entry.description || '',
        amount: entry.amount || 0,
        accountDebit: entry.accountDebit || '',
        accountCredit: entry.accountCredit || '',
        frequency: entry.frequency || 'monthly',
        startDate: entry.startDate || new Date().toISOString().split('T')[0],
        projectId: entry.projectId ? entry.projectId.toString() : 'none',
        autoPost: entry.autoPost !== undefined ? entry.autoPost : true,
        autoBalance: entry.autoBalance !== undefined ? entry.autoBalance : true,
        dayOfMonth: entry.dayOfMonth || 1,
      });
    }
  }, [entry]);

  // طلب تحديث القيد المتكرر
  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch(`/api/recurring-journal-entries/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update recurring entry');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'تم تحديث القيد المتكرر',
        description: 'تم تحديث القيد المتكرر بنجاح',
      });
      setLocation('/financial/journal-entries/recurring');
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ',
        description: `فشل تحديث القيد المتكرر: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  // طلب حذف القيد المتكرر
  const deleteMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/recurring-journal-entries/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete recurring entry');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'تم حذف القيد المتكرر',
        description: 'تم حذف القيد المتكرر بنجاح',
      });
      setLocation('/financial/journal-entries/recurring');
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ',
        description: `فشل حذف القيد المتكرر: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  // التعامل مع تغييرات النموذج
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'amount' ? parseFloat(value) || 0 : value,
    }));
  };

  // التعامل مع تغييرات خانات الاختيار
  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      [name]: checked,
    }));
  };

  // التعامل مع تغييرات القائمة المنسدلة
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  // التعامل مع تغييرات التاريخ
  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setFormData(prev => ({
        ...prev,
        startDate: date.toISOString().split('T')[0],
      }));
    }
  };

  // إرسال النموذج
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // تحويل القيم إلى الأنواع المناسبة
    const dataToSubmit = {
      ...formData,
      amount: Number(formData.amount),
      projectId: formData.projectId === 'none' ? null : Number(formData.projectId),
      dayOfMonth: Number(formData.dayOfMonth),
    };
    
    updateMutation.mutate(dataToSubmit);
  };

  // إذا كان هناك خطأ في تحميل البيانات
  if (error) {
    return (
      <div className="container py-6">
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <h1 className="text-2xl font-bold mb-4">حدث خطأ أثناء تحميل بيانات القيد المتكرر</h1>
          <p className="text-muted-foreground mb-6">{(error as Error).message}</p>
          <Button variant="outline" onClick={() => setLocation('/financial/journal-entries/recurring')}>
            العودة إلى قائمة القيود المتكررة
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link href="/financial/journal-entries/recurring">
            <Button variant="ghost" size="sm">
              <ArrowLeftIcon className="h-4 w-4 mr-2" />
              {t('back_to_recurring_entries')}
            </Button>
          </Link>
          <h1 className="text-3xl font-bold tracking-tight">تعديل قيد متكرر</h1>
          <p className="text-muted-foreground">تعديل معلومات وإعدادات القيد المتكرر</p>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-6">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="grid gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>معلومات القيد المتكرر</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">عنوان القيد المتكرر</Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="أدخل عنوان القيد المتكرر"
                      value={formData.title}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="amount">المبلغ</Label>
                    <Input
                      id="amount"
                      name="amount"
                      type="number"
                      step="0.01"
                      placeholder="أدخل المبلغ"
                      value={formData.amount}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">وصف القيد</Label>
                  <Textarea
                    id="description"
                    name="description"
                    placeholder="أدخل وصف تفصيلي للقيد المتكرر"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={3}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="accountDebit">الحساب المدين</Label>
                    <Select
                      value={formData.accountDebit}
                      onValueChange={(value) => handleSelectChange('accountDebit', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الحساب المدين" />
                      </SelectTrigger>
                      <SelectContent>
                        {accounts.map((account: any) => (
                          <SelectItem key={account.code} value={account.code}>
                            {account.code} - {account.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="accountCredit">الحساب الدائن</Label>
                    <Select
                      value={formData.accountCredit}
                      onValueChange={(value) => handleSelectChange('accountCredit', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الحساب الدائن" />
                      </SelectTrigger>
                      <SelectContent>
                        {accounts.map((account: any) => (
                          <SelectItem key={account.code} value={account.code}>
                            {account.code} - {account.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="projectId">المشروع (اختياري)</Label>
                  <Select
                    value={formData.projectId}
                    onValueChange={(value) => handleSelectChange('projectId', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المشروع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">لا يوجد مشروع</SelectItem>
                      {projects.map((project: any) => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>جدولة القيد المتكرر</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>تاريخ البدء</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-right"
                        >
                          <CalendarIcon className="ml-2 h-4 w-4" />
                          {formData.startDate
                            ? format(new Date(formData.startDate), 'PPP', { locale: ar })
                            : "اختر تاريخ البدء"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={new Date(formData.startDate)}
                          onSelect={handleDateChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="frequency">نمط التكرار</Label>
                    <Select
                      value={formData.frequency}
                      onValueChange={(value) => handleSelectChange('frequency', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نمط التكرار" />
                      </SelectTrigger>
                      <SelectContent>
                        {frequencies.map((freq) => (
                          <SelectItem key={freq.value} value={freq.value}>
                            {freq.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {formData.frequency === 'monthly' && (
                  <div className="space-y-2">
                    <Label htmlFor="dayOfMonth">اليوم من الشهر</Label>
                    <Select
                      value={formData.dayOfMonth.toString()}
                      onValueChange={(value) => handleSelectChange('dayOfMonth', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر اليوم من الشهر" />
                      </SelectTrigger>
                      <SelectContent>
                        {daysOfMonth.map((day) => (
                          <SelectItem key={day} value={day.toString()}>
                            {day}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox 
                      id="autoPost" 
                      checked={formData.autoPost}
                      onCheckedChange={(checked) => 
                        handleCheckboxChange('autoPost', checked as boolean)
                      }
                    />
                    <Label htmlFor="autoPost">ترحيل القيد تلقائياً</Label>
                  </div>
                  <p className="text-sm text-muted-foreground mr-6">
                    عند تفعيل هذا الخيار، سيتم ترحيل القيد الذي يتم إنشاؤه تلقائياً بدون الحاجة للمراجعة
                  </p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox 
                      id="autoBalance" 
                      checked={formData.autoBalance}
                      onCheckedChange={(checked) => 
                        handleCheckboxChange('autoBalance', checked as boolean)
                      }
                    />
                    <Label htmlFor="autoBalance">موازنة القيد تلقائياً</Label>
                  </div>
                  <p className="text-sm text-muted-foreground mr-6">
                    عند تفعيل هذا الخيار، سيتم التأكد من موازنة القيد تلقائياً (مجموع المدين = مجموع الدائن)
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="flex justify-between">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" type="button">
                  <Trash2 className="h-4 w-4 mr-2" />
                  حذف القيد المتكرر
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>هل أنت متأكد من حذف هذا القيد المتكرر؟</AlertDialogTitle>
                  <AlertDialogDescription>
                    سيتم حذف القيد المتكرر نهائياً ولن يتم إنشاء قيود جديدة في المستقبل.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>إلغاء</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteMutation.mutate()}
                    className="bg-red-500 hover:bg-red-600"
                  >
                    حذف
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          
            <div className="space-x-2 space-x-reverse">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setLocation('/financial/journal-entries/recurring')}
              >
                إلغاء
              </Button>
              <Button type="submit" disabled={updateMutation.isPending}>
                {updateMutation.isPending ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    جاري الحفظ...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <SaveIcon className="h-4 w-4 mr-2" />
                    حفظ التغييرات
                  </span>
                )}
              </Button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}