import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DatePicker } from "@/components/ui/date-picker";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, Download, FileDown, Printer, Search, Filter, BarChart4, Eye, EyeOff, ArrowUpDown, Settings2 } from "lucide-react";
import { format } from "date-fns";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ExportMenu } from "@/components/financial/ExportMenu";
import { printDocument } from "@/utils/printUtils";

export default function TrialBalance() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const tableRef = useRef<HTMLTableElement>(null);
  const printSectionRef = useRef<HTMLDivElement>(null);
  
  // تاريخ ميزان المراجعة (افتراضيًا تاريخ اليوم)
  const [asOfDate, setAsOfDate] = useState<Date>(new Date());
  const [fiscalYear, setFiscalYear] = useState<string | undefined>();
  const [fiscalPeriod, setFiscalPeriod] = useState<string | undefined>();
  
  // خيارات عرض إضافية
  const [showZeroBalances, setShowZeroBalances] = useState<boolean>(true);
  const [accountTypeView, setAccountTypeView] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"expanded" | "summary">("expanded");
  
  // استدعاء واجهة برمجة التطبيقات للحصول على ميزان المراجعة
  const { data: trialBalanceData, isLoading, refetch } = useQuery({
    queryKey: ['/api/financial/trial-balance', asOfDate, fiscalYear, fiscalPeriod],
    queryFn: async () => {
      try {
        // بناء معلمات الاستعلام
        const params = new URLSearchParams();
        params.append('asOfDate', asOfDate.toISOString());
        if (fiscalYear) params.append('fiscalYear', fiscalYear);
        if (fiscalPeriod) params.append('fiscalPeriod', fiscalPeriod);
        
        const response = await apiRequest('GET', `/api/financial/trial-balance?${params.toString()}`);
        return await response.json();
      } catch (error) {
        console.error('Error fetching trial balance:', error);
        toast({
          variant: "destructive",
          title: t('financial.trial_balance.fetch_error') || "خطأ في جلب ميزان المراجعة",
          description: String(error),
        });
        return null;
      }
    },
  });
  
  // تنسيق الأرقام بالعملة السعودية
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // فلترة الحسابات حسب المستوى
  const [filterLevel, setFilterLevel] = useState<string>("all");
  
  // حساب نسبة التوازن
  const balanceRatio = trialBalanceData ? 
    (trialBalanceData.totalDebitBalance / 
    (trialBalanceData.totalDebitBalance + trialBalanceData.totalCreditBalance)) * 100 : 50;
  
  // الحسابات بعد تطبيق الفلترة
  const filteredAccounts = trialBalanceData?.accounts?.filter((account: any) => {
    // فلترة حسب المستوى
    if (filterLevel !== "all" && account.level.toString() !== filterLevel) return false;
    
    // فلترة الأرصدة الصفرية
    if (!showZeroBalances && account.debitBalance === 0 && account.creditBalance === 0) return false;
    
    // فلترة حسب نوع الحساب
    if (accountTypeView !== "all" && account.accountType !== accountTypeView) return false;
    
    return true;
  }) || [];
  
  // تجميع الحسابات حسب النوع للرسم البياني
  const accountTypeGroups = filteredAccounts.reduce((groups: any, account: any) => {
    const type = account.accountType;
    if (!groups[type]) {
      groups[type] = {
        type,
        debitTotal: 0,
        creditTotal: 0,
        count: 0
      };
    }
    groups[type].debitTotal += account.debitBalance || 0;
    groups[type].creditTotal += account.creditBalance || 0;
    groups[type].count += 1;
    return groups;
  }, {});
  
  return (
    <PageLayout
      title={t('financial.trial_balance.title') || "ميزان المراجعة"}
      sections={[
        {
          title: t('financial.reports.categories') || "فئات التقارير",
          items: [
            { title: t('financial.overview') || "نظرة عامة", href: "/financial/reports" },
            { title: t('financial.account_statement') || "كشف الحساب", href: "/financial/account-statement" },
            { title: t('financial.trial_balance') || "ميزان المراجعة", href: "/financial/trial-balance" },
            { title: t('financial.balance_sheet') || "الميزانية العمومية", href: "/financial/balance-sheet" },
            { title: t('financial.income_statement') || "قائمة الدخل", href: "/financial/income-statement" },
          ],
        },
      ]}
    >
      <div ref={printSectionRef} className="space-y-4">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>{t('financial.trial_balance.filter') || "تصفية ميزان المراجعة"}</CardTitle>
              <div className="flex space-x-2 print:hidden">
                <Button variant="outline" onClick={() => printDocument(printSectionRef, t('financial.trial_balance.title') || "ميزان المراجعة")}>
                  <Printer className="h-4 w-4 mr-2" />
                  {t('common.print') || "طباعة"}
                </Button>
                <ExportMenu 
                  tableRef={tableRef}
                  reportTitle={t('financial.trial_balance.title') || "ميزان المراجعة"}
                  fileName={`${t('financial.trial_balance.title') || "ميزان المراجعة"}_${format(asOfDate, 'yyyy-MM-dd')}`} 
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/30 p-4 rounded-lg border mb-4">
              <h3 className="text-sm font-medium mb-3 flex items-center">
                <Filter className="h-4 w-4 mr-2 text-primary" />
                {t('financial.filter_options') || "خيارات التصفية"}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.as_of_date') || "كما في تاريخ"}
                  </label>
                  <DatePicker
                    date={asOfDate}
                    onSelect={setAsOfDate}
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.fiscal_year') || "السنة المالية"}
                  </label>
                  <Select value={fiscalYear} onValueChange={setFiscalYear}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('financial.select_fiscal_year') || "اختر السنة المالية"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2025">2025</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.fiscal_period') || "الفترة المالية"}
                  </label>
                  <Select value={fiscalPeriod} onValueChange={setFiscalPeriod}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('financial.select_fiscal_period') || "اختر الفترة المالية"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">{t('financial.period_1') || "الفترة 1"}</SelectItem>
                      <SelectItem value="2">{t('financial.period_2') || "الفترة 2"}</SelectItem>
                      <SelectItem value="3">{t('financial.period_3') || "الفترة 3"}</SelectItem>
                      <SelectItem value="4">{t('financial.period_4') || "الفترة 4"}</SelectItem>
                      <SelectItem value="5">{t('financial.period_5') || "الفترة 5"}</SelectItem>
                      <SelectItem value="6">{t('financial.period_6') || "الفترة 6"}</SelectItem>
                      <SelectItem value="7">{t('financial.period_7') || "الفترة 7"}</SelectItem>
                      <SelectItem value="8">{t('financial.period_8') || "الفترة 8"}</SelectItem>
                      <SelectItem value="9">{t('financial.period_9') || "الفترة 9"}</SelectItem>
                      <SelectItem value="10">{t('financial.period_10') || "الفترة 10"}</SelectItem>
                      <SelectItem value="11">{t('financial.period_11') || "الفترة 11"}</SelectItem>
                      <SelectItem value="12">{t('financial.period_12') || "الفترة 12"}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('financial.account_level') || "مستوى الحساب"}
                  </label>
                  <Select value={filterLevel} onValueChange={setFilterLevel}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('financial.select_level') || "اختر المستوى"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('financial.all_levels') || "جميع المستويات"}</SelectItem>
                      <SelectItem value="1">{t('financial.level_1') || "المستوى 1"}</SelectItem>
                      <SelectItem value="2">{t('financial.level_2') || "المستوى 2"}</SelectItem>
                      <SelectItem value="3">{t('financial.level_3') || "المستوى 3"}</SelectItem>
                      <SelectItem value="4">{t('financial.level_4') || "المستوى 4"}</SelectItem>
                      <SelectItem value="5">{t('financial.level_5') || "المستوى 5"}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button className="px-6" onClick={() => refetch()}>
                  <Search className="h-4 w-4 mr-2" />
                  {t('common.search') || "بحث"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* بطاقة الملخص العلوي */}
        {!isLoading && trialBalanceData && (
          <Card className="bg-card/50 border-primary/20">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-xl">
                    {t('financial.trial_balance.header', { date: format(asOfDate, 'yyyy/MM/dd') }) || 
                      `ميزان المراجعة كما في ${format(asOfDate, 'yyyy/MM/dd')}`}
                  </CardTitle>
                  <CardDescription>
                    {t('financial.trial_balance.summary_description') || "ملخص الأرصدة ومؤشرات التوازن"}
                  </CardDescription>
                </div>
                <div className="space-x-2 flex">
                  <Badge variant={trialBalanceData.isBalanced ? "success" : "destructive"}>
                    {trialBalanceData.isBalanced 
                      ? t('financial.balanced') || "متوازن" 
                      : t('financial.not_balanced') || "غير متوازن"}
                  </Badge>
                  <Badge variant="outline">
                    {t('financial.total_accounts') || "عدد الحسابات"}: {trialBalanceData.accounts.length}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="p-3 rounded-md bg-background border">
                  <div className="text-sm font-medium text-muted-foreground">
                    {t('financial.total_debit_balance') || "إجمالي الأرصدة المدينة"}
                  </div>
                  <div className="text-2xl font-bold mt-1">
                    {formatCurrency(trialBalanceData.totalDebitBalance)}
                  </div>
                </div>
                <div className="p-3 rounded-md bg-background border">
                  <div className="text-sm font-medium text-muted-foreground">
                    {t('financial.total_credit_balance') || "إجمالي الأرصدة الدائنة"}
                  </div>
                  <div className="text-2xl font-bold mt-1">
                    {formatCurrency(trialBalanceData.totalCreditBalance)}
                  </div>
                </div>
                <div className="p-3 rounded-md bg-background border">
                  <div className="text-sm font-medium text-muted-foreground">
                    {t('financial.difference') || "الفرق"}
                  </div>
                  <div className={`text-2xl font-bold mt-1 ${trialBalanceData.isBalanced ? 'text-green-500' : 'text-red-500'}`}>
                    {formatCurrency(Math.abs(trialBalanceData.totalDebitBalance - trialBalanceData.totalCreditBalance))}
                  </div>
                </div>
                <div className="p-3 rounded-md bg-background border">
                  <div className="text-sm font-medium text-muted-foreground">
                    {t('financial.as_of_date') || "كما في تاريخ"}
                  </div>
                  <div className="text-xl font-medium mt-1">
                    {format(new Date(trialBalanceData.asOfDate), 'yyyy/MM/dd')}
                  </div>
                </div>
              </div>
              
              {/* شريط التوازن */}
              <div className="mt-3 mb-4">
                <div className="flex justify-between mb-1 text-sm">
                  <div>{t('financial.debit_balance') || "رصيد مدين"}</div>
                  <div>{t('financial.credit_balance') || "رصيد دائن"}</div>
                </div>
                <div className="relative h-3 rounded-full bg-muted overflow-hidden">
                  <div className="absolute inset-0 flex">
                    <div 
                      className="bg-blue-500 h-full" 
                      style={{ width: `${balanceRatio}%` }}
                    />
                    <div 
                      className="bg-green-500 h-full" 
                      style={{ width: `${100 - balanceRatio}%` }}
                    />
                  </div>
                </div>
                <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                  <div>{`${Math.round(balanceRatio)}%`}</div>
                  <div>{`${Math.round(100 - balanceRatio)}%`}</div>
                </div>
              </div>
              
              {/* أزرار التحكم في العرض */}
              <div className="border rounded-lg p-3 bg-background/60 my-4">
                <h3 className="text-sm font-medium mb-3 flex items-center">
                  <Settings2 className="h-4 w-4 mr-2 text-primary" />
                  {t('financial.display_options') || "خيارات العرض"}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      {t('financial.account_type_filter') || "تصفية حسب نوع الحساب"}
                    </label>
                    <Select value={accountTypeView} onValueChange={setAccountTypeView}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder={t('financial.account_type') || "نوع الحساب"} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">{t('financial.all_types') || "جميع الأنواع"}</SelectItem>
                        <SelectItem value="asset">{t('financial.account_types.asset') || "أصول"}</SelectItem>
                        <SelectItem value="liability">{t('financial.account_types.liability') || "التزامات"}</SelectItem>
                        <SelectItem value="equity">{t('financial.account_types.equity') || "حقوق ملكية"}</SelectItem>
                        <SelectItem value="revenue">{t('financial.account_types.revenue') || "إيرادات"}</SelectItem>
                        <SelectItem value="expense">{t('financial.account_types.expense') || "مصروفات"}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => setShowZeroBalances(!showZeroBalances)}
                      >
                        {showZeroBalances ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                        {showZeroBalances 
                          ? t('financial.hide_zero_balances') || "إخفاء الأرصدة الصفرية" 
                          : t('financial.show_zero_balances') || "إظهار الأرصدة الصفرية"}
                      </Button>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => setViewMode(viewMode === "expanded" ? "summary" : "expanded")}
                      >
                        {viewMode === "expanded" 
                          ? <BarChart4 className="w-4 h-4 mr-2" /> 
                          : <ArrowUpDown className="w-4 h-4 mr-2" />}
                        {viewMode === "expanded" 
                          ? t('financial.summary_view') || "عرض ملخص" 
                          : t('financial.detailed_view') || "عرض تفصيلي"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* بطاقة جدول البيانات */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>
                {t('financial.trial_balance.data_table') || "جدول الحسابات"}
              </CardTitle>
              <div className="flex space-x-2 print:hidden">
                <Button variant="outline" onClick={() => printDocument(printSectionRef, t('financial.trial_balance.title') || "ميزان المراجعة")}>
                  <Printer className="h-4 w-4 mr-2" />
                  {t('common.print') || "طباعة"}
                </Button>
                <ExportMenu 
                  tableRef={tableRef}
                  reportTitle={t('financial.trial_balance.title') || "ميزان المراجعة"}
                  fileName={`${t('financial.trial_balance.title') || "ميزان المراجعة"}_${format(asOfDate, 'yyyy-MM-dd')}`} 
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
              </div>
            ) : (
              <>
                {viewMode === "expanded" ? (
                  // عرض تفصيلي - جدول الحسابات
                  <div className="rounded-md border">
                    <Table ref={tableRef} dir="rtl">
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12">#</TableHead>
                          <TableHead className="w-24">{t('financial.account_code') || "رمز الحساب"}</TableHead>
                          <TableHead>{t('financial.account_name') || "اسم الحساب"}</TableHead>
                          <TableHead className="text-left">{t('financial.account_type') || "نوع الحساب"}</TableHead>
                          <TableHead className="text-left">{t('financial.account_level') || "المستوى"}</TableHead>
                          <TableHead className="text-left">{t('financial.total_debit') || "إجمالي المدين"}</TableHead>
                          <TableHead className="text-left">{t('financial.total_credit') || "إجمالي الدائن"}</TableHead>
                          <TableHead className="text-left">{t('financial.debit_balance') || "رصيد مدين"}</TableHead>
                          <TableHead className="text-left">{t('financial.credit_balance') || "رصيد دائن"}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredAccounts.length > 0 ? (
                          filteredAccounts.map((account: any, index: number) => (
                            <TableRow key={account.accountId} className={`${account.level === 1 ? 'bg-muted/50 font-medium' : ''}`}>
                              <TableCell>{index + 1}</TableCell>
                              <TableCell>{account.accountCode}</TableCell>
                              <TableCell>
                                <div className="font-medium">
                                  {account.accountName}
                                </div>
                                {account.accountNameEn && (
                                  <div className="text-xs text-muted-foreground">
                                    {account.accountNameEn}
                                  </div>
                                )}
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="font-normal">
                                  {t(`financial.account_types.${account.accountType}`) || account.accountType}
                                </Badge>
                              </TableCell>
                              <TableCell>{account.level}</TableCell>
                              <TableCell>
                                {account.totalDebit > 0 ? formatCurrency(account.totalDebit) : '-'}
                              </TableCell>
                              <TableCell>
                                {account.totalCredit > 0 ? formatCurrency(account.totalCredit) : '-'}
                              </TableCell>
                              <TableCell className={`font-medium ${account.debitBalance > 0 ? 'text-blue-600' : ''}`}>
                                {account.debitBalance > 0 ? formatCurrency(account.debitBalance) : '-'}
                              </TableCell>
                              <TableCell className={`font-medium ${account.creditBalance > 0 ? 'text-green-600' : ''}`}>
                                {account.creditBalance > 0 ? formatCurrency(account.creditBalance) : '-'}
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-4">
                              {t('financial.no_accounts_found') || "لم يتم العثور على حسابات"}
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  // عرض ملخص - تجميع حسب نوع الحساب
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.values(accountTypeGroups).map((group: any) => (
                      <Card key={group.type} className="overflow-hidden">
                        <CardHeader className="bg-muted/30 py-2">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary">
                                {t(`financial.account_types.${group.type}`) || group.type}
                              </Badge>
                              <span className="text-sm text-muted-foreground">
                                ({group.count} {t('financial.accounts') || "حسابات"})
                              </span>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="p-4">
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <div>{t('financial.total_debit') || "إجمالي المدين"}</div>
                              <div className="font-medium">
                                {formatCurrency(group.debitTotal)}
                              </div>
                            </div>
                            <div className="flex justify-between">
                              <div>{t('financial.total_credit') || "إجمالي الدائن"}</div>
                              <div className="font-medium">
                                {formatCurrency(group.creditTotal)}
                              </div>
                            </div>
                            <Separator className="my-2" />
                            <div className="flex justify-between">
                              <div>{t('financial.net_balance') || "صافي الرصيد"}</div>
                              <div className={`font-bold ${group.debitTotal > group.creditTotal ? 'text-blue-600' : 'text-green-600'}`}>
                                {formatCurrency(Math.abs(group.debitTotal - group.creditTotal))}
                                <span className="text-xs mr-1">
                                  {group.debitTotal > group.creditTotal 
                                    ? `(${t('financial.debit') || "مدين"})` 
                                    : `(${t('financial.credit') || "دائن"})`}
                                </span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {trialBalanceData && (
                  <div className="mt-6 flex flex-col gap-4">
                    <Separator />
                    <div className="flex justify-between items-center">
                      <div className="font-semibold text-lg">
                        {t('financial.trial_balance.summary') || "ملخص ميزان المراجعة"}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div className="flex justify-between">
                              <div>{t('financial.total_debit_balance') || "إجمالي الأرصدة المدينة"}</div>
                              <div className="font-bold">
                                {formatCurrency(trialBalanceData.totalDebitBalance)}
                              </div>
                            </div>
                            <div className="flex justify-between">
                              <div>{t('financial.total_credit_balance') || "إجمالي الأرصدة الدائنة"}</div>
                              <div className="font-bold">
                                {formatCurrency(trialBalanceData.totalCreditBalance)}
                              </div>
                            </div>
                            <Separator />
                            <div className="flex justify-between">
                              <div>{t('financial.balance_status') || "حالة التوازن"}</div>
                              <div className={`font-bold ${trialBalanceData.isBalanced ? 'text-green-500' : 'text-red-500'}`}>
                                {trialBalanceData.isBalanced 
                                  ? t('financial.balanced') || "متوازن" 
                                  : t('financial.not_balanced') || "غير متوازن"}
                              </div>
                            </div>
                            <div className="flex justify-between">
                              <div>{t('financial.difference') || "الفرق"}</div>
                              <div className="font-bold">
                                {formatCurrency(Math.abs(trialBalanceData.totalDebitBalance - trialBalanceData.totalCreditBalance))}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div className="flex justify-between">
                              <div>{t('financial.as_of_date') || "كما في تاريخ"}</div>
                              <div className="font-medium">
                                {format(new Date(trialBalanceData.asOfDate), 'yyyy/MM/dd')}
                              </div>
                            </div>
                            {trialBalanceData.fiscalYear && (
                              <div className="flex justify-between">
                                <div>{t('financial.fiscal_year') || "السنة المالية"}</div>
                                <div className="font-medium">{trialBalanceData.fiscalYear}</div>
                              </div>
                            )}
                            {trialBalanceData.fiscalPeriod && (
                              <div className="flex justify-between">
                                <div>{t('financial.fiscal_period') || "الفترة المالية"}</div>
                                <div className="font-medium">{trialBalanceData.fiscalPeriod}</div>
                              </div>
                            )}
                            <div className="flex justify-between">
                              <div>{t('financial.total_accounts') || "عدد الحسابات"}</div>
                              <div className="font-medium">{trialBalanceData.accounts.length}</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}