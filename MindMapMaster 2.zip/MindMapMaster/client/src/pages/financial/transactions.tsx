import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { SearchIcon, Plus, Filter, ArrowUpRight, ArrowDownLeft, Repeat, Eye, CalendarIcon, Loader2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// Interface for API transaction data
interface Transaction {
  id: number;
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: string | Date;
  description: string | null;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number;
  creditAccountId: number;
  referenceNumber: string;
  status: string;
  createdAt: string | Date;
  updatedAt: string | Date;
  debitAccount: { id?: number; name: string; code: string; type?: string };
  creditAccount: { id?: number; name: string; code: string; type?: string };
  project: { id?: number; name: string } | null;
}

interface Account {
  id: number;
  code: string;
  name: string;
  type: string;
  level: number;
  hasChildren: boolean;
  parentId?: number;
}

interface Project {
  id: number;
  name: string;
}

interface CostCategory {
  id: string;
  name: string;
}

interface TransactionFormData {
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: Date;
  description: string;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number | null;
  creditAccountId: number | null;
  referenceNumber: string;
  createJournalEntry: boolean;
}

export default function FinancialTransactions() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State for filters
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [projectFilter, setProjectFilter] = useState<number | "all">("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
  const [selectedTransactionId, setSelectedTransactionId] = useState<number | null>(null);
  
  // Form state for new transaction
  const [newTransaction, setNewTransaction] = useState<TransactionFormData>({
    type: "income",
    amount: 0,
    transactionDate: new Date(),
    description: "",
    costCategory: null,
    projectId: null,
    debitAccountId: null,
    creditAccountId: null,
    referenceNumber: "",
    createJournalEntry: true
  });
  
  // Query parameters for transactions
  const [queryParams, setQueryParams] = useState({
    page: 1,
    limit: 10,
    type: typeFilter !== "all" ? typeFilter : undefined,
    projectId: projectFilter !== "all" ? projectFilter : undefined,
    search: searchQuery || undefined
  });
  
  // Fetch transactions
  const { 
    data: transactionsData, 
    isLoading: isLoadingTransactions,
    isError: isTransactionsError,
    error: transactionsError
  } = useQuery({
    queryKey: ['/api/financial/transactions', queryParams],
    refetchOnWindowFocus: false
  });
  
  // Fetch accounts for dropdown
  const { 
    data: accounts,
    isLoading: isLoadingAccounts
  } = useQuery({
    queryKey: ['/api/financial/accounts'],
    refetchOnWindowFocus: false
  });
  
  // Fetch projects for dropdown
  const { 
    data: projects,
    isLoading: isLoadingProjects
  } = useQuery({
    queryKey: ['/api/financial/projects'],
    refetchOnWindowFocus: false
  });
  
  // Fetch cost categories for dropdown
  const { 
    data: costCategories,
    isLoading: isLoadingCategories
  } = useQuery({
    queryKey: ['/api/financial/cost-categories'],
    refetchOnWindowFocus: false
  });
  
  // Fetch transaction details when viewing a specific transaction
  const { 
    data: transactionDetails,
    isLoading: isLoadingDetails
  } = useQuery({
    queryKey: ['/api/financial/transactions', selectedTransactionId],
    enabled: selectedTransactionId !== null && isViewDetailsOpen,
    refetchOnWindowFocus: false
  });
  
  // Create new transaction mutation
  const createTransactionMutation = useMutation({
    mutationFn: (data: TransactionFormData) => {
      return apiRequest("POST", "/api/financial/transactions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/transactions'] });
      toast({
        title: t("financial.transactions.successTitle"),
        description: t("financial.transactions.createSuccess"),
      });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: t("financial.transactions.errorTitle"),
        description: error.message || t("financial.transactions.genericError"),
        variant: "destructive"
      });
    }
  });
  
  // Reset form after submission
  const resetForm = () => {
    setNewTransaction({
      type: "income",
      amount: 0,
      transactionDate: new Date(),
      description: "",
      costCategory: null,
      projectId: null,
      debitAccountId: null,
      creditAccountId: null,
      referenceNumber: "",
      createJournalEntry: true
    });
  };
  
  // Update query params when filters change
  useEffect(() => {
    setQueryParams({
      page: 1,
      limit: 10,
      type: typeFilter !== "all" ? typeFilter : undefined,
      projectId: projectFilter !== "all" ? projectFilter : undefined,
      search: searchQuery || undefined
    });
  }, [typeFilter, projectFilter, searchQuery]);
  
  // Handle view transaction details
  const handleViewDetails = (id: number) => {
    setSelectedTransactionId(id);
    setIsViewDetailsOpen(true);
  };
  
  // Handle form input changes
  const handleInputChange = (field: keyof TransactionFormData, value: any) => {
    setNewTransaction(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle transaction submission
  const handleAddTransaction = () => {
    // Validation
    if (!newTransaction.amount || newTransaction.amount <= 0) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.amountRequired"),
        variant: "destructive"
      });
      return;
    }
    
    if (!newTransaction.transactionDate) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.dateRequired"),
        variant: "destructive"
      });
      return;
    }
    
    if (!newTransaction.debitAccountId) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.debitAccountRequired"),
        variant: "destructive"
      });
      return;
    }
    
    if (!newTransaction.creditAccountId) {
      toast({
        title: t("financial.transactions.validationError"),
        description: t("financial.transactions.creditAccountRequired"),
        variant: "destructive"
      });
      return;
    }
    
    // Submit the form data
    createTransactionMutation.mutate(newTransaction);
  };
  
  // Helper function to get icon for transaction type
  const getTypeIcon = (type: Transaction["type"]) => {
    switch (type) {
      case "income":
        return <ArrowUpRight className="h-4 w-4 text-green-500" />;
      case "expense":
        return <ArrowDownLeft className="h-4 w-4 text-red-500" />;
      case "transfer":
        return <Repeat className="h-4 w-4 text-blue-500" />;
    }
  };

  // Helper function to get badge for transaction type
  const getTypeBadge = (type: Transaction["type"]) => {
    switch (type) {
      case "income":
        return <Badge variant="success">{t("financial.transactions.income")}</Badge>;
      case "expense":
        return <Badge variant="destructive">{t("financial.transactions.expense")}</Badge>;
      case "transfer":
        return <Badge variant="default">{t("financial.transactions.transfer")}</Badge>;
    }
  };

  // Format currency amount
  const formatAmount = (amount: number, type: Transaction["type"]) => {
    const formatted = new Intl.NumberFormat('ar-SA', { 
      style: 'currency', 
      currency: 'SAR',
      maximumFractionDigits: 0
    }).format(amount);
    
    if (type === "expense") {
      return <span className="text-red-500">- {formatted}</span>;
    } else if (type === "income") {
      return <span className="text-green-500">{formatted}</span>;
    } else {
      return <span className="text-blue-500">{formatted}</span>;
    }
  };
  
  // Format date to display
  const formatDate = (date: string | Date) => {
    return format(new Date(date), "yyyy/MM/dd");
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{t("financial.transactions.title")}</h1>
            <p className="text-muted-foreground">{t("financial.transactions.list")}</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                {t("financial.transactions.add")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[700px] p-0 overflow-hidden">
              <DialogHeader className="bg-gradient-to-l from-primary/10 to-transparent p-6 border-b">
                <div className="flex items-center gap-3 mb-1">
                  <div className="bg-primary/20 rounded-full p-1.5">
                    <Plus className="h-5 w-5 text-primary" />
                  </div>
                  <DialogTitle className="text-xl font-bold text-primary">{t("financial.transactions.addNew")}</DialogTitle>
                </div>
                <DialogDescription className="text-[15px]">
                  {t("financial.transactions.addNewDescription")}
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-6 p-6 max-h-[70vh] overflow-y-auto">
                {/* نوع المعاملة - تعديل التصميم مع أيقونات وألوان لكل نوع */}
                <div className="space-y-3">
                  <Label htmlFor="transaction-type" className="text-[15px] font-medium">
                    {t("financial.transactions.type")}
                  </Label>
                  <div className="grid grid-cols-3 gap-3">
                    <div 
                      className={cn(
                        "flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-all",
                        newTransaction.type === "income" 
                          ? "bg-green-50 border-green-300 shadow-sm" 
                          : "hover:bg-gray-50 border-gray-200"
                      )}
                      onClick={() => handleInputChange("type", "income")}
                    >
                      <div className={cn(
                        "rounded-full p-2 transition-colors",
                        newTransaction.type === "income" ? "bg-green-100" : "bg-gray-100"
                      )}>
                        <ArrowUpRight className={cn(
                          "h-5 w-5",
                          newTransaction.type === "income" ? "text-green-600" : "text-gray-500"  
                        )} />
                      </div>
                      <div>
                        <div className={cn(
                          "font-medium text-[15px]",
                          newTransaction.type === "income" ? "text-green-700" : "text-gray-700"
                        )}>
                          {t("financial.transactions.income")}
                        </div>
                        <div className="text-xs text-gray-500">
                          {t("financial.transactions.incomeDescription")}
                        </div>
                      </div>
                    </div>
                    
                    <div 
                      className={cn(
                        "flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-all",
                        newTransaction.type === "expense" 
                          ? "bg-red-50 border-red-300 shadow-sm" 
                          : "hover:bg-gray-50 border-gray-200"
                      )}
                      onClick={() => handleInputChange("type", "expense")}
                    >
                      <div className={cn(
                        "rounded-full p-2 transition-colors",
                        newTransaction.type === "expense" ? "bg-red-100" : "bg-gray-100"
                      )}>
                        <ArrowDownLeft className={cn(
                          "h-5 w-5",
                          newTransaction.type === "expense" ? "text-red-600" : "text-gray-500"  
                        )} />
                      </div>
                      <div>
                        <div className={cn(
                          "font-medium text-[15px]",
                          newTransaction.type === "expense" ? "text-red-700" : "text-gray-700"
                        )}>
                          {t("financial.transactions.expense")}
                        </div>
                        <div className="text-xs text-gray-500">
                          {t("financial.transactions.expenseDescription")}
                        </div>
                      </div>
                    </div>
                    
                    <div 
                      className={cn(
                        "flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-all",
                        newTransaction.type === "transfer" 
                          ? "bg-blue-50 border-blue-300 shadow-sm" 
                          : "hover:bg-gray-50 border-gray-200"
                      )}
                      onClick={() => handleInputChange("type", "transfer")}
                    >
                      <div className={cn(
                        "rounded-full p-2 transition-colors",
                        newTransaction.type === "transfer" ? "bg-blue-100" : "bg-gray-100"
                      )}>
                        <Repeat className={cn(
                          "h-5 w-5",
                          newTransaction.type === "transfer" ? "text-blue-600" : "text-gray-500"  
                        )} />
                      </div>
                      <div>
                        <div className={cn(
                          "font-medium text-[15px]",
                          newTransaction.type === "transfer" ? "text-blue-700" : "text-gray-700"
                        )}>
                          {t("financial.transactions.transfer")}
                        </div>
                        <div className="text-xs text-gray-500">
                          {t("financial.transactions.transferDescription")}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* القيمة المالية */}
                  <div className="space-y-3">
                    <Label htmlFor="amount" className="text-[15px] font-medium">
                      {t("financial.transactions.amount")}
                    </Label>
                    <div className="relative">
                      <span className="absolute right-3 top-3 text-gray-500 font-medium">ر.س</span>
                      <Input 
                        id="amount" 
                        type="number" 
                        value={newTransaction.amount || ''} 
                        onChange={(e) => handleInputChange("amount", Number(e.target.value))}
                        className="pr-12 py-6 text-lg font-medium"
                        placeholder="0"
                      />
                    </div>
                  </div>
                  
                  {/* التاريخ */}
                  <div className="space-y-3">
                    <Label className="text-[15px] font-medium">
                      {t("financial.transactions.date")}
                    </Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-right py-6 text-[15px]"
                        >
                          {newTransaction.transactionDate ? (
                            format(newTransaction.transactionDate, "yyyy/MM/dd")
                          ) : (
                            <span className="text-muted-foreground">{t("financial.transactions.selectDate")}</span>
                          )}
                          <CalendarIcon className="ml-auto h-5 w-5 opacity-70" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={newTransaction.date}
                          onSelect={(date) => handleInputChange("date", date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* الحساب */}
                  <div className="space-y-3">
                    <Label htmlFor="account" className="text-[15px] font-medium">
                      {t("financial.transactions.account")}
                    </Label>
                    <Select 
                      value={newTransaction.account || ''} 
                      onValueChange={(value) => handleInputChange("account", value)}
                    >
                      <SelectTrigger id="account" className="py-6 text-[15px]">
                        <SelectValue placeholder={t("financial.transactions.selectAccount")} />
                      </SelectTrigger>
                      <SelectContent>
                        {accounts.map(account => (
                          <SelectItem key={account} value={account} className="text-[15px]">{account}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* رقم المرجع */}
                  <div className="space-y-3">
                    <Label htmlFor="reference" className="text-[15px] font-medium">
                      {t("financial.transactions.reference")}
                    </Label>
                    <Input 
                      id="reference" 
                      value={newTransaction.reference || ''} 
                      onChange={(e) => handleInputChange("reference", e.target.value)}
                      className="py-6 text-[15px]"
                      placeholder="مثال: INV-2023-001"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* التصنيف */}
                  <div className="space-y-3">
                    <Label htmlFor="category" className="text-[15px] font-medium">
                      {t("financial.transactions.category")}
                    </Label>
                    <Select 
                      value={newTransaction.category || ''} 
                      onValueChange={(value) => handleInputChange("category", value)}
                    >
                      <SelectTrigger id="category" className="py-6 text-[15px]">
                        <SelectValue placeholder={t("financial.transactions.selectCategory")} />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category} value={category} className="text-[15px]">{category}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* المشروع */}
                  <div className="space-y-3">
                    <Label htmlFor="project" className="text-[15px] font-medium">
                      {t("financial.transactions.project")}
                    </Label>
                    <Select 
                      value={newTransaction.project || ''} 
                      onValueChange={(value) => handleInputChange("project", value)}
                    >
                      <SelectTrigger id="project" className="py-6 text-[15px]">
                        <SelectValue placeholder={t("financial.transactions.selectProject")} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="no_project" className="text-[15px]">-</SelectItem>
                        {projects.map(project => (
                          <SelectItem key={project} value={project} className="text-[15px]">{project}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {/* الوصف */}
                <div className="space-y-3">
                  <Label htmlFor="description" className="text-[15px] font-medium">
                    {t("financial.transactions.description")}
                  </Label>
                  <Textarea 
                    id="description" 
                    rows={3}
                    value={newTransaction.description || ''} 
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    className="resize-none text-[15px]"
                    placeholder={t("financial.transactions.descriptionPlaceholder") || "أضف تفاصيل إضافية هنا..."}
                  />
                </div>
              </div>
              
              <DialogFooter className="bg-gray-50 p-4 border-t flex-row-reverse gap-2">
                <Button 
                  onClick={handleAddTransaction} 
                  disabled={
                    !newTransaction.type || !newTransaction.amount || !newTransaction.account ||
                    !newTransaction.date || !newTransaction.reference
                  }
                  className="px-6 py-5 text-[15px]"
                >
                  {t("common.save")}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                  className="px-6 py-5 text-[15px]"
                >
                  {t("common.cancel")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex-1 relative min-w-[300px]">
            <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder={t("financial.transactions.searchPlaceholder")}
              className="w-full pr-4 pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">{t("financial.transactions.filters")}:</span>
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t("financial.transactions.type")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("financial.transactions.allTypes")}</SelectItem>
              <SelectItem value="income">{t("financial.transactions.income")}</SelectItem>
              <SelectItem value="expense">{t("financial.transactions.expense")}</SelectItem>
              <SelectItem value="transfer">{t("financial.transactions.transfer")}</SelectItem>
            </SelectContent>
          </Select>
          <Select value={projectFilter} onValueChange={setProjectFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder={t("financial.transactions.project")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("financial.transactions.allProjects")}</SelectItem>
              {projects.map(project => (
                <SelectItem key={project} value={project}>{project}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>{t("financial.transactions.title")}</CardTitle>
            <CardDescription>{t("financial.transactions.list")}</CardDescription>
          </CardHeader>
          <CardContent>
            <Alert className="mb-4">
              <AlertCircle className="h-4 w-4 ml-2" />
              <AlertTitle>{t("financial.formUnderDevelopment")}</AlertTitle>
              <AlertDescription>
                هذه الواجهة تعرض بيانات تجريبية وليست متصلة بقاعدة البيانات.
              </AlertDescription>
            </Alert>
            
            {filteredTransactions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-center">
                <p className="text-muted-foreground mb-2">{t("financial.transactions.empty")}</p>
                <Button variant="outline" onClick={() => {
                  setTypeFilter("all");
                  setProjectFilter("all");
                  setSearchQuery("");
                }}>
                  {t("common.view_all")}
                </Button>
              </div>
            ) : (
              <div className="rounded-md border">
                <div className="grid grid-cols-7 border-b px-4 py-3 font-medium text-sm">
                  <div>{t("financial.transactions.date")}</div>
                  <div>{t("financial.transactions.type")}</div>
                  <div>{t("financial.transactions.description")}</div>
                  <div>{t("financial.transactions.amount")}</div>
                  <div>{t("financial.transactions.project")}</div>
                  <div>{t("financial.transactions.reference")}</div>
                  <div className="text-right">{t("common.actions")}</div>
                </div>
                
                {filteredTransactions.map(transaction => (
                  <div key={transaction.id} className="grid grid-cols-7 border-b last:border-0 px-4 py-3 text-sm items-center">
                    <div className="text-muted-foreground">
                      {format(transaction.date, "yyyy/MM/dd")}
                    </div>
                    <div className="flex items-center gap-2">
                      {getTypeIcon(transaction.type)}
                      {getTypeBadge(transaction.type)}
                    </div>
                    <div className="truncate max-w-[200px]">
                      {transaction.description || 
                        <span className="text-muted-foreground italic">{t("financial.transactions.noDescription")}</span>}
                    </div>
                    <div className="font-medium">
                      {formatAmount(transaction.amount, transaction.type)}
                    </div>
                    <div>
                      {transaction.project ? (
                        <span className="inline-flex items-center rounded px-2 py-1 text-xs font-medium bg-gray-100">
                          {transaction.project}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </div>
                    <div className="font-mono">{transaction.reference}</div>
                    <div className="flex justify-end">
                      <Button variant="ghost" size="icon" title={t("common.view")}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}