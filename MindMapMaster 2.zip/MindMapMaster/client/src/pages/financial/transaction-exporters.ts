import { format } from "date-fns";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";

// Copy of Transaction interface from transactions-v2.tsx
export interface Transaction {
  id: number;
  type: "income" | "expense" | "transfer";
  amount: number;
  transactionDate: string | Date;
  description: string | null;
  costCategory: string | null;
  projectId: number | null;
  debitAccountId: number;
  creditAccountId: number;
  referenceNumber: string;
  status: string;
  createdAt: string | Date;
  updatedAt: string | Date;
  debitAccount: { id?: number; name: string; code: string; type?: string };
  creditAccount: { id?: number; name: string; code: string; type?: string };
  project: { id?: number; name: string } | null;
  journalEntry?: {
    id: number;
    journalNumber: string;
    journalDate: string | Date;
    totalDebit: number;
    totalCredit: number;
    isBalanced: boolean;
    lines: {
      id: number;
      accountId: number;
      accountName: string;
      accountCode: string;
      debitAmount: number;
      creditAmount: number;
      description: string;
    }[];
  };
  // Additional fields that might be used in newer versions
  relatedCertificateId?: number | null;
  relatedBudgetItemId?: number | null;
}

export interface ExportOptions {
  t: (key: string, options?: any) => string; 
  formatAmount: (amount: number) => string;
  formatDate: (date: string | Date) => string;
}

// Print transaction details
export const printTransaction = async (
  element: HTMLElement | null, 
  transaction: Transaction, 
  options: ExportOptions,
  onSuccess: (title: string, description: string) => void,
  onError: (title: string, description: string) => void
) => {
  if (!element) {
    onError(
      options.t("financial.transactions.printError"), 
      options.t("financial.transactions.printErrorDesc")
    );
    return;
  }
  
  try {
    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL('image/png');
    
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Add title
    const title = options.t("financial.transactions.printTitle");
    pdf.setFontSize(18);
    pdf.text(title, 105, 15, { align: 'center' });
    
    // Add image of the rendered component
    const imgWidth = 190;
    const imgHeight = canvas.height * imgWidth / canvas.width;
    pdf.addImage(imgData, 'PNG', 10, 20, imgWidth, imgHeight);
    
    // Add footer with date
    const footer = `${options.t("common.printedOn")} ${format(new Date(), "yyyy/MM/dd HH:mm")}`;
    pdf.setFontSize(10);
    pdf.text(footer, 105, 287, { align: 'center' });
    
    // Download PDF
    pdf.save(`transaction_${transaction.id || 'details'}.pdf`);
    
    onSuccess(
      options.t("financial.transactions.printSuccess"),
      options.t("financial.transactions.printSuccessDesc")
    );
  } catch (error) {
    console.error('Error printing transaction:', error);
    onError(
      options.t("financial.transactions.printError"),
      options.t("financial.transactions.printErrorDesc")
    );
  }
};

// Export transaction details to Excel
export const exportTransactionToExcel = (
  transaction: Transaction, 
  options: ExportOptions,
  onSuccess: (title: string, description: string) => void,
  onError: (title: string, description: string) => void
) => {
  try {
    // Prepare data for export
    const data = [{
      [options.t("financial.transactions.id")]: transaction.id,
      [options.t("financial.transactions.reference")]: transaction.referenceNumber,
      [options.t("financial.transactions.date")]: options.formatDate(transaction.transactionDate),
      [options.t("financial.transactions.type")]: options.t(`financial.transactions.type_${transaction.type}`),
      [options.t("financial.transactions.amount")]: transaction.amount,
      [options.t("financial.transactions.description")]: transaction.description || '',
      [options.t("financial.transactions.debitAccount")]: transaction.debitAccount?.name || '',
      [options.t("financial.transactions.debitAccountCode")]: transaction.debitAccount?.code || '',
      [options.t("financial.transactions.creditAccount")]: transaction.creditAccount?.name || '',
      [options.t("financial.transactions.creditAccountCode")]: transaction.creditAccount?.code || '',
      [options.t("financial.transactions.project")]: transaction.project?.name || '',
      [options.t("financial.transactions.category")]: transaction.costCategory || '',
      [options.t("financial.transactions.status")]: options.t(`financial.transactions.status_${transaction.status}`),
      [options.t("financial.transactions.createdAt")]: options.formatDate(transaction.createdAt),
      [options.t("financial.transactions.updatedAt")]: options.formatDate(transaction.updatedAt),
    }];
    
    // Add journal entry details if exists
    let journalData: any[] = [];
    if (transaction.journalEntry) {
      journalData = transaction.journalEntry.lines.map(line => ({
        [options.t("financial.transactions.journalNumber")]: transaction.journalEntry?.journalNumber,
        [options.t("financial.transactions.accountCode")]: line.accountCode,
        [options.t("financial.transactions.accountName")]: line.accountName,
        [options.t("financial.transactions.debitAmount")]: line.debitAmount,
        [options.t("financial.transactions.creditAmount")]: line.creditAmount,
        [options.t("financial.transactions.description")]: line.description,
      }));
    }
    
    // Create workbook
    const wb = XLSX.utils.book_new();
    
    // Add main transaction sheet
    const ws1 = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws1, options.t("financial.transactions.transaction"));
    
    // Add journal entry sheet if exists
    if (journalData.length > 0) {
      const ws2 = XLSX.utils.json_to_sheet(journalData);
      XLSX.utils.book_append_sheet(wb, ws2, options.t("financial.transactions.journalEntry"));
    }
    
    // Save to file
    XLSX.writeFile(wb, `transaction_${transaction.id}.xlsx`);
    
    onSuccess(
      options.t("financial.transactions.exportSuccess"),
      options.t("financial.transactions.exportSuccessDesc")
    );
  } catch (error) {
    console.error('Error exporting transaction:', error);
    onError(
      options.t("financial.transactions.exportError"),
      options.t("financial.transactions.exportErrorDesc")
    );
  }
};