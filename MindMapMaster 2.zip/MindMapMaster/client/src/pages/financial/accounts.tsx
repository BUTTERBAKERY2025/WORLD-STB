import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, ChevronDown, Search, Plus, Edit, Trash2, FileText, BarChart4, FileBarChart, Download, Filter } from "lucide-react";
// تم إزالة استيراد مكتبة recharts
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ChartOfAccount } from "@shared/schema";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// زر إنشاء حساب جديد مع مربع حوار
const NewAccountDialog = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    nameEn: "",
    type: "asset",
    parentId: null as number | null,
    description: "",
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/accounts");
      return response.json ? await response.json() : response;
    },
    enabled: isOpen
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    if (name === "parentId") {
      setFormData(prev => ({ ...prev, [name]: value === "none" ? null : parseInt(value) }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async () => {
    try {
      await apiRequest("POST", "/api/accounts", formData);
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: t("success"),
        description: t("account_created_successfully"),
      });
      setIsOpen(false);
      setFormData({
        code: "",
        name: "",
        nameEn: "",
        type: "asset",
        parentId: null,
        description: "",
      });
    } catch (error: any) {
      toast({
        title: t("error"),
        description: error.message || t("failed_to_create_account"),
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="ml-4">
          <Plus className="mr-2 h-4 w-4" />
          {t("new_account")}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{t("create_new_account")}</DialogTitle>
          <DialogDescription>
            {t("enter_account_details_below")}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="code" className="text-right">
              {t("code")}
            </Label>
            <Input
              id="code"
              name="code"
              value={formData.code}
              onChange={handleInputChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              {t("name_ar")}
            </Label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="nameEn" className="text-right">
              {t("name_en")}
            </Label>
            <Input
              id="nameEn"
              name="nameEn"
              value={formData.nameEn}
              onChange={handleInputChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="type" className="text-right">
              {t("type")}
            </Label>
            <Select
              name="type"
              value={formData.type}
              onValueChange={value => handleSelectChange("type", value)}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder={t("select_account_type")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="asset">{t("asset")}</SelectItem>
                <SelectItem value="liability">{t("liability")}</SelectItem>
                <SelectItem value="equity">{t("equity")}</SelectItem>
                <SelectItem value="revenue">{t("revenue")}</SelectItem>
                <SelectItem value="expense">{t("expense")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="parentId" className="text-right">
              {t("parent_account")}
            </Label>
            <Select
              name="parentId"
              value={formData.parentId?.toString() || "none"}
              onValueChange={value => handleSelectChange("parentId", value)}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder={t("select_parent_account")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">{t("none")}</SelectItem>
                {accounts?.map((account: ChartOfAccount) => (
                  <SelectItem key={account.id} value={account.id.toString()}>
                    {account.code} - {account.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="description" className="text-right">
              {t("description")}
            </Label>
            <Input
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleSubmit}>
            {t("create")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// شريط أدوات البحث والفرز
const AccountsToolbar = () => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");
  const [accountType, setAccountType] = useState<string | null>(null);
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [hasBalance, setHasBalance] = useState<string | null>(null);
  const [minBalance, setMinBalance] = useState<string>("");
  const [maxBalance, setMaxBalance] = useState<string>("");
  const [parentId, setParentId] = useState<string | null>(null);
  
  // استدعاء API للحصول على الحسابات للاستخدام في قائمة الحسابات الأب
  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts", "parents-list"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/accounts");
      return response.json ? await response.json() : response;
    },
    enabled: showAdvancedSearch
  });
  
  // مسح جميع معايير البحث
  const handleClearFilters = () => {
    setSearchTerm("");
    setAccountType(null);
    setHasBalance(null);
    setMinBalance("");
    setMaxBalance("");
    setParentId(null);
  };

  return (
    <div className="flex flex-col space-y-4 mb-6">
      <div className="flex flex-col sm:flex-row justify-between space-y-4 sm:space-y-0 sm:space-x-4">
        <div className="flex flex-wrap gap-4">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder={t("search_accounts")}
              className="w-full pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select value={accountType || "all"} onValueChange={(value) => setAccountType(value === "all" ? null : value)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t("account_type")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("all")}</SelectItem>
              <SelectItem value="asset">{t("asset")}</SelectItem>
              <SelectItem value="liability">{t("liability")}</SelectItem>
              <SelectItem value="equity">{t("equity")}</SelectItem>
              <SelectItem value="revenue">{t("revenue")}</SelectItem>
              <SelectItem value="expense">{t("expense")}</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
            className="flex items-center"
          >
            <Filter className="mr-2 h-4 w-4" />
            {t("advanced_search")}
          </Button>
        </div>
        <div className="flex space-x-2">
          <NewAccountDialog />
        </div>
      </div>
      
      {showAdvancedSearch && (
        <Card className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="hasBalance">{t("balance_status")}</Label>
              <Select 
                value={hasBalance || "all"} 
                onValueChange={(value) => setHasBalance(value === "all" ? null : value)}
              >
                <SelectTrigger id="hasBalance">
                  <SelectValue placeholder={t("all")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("all")}</SelectItem>
                  <SelectItem value="has">{t("has_balance")}</SelectItem>
                  <SelectItem value="zero">{t("zero_balance")}</SelectItem>
                  <SelectItem value="positive">{t("positive_balance")}</SelectItem>
                  <SelectItem value="negative">{t("negative_balance")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="minBalance">{t("min_balance")}</Label>
              <Input
                type="number"
                id="minBalance"
                value={minBalance}
                onChange={(e) => setMinBalance(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="maxBalance">{t("max_balance")}</Label>
              <Input
                type="number"
                id="maxBalance"
                value={maxBalance}
                onChange={(e) => setMaxBalance(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="parentAccount">{t("parent_account")}</Label>
              <Select
                value={parentId || "all"}
                onValueChange={(value) => setParentId(value === "all" ? null : value)}
              >
                <SelectTrigger id="parentAccount">
                  <SelectValue placeholder={t("all")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("all")}</SelectItem>
                  <SelectItem value="none">{t("no_parent")}</SelectItem>
                  {accounts.map((account: ChartOfAccount) => (
                    <SelectItem key={account.id} value={account.id.toString()}>
                      {account.code} - {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="col-span-1 md:col-span-2 lg:col-span-3 flex justify-end space-x-2">
              <Button variant="outline" onClick={handleClearFilters}>
                {t("clear_filters")}
              </Button>
              <Button>
                {t("apply_filters")}
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

// عرض شجرة الحسابات
const AccountTree = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [expandedAccounts, setExpandedAccounts] = useState<Record<string, boolean>>({});
  const [editAccount, setEditAccount] = useState<ChartOfAccount | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editFormData, setEditFormData] = useState({
    name: "",
    nameEn: "",
    description: ""
  });

  // استدعاء API للحصول على الحسابات الرئيسية
  const { data: rootAccounts, isLoading } = useQuery({
    queryKey: ["/api/accounts", { root: "true" }],
    queryFn: async () => {
      const response = await fetch("/api/accounts?root=true&withBalance=true");
      if (!response.ok) {
        throw new Error(t("failed_to_fetch_accounts"));
      }
      return response.json();
    }
  });

  // استدعاء API للحصول على الحسابات الفرعية عند توسيع حساب معين
  const fetchChildAccounts = async (parentId: number) => {
    try {
      const response = await fetch(`/api/accounts?parentId=${parentId}&withBalance=true`);
      if (!response.ok) {
        throw new Error(t("failed_to_fetch_child_accounts"));
      }
      return await response.json();
    } catch (error) {
      toast({
        title: t("error"),
        description: (error as Error).message,
        variant: "destructive",
      });
      return [];
    }
  };

  const toggleExpand = async (account: ChartOfAccount) => {
    const newExpandedAccounts = { ...expandedAccounts };
    newExpandedAccounts[account.id] = !newExpandedAccounts[account.id];
    setExpandedAccounts(newExpandedAccounts);

    // إذا كان الحساب مفتوحًا الآن ونحتاج لجلب الحسابات الفرعية
    if (newExpandedAccounts[account.id]) {
      const children = await fetchChildAccounts(account.id);
      // يمكن تخزين البيانات في ذاكرة التخزين المؤقت
      queryClient.setQueryData(["/api/accounts", { parentId: account.id }], children);
    }
  };

  const handleEditClick = (account: ChartOfAccount) => {
    setEditAccount(account);
    setEditFormData({
      name: account.name,
      nameEn: account.nameEn || "",
      description: account.description || ""
    });
    setIsEditDialogOpen(true);
  };

  const handleEditInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleEditSubmit = async () => {
    if (!editAccount) return;

    try {
      await apiRequest("PATCH", `/api/accounts/${editAccount.id}`, editFormData);
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: t("success"),
        description: t("account_updated_successfully"),
      });
      setIsEditDialogOpen(false);
    } catch (error: any) {
      toast({
        title: t("error"),
        description: error.message || t("failed_to_update_account"),
        variant: "destructive",
      });
    }
  };

  const handleDeleteAccount = async (account: ChartOfAccount) => {
    if (window.confirm(t("confirm_delete_account"))) {
      try {
        await apiRequest("DELETE", `/api/accounts/${account.id}`);
        queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
        toast({
          title: t("success"),
          description: t("account_deleted_successfully"),
        });
      } catch (error: any) {
        toast({
          title: t("error"),
          description: error.message || t("failed_to_delete_account"),
          variant: "destructive",
        });
      }
    }
  };

  // استعلامات لبيانات الحسابات الفرعية
  const childAccountsQueries: Record<number, any[]> = {};
  
  Object.keys(expandedAccounts).forEach(accountId => {
    if (expandedAccounts[parseInt(accountId)]) {
      const { data } = useQuery({
        queryKey: ["/api/accounts", { parentId: parseInt(accountId) }],
        queryFn: () => fetchChildAccounts(parseInt(accountId)),
        enabled: expandedAccounts[parseInt(accountId)],
      });
      
      childAccountsQueries[parseInt(accountId)] = data || [];
    }
  });

  // وظيفة تكرارية لعرض صف حساب مع الصفوف الفرعية
  const renderAccountRow = (account: ChartOfAccount, level: number = 0): JSX.Element[] => {
    const isExpanded = expandedAccounts[account.id] || false;
    const childAccounts = childAccountsQueries[account.id] || [];
    
    // صف الحساب الرئيسي
    const mainRow = (
      <TableRow key={`account-row-${account.id}`} className="group hover:bg-muted/50">
        <TableCell className="font-medium" style={{ paddingLeft: `${level * 2}rem` }}>
          <div className="flex items-center">
            <button
              type="button"
              onClick={() => toggleExpand(account)}
              className="p-1 rounded-md hover:bg-muted"
            >
              {isExpanded ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </button>
            <span className="ml-2">{account.code}</span>
          </div>
        </TableCell>
        <TableCell>{account.name}</TableCell>
        <TableCell>{account.nameEn}</TableCell>
        <TableCell>
          <Badge
            variant={
              account.type === "asset" ? "default" :
              account.type === "liability" ? "destructive" :
              account.type === "equity" ? "secondary" :
              account.type === "revenue" ? "success" : "outline"
            }
          >
            {t(account.type)}
          </Badge>
        </TableCell>
        <TableCell className={`font-medium ${account.balance && account.balance < 0 ? 'text-destructive' : ''}`}>
          {account.balance ? new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(account.balance) : '-'}
        </TableCell>
        <TableCell className="text-right">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex space-x-2 justify-end">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href={`/financial/account-statement?accountId=${account.id}`}>
                    <Button
                      variant="ghost"
                      size="icon"
                    >
                      <FileText className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{t("view_account_statement")}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href={`/financial/journal-entries?accountId=${account.id}`}>
                    <Button
                      variant="ghost"
                      size="icon"
                    >
                      <FileBarChart className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{t("view_journal_entries")}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleEditClick(account)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{t("edit_account")}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteAccount(account)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{t("delete_account")}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </TableCell>
      </TableRow>
    );
    
    // إنشاء مصفوفة النتائج
    const result: JSX.Element[] = [mainRow];
    
    // إضافة الصفوف الفرعية إذا كان الحساب مفتوحاً
    if (isExpanded && childAccounts?.length > 0) {
      childAccounts.forEach((child: ChartOfAccount) => {
        const childRows = renderAccountRow(child, level + 1);
        childRows.forEach(row => {
          result.push(row);
        });
      });
    }
    
    return result;
  };

  return (
    <div>
      <Card>
        <CardHeader>
          <CardTitle>{t("chart_of_accounts")}</CardTitle>
          <CardDescription>
            {t("chart_of_accounts_description")}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-6">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("code")}</TableHead>
                  <TableHead>{t("name_ar")}</TableHead>
                  <TableHead>{t("name_en")}</TableHead>
                  <TableHead>{t("type")}</TableHead>
                  <TableHead>{t("balance")}</TableHead>
                  <TableHead className="text-right">{t("actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rootAccounts?.map((account: ChartOfAccount) => renderAccountRow(account, 0)).flat()}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* مربع حوار تعديل الحساب */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t("edit_account")}</DialogTitle>
            <DialogDescription>
              {editAccount && `${editAccount.code} - ${editAccount.name}`}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                {t("name_ar")}
              </Label>
              <Input
                id="name"
                name="name"
                value={editFormData.name}
                onChange={handleEditInputChange}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="nameEn" className="text-right">
                {t("name_en")}
              </Label>
              <Input
                id="nameEn"
                name="nameEn"
                value={editFormData.nameEn}
                onChange={handleEditInputChange}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="description" className="text-right">
                {t("description")}
              </Label>
              <Input
                id="description"
                name="description"
                value={editFormData.description}
                onChange={handleEditInputChange}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" onClick={handleEditSubmit}>
              {t("save_changes")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// عرض جدول الحسابات حسب النوع
const AccountsByTypeTab = ({ type }: { type: string }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [editAccount, setEditAccount] = useState<ChartOfAccount | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editFormData, setEditFormData] = useState({
    name: "",
    nameEn: "",
    description: ""
  });

  const { data: accounts, isLoading } = useQuery({
    queryKey: ["/api/accounts", { type }],
    queryFn: async () => {
      const response = await fetch(`/api/accounts?type=${type}&withBalance=true`);
      if (!response.ok) {
        throw new Error(t("failed_to_fetch_accounts"));
      }
      return response.json();
    }
  });

  const handleEditClick = (account: ChartOfAccount) => {
    setEditAccount(account);
    setEditFormData({
      name: account.name,
      nameEn: account.nameEn || "",
      description: account.description || ""
    });
    setIsEditDialogOpen(true);
  };

  const handleEditInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleEditSubmit = async () => {
    if (!editAccount) return;

    try {
      await apiRequest("PATCH", `/api/accounts/${editAccount.id}`, editFormData);
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: t("success"),
        description: t("account_updated_successfully"),
      });
      setIsEditDialogOpen(false);
    } catch (error: any) {
      toast({
        title: t("error"),
        description: error.message || t("failed_to_update_account"),
        variant: "destructive",
      });
    }
  };

  const handleDeleteAccount = async (account: ChartOfAccount) => {
    if (window.confirm(t("confirm_delete_account"))) {
      try {
        await apiRequest("DELETE", `/api/accounts/${account.id}`);
        queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
        toast({
          title: t("success"),
          description: t("account_deleted_successfully"),
        });
      } catch (error: any) {
        toast({
          title: t("error"),
          description: error.message || t("failed_to_delete_account"),
          variant: "destructive",
        });
      }
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>{t(type)}</CardTitle>
          <CardDescription>
            {t(`${type}_accounts_description`)}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-6">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("code")}</TableHead>
                  <TableHead>{t("name_ar")}</TableHead>
                  <TableHead>{t("name_en")}</TableHead>
                  <TableHead>{t("parent_account")}</TableHead>
                  <TableHead>{t("balance")}</TableHead>
                  <TableHead className="text-right">{t("actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts?.map((account: ChartOfAccount) => (
                  <TableRow key={account.id} className="group hover:bg-muted/50">
                    <TableCell className="font-medium">{account.code}</TableCell>
                    <TableCell>{account.name}</TableCell>
                    <TableCell>{account.nameEn}</TableCell>
                    <TableCell>{account.parentId || '-'}</TableCell>
                    <TableCell className={`font-medium ${account.balance && account.balance < 0 ? 'text-destructive' : ''}`}>
                      {account.balance ? new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(account.balance) : '-'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity flex space-x-2 justify-end">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Link href={`/financial/account-statement?accountId=${account.id}`}>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                >
                                  <FileText className="h-4 w-4" />
                                </Button>
                              </Link>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{t("view_account_statement")}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Link href={`/financial/journal-entries?accountId=${account.id}`}>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                >
                                  <FileBarChart className="h-4 w-4" />
                                </Button>
                              </Link>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{t("view_journal_entries")}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEditClick(account)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{t("edit_account")}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteAccount(account)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{t("delete_account")}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* مربع حوار تعديل الحساب */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t("edit_account")}</DialogTitle>
            <DialogDescription>
              {editAccount && `${editAccount.code} - ${editAccount.name}`}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                {t("name_ar")}
              </Label>
              <Input
                id="name"
                name="name"
                value={editFormData.name}
                onChange={handleEditInputChange}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="nameEn" className="text-right">
                {t("name_en")}
              </Label>
              <Input
                id="nameEn"
                name="nameEn"
                value={editFormData.nameEn}
                onChange={handleEditInputChange}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="description" className="text-right">
                {t("description")}
              </Label>
              <Input
                id="description"
                name="description"
                value={editFormData.description}
                onChange={handleEditInputChange}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" onClick={handleEditSubmit}>
              {t("save_changes")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

// مكون لعرض بطاقات الإحصائيات
const AccountStats = () => {
  const { t } = useTranslation();
  
  // استدعاء API للحصول على إحصائيات الحسابات
  const { data: accountsData, isLoading } = useQuery({
    queryKey: ["/api/accounts", "stats"],
    queryFn: async () => {
      const response = await fetch("/api/accounts?withBalance=true");
      if (!response.ok) {
        throw new Error(t("failed_to_fetch_accounts"));
      }
      return response.json();
    }
  });
  
  // حساب الإحصائيات من البيانات المسترجعة
  const stats = useMemo(() => {
    if (!accountsData || !Array.isArray(accountsData)) {
      return {
        totalAccounts: 0,
        assetCount: 0,
        liabilityCount: 0,
        equityCount: 0,
        revenueCount: 0,
        expenseCount: 0,
        assetBalance: 0,
        liabilityBalance: 0,
        equityBalance: 0,
        revenueBalance: 0,
        expenseBalance: 0
      };
    }
    
    const typeCountMap: Record<string, number> = {
      asset: 0,
      liability: 0,
      equity: 0,
      revenue: 0,
      expense: 0
    };
    
    const typeBalanceMap: Record<string, number> = {
      asset: 0,
      liability: 0,
      equity: 0,
      revenue: 0,
      expense: 0
    };
    
    accountsData.forEach((account: ChartOfAccount) => {
      if (account.type in typeCountMap) {
        typeCountMap[account.type]++;
        if (account.balance) {
          typeBalanceMap[account.type] += account.balance;
        }
      }
    });
    
    return {
      totalAccounts: accountsData.length,
      assetCount: typeCountMap.asset,
      liabilityCount: typeCountMap.liability,
      equityCount: typeCountMap.equity,
      revenueCount: typeCountMap.revenue,
      expenseCount: typeCountMap.expense,
      assetBalance: typeBalanceMap.asset,
      liabilityBalance: typeBalanceMap.liability,
      equityBalance: typeBalanceMap.equity,
      revenueBalance: typeBalanceMap.revenue,
      expenseBalance: typeBalanceMap.expense
    };
  }, [accountsData]);
  
  // تم إزالة بيانات الرسم البياني
  
  // تصدير البيانات كملف Excel
  const exportToExcel = () => {
    if (!accountsData || !Array.isArray(accountsData)) return;
    
    const workbook = XLSX.utils.book_new();
    
    // تجهيز البيانات للتصدير
    const exportData = accountsData.map(account => ({
      [t("code")]: account.code,
      [t("name_ar")]: account.name,
      [t("name_en")]: account.nameEn,
      [t("type")]: t(account.type),
      [t("parent_account")]: account.parentId || "",
      [t("balance")]: account.balance || 0,
    }));
    
    // إنشاء ورقة عمل
    const worksheet = XLSX.utils.json_to_sheet(exportData);
    
    // إضافة ورقة العمل إلى الكتاب
    XLSX.utils.book_append_sheet(workbook, worksheet, t("chart_of_accounts"));
    
    // تصدير الكتاب كملف
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    // حفظ الملف
    saveAs(data, `${t("chart_of_accounts")}_${new Date().toLocaleDateString()}.xlsx`);
  };
  
  // تنسيق العملة
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(amount);
  };
  
  return (
    <div className="grid grid-cols-1 gap-6 mb-6">
      <div className="flex flex-col md:flex-row justify-between">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 flex-1 mb-4 md:mb-0">
          <Card className={`border-l-4 border-l-primary`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t("total_accounts")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="animate-pulse h-6 w-16 bg-muted rounded"></div>
              ) : (
                <div className="text-2xl font-bold">{stats.totalAccounts}</div>
              )}
            </CardContent>
          </Card>
          
          <Card className={`border-l-4 border-l-blue-500`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t("asset")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="animate-pulse h-6 w-24 bg-muted rounded"></div>
              ) : (
                <div>
                  <div className="text-2xl font-bold">{stats.assetCount}</div>
                  <div className="text-sm text-muted-foreground">{formatCurrency(stats.assetBalance)}</div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className={`border-l-4 border-l-red-500`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t("liability")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="animate-pulse h-6 w-24 bg-muted rounded"></div>
              ) : (
                <div>
                  <div className="text-2xl font-bold">{stats.liabilityCount}</div>
                  <div className="text-sm text-muted-foreground">{formatCurrency(stats.liabilityBalance)}</div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className={`border-l-4 border-l-purple-500`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t("equity")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="animate-pulse h-6 w-24 bg-muted rounded"></div>
              ) : (
                <div>
                  <div className="text-2xl font-bold">{stats.equityCount}</div>
                  <div className="text-sm text-muted-foreground">{formatCurrency(stats.equityBalance)}</div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className={`border-l-4 border-l-green-500`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t("revenue")}/{t("expense")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="animate-pulse h-6 w-24 bg-muted rounded"></div>
              ) : (
                <div>
                  <div className="text-2xl font-bold">{stats.revenueCount + stats.expenseCount}</div>
                  <div className="text-sm text-muted-foreground">
                    {formatCurrency(stats.revenueBalance - stats.expenseBalance)}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="md:ml-4 flex flex-col items-end">
          <Button 
            variant="outline" 
            onClick={exportToExcel} 
            className="mb-2 w-full md:w-auto"
            disabled={isLoading || !accountsData}
          >
            <Download className="mr-2 h-4 w-4" />
            {t("export_to_excel")}
          </Button>
        </div>
      </div>
      

    </div>
  );
};

// صفحة شجرة الحسابات الرئيسية
const AccountsPage = () => {
  const { t } = useTranslation();

  return (
    <div className="container mx-auto py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">{t("chart_of_accounts")}</h1>
        <p className="text-muted-foreground mt-2">
          {t("chart_of_accounts_page_description")}
        </p>
        <Separator className="my-4" />
      </div>
      
      <AccountStats />
      
      <AccountsToolbar />

      <Tabs defaultValue="tree" className="mb-8">
        <TabsList>
          <TabsTrigger value="tree">{t("tree_view")}</TabsTrigger>
          <TabsTrigger value="assets">{t("assets")}</TabsTrigger>
          <TabsTrigger value="liabilities">{t("liabilities")}</TabsTrigger>
          <TabsTrigger value="equity">{t("equity")}</TabsTrigger>
          <TabsTrigger value="revenue">{t("revenue")}</TabsTrigger>
          <TabsTrigger value="expenses">{t("expenses")}</TabsTrigger>
        </TabsList>
        <TabsContent value="tree">
          <div className="tab-content-wrapper">
            {/* لاحظ أننا قمنا بإزالة مكوّن AccountTree بشكل مؤقت حتى يتم إصلاحه بشكل صحيح */}
            <Card>
              <CardHeader>
                <CardTitle>{t("chart_of_accounts")}</CardTitle>
                <CardDescription>
                  {t("chart_of_accounts_description")}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <h3 className="text-lg font-medium">{t("tree_view_coming_soon")}</h3>
                  <p className="text-muted-foreground mt-2">{t("tree_view_description")}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="assets">
          <AccountsByTypeTab type="asset" />
        </TabsContent>
        <TabsContent value="liabilities">
          <AccountsByTypeTab type="liability" />
        </TabsContent>
        <TabsContent value="equity">
          <AccountsByTypeTab type="equity" />
        </TabsContent>
        <TabsContent value="revenue">
          <AccountsByTypeTab type="revenue" />
        </TabsContent>
        <TabsContent value="expenses">
          <AccountsByTypeTab type="expense" />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AccountsPage;