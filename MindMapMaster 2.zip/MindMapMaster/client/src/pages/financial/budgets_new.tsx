import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Search, Plus, Edit, Trash2, CalendarIcon } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ProjectBudget, Project } from "@shared/schema";
import { Label } from "@/components/ui/label";

// مكون لعرض القيمة المالية
const CurrencyDisplay = ({ value, positive = false }: { value: number, positive?: boolean }) => {
  return (
    <span className={`font-medium ${positive ? "text-green-600" : ""}`}>
      {new Intl.NumberFormat("ar-SA", {
        style: "currency",
        currency: "SAR",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(value)}
    </span>
  );
};

// مكون مربع حوار إنشاء ميزانية جديدة
const NewBudgetDialog = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    projectId: 0,
    fiscalYear: new Date().getFullYear(),
    fiscalQuarter: 1,
    plannedAmount: 0,
    actualAmount: 0,
    notes: "",
  });

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
    enabled: isOpen
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (name === "plannedAmount" || name === "actualAmount") {
      setFormData(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSelectChange = (name: string, value: string) => {
    if (name === "projectId") {
      setFormData(prev => ({ ...prev, [name]: parseInt(value) }));
    } else if (name === "fiscalYear" || name === "fiscalQuarter") {
      setFormData(prev => ({ ...prev, [name]: parseInt(value) }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async () => {
    try {
      await apiRequest("POST", "/api/budgets", formData);
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      toast({
        title: t("success"),
        description: t("budget_created_successfully"),
      });
      setIsOpen(false);
      setFormData({
        projectId: 0,
        fiscalYear: new Date().getFullYear(),
        fiscalQuarter: 1,
        plannedAmount: 0,
        actualAmount: 0,
        notes: "",
      });
    } catch (error: any) {
      toast({
        title: t("error"),
        description: error.message || t("failed_to_create_budget"),
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="ml-4">
          <Plus className="mr-2 h-4 w-4" />
          {t("new_budget")}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{t("create_new_budget")}</DialogTitle>
          <DialogDescription>
            {t("enter_budget_details_below")}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="projectId" className="text-right">
              {t("project")}
            </Label>
            <Select
              name="projectId"
              value={formData.projectId.toString()}
              onValueChange={value => handleSelectChange("projectId", value)}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder={t("select_project")} />
              </SelectTrigger>
              <SelectContent>
                {projects?.map((project: Project) => (
                  <SelectItem key={project.id} value={project.id.toString()}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="fiscalYear" className="text-right">
              {t("fiscal_year")}
            </Label>
            <Select
              name="fiscalYear"
              value={formData.fiscalYear.toString()}
              onValueChange={value => handleSelectChange("fiscalYear", value)}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder={t("select_year")} />
              </SelectTrigger>
              <SelectContent>
                {[2023, 2024, 2025, 2026, 2027].map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="fiscalQuarter" className="text-right">
              {t("fiscal_quarter")}
            </Label>
            <Select
              name="fiscalQuarter"
              value={formData.fiscalQuarter.toString()}
              onValueChange={value => handleSelectChange("fiscalQuarter", value)}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder={t("select_quarter")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Q1</SelectItem>
                <SelectItem value="2">Q2</SelectItem>
                <SelectItem value="3">Q3</SelectItem>
                <SelectItem value="4">Q4</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="plannedAmount" className="text-right">
              {t("budget_amount")}
            </Label>
            <Input
              id="plannedAmount"
              name="plannedAmount"
              type="number"
              value={formData.plannedAmount}
              onChange={handleInputChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="actualAmount" className="text-right">
              {t("actual_amount")}
            </Label>
            <Input
              id="actualAmount"
              name="actualAmount"
              type="number"
              value={formData.actualAmount}
              onChange={handleInputChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="notes" className="text-right">
              {t("notes")}
            </Label>
            <Input
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleSubmit}>
            {t("create")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// مكون تحرير الميزانية
const EditBudgetDialog = ({ budget, onClose }: { budget: ProjectBudget, onClose: () => void }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    plannedAmount: budget.plannedAmount,
    actualAmount: budget.actualAmount,
    notes: budget.notes || "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (name === "plannedAmount" || name === "actualAmount") {
      setFormData(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async () => {
    try {
      await apiRequest("PATCH", `/api/budgets/${budget.id}`, formData);
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      toast({
        title: t("success"),
        description: t("budget_updated_successfully"),
      });
      onClose();
    } catch (error: any) {
      toast({
        title: t("error"),
        description: error.message || t("failed_to_update_budget"),
        variant: "destructive",
      });
    }
  };

  return (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>{t("edit_budget")}</DialogTitle>
        <DialogDescription>
          {t("edit_budget_details")}
        </DialogDescription>
      </DialogHeader>
      <div className="grid gap-4 py-4">
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="plannedAmount" className="text-right">
            {t("budget_amount")}
          </Label>
          <Input
            id="plannedAmount"
            name="plannedAmount"
            type="number"
            value={formData.plannedAmount}
            onChange={handleInputChange}
            className="col-span-3"
          />
        </div>
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="actualAmount" className="text-right">
            {t("actual_amount")}
          </Label>
          <Input
            id="actualAmount"
            name="actualAmount"
            type="number"
            value={formData.actualAmount}
            onChange={handleInputChange}
            className="col-span-3"
          />
        </div>
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="notes" className="text-right">
            {t("notes")}
          </Label>
          <Input
            id="notes"
            name="notes"
            value={formData.notes}
            onChange={handleInputChange}
            className="col-span-3"
          />
        </div>
      </div>
      <DialogFooter>
        <Button type="submit" onClick={handleSubmit}>
          {t("save_changes")}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
};

// شريط أدوات البحث والفرز
const BudgetsToolbar = ({ 
  onProjectChange,
  onYearChange
}: { 
  onProjectChange: (projectId: number | null) => void, 
  onYearChange: (year: number | null) => void 
}) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  return (
    <div className="flex flex-col sm:flex-row justify-between space-y-4 sm:space-y-0 sm:space-x-4 mb-6">
      <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder={t("search_budgets")}
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select onValueChange={(value) => onProjectChange(value === "all" ? null : parseInt(value))}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={t("select_project")} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("all_projects")}</SelectItem>
            {projects?.map((project: Project) => (
              <SelectItem key={project.id} value={project.id.toString()}>
                {project.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select onValueChange={(value) => onYearChange(value === "all" ? null : parseInt(value))}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={t("select_year")} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("all_years")}</SelectItem>
            {[2023, 2024, 2025, 2026, 2027].map(year => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <NewBudgetDialog />
    </div>
  );
};

// مكون عرض الميزانيات
const BudgetsTable = ({ 
  projectId, 
  fiscalYear 
}: { 
  projectId: number | null, 
  fiscalYear: number | null
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedBudget, setSelectedBudget] = useState<ProjectBudget | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // بناء عنوان الاستعلام للتصفية
  let queryPath = "/api/budgets";
  let queryParams = {};
  
  if (projectId) {
    queryParams = { ...queryParams, projectId };
  }
  
  if (fiscalYear) {
    queryParams = { ...queryParams, year: fiscalYear };
  }

  const { data: budgets, isLoading } = useQuery({
    queryKey: [queryPath, queryParams],
    queryFn: async () => {
      let url = queryPath;
      const params = new URLSearchParams();
      
      if (projectId) {
        params.append("projectId", projectId.toString());
      }
      
      if (fiscalYear) {
        params.append("year", fiscalYear.toString());
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(t("failed_to_fetch_budgets"));
      }
      return response.json();
    }
  });

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  // الحصول على اسم المشروع من معرفه
  const getProjectName = (projectId: number) => {
    const project = projects?.find((p: Project) => p.id === projectId);
    return project ? project.name : t("unknown_project");
  };

  const handleEditClick = (budget: ProjectBudget) => {
    setSelectedBudget(budget);
    setIsEditDialogOpen(true);
  };

  const handleDeleteBudget = async (budget: ProjectBudget) => {
    if (window.confirm(t("confirm_delete_budget"))) {
      try {
        await apiRequest("DELETE", `/api/budgets/${budget.id}`);
        queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
        toast({
          title: t("success"),
          description: t("budget_deleted_successfully"),
        });
      } catch (error: any) {
        toast({
          title: t("error"),
          description: error.message || t("failed_to_delete_budget"),
          variant: "destructive",
        });
      }
    }
  };

  // حساب نسبة الإنجاز من الميزانية
  const calculatePercentage = (budget: ProjectBudget) => {
    if (budget.plannedAmount === 0) return 0;
    const actualAmount = budget.actualAmount || 0;
    return Math.min(100, Math.round((actualAmount / budget.plannedAmount) * 100));
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>{t("project_budgets")}</CardTitle>
          <CardDescription>
            {t("project_budgets_description")}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-6">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("project")}</TableHead>
                  <TableHead>{t("fiscal_period")}</TableHead>
                  <TableHead className="text-right">{t("budget_amount")}</TableHead>
                  <TableHead className="text-right">{t("actual_amount")}</TableHead>
                  <TableHead className="text-right">{t("variance")}</TableHead>
                  <TableHead>{t("completion")}</TableHead>
                  <TableHead className="text-right">{t("actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {budgets?.map((budget: ProjectBudget) => (
                  <TableRow key={budget.id} className="group hover:bg-muted/50">
                    <TableCell className="font-medium">
                      {getProjectName(budget.projectId)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                        <span>{budget.fiscalYear} - Q{budget.fiscalQuarter}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <CurrencyDisplay value={budget.plannedAmount} />
                    </TableCell>
                    <TableCell className="text-right">
                      <CurrencyDisplay value={budget.actualAmount || 0} />
                    </TableCell>
                    <TableCell className="text-right">
                      <CurrencyDisplay 
                        value={budget.plannedAmount - (budget.actualAmount || 0)} 
                        positive={budget.plannedAmount >= (budget.actualAmount || 0)} 
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div
                            className={`h-2.5 rounded-full ${
                              calculatePercentage(budget) > 90
                                ? "bg-green-600"
                                : calculatePercentage(budget) > 65
                                ? "bg-yellow-500"
                                : "bg-primary"
                            }`}
                            style={{ width: `${calculatePercentage(budget)}%` }}
                          ></div>
                        </div>
                        <span className="ml-2 text-xs">{calculatePercentage(budget)}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity flex space-x-2 justify-end">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditClick(budget)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteBudget(budget)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* مربع حوار تعديل الميزانية */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        {selectedBudget && (
          <EditBudgetDialog 
            budget={selectedBudget} 
            onClose={() => setIsEditDialogOpen(false)} 
          />
        )}
      </Dialog>
    </>
  );
};

// مكون مخطط الميزانية
const BudgetChart = ({ 
  projectId,
  fiscalYear 
}: { 
  projectId: number | null,
  fiscalYear: number | null
}) => {
  const { t } = useTranslation();

  // بناء عنوان الاستعلام للتصفية
  let queryPath = "/api/budgets";
  let queryParams = {};
  
  if (projectId) {
    queryParams = { ...queryParams, projectId };
  }
  
  if (fiscalYear) {
    queryParams = { ...queryParams, year: fiscalYear };
  }

  const { data: budgets, isLoading } = useQuery({
    queryKey: [queryPath, queryParams],
    queryFn: async () => {
      let url = queryPath;
      const params = new URLSearchParams();
      
      if (projectId) {
        params.append("projectId", projectId.toString());
      }
      
      if (fiscalYear) {
        params.append("year", fiscalYear.toString());
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(t("failed_to_fetch_budgets"));
      }
      return response.json();
    }
  });

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  // تحويل البيانات للرسم البياني
  const chartData = budgets?.map((budget: ProjectBudget) => {
    const project = projects?.find((p: Project) => p.id === budget.projectId);
    const projectName = project ? project.name : t("unknown_project");
    
    return {
      name: `${projectName} (${budget.fiscalYear}-Q${budget.fiscalQuarter})`,
      المخطط: budget.plannedAmount,
      الفعلي: budget.actualAmount || 0,
    };
  });

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>{t("budget_comparison")}</CardTitle>
        <CardDescription>
          {t("budget_comparison_description")}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center p-6">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : chartData?.length ? (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart
              data={chartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 130
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip formatter={(value) => new Intl.NumberFormat("ar-SA", {
                style: "currency",
                currency: "SAR",
                minimumFractionDigits: 0,
                maximumFractionDigits: 0,
              }).format(value as number)} />
              <Legend />
              <Bar dataKey="المخطط" fill="#8884d8" />
              <Bar dataKey="الفعلي" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex justify-center items-center h-[400px] text-muted-foreground">
            {t("no_budget_data_available")}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// صفحة الميزانيات الرئيسية
const BudgetsPage = () => {
  const { t } = useTranslation();
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [selectedYear, setSelectedYear] = useState<number | null>(null);

  return (
    <div className="container mx-auto py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">{t("project_budgets")}</h1>
        <p className="text-muted-foreground mt-2">
          {t("project_budgets_page_description")}
        </p>
        <Separator className="my-4" />
      </div>

      <BudgetsToolbar 
        onProjectChange={setSelectedProjectId} 
        onYearChange={setSelectedYear} 
      />

      <BudgetsTable 
        projectId={selectedProjectId} 
        fiscalYear={selectedYear} 
      />

      <BudgetChart 
        projectId={selectedProjectId} 
        fiscalYear={selectedYear} 
      />
    </div>
  );
};

export default BudgetsPage;