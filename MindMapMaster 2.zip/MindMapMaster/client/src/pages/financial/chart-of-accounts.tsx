import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ChevronRightIcon,
  ChevronDownIcon,
  FolderIcon,
  FolderOpenIcon,
  PlusIcon,
  EditIcon,
  TrashIcon,
  ArrowUpIcon,
  FileIcon,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ChartOfAccount, financialAccountTypeMap } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import SarSymbol from "@/components/ui/sar-symbol";

// مكون لعنصر واحد في شجرة الحسابات
interface AccountNodeProps {
  account: ChartOfAccount;
  level: number;
  expanded: Record<number, boolean>;
  toggleExpand: (id: number) => void;
  children: ChartOfAccount[];
  onEdit: (account: ChartOfAccount) => void;
  onDelete: (id: number) => void;
  onAddChild: (parentId: number) => void;
}

const AccountNode = ({
  account,
  level,
  expanded,
  toggleExpand,
  children,
  onEdit,
  onDelete,
  onAddChild,
}: AccountNodeProps) => {
  const { t, i18n } = useTranslation();
  const hasChildren = children.length > 0;
  const isExpanded = expanded[account.id] || false;
  const paddingLeft = level * 20;

  return (
    <>
      <TableRow className="hover:bg-muted/50">
        <TableCell className="p-2">
          <div
            className="flex items-center cursor-pointer"
            style={{ paddingLeft: `${paddingLeft}px` }}
            onClick={() => hasChildren && toggleExpand(account.id)}
          >
            {hasChildren ? (
              <>
                {isExpanded ? <ChevronDownIcon size={16} /> : <ChevronRightIcon size={16} />}
                {isExpanded ? <FolderOpenIcon size={16} className="mr-2" /> : <FolderIcon size={16} className="mr-2" />}
              </>
            ) : (
              <>
                <span className="w-4" />
                <FileIcon size={16} className="mr-2" />
              </>
            )}
            <span className="font-medium">
              {account.code} - {i18n.language === "ar" ? account.name : account.nameEn || account.name}
            </span>
          </div>
        </TableCell>
        <TableCell>
          <Badge variant="outline">
            {i18n.language === "ar"
              ? financialAccountTypeMap[account.type].ar
              : financialAccountTypeMap[account.type].en}
          </Badge>
        </TableCell>
        <TableCell className="text-right">
          <div className="flex justify-end space-x-2 rtl:space-x-reverse">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onAddChild(account.id)}
              title={t("financial.accounts.addChild")}
            >
              <PlusIcon size={16} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit(account)}
              title={t("financial.accounts.edit")}
            >
              <EditIcon size={16} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(account.id)}
              title={t("financial.accounts.delete")}
              disabled={hasChildren}
            >
              <TrashIcon size={16} />
            </Button>
          </div>
        </TableCell>
      </TableRow>

      {isExpanded &&
        children.map((child) => (
          <AccountNodeWithChildren
            key={child.id}
            account={child}
            level={level + 1}
            expanded={expanded}
            toggleExpand={toggleExpand}
            onEdit={onEdit}
            onDelete={onDelete}
            onAddChild={onAddChild}
          />
        ))}
    </>
  );
};

// Higher-order component to fetch and pass children to AccountNode
const AccountNodeWithChildren = (props: Omit<AccountNodeProps, "children">) => {
  const { data: accounts = [] } = useQuery<ChartOfAccount[]>({
    queryKey: ["/api/chart-of-accounts"],
  });

  const children = accounts.filter((item) => item.parentId === props.account.id);

  return <AccountNode {...props} children={children} />;
};

export default function ChartOfAccounts() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  const [selectedAccount, setSelectedAccount] = useState<ChartOfAccount | null>(null);

  // جلب بيانات شجرة الحسابات
  const { data: accounts = [], isLoading } = useQuery<ChartOfAccount[]>({
    queryKey: ["/api/chart-of-accounts"],
  });

  // الحسابات الرئيسية (مستوى أول - ليس لها آباء)
  const rootAccounts = accounts.filter((account) => !account.parentId);

  // توسيع/طي العنصر في الشجرة
  const toggleExpand = (id: number) => {
    setExpanded((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // فتح نافذة تحرير الحساب
  const handleEdit = (account: ChartOfAccount) => {
    setSelectedAccount(account);
    // هنا يمكن فتح مودال للتحرير
  };

  // حذف حساب
  const deleteAccountMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/chart-of-accounts/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chart-of-accounts"] });
      toast({
        title: t("financial.accounts.deleteSuccess"),
        description: t("financial.accounts.deleteSuccessMessage"),
      });
    },
    onError: (error: any) => {
      toast({
        title: t("financial.accounts.deleteError"),
        description: error.message || t("financial.accounts.deleteErrorMessage"),
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: number) => {
    // هنا يمكن طلب تأكيد قبل الحذف
    deleteAccountMutation.mutate(id);
  };

  // إضافة حساب فرعي
  const handleAddChild = (parentId: number) => {
    // هنا يمكن فتح مودال لإضافة حساب فرعي جديد
    const parent = accounts.find((a) => a.id === parentId);
    if (parent) {
      setExpanded((prev) => ({
        ...prev,
        [parentId]: true, // توسيع الأب تلقائيًا عند إضافة حساب فرعي
      }));
    }
  };

  // إضافة حساب رئيسي جديد
  const handleAddRootAccount = () => {
    // هنا يمكن فتح مودال لإضافة حساب رئيسي جديد
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label={t("common.loading")}/>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">{t("financial.accounts.title")}</h1>
        <Button onClick={handleAddRootAccount}>
          <PlusIcon className="mr-2 h-4 w-4" />
          {t("financial.accounts.addRoot")}
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>{t("financial.accounts.structure")}</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("financial.accounts.accountName")}</TableHead>
                <TableHead>{t("financial.accounts.type")}</TableHead>
                <TableHead className="text-right">{t("common.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rootAccounts.map((account) => (
                <AccountNodeWithChildren
                  key={account.id}
                  account={account}
                  level={0}
                  expanded={expanded}
                  toggleExpand={toggleExpand}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                  onAddChild={handleAddChild}
                />
              ))}
              {rootAccounts.length === 0 && (
                <TableRow>
                  <TableCell colSpan={3} className="text-center py-6 text-muted-foreground">
                    {t("financial.accounts.empty")}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* يمكن إضافة مكونات المودال هنا لإضافة/تحرير الحسابات */}
    </div>
  );
}