import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

/**
 * الطباعة مباشرة من قسم محدد في صفحة
 * هذه الدالة تقوم بإنشاء صفحة طباعة مخصصة تحتوي فقط على المحتوى المحدد
 */
export const printDocument = async (
  sectionRef: React.RefObject<HTMLElement>,
  reportTitle: string = ''
): Promise<void> => {
  if (!sectionRef.current) return;
  
  try {
    // إنشاء وثيقة PDF
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // ضبط إعدادات النص العربي
    doc.setFont('Helvetica', 'normal');
    doc.setR2L(true);
    
    // إضافة العنوان في أعلى الصفحة
    if (reportTitle) {
      doc.setFontSize(18);
      doc.text(reportTitle, doc.internal.pageSize.width / 2, 15, { align: 'center' });
    }
    
    // إضافة التاريخ
    const currentDate = new Date().toLocaleDateString('ar-SA');
    doc.setFontSize(10);
    doc.text(`تاريخ الطباعة: ${currentDate}`, doc.internal.pageSize.width - 15, 10, { align: 'right' });
    
    // تحويل القسم إلى صورة canvas
    const canvas = await html2canvas(sectionRef.current, {
      scale: 1.5,
      logging: false,
      useCORS: true
    });
    
    // حساب أبعاد الصورة للطباعة
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;
    const imgWidth = pageWidth - 20; // هوامش
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    // إضافة الصورة إلى وثيقة PDF
    if (imgHeight > pageHeight - 40) {
      // تقسيم الصورة على عدة صفحات إذا كانت طويلة
      let heightLeft = imgHeight;
      let position = 0;
      let pageNumber = 1;
      
      // الصفحة الأولى
      doc.addImage(
        canvas.toDataURL('image/jpeg', 0.7),
        'JPEG',
        10,
        25, // بدء بعد العنوان
        imgWidth,
        Math.min(imgHeight, pageHeight - 35) // ترك مساحة للعنوان والتذييل
      );
      
      heightLeft -= (pageHeight - 35);
      position = -(pageHeight - 35);
      
      // إضافة صفحات إضافية عند الحاجة
      while (heightLeft > 0) {
        doc.addPage();
        pageNumber++;
        position -= (pageHeight - 25); // هامش أقل في الصفحات التالية
        
        doc.addImage(
          canvas.toDataURL('image/jpeg', 0.7),
          'JPEG',
          10,
          position,
          imgWidth,
          imgHeight
        );
        
        heightLeft -= (pageHeight - 25);
      }
      
      // عدد الصفحات الإجمالي
      const pagesCount = pageNumber;
      
      // إضافة أرقام الصفحات وتذييل
      for (let i = 1; i <= pagesCount; i++) {
        doc.setPage(i);
        doc.setFontSize(10);
        
        // التذييل
        doc.text(
          "تم إنشاء هذا التقرير بواسطة نظام إدارة مشاريع البنية التحتية",
          pageWidth / 2,
          pageHeight - 15,
          { align: 'center' }
        );
        
        // رقم الصفحة
        doc.text(
          `صفحة ${i} من ${pagesCount}`,
          pageWidth / 2,
          pageHeight - 10,
          { align: 'center' }
        );
      }
    } else {
      // صورة تناسب صفحة واحدة
      doc.addImage(
        canvas.toDataURL('image/jpeg', 0.7),
        'JPEG',
        10,
        25,
        imgWidth,
        imgHeight
      );
      
      // التذييل
      doc.setFontSize(10);
      doc.text(
        "تم إنشاء هذا التقرير بواسطة نظام إدارة مشاريع البنية التحتية",
        pageWidth / 2,
        pageHeight - 15,
        { align: 'center' }
      );
      
      // رقم الصفحة
      doc.text(
        "صفحة 1 من 1",
        pageWidth / 2,
        pageHeight - 10,
        { align: 'center' }
      );
    }
    
    // طباعة الوثيقة
    window.open(URL.createObjectURL(doc.output('blob')));
  } catch (error) {
    console.error('Error printing document:', error);
  }
};