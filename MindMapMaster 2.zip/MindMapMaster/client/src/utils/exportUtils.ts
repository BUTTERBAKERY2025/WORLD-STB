import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

/**
 * تصدير جدول HTML إلى ملف PDF
 */
export const exportTableToPDF = async (
  tableRef: HTMLElement,
  fileName: string = 'exported-table',
  reportTitle: string = '',
  subtitle: string = ''
): Promise<void> => {
  // إنشاء وثيقة PDF بحجم A4 واتجاه أفقي
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  // ضبط إعدادات النص العربي
  doc.setFont('Helvetica', 'normal');
  doc.setR2L(true);

  // إضافة معلومات الرأس
  if (reportTitle) {
    doc.setFontSize(18);
    doc.text(reportTitle, doc.internal.pageSize.width / 2, 15, { align: 'center' });
  }

  if (subtitle) {
    doc.setFontSize(12);
    doc.text(subtitle, doc.internal.pageSize.width / 2, 25, { align: 'center' });
  }

  // إضافة التاريخ
  const currentDate = new Date().toLocaleDateString('ar-SA');
  doc.setFontSize(10);
  doc.text(`تاريخ التصدير: ${currentDate}`, doc.internal.pageSize.width - 15, 10, { align: 'right' });

  // تحويل الجدول إلى صورة canvas
  const canvas = await html2canvas(tableRef, {
    scale: 2, // تحسين الجودة
    logging: false,
    useCORS: true
  });

  // إضافة الصورة إلى وثيقة PDF
  const imgData = canvas.toDataURL('image/png');
  const imgWidth = doc.internal.pageSize.width - 30; // هوامش
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  // ضمان أن الصورة تناسب الصفحة
  if (imgHeight > doc.internal.pageSize.height - 40) {
    // إذا كانت الصورة أطول من الصفحة، قم بتنسيقها للمواءمة
    const ratio = (doc.internal.pageSize.height - 40) / imgHeight;
    doc.addImage(imgData, 'PNG', 15, 30, imgWidth * ratio, imgHeight * ratio);
  } else {
    doc.addImage(imgData, 'PNG', 15, 30, imgWidth, imgHeight);
  }

  // إضافة أرقام الصفحات
  const pageCount = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(10);
    doc.text(`صفحة ${i} من ${pageCount}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, {
      align: 'center'
    });
  }

  // حفظ الملف
  doc.save(`${fileName}.pdf`);
};

/**
 * تصدير بيانات JSON إلى ملف PDF
 */
export const exportDataToPDF = (
  data: any[],
  headers: { header: string; dataKey: string }[],
  fileName: string = 'exported-data',
  reportTitle: string = '',
  subtitle: string = ''
): void => {
  // إنشاء وثيقة PDF بحجم A4 واتجاه أفقي
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  // ضبط إعدادات النص العربي
  doc.setFont('Helvetica', 'normal');
  doc.setR2L(true);

  // إضافة معلومات الرأس
  if (reportTitle) {
    doc.setFontSize(18);
    doc.text(reportTitle, doc.internal.pageSize.width / 2, 15, { align: 'center' });
  }

  if (subtitle) {
    doc.setFontSize(12);
    doc.text(subtitle, doc.internal.pageSize.width / 2, 25, { align: 'center' });
  }

  // إضافة التاريخ
  const currentDate = new Date().toLocaleDateString('ar-SA');
  doc.setFontSize(10);
  doc.text(`تاريخ التصدير: ${currentDate}`, doc.internal.pageSize.width - 15, 10, { align: 'right' });

  // تحضير البيانات لجدول jspdf-autotable
  const tableHeaders = headers.map(h => h.header);
  const tableData = data.map(row => 
    headers.map(header => {
      const value = row[header.dataKey];
      
      // معالجة التواريخ
      if (header.dataKey.toLowerCase().includes('date') && value) {
        try {
          if (typeof value === 'string') {
            return new Date(value).toLocaleDateString('ar-SA');
          } else if (value instanceof Date) {
            return value.toLocaleDateString('ar-SA');
          }
        } catch (e) {
          // إذا فشل تنسيق التاريخ، أعد القيمة الأصلية
        }
      }
      
      // معالجة الأرقام والمبالغ المالية
      if (typeof value === 'number') {
        // التحقق مما إذا كان العنوان يشير إلى مبلغ مالي
        if (
          header.dataKey.toLowerCase().includes('amount') || 
          header.dataKey.toLowerCase().includes('balance') ||
          header.dataKey.toLowerCase().includes('total') ||
          header.dataKey.toLowerCase().includes('price') ||
          header.dataKey.toLowerCase().includes('debit') ||
          header.dataKey.toLowerCase().includes('credit')
        ) {
          return `${value.toLocaleString('ar-SA')} ريال`;
        }
        return value.toLocaleString('ar-SA');
      }
      
      return value || '-';
    })
  );

  // إنشاء الجدول في وثيقة PDF
  autoTable(doc, {
    head: [tableHeaders],
    body: tableData,
    startY: 35,
    styles: {
      font: 'Helvetica',
      fontSize: 10,
      overflow: 'linebreak',
      cellPadding: 3,
    },
    headStyles: {
      fillColor: [41, 128, 185],
      textColor: 255,
      fontStyle: 'bold',
      halign: 'center',
    },
    alternateRowStyles: {
      fillColor: [240, 240, 240],
    },
    margin: { top: 35 },
    theme: 'grid',
  });

  // إضافة أرقام الصفحات
  const pageCount = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(10);
    doc.text(`صفحة ${i} من ${pageCount}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, {
      align: 'center'
    });
  }

  // حفظ الملف
  doc.save(`${fileName}.pdf`);
};

/**
 * تصدير بيانات إلى ملف Excel
 */
export const exportToExcel = (
  data: any[],
  headers: { header: string; dataKey: string }[],
  fileName: string = 'exported-data'
): void => {
  // تنسيق البيانات للتصدير
  const exportData = data.map(item => {
    const rowData: Record<string, any> = {};
    headers.forEach(header => {
      const value = item[header.dataKey];
      
      // التحقق مما إذا كانت القيمة تاريخًا وتنسيقها
      if (header.dataKey.toLowerCase().includes('date') && value) {
        try {
          if (typeof value === 'string') {
            rowData[header.header] = new Date(value).toLocaleDateString('ar-SA');
          } else if (value instanceof Date) {
            rowData[header.header] = value.toLocaleDateString('ar-SA');
          } else {
            rowData[header.header] = value;
          }
        } catch (e) {
          rowData[header.header] = value;
        }
      } else {
        rowData[header.header] = value;
      }
    });
    return rowData;
  });

  // إنشاء ورقة عمل
  const worksheet = XLSX.utils.json_to_sheet(exportData);

  // ضبط عرض الأعمدة
  const columnWidths = headers.map(header => ({ wch: Math.max(header.header.length * 1.5, 10) }));
  worksheet['!cols'] = columnWidths;

  // إنشاء مصنف عمل
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'البيانات');

  // تصدير الملف
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  saveAs(blob, `${fileName}.xlsx`);
};

/**
 * تصدير مخطط إلى ملف PDF
 */
export const exportChartToPDF = async (
  chartRef: HTMLElement,
  fileName: string = 'exported-chart',
  reportTitle: string = '',
  subtitle: string = ''
): Promise<void> => {
  // إنشاء وثيقة PDF بحجم A4 واتجاه أفقي
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  // ضبط إعدادات النص العربي
  doc.setFont('Helvetica', 'normal');
  doc.setR2L(true);

  // إضافة معلومات الرأس
  if (reportTitle) {
    doc.setFontSize(18);
    doc.text(reportTitle, doc.internal.pageSize.width / 2, 15, { align: 'center' });
  }

  if (subtitle) {
    doc.setFontSize(12);
    doc.text(subtitle, doc.internal.pageSize.width / 2, 25, { align: 'center' });
  }

  // إضافة التاريخ
  const currentDate = new Date().toLocaleDateString('ar-SA');
  doc.setFontSize(10);
  doc.text(`تاريخ التصدير: ${currentDate}`, doc.internal.pageSize.width - 15, 10, { align: 'right' });

  // تحويل المخطط إلى صورة canvas
  const canvas = await html2canvas(chartRef, {
    scale: 2, // تحسين الجودة
    logging: false,
    useCORS: true
  });

  // إضافة الصورة إلى وثيقة PDF
  const imgData = canvas.toDataURL('image/png');
  const imgWidth = doc.internal.pageSize.width - 30; // هوامش
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  doc.addImage(imgData, 'PNG', 15, 30, imgWidth, imgHeight);

  // إضافة أرقام الصفحات
  doc.setFontSize(10);
  doc.text('صفحة 1 من 1', doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, {
    align: 'center'
  });

  // حفظ الملف
  doc.save(`${fileName}.pdf`);
};

/**
 * تصدير صفحة كاملة إلى ملف PDF
 */
export const exportPageToPDF = async (
  pageRef: HTMLElement,
  fileName: string = 'exported-page',
  reportTitle: string = ''
): Promise<void> => {
  // إنشاء وثيقة PDF بحجم A4 واتجاه أفقي
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  // ضبط إعدادات النص العربي
  doc.setFont('Helvetica', 'normal');
  doc.setR2L(true);

  // تحويل الصفحة إلى صورة canvas
  const canvas = await html2canvas(pageRef, {
    scale: 1.5, // تحسين الجودة
    logging: false,
    useCORS: true,
    windowWidth: pageRef.scrollWidth,
    windowHeight: pageRef.scrollHeight
  });

  // الحصول على نسبة أبعاد الصفحة
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;
  
  // حساب عدد الصفحات المطلوبة
  const imgWidth = pageWidth - 20; // هوامش
  const imgHeight = (canvas.height * imgWidth) / canvas.width;
  const pagesCount = Math.ceil(imgHeight / (pageHeight - 20));
  
  // إذا كانت الصفحة كبيرة، قم بتقسيمها إلى عدة صفحات
  let heightLeft = imgHeight;
  let position = 0;
  let pageNumber = 1;
  
  // إضافة العنوان والتاريخ إلى الصفحة الأولى
  if (reportTitle) {
    doc.setFontSize(16);
    doc.text(reportTitle, pageWidth / 2, 15, { align: 'center' });
  }

  const currentDate = new Date().toLocaleDateString('ar-SA');
  doc.setFontSize(10);
  doc.text(`تاريخ التصدير: ${currentDate}`, pageWidth - 15, 10, { align: 'right' });
  
  // أضف الصورة إلى الصفحة الأولى
  doc.addImage(
    canvas.toDataURL('image/jpeg', 0.7),
    'JPEG',
    10,
    20,
    imgWidth,
    imgHeight > pageHeight - 20 ? pageHeight - 20 : imgHeight
  );
  
  heightLeft -= (pageHeight - 20);
  position = -(pageHeight - 20);
  
  // إضافة باقي الصفحات إذا لزم الأمر
  while (heightLeft > 0) {
    doc.addPage();
    pageNumber++;
    position -= (pageHeight - 20);
    
    doc.addImage(
      canvas.toDataURL('image/jpeg', 0.7),
      'JPEG',
      10,
      position,
      imgWidth,
      imgHeight
    );
    
    heightLeft -= (pageHeight - 20);
  }
  
  // إضافة أرقام الصفحات
  for (let i = 1; i <= pagesCount; i++) {
    doc.setPage(i);
    doc.setFontSize(10);
    doc.text(`صفحة ${i} من ${pagesCount}`, pageWidth / 2, pageHeight - 10, {
      align: 'center'
    });
  }

  // حفظ الملف
  doc.save(`${fileName}.pdf`);
};