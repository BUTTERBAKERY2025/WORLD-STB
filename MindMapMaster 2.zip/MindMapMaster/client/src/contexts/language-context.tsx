import { createContext, useContext } from "react";

export type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
}

export const LanguageContext = createContext<LanguageContextType>({
  language: "ar",
  setLanguage: () => {},
});

export const useLanguage = () => useContext(LanguageContext);
