import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number, precision: number = 2): string {
  // Always use latin (English) numerals even for Arabic locale
  return new Intl.NumberFormat('en-US', {
    style: 'decimal',
    minimumFractionDigits: 0,
    maximumFractionDigits: precision,
  }).format(amount);
}

export function formatCurrencyWithSymbol(amount: number): string {
  // Always use latin (English) numerals
  const formattedAmount = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
  
  // We return just the formatted number - the SAR symbol will be added by the component
  return formattedAmount;
}

// For compatibility, if code is using the old format with text "SAR"
export function formatCurrencyWithTextSymbol(amount: number): string {
  return `${formatCurrency(amount)} SAR`;
}

export function formatPercentage(value: number): string {
  // Always use latin (English) numerals
  return new Intl.NumberFormat('en-US', {
    style: 'percent',
    minimumFractionDigits: 0,
    maximumFractionDigits: 1,
  }).format(value / 100);
}

export function formatDate(date: Date | string): string {
  if (!date) return '';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  // Use english format with latin numbers
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(dateObj);
}

export function getInitials(name: string): string {
  if (!name) return '';
  
  const parts = name.split(' ');
  if (parts.length === 1) return parts[0].charAt(0);
  
  return parts[0].charAt(0) + parts[parts.length - 1].charAt(0);
}

export function formatNumber(num: number, precision: number = 0): string {
  // Always use latin (English) numerals
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: precision
  }).format(num);
}

export function getBadgeColorByStatus(status: string): { bg: string, text: string } {
  switch (status) {
    case 'in_progress':
      return { bg: 'bg-green-100', text: 'text-green-700' };
    case 'delayed':
      return { bg: 'bg-yellow-100', text: 'text-yellow-700' };
    case 'completed':
      return { bg: 'bg-blue-100', text: 'text-blue-700' };
    case 'planning':
      return { bg: 'bg-purple-100', text: 'text-purple-700' };
    case 'stopped':
      return { bg: 'bg-red-100', text: 'text-red-700' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-700' };
  }
}

export function getBadgeColorByType(type: string): { bg: string, text: string } {
  switch (type) {
    case 'road':
      return { bg: 'bg-blue-100', text: 'text-blue-700' };
    case 'water':
      return { bg: 'bg-cyan-100', text: 'text-cyan-700' };
    case 'electricity':
      return { bg: 'bg-yellow-100', text: 'text-yellow-700' };
    case 'telecom':
      return { bg: 'bg-purple-100', text: 'text-purple-700' };
    case 'building':
      return { bg: 'bg-indigo-100', text: 'text-indigo-700' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-700' };
  }
}

export function getProgressColorByValue(progress: number): string {
  if (progress >= 75) return 'bg-green-500';
  if (progress >= 50) return 'bg-yellow-500';
  return 'bg-red-500';
}

export function getProjectIconByType(type: string): string {
  switch (type) {
    case 'road':
      return 'add_road';
    case 'water':
      return 'water_drop';
    case 'electricity':
      return 'bolt';
    case 'telecom':
      return 'cell_tower';
    case 'building':
      return 'apartment';
    default:
      return 'engineering';
  }
}

export function getIconBgByType(type: string): string {
  switch (type) {
    case 'road':
      return 'bg-primary';
    case 'water':
      return 'bg-blue-500';
    case 'electricity':
      return 'bg-yellow-500';
    case 'telecom':
      return 'bg-purple-500';
    case 'building':
      return 'bg-indigo-500';
    default:
      return 'bg-gray-500';
  }
}
