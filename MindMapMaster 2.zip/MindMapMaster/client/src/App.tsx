import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Projects from "@/pages/projects/index";
import NewProject from "@/pages/projects/new";
import ProjectDetails from "@/pages/projects/[id]";
import EditProject from "@/pages/projects/[id].edit";
import Financial from "@/pages/financial/index";
import FinancialTransactions from "@/pages/financial/transactions-v2";
import FinancialAccounts from "@/pages/financial/accounts";
import FinancialBudgets from "@/pages/financial/budgets";
import FinancialBudgetsNew from "@/pages/financial/budgets_new";
import Certificates from "@/pages/financial/certificates/index";
import CertificateDetails from "@/pages/financial/certificates/[id]";
import NewCertificate from "@/pages/financial/certificates/new";
import EditCertificate from "@/pages/financial/certificates/[id].edit";
import JournalEntries from "@/pages/financial/journal-entries/index";
import NewJournalEntry from "@/pages/financial/journal-entries/new";
import RecurringJournalEntries from "@/pages/financial/journal-entries/recurring";
import NewRecurringJournalEntry from "@/pages/financial/journal-entries/recurring/new";
import EditRecurringJournalEntry from "@/pages/financial/journal-entries/recurring/edit/index";
import AccountStatement from "@/pages/financial/account-statement";
import FinancialReports from "@/pages/financial/reports";
import TrialBalance from "@/pages/financial/trial-balance";
import BalanceSheet from "@/pages/financial/balance-sheet";
import IncomeStatement from "@/pages/financial/income-statement";
import ProjectFinancialReports from "@/pages/projects/[id]/financial-reports";
import ProjectsReports from "@/pages/projects/reports";
import Assets from "@/pages/assets/index";
import Maps from "@/pages/maps/index";
import Reports from "@/pages/reports/index";
import Documents from "@/pages/documents/index";
import Settings from "@/pages/settings/index";
import { AppShell } from "@/components/layout/app-shell";
import { useLanguage } from "@/contexts/language-context";
import ProjectsDashboard from "@/pages/projects/dashboard";
// Fix imports by using relative paths
import AllProjects from "./pages/projects/list";
import ProjectTypes from "./pages/projects/types-new";
import ProjectTypesRedesigned from "./pages/projects/types-redesigned";

function Router() {
  return (
    <Switch>
      <Route path="/projects/dashboard" component={ProjectsDashboard} />
      <Route path="/projects/list" component={AllProjects} />
      <Route path="/projects/types-redesigned" component={ProjectTypesRedesigned} />
      <Route path="/projects/types" component={ProjectTypes} />
      <Route path="/projects/reports" component={ProjectsReports} />
      <Route path="/projects/new" component={NewProject} />
      <Route path="/projects/:id/edit" component={EditProject} />
      <Route path="/projects/:id" component={ProjectDetails} />
      <Route path="/projects" component={Projects} />
      <Route path="/" component={Dashboard} />
      <Route path="/financial/certificates/new" component={NewCertificate} />
      <Route path="/financial/certificates/:id/edit" component={EditCertificate} />
      <Route path="/financial/certificates/:id" component={CertificateDetails} />
      <Route path="/financial/certificates" component={Certificates} />
      
      <Route path="/financial/journal-entries/recurring/new" component={NewRecurringJournalEntry} />
      <Route path="/financial/journal-entries/recurring/edit/:id" component={EditRecurringJournalEntry} />
      <Route path="/financial/journal-entries/recurring" component={RecurringJournalEntries} />
      <Route path="/financial/journal-entries/new" component={NewJournalEntry} />
      <Route path="/financial/journal-entries" component={JournalEntries} />
      
      <Route path="/financial/budgets-new" component={FinancialBudgetsNew} />
      <Route path="/financial/budgets" component={FinancialBudgets} />
      <Route path="/financial/transactions" component={FinancialTransactions} />
      <Route path="/financial/accounts" component={FinancialAccounts} />
      <Route path="/financial/account-statement" component={AccountStatement} />
      <Route path="/financial/reports" component={FinancialReports} />
      <Route path="/financial/trial-balance" component={TrialBalance} />
      <Route path="/financial/balance-sheet" component={BalanceSheet} />
      <Route path="/financial/income-statement" component={IncomeStatement} />
      <Route path="/financial" component={Financial} />
      
      <Route path="/projects/:id/financial-reports" component={ProjectFinancialReports} />
      <Route path="/assets" component={Assets} />
      <Route path="/maps" component={Maps} />
      <Route path="/reports" component={Reports} />
      <Route path="/documents" component={Documents} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const { language } = useLanguage();
  
  return (
    <QueryClientProvider client={queryClient}>
      <div dir={language === 'ar' ? 'rtl' : 'ltr'} lang={language} className="font-arabic">
        <AppShell>
          <Router />
        </AppShell>
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;
