import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import arTranslation from './locales/ar.json';
import enTranslation from './locales/en.json';

// Create type-safe namespaces
declare module 'i18next' {
  interface CustomTypeOptions {
    defaultNS: 'translation';
    resources: {
      translation: typeof arTranslation;
    };
    returnNull: false;
    allowObjectInHTMLChildren: true;
  }
}

// Extend the TFunction to accept any string key
declare module 'react-i18next' {
  interface TFunction {
    (key: string, options?: any): string;
  }
}

// بناء i18n بطريقة مختلفة تماماً
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    // هنا نفعل وضع التصحيح لمراقبة المشاكل
    debug: true, 
    fallbackLng: 'ar',
    lng: 'ar', // تعيين اللغة العربية كلغة افتراضية
    
    ns: ['translation'], // مساحة الاسم الافتراضية
    defaultNS: 'translation',
    
    resources: {
      ar: {
        translation: arTranslation
      },
      en: {
        translation: enTranslation
      }
    },
    
    // اعدادات متقدمة
    interpolation: {
      escapeValue: false, // عدم هروب من العلامات HTML
    },
    
    // استخدام النقطة كفاصل للمفاتيح المتداخلة
    keySeparator: '.',
    
    // التعامل مع المفاتيح المفقودة
    saveMissing: true,
    missingKeyHandler: (lng, ns, key) => {
      console.warn(`مفتاح الترجمة مفقود: ${key}`);
      return key;
    }
  });

// للاستخدام في ديباج التطبيق
console.log('تم تهيئة i18n بنجاح');

export default i18n;
